from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import difflib,json,subprocess
repo=Path('/dev/shm/game-cores-G03-followup-20261009');job=repo/'jobs/G03-pack-the-hold';base=Path(__file__).resolve().parent;head='a049d0cef09f0ba38f099d5927ebbf85f6a6480e';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
old=(job/'scripts/visual.mjs').read_text();new=old.replace("import { awaitFrameGrant, closeFrameWindow } from './frame-coordination.mjs';","import { awaitFrameGrant, closeFrameWindow, awaitCaptureEncoderGrant, closeCaptureEncoderWindow } from './frame-coordination.mjs';")
new=new.replace('let localServer;\ntry {','let localServer;\nlet uiChecksComplete = false;\nlet encoderWindow = null;\nconst frameDir = resolve(\'.tmp/capture\');\ntry {')
new=new.replace("const frameDir = resolve('.tmp/capture'); mkdirSync(frameDir, { recursive: true });","mkdirSync(frameDir, { recursive: true });")
encode="  execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-framerate', '10', '-i', `${frameDir}/%03d.png`, '-c:v', 'libvpx-vp9', '-crf', '38', '-b:v', '0', '-an', `${output}/${videoFile}`]);"
assert new.count(encode)==1;new=new.replace(encode+'\n  assert.ok(readFileSync(`${output}/${videoFile}`).length < 10_000_000);\n','')
new=new.replace('  const video = readFileSync(`${output}/${videoFile}`);\n','')
video_fields="videoFile, videoBytes: video.length, videoSha256: createHash('sha256').update(video).digest('hex'), encodedVideoFps: 10, videoScope: '36 separately captured real UI images; encoded10fps is not rendering acceptance'"
assert new.count(', '+video_fields)==1;new=new.replace(', '+video_fields,'')
assert new.count("  report.status = 'passed';")==1;new=new.replace("  report.status = 'passed';","  uiChecksComplete = true;")
old_final="""  await browserClosed;
  report.finishedAtUtc = new Date().toISOString(); report.sourceHashesEnd = sourceHashes();
  if (JSON.stringify(report.sourceHashesEnd) !== JSON.stringify(sourceHashesStart)) { report.status = 'failed'; report.failure = 'source changed during browser run'; process.exitCode = 1; }
  saveReport(); console.log(JSON.stringify(report));
"""
new_final="""  try {
    await browserClosed;
    if (uiChecksComplete) {
      encoderWindow = await awaitCaptureEncoderGrant(sourceHashesStart['play.html'], browser.pid);
"""+encode+"""
      const video = readFileSync(`${output}/${videoFile}`);
      assert.ok(video.length < 10_000_000);
      Object.assign(report, { """+video_fields+""" });
      report.status = 'passed';
      closeCaptureEncoderWindow(encoderWindow, { status: 'closed', videoBytes: video.length }); encoderWindow = null;
    }
  } catch (error) {
    report.status = 'failed'; report.failure = String(error); throw error;
  } finally {
    closeCaptureEncoderWindow(encoderWindow, { status: 'failed', reason: 'runner closing' });
    report.finishedAtUtc = new Date().toISOString(); report.sourceHashesEnd = sourceHashes();
    if (JSON.stringify(report.sourceHashesEnd) !== JSON.stringify(sourceHashesStart)) { report.status = 'failed'; report.failure = 'source changed during browser run'; process.exitCode = 1; }
    saveReport(); console.log(JSON.stringify(report));
  }
"""
assert new.count(old_final)==1;new=new.replace(old_final,new_final)
# Every native measurement byte and every real capture/event byte stays identical.
old_measure=old[old.index('  async function measure'):old.index('  await evaluate(\'document.querySelector("[data-select]").click()\');',old.index('  async function measure'))]
new_measure=new[new.index('  async function measure'):new.index('  await evaluate(\'document.querySelector("[data-select]").click()\');',new.index('  async function measure'))];assert old_measure==new_measure
assert old[old.index('  for (let frame = 0; frame < 36; frame++)'):old.index(encode)]==new[new.index('  for (let frame = 0; frame < 36; frame++)'):new.index("  await evaluate('document.getElementById(\"submit\").click()');")]
(base/'visual.mjs').write_text(new);(base/'visual.mjs.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original/scripts/visual.mjs',tofile='proposed/scripts/visual.mjs')))
helper=(job/'scripts/frame-coordination.mjs').read_text();addition="""
// Optional ownership witness for capture encoding, separate from native frame grants.
export async function awaitCaptureEncoderGrant(sourceSha256, browserPid, { timeoutMs = 10_000 } = {}) {
  const configured = process.env.G03_CAPTURE_ENCODER_BARRIER_DIR;
  if (!configured) return null;
  assert.match(sourceSha256, /^[a-f0-9]{64}$/);
  assert.ok(Number.isSafeInteger(browserPid) && browserPid > 0);
  assert.ok(Number.isFinite(timeoutMs) && timeoutMs > 0);
  const directory = resolve(configured); mkdirSync(directory, { recursive: true });
  const base = resolve(directory, 'encoder');
  for (const suffix of ['ready.json', 'grant.json', 'closed.json']) assert.ok(!existsSync(`${base}-${suffix}`), 'encoder witness must use an unused directory');
  const identity = { sourceSha256, browserPid, attemptNonce: randomUUID() };
  atomic(`${base}-ready.json`, { ...identity, utc: new Date().toISOString(), browserClosed: true, sourceFrameCount: 36, width: 1280, height: 900, encodedFps: 10, noNativeFrameWindow: true });
  console.log(JSON.stringify({ captureEncoder: 'READY', ...identity }));
  const began = performance.now();
  while (performance.now() - began < timeoutMs) {
    const path = `${base}-grant.json`;
    if (existsSync(path)) {
      let grant; try { grant = JSON.parse(readFileSync(path, 'utf8')); } catch { grant = null; }
      if (grant && typeof grant === 'object' && !Array.isArray(grant) &&
          Object.keys(grant).sort().join(',') === 'attemptNonce,browserPid,sourceSha256' &&
          Object.keys(identity).every(key => grant[key] === identity[key])) return { ...identity, base };
    }
    await new Promise(resolve => setTimeout(resolve, 25));
  }
  closeCaptureEncoderWindow({ ...identity, base }, { status: 'failed', reason: 'matching closed-browser encoder grant timed out' });
  throw new Error('G03 closed-browser encoder grant timed out');
}
export function closeCaptureEncoderWindow(window, result) {
  if (!window) return;
  const { base, ...identity } = window;
  atomic(`${base}-closed.json`, { ...identity, ...result, utc: new Date().toISOString() });
  console.log(JSON.stringify({ captureEncoder: 'CLOSED', ...identity, ...result }));
}
"""
new_helper=helper+addition;assert new_helper.startswith(helper);(base/'frame-coordination.mjs').write_text(new_helper);(base/'frame-coordination.mjs.diff').write_text(''.join(difflib.unified_diff(helper.splitlines(True),new_helper.splitlines(True),fromfile='original/scripts/frame-coordination.mjs',tofile='proposed/scripts/frame-coordination.mjs')))
info={'status':'PRIVATE_UNADOPTED_NO_BROWSER_GRANT','createdAt':datetime.now(timezone.utc).isoformat(),'head':head,'oldVisualSHA256':sha256(old.encode()).hexdigest(),'candidateVisualSHA256':sha256(new.encode()).hexdigest(),'oldFrameCoordinatorSHA256':sha256(helper.encode()).hexdigest(),'candidateFrameCoordinatorSHA256':sha256(new_helper.encode()).hexdigest(),'nativeMeasureFunctionEveryByteUnchanged':True,'all36CaptureLoopEveryByteUnchanged':True,'originalFrameGrantEveryBytePrefixUnchanged':True,'originalEncoderFlagsDimensionsFramesEveryByteUnchanged':True,'originalSchemasValidatorsCaptureCorruptionsWorkflowAllUnchanged':True,'sourceStillCleanUnmodified':not subprocess.check_output(['git','status','--porcelain'],cwd=repo),'scope':'Proposed delivery scheduling fix: complete every original UI control first, close socket/browser/server and await actual browser close; optional nonce/actualPID/source bound owned-only-Node witness before original encoder; encode all36 original frames unchanged; mark passed onlyafter encoding/size and save actual failed errors/final guards unconditionally. Parent must review exact new controller and source before any browser. Current capture reference15 will become unused16 if adopted; oldfailed15 stays unchanged. Original file-open/native900both/gates remain byte unchanged.'}
(base/'proposal.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info))
