from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,os,subprocess,sys,uuid
BASE=Path(__file__).resolve().parent;AUTHOR=Path('/dev/shm/game-cores-G03-followup-20261009');JOB=Path('/dev/shm/G03-http-capture15-source-b014-20261009/jobs/G03-pack-the-hold');OUT=Path('/dev/shm/G03-saved36-deferred-encoding-20261009');HEAD='a049d0cef09f0ba38f099d5927ebbf85f6a6480e';saved_head='b0144146a81626c84660156126d9722e57bd3dab'
assert not (BASE/'ready.json').exists() and not OUT.exists();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=AUTHOR,text=True).strip()==HEAD
old=json.loads(Path('/dev/shm/G03-http-capture15-protocol-b014-20261009/freeze-spec.json').read_text());paths={label:Path(v['path']) for label,v in old['files'].items()};inventories=dict(old['inventories']);links={}
def row(p):
 p=p.absolute();s=p.stat();h=sha256()
 with p.open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return {'path':str(p),'resolved':str(p.resolve()),'bytes':s.st_size,'sha256':h.hexdigest(),'stat':[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]}
for raw in subprocess.check_output(['git','ls-files','-z','jobs/G03-pack-the-hold','contract','.github/workflows/G03.yml','README.md','RULES.md','JOBS.md'],cwd=AUTHOR).split(b'\0'):
 if raw:paths['fresh-authoritative/'+raw.decode()]=AUTHOR/raw.decode()
for root in [JOB/'.tmp/chrome',JOB/'.tmp/capture',Path('/dev/shm/G03-actual-http-capture15-b014-20261009')]:
 inventories[str(root)]=sorted(str(p) for p in root.rglob('*') if p.is_file())
 for name in inventories[str(root)]:paths['saved-original/'+name]=Path(name)
for root,inventory in list(inventories.items()):
 actual=sorted(str(p) for p in Path(root).rglob('*') if p.is_file());assert actual==inventory,'Original preserved/runtime inventory drifted before saved-only inquiry: '+root
 links[root]=[{'path':str(p),'target':os.readlink(p),'lstat':[p.lstat().st_dev,p.lstat().st_ino,p.lstat().st_mtime_ns,p.lstat().st_ctime_ns]} for p in sorted(Path(root).rglob('*')) if p.is_symlink()]
for name in ['milestone-15.webm','capture-15-report.json','packing-desktop-15.png']:paths['saved-media/'+name]=JOB/'media'/name
for name in ['controller.py','saved-components-and-encoder.py','prepare.py']:p=BASE/name;paths['saved-only-protocol/'+name]=p;compile(p.read_text(),str(p),'exec')
for p in [Path('/dev/shm/G03-normal-ancestry-repair-5e3-20261009/receipt.json'),Path('/dev/shm/G03-rest-dirty-no-workflow-before-ancestry-20261009.json')]:paths['history-proof/'+p.name]=p
spec={'createdAt':datetime.now(timezone.utc).isoformat(),'head':HEAD,'savedSourceHead':saved_head,'files':{k:row(p) for k,p in sorted(paths.items())},'inventories':inventories,'preservedOldProfileLinks':links};(BASE/'freeze-spec.json').write_text(json.dumps(spec,indent=2)+'\n');OUT.mkdir()
ready={'mode':'SAVED_ONLY_NO_BROWSER_NO_NATIVE_CLOCK','createdAt':datetime.now(timezone.utc).isoformat(),'head':HEAD,'savedSourceHead':saved_head,'nonce':'G03-saved36-deferred-encode-'+str(uuid.uuid4()),'job':str(JOB),'output':str(OUT),'node':'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node','chrome':'/usr/bin/chromium','savedArgv':[sys.executable,str(BASE/'saved-components-and-encoder.py'),str(OUT)],'freezeSpecSha256':row(BASE/'freeze-spec.json')['sha256'],'controllerSha256':row(BASE/'controller.py')['sha256'],'driverSha256':row(BASE/'saved-components-and-encoder.py')['sha256'],'wholeSeconds':240,'savedChildSeconds':180,'ownedRssBytes':512*1024**2,'sharedReserveBytes':256*1024**2,'newOutputReservationBytes':32*1024**2,'maxOrdinaryCleanCreditBytes':512*1024**2,'scope':'Finite saved-only full36 original1280x900 PNG EOF/CRC/inflate, original failed WebM content classification, independently same-original-flags VP9 encode after actual every old browser/encoder identity closed and whole36 native frame decode/equality where original complete. Current source/runtime/self/old failures/profile/policies guarded; no browser/new native frame clock/FPS, cap relaxation, current successful UI report, adoption or KEEP qualification.'};(BASE/'ready.json').write_text(json.dumps(ready,indent=2)+'\n')
print(json.dumps({'status':'READY_SAVED_ONLY_UNEXECUTED','head':HEAD,'readyPath':str(BASE/'ready.json'),'readySha256':row(BASE/'ready.json')['sha256'],'specSha256':ready['freezeSpecSha256'],'guardRows':len(spec['files']),'controllerSha256':ready['controllerSha256'],'driverSha256':ready['driverSha256'],'nonce':ready['nonce']}))
