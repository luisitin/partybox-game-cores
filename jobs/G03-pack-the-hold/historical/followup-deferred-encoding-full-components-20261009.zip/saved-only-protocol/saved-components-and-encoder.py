"""Read actual failed-capture components; encode identical saved frames after closure."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import binascii,json,struct,subprocess,sys,zlib
JOB=Path('/dev/shm/G03-http-capture15-source-b014-20261009/jobs/G03-pack-the-hold');OUT=Path(sys.argv[1]);utc=lambda:datetime.now(timezone.utc).isoformat()
def row(p):
 data=p.read_bytes();s=p.stat();return {'path':str(p),'bytes':len(data),'sha256':sha256(data).hexdigest(),'stat':[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]}
paths=sorted((JOB/'.tmp/capture').glob('*.png'));assert [p.name for p in paths]==[f'{i:03}.png' for i in range(36)]
old_video=JOB/'media/milestone-15.webm';report_path=JOB/'media/capture-15-report.json';desktop=JOB/'media/packing-desktop-15.png';inputs=paths+[old_video,report_path,desktop];before=[row(p) for p in inputs]
report=json.loads(report_path.read_text());assert report['status']=='running' and report['finishedAtUtc'] is None and report['desktop'] is None and report['phone'] is None and len(report['sourceHashesStart'])==28
failed=json.loads(Path('/dev/shm/G03-actual-http-capture15-b014-20261009/controller.json').read_text());assert failed['status']=='CLOSED_FAILED' and len(failed['controllerForcedSignals'])==9 and failed['finalOwnedDescendants']==[]
old_samples=json.loads(Path('/dev/shm/G03-actual-http-capture15-b014-20261009/rss-samples.json').read_text());identities={(p['pid'],p['startTicks']) for sample in old_samples['samples'] for p in sample['owned']}
closure=[]
for pid,start in sorted(identities):
 p=Path('/proc')/str(pid)/'stat'
 try:
  text=p.read_text();fields=text[text.rfind(')')+2:].split();actual_start=int(fields[19]);assert actual_start!=start,'Old browser/encoder descendant still exists'
  closure.append({'pid':pid,'originalStartTicks':start,'condition':'identity_reused','actualStartTicks':actual_start})
 except FileNotFoundError:closure.append({'pid':pid,'originalStartTicks':start,'condition':'absent'})
(OUT/'actual-old-browser-and-encoder-identities-closed.json').write_text(json.dumps({'at':utc(),'allOldOwnedProcessIdentitiesClosed':True,'identities':closure},indent=2)+'\n')
pngs=[]
for p in paths+[desktop]:
 data=p.read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n';cursor=8;chunks=[];idat=bytearray();ihdr=None
 while cursor<len(data):
  length=struct.unpack('>I',data[cursor:cursor+4])[0];kind=data[cursor+4:cursor+8];payload=data[cursor+8:cursor+8+length];assert len(payload)==length and cursor+12+length<=len(data)
  crc=struct.unpack('>I',data[cursor+8+length:cursor+12+length])[0];assert binascii.crc32(kind+payload)&0xffffffff==crc;chunks.append(kind.decode('ascii'))
  if kind==b'IHDR':assert ihdr is None;ihdr=struct.unpack('>IIBBBBB',payload)
  if kind==b'IDAT':idat.extend(payload)
  cursor+=length+12
  if kind==b'IEND':assert payload==b'' and cursor==len(data);break
 assert chunks[0]=='IHDR' and chunks[-1]=='IEND' and ihdr is not None
 width,height,depth,colour,compression,filtering,interlace=ihdr;assert (width,height,depth,compression,filtering,interlace)==(1280,900,8,0,0,0) and colour in (2,6)
 inflater=zlib.decompressobj();pixels=inflater.decompress(bytes(idat))+inflater.flush();assert inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail
 stride=width*(3 if colour==2 else 4)+1;assert len(pixels)==height*stride and all(pixels[y*stride] in range(5) for y in range(height))
 pngs.append({**row(p),'width':width,'height':height,'colour':colour,'allChunksCRC':True,'completeInflatedScanlineBytes':len(pixels),'wholeInflatedScanlineSHA256':sha256(pixels).hexdigest(),'noCropResizeResample':True})
(OUT/'whole37-png-eof-crc-inflate.json').write_text(json.dumps({'at':utc(),'all36OriginalFullFramesAndDesktopPNG':pngs},indent=2)+'\n')
print(json.dumps({'phase':'all37_complete_original_PNGs_and_old_process_closure','at':utc(),'sourceFrames':36,'originalWidth':1280,'originalHeight':900}),flush=True)
formats={'yuv420p':1728000,'yuv422p':2304000,'yuv444p':3456000,'gbrp':3456000,'yuva420p':2880000,'gbrap':4608000,'yuv420p10le':3456000,'yuv444p10le':6912000,'gbrp10le':6912000}
def inspect_video(p,label,strict):
 outcome={'path':str(p),'wholePhysical':row(p),'at':utc(),'contentQualifies':False}
 try:
  probe=subprocess.run(['/usr/bin/ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(p)],capture_output=True,timeout=25);(OUT/(label+'-ffprobe.stdout')).write_bytes(probe.stdout);(OUT/(label+'-ffprobe.stderr')).write_bytes(probe.stderr);outcome['probeExit']=probe.returncode
  assert probe.returncode==0 and not probe.stderr;meta=json.loads(probe.stdout);assert len(meta['streams'])==1;stream=meta['streams'][0]
  assert stream['codec_name']=='vp9' and stream['codec_type']=='video' and (stream['width'],stream['height'])==(1280,900)
  assert stream['nb_read_frames']=='36' and stream['r_frame_rate']=='10/1' and stream['avg_frame_rate']=='10/1';assert abs(float(meta['format']['duration'])-3.6)<1e-8 and int(meta['format']['size'])==p.stat().st_size<10_000_000
  decode=subprocess.run(['/usr/bin/ffmpeg','-v','error','-i',str(p),'-map','0:v:0','-f','framemd5','-'],capture_output=True,timeout=25);(OUT/(label+'-native-full-frame-md5.stdout')).write_bytes(decode.stdout);(OUT/(label+'-native-full-frame-md5.stderr')).write_bytes(decode.stderr);outcome['decodeExit']=decode.returncode
  assert decode.returncode==0 and not decode.stderr;text=decode.stdout.decode();assert '#dimensions 0: 1280x900' in text
  frames=[line for line in text.splitlines() if line and not line.startswith('#')];assert len(frames)==36;frame_bytes=formats[stream['pix_fmt']];parsed=[]
  for i,line in enumerate(frames):
   f=[x.strip() for x in line.split(',')];assert len(f)==6 and int(f[0])==0 and int(f[1])==i and int(f[2])==i and int(f[3])==1 and int(f[4])==frame_bytes and len(f[5])==32;parsed.append(f)
  outcome.update({'contentQualifies':True,'completeNativeFrames':36,'nativePixelFormat':stream['pix_fmt'],'nativeBytesPerFrame':frame_bytes,'allFrames':parsed,'encodedFps':10,'seconds':3.6,'noCropResizeResample':True})
 except BaseException as e:
  outcome.update({'errorType':type(e).__name__,'error':str(e)})
  (OUT/(label+'-whole-content-result.json')).write_text(json.dumps(outcome,indent=2)+'\n')
  if strict:raise
 (OUT/(label+'-whole-content-result.json')).write_text(json.dumps(outcome,indent=2)+'\n');return outcome
original=inspect_video(old_video,'actual-failed-protocol-raw-video',False)
print(json.dumps({'phase':'original_failed_video_components_read','at':utc(),'contentQualifies':original['contentQualifies'],'protocolAndFunctionalReportRemainFailed':True}),flush=True)
new_video=OUT/'saved36-original-flags-after-browser-closure.webm';assert not new_video.exists()
argv=['/usr/bin/ffmpeg','-y','-loglevel','error','-framerate','10','-i',str(JOB/'.tmp/capture/%03d.png'),'-c:v','libvpx-vp9','-crf','38','-b:v','0','-an',str(new_video)]
print(json.dumps({'phase':'encode_original36_after_all_old_identities_closed','at':utc()}),flush=True)
p=subprocess.run(argv,capture_output=True,timeout=120);(OUT/'same-original-encoding.stdout').write_bytes(p.stdout);(OUT/'same-original-encoding.stderr').write_bytes(p.stderr);assert p.returncode==0 and not p.stderr
new=inspect_video(new_video,'independent-deferred-saved-video',True)
if original['contentQualifies']:assert original['allFrames']==new['allFrames'],'Saved full native decoded frames differ despite identical source frames/encoder flags'
after=[row(p) for p in inputs];assert after==before
receipt={'status':'PASS','closedAt':utc(),'whole39OriginalPhysicalInputsBeforeAfterEqual':True,'inputCount':len(inputs),'inputs':before,'all37PNGsFullEOFCRCInflate':True,'all36Original1280x900FramesEncodedAfterEveryOldOwnedIdentityClosed':True,'oldOwnedIdentityCount':len(closure),'originalRawVideoContentQualifies':original['contentQualifies'],'originalProtocolAndRunningReportRemainUnqualified':True,'newVideo':new['wholePhysical'],'completeNativeFrames':36,'all36NativeDecodedFramesEqualOldWhenOldComplete':original['contentQualifies'],'exactOriginalEncoderArgvExceptUniqueOutput':argv,'originalEncodedFps':10,'originalSeconds':3.6,'noCropResizeResampleFilteringOrThreadCap':True,'scope':'Saved-only untimed delivery components and encoder scheduling feasibility. No browser launch, native RAF/frame-clock/performance acceptance, successful current UI report, KEEP/no-gain qualification, or product adoption.'}
(OUT/'saved-only-component-and-encoder-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='inputs'}),flush=True)
