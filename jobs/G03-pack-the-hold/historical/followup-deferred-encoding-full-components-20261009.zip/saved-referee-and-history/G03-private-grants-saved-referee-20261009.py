from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,re
BASE=Path('/dev/shm/G03-deferred-encoder-pure-syntax-grants-20261009');OUT=Path('/dev/shm/G03-private-grants-saved-referee-20261009.json');assert not OUT.exists()
receipt=BASE/'receipt.json';before_path=BASE/'before.json';after_path=BASE/'always-final-guards.json';stdout=BASE/'genuine-original-and-encoder-grants.stdout';failure=BASE/'failure.json'
proof_inputs=[receipt,before_path,after_path,stdout,failure,Path(__file__)];frozen={str(p):sha256(p.read_bytes()).hexdigest() for p in proof_inputs};r=json.loads(receipt.read_text());before=json.loads(before_path.read_text())['rows'];after=json.loads(after_path.read_text())
assert r['status']=='CLOSED_FAILED' and r['allPhysicalSourceRuntimeSelfGuardsUnchanged'] and r['guardRows']==len(before)==2491 and after['equalBefore'] and after['rows']==before
assert r['peakOwnedRssBytes']==106037248 and not r['signals'] and r['finalOwnedGroup']==[]
assert len(r['actualSteps'])==3 and all(s['actualExitCode']==0 and not s['finalOwnedGroup'] for s in r['actualSteps'])
for saved in before:
 p=Path(saved['path']);s=p.stat();h=sha256()
 with p.open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 assert saved=={'path':str(p),'bytes':s.st_size,'sha256':h.hexdigest(),'stat':[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]},'Actual physical guard no longer matches saved successful execution: '+str(p)
text=stdout.read_text();assert len([x for x in text.splitlines() if x.startswith('✔ ')])==4
for label,n in [('tests',4),('pass',4),('fail',0),('cancelled',0),('skipped',0),('todo',0)]:assert re.search(r'^ℹ '+label+r' '+str(n)+r'$',text,re.M)
objects=[json.loads(x) for x in text.splitlines() if x.startswith('{')];assert any(x.get('actualGrantCorruptionControls')==10 and x.get('sequentialAttempts')==2 for x in objects);assert any(x.get('actualEncoderGrantCorruptionControls')==9 and x.get('originalWitnessFilesPreserved') is True for x in objects)
assert "'# tests 4'" in json.loads(failure.read_text())['error']
assert frozen=={str(p):sha256(p.read_bytes()).hexdigest() for p in proof_inputs}
result={'status':'PASS_SAVED_OUTPUT_QUALIFICATION','closedAt':datetime.now(timezone.utc).isoformat(),'actualOriginalExecutionClosedAt':r['closedAt'],'allThreeActualChildrenExit0AndGroupsEmpty':True,'bothCandidateSyntaxChecksPass':True,'actualFourGenuineGrantTestsPassZeroFailures':True,'actualOriginalGrantCorruptions':10,'actualNewEncoderGrantCorruptions':9,'all2491SavedAndCurrentPhysicalGuardsEqual':True,'actualObservedPeakBytes':106037248,'actualForcedSignals':[],'originalControllerBroadFAILEDReceiptPreservedSHA256':frozen[str(receipt)],'observerFailureScope':'Required TAP-style literal # tests4 was absent; actual Node24 spec-style ℹ tests4/pass4/fail0 is preserved. This corrects only saved-output classification; no test rerun or timestamp/broad-flag rewrite.','inputHashes':frozen,'scope':'Untimed saved-only independent qualification of already successful syntax/nonce tests; no browser/native FPS/adoption/current clip/KEEP gain.'};OUT.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='inputHashes'}))
