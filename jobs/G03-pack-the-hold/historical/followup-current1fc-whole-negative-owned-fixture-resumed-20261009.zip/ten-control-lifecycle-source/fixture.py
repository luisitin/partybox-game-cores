from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import ctypes,importlib.util,json,os,signal,subprocess,sys,time,traceback
BASE=Path(__file__).resolve().parent;OUT=Path('/dev/shm/G03-actual-encoder-ownership-fixture-resumed-1600-20261009');OUT.mkdir(exist_ok=False);(OUT/'valid-boundary').mkdir();gate_path=Path('/dev/shm/G03-http-capture16-protocol-resumed-1600-20261009/owned-encoder-gate.py');spec=importlib.util.spec_from_file_location('actual_owned_encoder_gate',gate_path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0;start=datetime.now(timezone.utc).isoformat();clock=time.monotonic();page='928958719234ad28ae13326953953d350fac4c52233ed8b5dee67f94a7d2f697';gate=module.EncoderOwnershipGate(OUT/'valid-boundary',page,OUT/'actual-positive-owned-boundary.json');peak=0;rows=[];signals=[];status='CLOSED_FAILED';p=None;negative_controls=None
try:
 env=dict(os.environ,G03_CAPTURE_ENCODER_BARRIER_DIR=str(OUT/'valid-boundary'),PYTHONDONTWRITEBYTECODE='1');node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
 with (OUT/'fixture-driver.stdout').open('wb') as stdout,(OUT/'fixture-driver.stderr').open('wb') as stderr:
  p=subprocess.Popen([node,str(BASE/'driver.mjs')],env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  while True:
   table=module.processes();owned=module.owned_rows(os.getpid(),table);gate.observe(owned);rss=sum(x['rssBytes'] for x in owned);peak=max(peak,rss);rows.append({'at':module.utc(),'owned':owned,'rssBytes':rss});assert rss<=512*1024**2 and time.monotonic()-clock<=20
   ready=OUT/'valid-boundary/encoder-ready.json'
   if ready.exists() and negative_controls is None:
    request=json.loads(ready.read_text());assert len(owned)>1,'Live detached fixture child must still exist when browserClosed request arrives'
    corrupt=[]
    variants=[('wrong-page',dict(request,sourceSha256='b'*64)),('unknown-browser',dict(request,browserPid=2147483647)),('extra-field',dict(request,extra=True)),('malformed-nonce',dict(request,attemptNonce='stale')),('browser-not-closed',dict(request,browserClosed=False)),('wrong-frame-count',dict(request,sourceFrameCount=35)),('wrong-width',dict(request,width=640)),('wrong-height',dict(request,height=450)),('false-native-window',dict(request,noNativeFrameWindow=False)),('wrong-encoding-fps',dict(request,encodedFps=60))]
    for label,bad in variants:
     directory=OUT/label;directory.mkdir();(directory/'encoder-ready.json').write_text(json.dumps(bad)+'\n');negative=module.EncoderOwnershipGate(directory,page,OUT/(label+'-unwritten-proof.json'));negative.observed=dict(gate.observed);rejected=False
     try:negative.try_grant(p.pid)
     except (AssertionError,ValueError,KeyError,TypeError):rejected=True
     assert rejected and not (directory/'encoder-grant.json').exists() and not negative.granted;corrupt.append({'case':label,'actualRejectedBeforeGrant':True})
    negative_controls=corrupt;(OUT/'actual-negative-controls.json').write_text(json.dumps(corrupt,indent=2)+'\n')
   gate.try_grant(p.pid)
   code=p.poll()
   if code is not None:break
   time.sleep(.025)
  code=p.wait(timeout=2);assert code==0 and gate.granted
 assert negative_controls is not None and len(negative_controls)==10 and len(gate.deferrals)>0 and len(gate.reaped)>0
 proof=json.loads((OUT/'actual-positive-owned-boundary.json').read_text());assert proof['status']=='PASS_ACTUAL_OWNED_ONLY_NODE_BEFORE_ENCODER' and len(proof['actualOnlyNode'])==1 and proof['actualOnlyNode'][0]['pid']==p.pid
 assert any(r['actualOtherOwnedRows'] and any(row['pgid']!=p.pid for row in r['actualOtherOwnedRows']) for r in gate.deferrals),'Detached child was not genuinely tested'
 assert all(x['mainNodeExcluded'] and x['onlyExitedDirectOwnedChild'] for x in gate.reaped)
 table=module.processes();assert module.owned_rows(os.getpid(),table)==[],'Final genuine fixture descendant tree nonempty'
 marker=json.loads((OUT/'valid-boundary/fixture-after-grant-marker.json').read_text());assert marker['noChromiumNoFfmpegNoGameFrameClock'] is True
 status='CLOSED_PASS'
except BaseException as error:
 (OUT/'failure.json').write_text(json.dumps({'at':module.utc(),'error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 if p is not None and p.poll() is None:
  for row in module.owned_rows(os.getpid(),module.processes()):
   if row['state']!='Z':
    try:os.kill(row['pid'],signal.SIGTERM);signals.append({'pid':row['pid'],'startTicks':row['startTicks'],'signal':'SIGTERM'})
    except ProcessLookupError:pass
  p.wait(timeout=3)
 remaining=module.owned_rows(os.getpid(),module.processes())
 (OUT/'all-resource-process-samples.json').write_text(json.dumps(rows,indent=2)+'\n')
 receipt={'status':status,'startedAt':start,'closedAt':module.utc(),'actualMainNodeExit':p.returncode if p else None,'actualPeakFullOwnedDescendantRSSBytes':peak,'declaredOwnedRSSBytes':512*1024**2,'actualWholeSeconds':time.monotonic()-clock,'allTenOutsideGrantCorruptionsRejected':negative_controls is not None and len(negative_controls)==10,'actualLiveDetachedChildWithheldGrant':bool(gate.deferrals),'actualExitedAdoptedChildReapedWithoutMainNodeStatusConsumption':bool(gate.reaped),'allPreviousObservedPIDStartIdentitiesClosedBeforeGrant':gate.granted,'finalOwnedDescendants':remaining,'actualForcedSignals':signals,'scope':'Genuine isolated process-lifecycle fixture using Node subprocesses, including detached child. No Chromium/ffmpeg/browser/page/game execution, native RAF/performance comparison, current recording or KEEP qualification.'};(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
