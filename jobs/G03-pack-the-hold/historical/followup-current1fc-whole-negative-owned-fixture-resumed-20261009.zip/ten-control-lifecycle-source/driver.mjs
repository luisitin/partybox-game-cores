// Process-lifecycle fixture only: these Node children are not Chromium or ffmpeg.
import { spawn } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { awaitCaptureEncoderGrant, closeCaptureEncoderWindow } from '/dev/shm/G03-http-capture16-source-1fc-20261009/jobs/G03-pack-the-hold/scripts/frame-coordination.mjs';
const browser = spawn(process.execPath, ['-e', "const {spawn}=require('node:child_process'); const worker=spawn(process.execPath,['-e','setTimeout(()=>process.exit(0),3000)'],{detached:true,stdio:'ignore'}); worker.unref(); setTimeout(()=>process.exit(0),1500);"], { stdio: 'ignore' });
await new Promise((resolve, reject) => { browser.once('close', resolve); browser.once('error', reject); });
const window = await awaitCaptureEncoderGrant('928958719234ad28ae13326953953d350fac4c52233ed8b5dee67f94a7d2f697', browser.pid);
writeFileSync(join(process.env.G03_CAPTURE_ENCODER_BARRIER_DIR, 'fixture-after-grant-marker.json'), JSON.stringify({ phase: 'SIMULATED_ENCODER_ALLOWED', browserPid: browser.pid, noChromiumNoFfmpegNoGameFrameClock: true }));
closeCaptureEncoderWindow(window, { status: 'closed', simulatedLifecycleFixtureOnly: true });
