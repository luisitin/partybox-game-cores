from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import difflib, json, os, shutil, subprocess, traceback

SOURCE = Path('/dev/shm/game-cores-G03-followup-20261009')
OLD = Path('/dev/shm/G03-capture14-protocol-20261009')
BASE = Path('/dev/shm/G03-http-capture15-protocol-b014-20261009'); BASE.mkdir(exist_ok=False)
WORK = Path('/dev/shm/G03-http-capture15-source-b014-20261009')
HEAD = 'b0144146a81626c84660156126d9722e57bd3dab'
started = datetime.now(timezone.utc).isoformat(); status = 'FAILED'
def row(p):
    data = p.read_bytes(); s = p.stat(); return {'path': str(p), 'bytes': len(data), 'sha256': sha256(data).hexdigest(), 'stat': [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]}
try:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE)
    assert not os.getenv('CI'), 'Configured local environment must not masquerade as hosted CI'
    p = subprocess.run(['git', 'worktree', 'add', '--detach', str(WORK), HEAD], cwd=SOURCE, capture_output=True, timeout=60)
    (BASE / 'exact-worktree-create.stdout').write_bytes(p.stdout); (BASE / 'exact-worktree-create.stderr').write_bytes(p.stderr); assert p.returncode == 0
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip() == HEAD
    tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=SOURCE).split(b'\0')
    bridge = []
    for name in tracked:
        if name:
            relative = name.decode(); original = SOURCE / relative; copy = WORK / relative
            assert original.read_bytes() == copy.read_bytes(); bridge.append({'relative': relative, 'authoritative': row(original), 'isolated': row(copy), 'fullPhysicalBytesEqual': True})
    job = WORK / 'jobs/G03-pack-the-hold'; original_job = SOURCE / 'jobs/G03-pack-the-hold'
    (job / 'node_modules').symlink_to((original_job / 'node_modules').resolve(), target_is_directory=True)
    (WORK / 'contract/node_modules').symlink_to((SOURCE / 'contract/node_modules').resolve(), target_is_directory=True)
    shutil.copytree(original_job / '.build', job / '.build')
    compiled = []
    for original in sorted((original_job / '.build').rglob('*')):
        if original.is_file():
            copy = job / '.build' / original.relative_to(original_job / '.build'); assert original.read_bytes() == copy.read_bytes()
            compiled.append({'authoritative': row(original), 'isolated': row(copy), 'fullPhysicalBytesEqual': True})
    for name in ['controller.py', 'whole-capture-reader.py', 'prepare.py']:
        text = (OLD / name).read_text()
        changed = text.replace('/dev/shm/game-cores-G03-followup-20261009', str(WORK)).replace('b141979b40d2a9c72261c783deeccd5091a3e9d1', HEAD).replace('/dev/shm/G03-actual-capture14-b141-20261009', '/dev/shm/G03-actual-http-capture15-b014-20261009').replace('capture-14', 'capture-15').replace('milestone-14', 'milestone-15').replace('desktop-14', 'desktop-15').replace('capture14', 'HTTP-capture15').replace('capture-only14', 'HTTP-capture-only15')
        changed = changed.replace("'--capture-only', '--record', '--milestone', '14'", "'--capture-only', '--http', '--record', '--milestone', '15'")
        if name == 'controller.py':
            changed = changed.replace("REPO = JOB.parent.parent", "REPO = JOB.parent.parent\nAUTHORITATIVE = Path('/dev/shm/game-cores-G03-followup-20261009')")
            changed = changed.replace("def freeze():\n", "def freeze():\n    assert subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD'], cwd=AUTHORITATIVE, text=True).strip() == raw['head']\n")
            changed = changed.replace("assert child.wait(timeout=2) == 0, 'Actual required child failed: ' + name", "code = child.wait(timeout=2)")
            changed = changed.replace("    assert elapsed <= limit, 'Final natural child interval exceeded declared bound'\n    closure = close_owned(False)\n    steps.append({'name': name, 'argv': argv, 'startedAt': at, 'closedAt': utc(), 'actualExitCode': code, 'actualChildSeconds': elapsed, 'declaredChildSeconds': limit, 'closure': closure})", "    step = {'name': name, 'argv': argv, 'startedAt': at, 'childExitedAt': utc(), 'actualExitCode': code, 'actualChildSeconds': elapsed, 'declaredChildSeconds': limit, 'actualOwnedAtChildExit': descendants()}\n    steps.append(step)\n    assert code == 0, 'Actual required child failed: ' + name + '; actual exit=' + str(code)\n    assert elapsed <= limit, 'Final natural child interval exceeded declared bound'\n    closure = close_owned(False)\n    step.update({'closedAt': utc(), 'closure': closure})")
            changed = changed.replace("assert report['fileOpened'] and report['serving'] == 'disk'", "assert not report['fileOpened'] and report['serving'] == 'localhost HTTP; not disk-open proof'")
            changed = changed.replace("One exact original current-source HTTP-capture-only15", "One exact original current-source isolated localhost HTTP-capture-only15; not disk-open proof")
        if name == 'prepare.py':
            changed = changed.replace("HEAD = '" + HEAD + "'", "HEAD = '" + HEAD + "'\nAUTHORITATIVE = Path('/dev/shm/game-cores-G03-followup-20261009')\nassert not os.getenv('CI')")
            changed = changed.replace("for root in [(JOB / 'node_modules').resolve()", "for root in [(AUTHORITATIVE / 'jobs/G03-pack-the-hold/.tmp/chrome'), Path('/dev/shm/G03-actual-capture14-b141-20261009/runtime-tmp'), (AUTHORITATIVE / 'jobs/G03-pack-the-hold/.build'), (JOB / 'node_modules').resolve()")
            changed = changed.replace("if name: files['source/' + name.decode()] = REPO / name.decode()", "if name:\n        relative = name.decode(); files['source/' + relative] = REPO / relative; files['authoritative-source/' + relative] = AUTHORITATIVE / relative\n        assert (REPO / relative).read_bytes() == (AUTHORITATIVE / relative).read_bytes()")
            changed = changed.replace("spec = {'createdAt':", "for root in [AUTHORITATIVE / 'jobs/G03-pack-the-hold/.tmp/chrome', Path('/dev/shm/G03-actual-capture14-b141-20261009/runtime-tmp')]:\n    links = [{'path': str(p), 'target': os.readlink(p), 'lstat': [p.lstat().st_dev, p.lstat().st_ino, p.lstat().st_mtime_ns, p.lstat().st_ctime_ns]} for p in root.rglob('*') if p.is_symlink()]\n    saved = BASE / ('old-profile-links.json' if root.name == 'chrome' else 'old-runtime-links.json'); saved.write_text(json.dumps(links, indent=2) + '\\n'); files['preserved-old-profile-links/' + saved.name] = saved\n+spec = {'createdAt':")
            changed = changed.replace("'captureChildSeconds': 120", "'authoritativeRepo': str(AUTHORITATIVE), 'oldFailurePreserved': True, 'captureChildSeconds': 120")
            changed = changed.replace("Exactly one original capture-only15 on actual b141", "Exactly one original --http capture-only15 on isolated actual b014")
            changed = changed.replace("Exactly one original HTTP-capture-only15 on actual b141", "Exactly one original --http capture-only15 on isolated actual b014")
        (BASE / name).write_text(changed)
        (BASE / (name + '.derivation.diff')).write_text(''.join(difflib.unified_diff(text.splitlines(keepends=True), changed.splitlines(keepends=True), fromfile=str(OLD / name), tofile=str(BASE / name))))
        compile(changed, str(BASE / name), 'exec')
    for original in bridge: assert row(Path(original['authoritative']['path'])) == original['authoritative']
    for original in compiled: assert row(Path(original['authoritative']['path'])) == original['authoritative']
    (BASE / 'exact-source-copy-bridge.json').write_text(json.dumps({'startedAt': started, 'closedAt': datetime.now(timezone.utc).isoformat(), 'head': HEAD, 'allTrackedCopiedFiles': bridge, 'allCompiledCopiedFiles': compiled, 'originalPhysicalInputsStatAndHashUnchanged': True, 'originalFailedChromeProfileRetainedAt': str(original_job / '.tmp/chrome'), 'newWorktreeWasCreatedFromActualHead': True}, indent=2) + '\n')
    status = 'PASS'
except BaseException as error:
    (BASE / 'derivation-failure.json').write_text(json.dumps({'at': datetime.now(timezone.utc).isoformat(), 'error': str(error), 'traceback': traceback.format_exc(), 'scope': 'Protocol derivation/source-copy failure only, no browser launched.'}, indent=2) + '\n'); raise
finally:
    result = {'status': status, 'closedAt': datetime.now(timezone.utc).isoformat(), 'head': HEAD, 'isolatedSource': str(WORK), 'protocol': str(BASE), 'noBrowserOrFrameLaunch': True}
    (BASE / 'derivation.json').write_text(json.dumps(result, indent=2) + '\n'); print(json.dumps(result), flush=True)
