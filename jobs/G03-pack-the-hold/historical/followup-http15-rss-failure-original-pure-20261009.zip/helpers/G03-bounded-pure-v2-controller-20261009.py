from pathlib import Path
import json,os,sys,datetime,time,subprocess,hashlib,signal,ctypes,traceback,re,shutil
plan=Path(sys.argv[1]);spec=json.loads(plan.read_text());base=Path(spec['output']);base.mkdir(exist_ok=False)
repo=Path('/dev/shm/game-cores-G03-followup-20261009');job=repo/'jobs/G03-pack-the-hold'
t=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 st=p.stat();return {'path':str(p),'bytes':st.st_size,'sha256':h.hexdigest(),'stat':[st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns]}
mutableOutputs={repo/x for x in spec.get('mutableBuildOutputs',[])}
source=[repo/x.decode() for x in subprocess.check_output(['git','ls-files','-z','jobs/G03-pack-the-hold','contract','.github/workflows/G03.yml'],cwd=repo).split(b'\0') if x]
depRoots=[(job/'node_modules').resolve(),(repo/'contract/node_modules').resolve()]
dependencies=[p.resolve() for root in depRoots for p in root.rglob('*') if p.is_file()]
extra=[Path(__file__).resolve(),plan,Path(sys.executable).resolve(),Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')]+[Path(x) for x in spec.get('extraInputs',[])]
mutableBefore=[digest(p) for p in sorted(mutableOutputs)]
paths=list(dict.fromkeys([p for p in source if p not in mutableOutputs]+dependencies+extra));before=[digest(p) for p in paths];(base/'before.json').write_text(json.dumps({'at':t(),'rows':before},indent=2)+'\n')
def group(pid):
 rows=[]
 for entry in Path('/proc').iterdir():
  if not entry.name.isdigit():continue
  try:
   raw=(entry/'stat').read_text();tail=raw[raw.rfind(')')+2:].split()
   if int(tail[2])==pid:rows.append({'pid':int(entry.name),'rss':int(tail[21])*os.sysconf('SC_PAGE_SIZE'),'state':tail[0]})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return rows
status='CLOSED_FAILED';started=t();steps=[];samples=[];signals=[];peak=0;pid=None;clock=time.monotonic()
try:
 maximum=int(Path('/sys/fs/cgroup/memory.max').read_text());current=int(Path('/sys/fs/cgroup/memory.current').read_text())
 stat={k:int(v) for k,v in (line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())}
 clean=max(0,stat['active_file']+stat['inactive_file']-stat['file_dirty']-stat['file_writeback']);credit=min(512*1024*1024,clean);potential=maximum-current+credit;required=spec['ownedBytes']+spec['reserveBytes']
 resource={'at':t(),'maximum':maximum,'current':current,'ordinaryCleanLRU':clean,'cleanCredit':credit,'shmemNotCredited':stat['shmem'],'dirtyWritebackSlabExcluded':True,'potential':potential,'required':required,'ownedBytes':spec['ownedBytes'],'reserveBytes':spec['reserveBytes'],'wholeSeconds':spec['wholeSeconds'],'gatePassed':potential>=required,'noBrowserNativeTiming':True,'noCacheEvictionOrDrop':True}
 (base/'fresh-resource-gate.json').write_text(json.dumps(resource,indent=2)+'\n');assert potential>=required,'genuine fresh resource gate unavailable; no children launched'
 for phase in spec['steps']:
  start=t()
  env=dict(os.environ);env.update(phase.get('env',{}))
  with (base/(phase['name']+'.stdout')).open('wb') as out,(base/(phase['name']+'.stderr')).open('wb') as err:
   p=subprocess.Popen(phase['argv'],cwd=job,env=env,stdout=out,stderr=err,start_new_session=True);pid=p.pid
   while p.poll() is None:
    owned=group(pid);rss=sum(x['rss'] for x in owned);peak=max(peak,rss);samples.append({'at':t(),'phase':phase['name'],'owned':owned,'rss':rss})
    if rss>spec['ownedBytes'] or time.monotonic()-clock>spec['wholeSeconds']:
     signals.append({'at':t(),'signal':'SIGTERM','why':'declared resource/time bound'});os.killpg(pid,signal.SIGTERM);p.wait(timeout=5);break
    time.sleep(.025)
   rc=p.returncode
   for _ in range(80):
    for row in group(pid):
     try:os.waitpid(row['pid'],os.WNOHANG)
     except ChildProcessError:pass
    if not group(pid):break
    time.sleep(.025)
  steps.append({'name':phase['name'],'argv':phase['argv'],'startedAt':start,'closedAt':t(),'actualExitCode':rc,'expectedExitCode':phase.get('expectedExit',0),'finalOwnedGroup':group(pid)})
  assert rc==phase.get('expectedExit',0) and not group(pid) and not signals,(phase['name'],rc,group(pid))
  if 'requiredStdout' in phase:
   text=(base/(phase['name']+'.stdout')).read_text()
   for value in phase['requiredStdout']:assert value in text,(phase['name'],value)
 if spec.get('copyCompiledTo'):
  dest=Path(spec['copyCompiledTo']);shutil.copytree(job/'.build',dest);(dest/'node_modules').symlink_to((job/'node_modules').resolve(),target_is_directory=True)
 final=[digest(p) for p in paths];assert before==final,'Guarded source/runtime/self input changed during pipeline'
 status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':t(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 after=[digest(p) for p in paths];(base/'always-final-guards.json').write_text(json.dumps({'at':t(),'equalBefore':before==after,'rows':after},indent=2)+'\n')
 r={'status':status,'declaredMutableBuildOutputsBefore':mutableBefore,'declaredMutableBuildOutputsAfter':[digest(p) for p in sorted(mutableOutputs)],'startedAt':started,'closedAt':t(),'sourceHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip(),'guardRows':len(before),'allPhysicalSourceRuntimeSelfGuardsUnchanged':before==after,'peakOwnedRssBytes':peak,'actualSteps':steps,'naturalClosure':status=='CLOSED_PASS' and not signals,'finalOwnedGroup':group(pid) if pid else [],'signals':signals,'noBrowserNativeTiming':True,'qualifiedKeepRounds':0,'scope':spec['scope']}
 (base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');(base/'resource-process.json').write_text(json.dumps(samples,indent=2)+'\n');print(json.dumps(r),flush=True)

