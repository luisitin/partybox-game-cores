from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, os, subprocess, sys, uuid

BASE = Path(__file__).resolve().parent
REPO = Path('/dev/shm/G03-http-capture15-source-b014-20261009'); JOB = REPO / 'jobs/G03-pack-the-hold'
HEAD = 'b0144146a81626c84660156126d9722e57bd3dab'
AUTHORITATIVE = Path('/dev/shm/game-cores-G03-followup-20261009')
assert not os.getenv('CI')
NODE = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')
OUT = Path('/dev/shm/G03-actual-http-capture15-b014-20261009')
assert not (BASE / 'ready.json').exists() and not OUT.exists()
assert subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
assert not subprocess.check_output(['/usr/bin/git', 'status', '--porcelain'], cwd=REPO)
def row(path):
    path = path.absolute(); s = path.stat(); h = sha256()
    with path.open('rb') as source:
        while block := source.read(1 << 20): h.update(block)
    return {'path': str(path), 'resolved': str(path.resolve()), 'bytes': s.st_size, 'sha256': h.hexdigest(), 'stat': [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]}
files = {}; inventories = {}
tracked = subprocess.check_output(['/usr/bin/git', 'ls-files', '-z', 'jobs/G03-pack-the-hold', 'contract', '.github/workflows/G03.yml', 'README.md', 'RULES.md', 'JOBS.md'], cwd=REPO).split(b'\0')
for name in tracked:
    if name:
        relative = name.decode(); files['source/' + relative] = REPO / relative; files['authoritative-source/' + relative] = AUTHORITATIVE / relative
        assert (REPO / relative).read_bytes() == (AUTHORITATIVE / relative).read_bytes()
for root in [(AUTHORITATIVE / 'jobs/G03-pack-the-hold/.tmp/chrome'), Path('/dev/shm/G03-actual-capture14-b141-20261009/runtime-tmp'), (AUTHORITATIVE / 'jobs/G03-pack-the-hold/.build'), Path('/etc/chromium'), (JOB / 'node_modules').resolve(), (REPO / 'contract/node_modules').resolve(), JOB / '.build', Path('/usr/lib/chromium')]:
    assert root.is_dir()
    inventory = sorted(str(p) for p in root.rglob('*') if p.is_file())
    assert inventory or root == Path('/dev/shm/G03-actual-capture14-b141-20261009/runtime-tmp')
    inventories[str(root)] = inventory
    for name in inventory: files['installed/' + name] = Path(name)
for name in ['controller.py', 'whole-capture-reader.py', 'prepare.py']: files['protocol/' + name] = BASE / name
for path in [NODE, Path(sys.executable).resolve(), Path('/usr/bin/chromium'), Path('/usr/bin/ffmpeg'), Path('/usr/bin/ffprobe')]:
    files['binary/' + str(path)] = path
    if path.read_bytes()[:4] == b'\x7fELF':
        library_lines = subprocess.check_output(['/usr/bin/ldd', str(path)], text=True).splitlines()
        for line in library_lines:
            for word in line.strip().split():
                if word.startswith('/') and Path(word).is_file(): files['native-library/' + word] = Path(word)
for path in [Path('/usr/lib/chromium/chromium')]:
    for line in subprocess.check_output(['/usr/bin/ldd', str(path)], text=True).splitlines():
        for word in line.strip().split():
            if word.startswith('/') and Path(word).is_file(): files['native-library/' + word] = Path(word)
for name in ['json', 'hashlib', 'binascii', 'struct', 'subprocess', 'zlib', 'ctypes', 'traceback', 'signal', 'datetime', 'uuid']:
    module = __import__(name)
    if getattr(module, '__file__', None): files['python-module/' + name] = Path(module.__file__)
profile_links = {}
for root in [AUTHORITATIVE / 'jobs/G03-pack-the-hold/.tmp/chrome', Path('/dev/shm/G03-actual-capture14-b141-20261009/runtime-tmp')]:
    links = [{'path': str(p), 'target': os.readlink(p), 'lstat': [p.lstat().st_dev, p.lstat().st_ino, p.lstat().st_mtime_ns, p.lstat().st_ctime_ns]} for p in sorted(root.rglob('*')) if p.is_symlink()]
    profile_links[str(root)] = links
    saved = BASE / ('old-profile-links.json' if root.name == 'chrome' else 'old-runtime-links.json'); saved.write_text(json.dumps(links, indent=2) + '\n'); files['preserved-old-profile-links/' + saved.name] = saved
spec = {'createdAt': datetime.now(timezone.utc).isoformat(), 'head': HEAD, 'files': {label: row(p) for label, p in sorted(files.items())}, 'inventories': inventories, 'preservedOldProfileLinks': profile_links}
(BASE / 'freeze-spec.json').write_text(json.dumps(spec, indent=2) + '\n')
OUT.mkdir()
ready = {'status': 'READY_UNEXECUTED_REQUIRES_EXACT_ROOT_GRANT', 'createdAt': datetime.now(timezone.utc).isoformat(), 'nonce': 'G03-current-HTTP-capture15-' + str(uuid.uuid4()), 'head': HEAD, 'job': str(JOB), 'output': str(OUT), 'node': str(NODE), 'chrome': '/usr/bin/chromium', 'captureArgv': [str(NODE), 'scripts/visual.mjs', '--capture-only', '--http', '--record', '--milestone', '15'], 'freezeSpecSha256': row(BASE / 'freeze-spec.json')['sha256'], 'controllerSha256': row(BASE / 'controller.py')['sha256'], 'independentReaderSha256': row(BASE / 'whole-capture-reader.py')['sha256'], 'authoritativeRepo': str(AUTHORITATIVE), 'oldFailurePreserved': True, 'captureChildSeconds': 120, 'wholeSeconds': 240, 'ownedRssBytes': 1024**3, 'sharedReserveBytes': 512 * 1024**2, 'newOutputReservationBytes': 128 * 1024**2, 'maxOrdinaryCleanCreditBytes': 1536 * 1024**2, 'scope': 'Exactly one original --http capture-only15 on isolated actual b014, all36 full original PNGs/whole WebM/full original controls and28 source guards. No measure/RAF window/900-interval sampling, no local FPS retry, no old capture13/current full or KEEP qualification borrowed. Supported --http transport flag, unused15 milestone and separate physical source paths are explicit. TMPDIR relocates temporary storage into unique owned /dev/shm output; original source, gates, codec, all36 frames, dimensions, clock and UI workload unchanged. HTTP is not disk-open proof.'}
(BASE / 'ready.json').write_text(json.dumps(ready, indent=2) + '\n')
root = Path('/sys/fs/cgroup'); stats = {k: int(v) for k, v in (x.split() for x in (root / 'memory.stat').read_text().splitlines())}; current = int((root / 'memory.current').read_text()); maximum = int((root / 'memory.max').read_text()); clean = max(0, stats['active_file'] + stats['inactive_file'] - stats['file_dirty'] - stats['file_writeback']); credit = min(clean, ready['maxOrdinaryCleanCreditBytes']); disk = os.statvfs(OUT)
resources = {'at': datetime.now(timezone.utc).isoformat(), 'current': current, 'maximum': maximum, 'ordinaryClean': clean, 'boundedCredit': credit, 'shmemExcluded': stats['shmem'], 'potentialCapacityBytes': maximum - current + credit, 'requiredCapacityBytes': ready['ownedRssBytes'] + ready['sharedReserveBytes'] + ready['newOutputReservationBytes'], 'diskFree': disk.f_bavail * disk.f_frsize, 'dirtyWritebackSlabExcluded': True, 'noCacheEvictionDropOrColdCacheClaim': True}
(BASE / 'prospective-resources.json').write_text(json.dumps(resources, indent=2) + '\n')
for path in [BASE / 'controller.py', BASE / 'whole-capture-reader.py', BASE / 'prepare.py']: compile(path.read_text(), str(path), 'exec')
print(json.dumps({'head': HEAD, 'nonce': ready['nonce'], 'readyPath': str(BASE / 'ready.json'), 'readySha256': row(BASE / 'ready.json')['sha256'], 'controllerSha256': ready['controllerSha256'], 'independentReaderSha256': ready['independentReaderSha256'], 'specSha256': ready['freezeSpecSha256'], 'guardRows': len(spec['files']), 'resourceSnapshot': resources, 'status': 'UNEXECUTED'}))
