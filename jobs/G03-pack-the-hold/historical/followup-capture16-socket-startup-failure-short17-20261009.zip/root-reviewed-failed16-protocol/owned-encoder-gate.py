"""An outside subreaper proves every owned browser identity closed before encoding."""
from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,os,uuid

def utc():return datetime.now(timezone.utc).isoformat()
def processes():
 result={}
 for path in Path('/proc').glob('[0-9]*/stat'):
  try:
   text=path.read_text();fields=text[text.rfind(')')+2:].split();pid=int(path.parent.name)
   result[pid]={'pid':pid,'ppid':int(fields[1]),'pgid':int(fields[2]),'state':fields[0],'startTicks':int(fields[19]),'rssBytes':int(fields[21])*os.sysconf('SC_PAGE_SIZE')}
  except (OSError,ValueError,IndexError):pass
 return result

def owned_rows(owner,table):
 owned={owner};changed=True
 while changed:
  size=len(owned);owned.update(pid for pid,row in table.items() if row['ppid'] in owned);changed=len(owned)!=size
 return [table[pid] for pid in sorted(owned-{owner}) if pid in table]

class EncoderOwnershipGate:
 def __init__(self,directory,page_sha,output):
  self.directory=Path(directory);self.page_sha=page_sha;self.output=Path(output);self.observed={};self.reaped=[];self.deferrals=[];self.request_hash=None;self.granted=False
 def observe(self,rows):
  for row in rows:
   key=(row['pid'],row['startTicks'])
   if key not in self.observed:self.observed[key]={'firstObservedAt':utc(),'initialPPID':row['ppid'],'initial':dict(row)}
   self.observed[key].update({'lastObservedAt':utc(),'last':dict(row)})
 def try_grant(self,main_node_pid):
  if self.granted:return
  path=self.directory/'encoder-ready.json'
  if not path.exists():return
  data=path.read_bytes();req=json.loads(data);assert type(req) is dict
  assert set(req)=={'sourceSha256','browserPid','attemptNonce','utc','browserClosed','sourceFrameCount','width','height','encodedFps','noNativeFrameWindow'}
  assert req['sourceSha256']==self.page_sha and type(req['browserPid']) is int and req['browserPid']>0 and str(uuid.UUID(req['attemptNonce']))==req['attemptNonce']
  assert req['browserClosed'] is True and req['noNativeFrameWindow'] is True and req['sourceFrameCount']==36 and req['width']==1280 and req['height']==900 and req['encodedFps']==10
  timestamp=datetime.fromisoformat(req['utc'].replace('Z','+00:00'));assert timestamp.tzinfo is not None
  digest=sha256(data).hexdigest()
  if self.request_hash is None:self.request_hash=digest
  assert self.request_hash==digest,'Immutable encoder request bytes drifted'
  browser_ids=[key for key,value in self.observed.items() if key[0]==req['browserPid'] and value['initialPPID']==main_node_pid];assert len(browser_ids)==1,'Request browser PID was not observed as this actual Node child'
  table=processes();self.observe(owned_rows(os.getpid(),table))
  # Reap only exited direct adopted children. Never consume Popen's main Node status.
  for row in owned_rows(os.getpid(),table):
   if row['pid']==main_node_pid or row['ppid']!=os.getpid() or row['state']!='Z':continue
   current=processes().get(row['pid'])
   if current is None or current['ppid']!=os.getpid() or current['state']!='Z' or current['startTicks']!=row['startTicks']:continue
   try:
    pid,status=os.waitpid(row['pid'],os.WNOHANG)
    if pid:self.reaped.append({'at':utc(),'pid':pid,'startTicks':row['startTicks'],'waitStatus':status,'onlyExitedDirectOwnedChild':True,'mainNodeExcluded':True})
   except ChildProcessError:pass
  table=processes();owned=owned_rows(os.getpid(),table);self.observe(owned)
  others=[row for row in owned if row['pid']!=main_node_pid]
  if others:
   identity=[(r['pid'],r['startTicks'],r['state']) for r in others]
   if not self.deferrals or self.deferrals[-1]['identities']!=[list(x) for x in identity]:self.deferrals.append({'at':utc(),'identities':[list(x) for x in identity],'actualOtherOwnedRows':others,'grantWritten':False})
   return
  assert len(owned)==1 and owned[0]['pid']==main_node_pid and owned[0]['ppid']==os.getpid() and owned[0]['state']!='Z','Outside encoder barrier must contain exactly live main Node'
  closed=[]
  for (pid,start),saved in sorted(self.observed.items()):
   if pid==main_node_pid:continue
   actual=table.get(pid);assert actual is None or actual['startTicks']!=start,'Observed non-Node process identity remains live or unreaped'
   closed.append({'pid':pid,'startTicks':start,'initialPPID':saved['initialPPID'],'condition':'absent' if actual is None else 'identity_reused','actualNewStartTicks':actual['startTicks'] if actual else None})
  assert any(x['pid']==req['browserPid'] for x in closed)
  identity={key:req[key] for key in ['sourceSha256','browserPid','attemptNonce']};grant=self.directory/'encoder-grant.json';assert not grant.exists()
  temporary=self.directory/'encoder-grant.json.tmp';assert not temporary.exists();temporary.write_text(json.dumps(identity,indent=2)+'\n');temporary.rename(grant)
  self.granted=True
  proof={'status':'PASS_ACTUAL_OWNED_ONLY_NODE_BEFORE_ENCODER','grantedAt':utc(),'requestSHA256':digest,'identity':identity,'actualOnlyNode':owned,'allObservedOtherPIDStartIdentitiesClosed':closed,'reapedOnlyExitedDirectOwnedChildren':self.reaped,'actualDeferralsWhileOtherOwnedRemain':self.deferrals,'noSignalsIssued':True,'noBrowserOrFFmpegLaunchByThisGate':True,'scope':'Actual outside subreaper-owned tree and exact PID/start identity closure before nonce grant; browserClosed alone is insufficient.'}
  self.output.write_text(json.dumps(proof,indent=2)+'\n')
