import assert from 'node:assert/strict';
import test from 'node:test';
import { writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
const base=pathToFileURL(process.env.G03_BUILD_DIR+'/');
const {game}=await import(new URL('jobs/G03-pack-the-hold/src/core.js',base));
const {createRng}=await import(new URL('contract/rng.js',base));
const rows=[];
for(let count=2;count<=8;count++)for(let prefix=0;prefix<=count;prefix++){
 const players=Array.from({length:count},(_,i)=>({id:'p'+i,name:'Player '+(i+1),avatarId:''+i,connected:i>=prefix}));
 const context={players,settings:{rounds:1,turnSeconds:45,difficulty:4,allowFlip:false},seed:91,now:1000};
 const state=game.init(context);
 rows.push({count,prefix,context,state,tvView:game.tvView(state),controllers:players.map(p=>game.controllerView(state,p.id)),firstReadyBot:prefix<count?game.bot.sampleInput(state,'p'+prefix,createRng(91),'normal'):null,expectedFirstConnected:prefix<count?'p'+prefix:null,expectedPackingDeadline:46000});
}
writeFileSync(process.env.G03_NEGATIVE_ROWS,JSON.stringify({source:'actual independently compiled original Ready3',rows},null,2)+'\n');
test('initial disconnected seats do not delay the first connected packing player',()=>{
 for(const row of rows.filter(x=>x.prefix>0&&x.prefix<x.count)){
  assert.equal(row.tvView.seatId,row.expectedFirstConnected);
  assert.equal(row.controllers[row.prefix].canPack,true);
  assert.notEqual(row.firstReadyBot,null);
  assert.equal(row.state.phase.deadline,row.expectedPackingDeadline);
 }
});
test('initial wholly unavailable rosters enter inspection without an empty packing turn',()=>{
 for(const row of rows.filter(x=>x.prefix===x.count)){
  assert.equal(row.state.phase.id,'reveal');
  assert.equal(row.tvView.seatId,null);
  assert.ok(row.controllers.every(x=>!x.canPack));
  assert.ok(Object.values(row.tvView.roundScores).every(x=>x.value===0&&x.ratio===0));
 }
});

