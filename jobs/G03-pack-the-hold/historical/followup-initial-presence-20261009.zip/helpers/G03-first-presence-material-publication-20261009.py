from pathlib import Path
import subprocess,datetime,json,hashlib,zipfile,traceback,re
repo=Path('/dev/shm/game-cores-G03-followup-20261009');job=repo/'jobs/G03-pack-the-hold';base=Path('/dev/shm/G03-first-presence-source-publication-20261009');base.mkdir(exist_ok=False)
parent='8085df9f5483430a3f91799a693289a72c7e33c9';branch='job/G03-pack-the-hold-followup-20261009';t=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();steps=[];status='CLOSED_FAILED';start=t()
def run(name,args,cwd=repo):
 at=t();p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=120);(base/(name+'.stdout')).write_bytes(p.stdout);(base/(name+'.stderr')).write_bytes(p.stderr);steps.append({'name':name,'at':at,'closedAt':t(),'exit':p.returncode,'argv':args});assert p.returncode==0,(name,p.stderr[:500]);return p.stdout
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def remote():
 b=subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],cwd=repo,timeout=30).decode().strip();return b.split()[0] if b else None
try:
 assert run('head',['git','rev-parse','HEAD']).decode().strip()==parent and remote() is None
 fixed=json.loads(Path('/dev/shm/G03-fixed-presence-actual-controls-20261009/receipt.json').read_text());assert fixed['status']=='CLOSED_PASS' and fixed['guardRows']==2509 and fixed['allPhysicalSourceRuntimeSelfGuardsUnchanged']
 benign=json.loads(Path('/dev/shm/G03-fixed-presence-actual-controls-20261009/actual-benign-summary.json').read_text());assert benign['completeGames']==1003 and benign['allCompleteInitialStatesAndLegalTransitionsViewsBotsResultsEqual']
 assert json.loads(Path('/dev/shm/G03-fixed-presence-build-20261009/receipt.json').read_text())['status']=='CLOSED_PASS'
 assert json.loads(Path('/dev/shm/G03-original-negative-saved-output-supplement-20261009.json').read_text())['actualOldFailures']==2
 selected={}
 folders=[('actual-baseline','/dev/shm/G03-original-build-and-negative-20261009'),('fixed-build','/dev/shm/G03-fixed-presence-build-20261009'),('actual-fixed-and-benign','/dev/shm/G03-fixed-presence-actual-controls-20261009'),('source-import-failed','/dev/shm/G03-followup-source-import-20261009'),('source-copy-503','/dev/shm/G03-followup-source-copy-v2-20261009'),('verified-source-copy','/dev/shm/G03-followup-source-copy-physical-v3-20261009')]
 for label,folder in folders:
  for p in sorted(Path(folder).iterdir()):
   if p.is_file():selected[label+'/'+p.name]=p
 for p in sorted(Path('/dev/shm').glob('G03*20261009*')):
  if p.is_file() and p.suffix in ['.json','.py','.mjs']:selected['helpers/'+p.name]=p
 for p in [Path('/tmp/G03-lawful-newclaim-20261009-1333-20261009/receipt.json'),Path('/tmp/G03-lawful-newclaim-20261009-1333-20261009/fresh-lowest-eligibility.json')]:selected['claim/'+p.name]=p
 for name in ['NEXT.md','LOOP.md','ASSUMPTIONS.md']:selected['historical-ready3/'+name]=job/name
 archive=job/'historical/followup-initial-presence-20261009.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,p in selected.items():z.writestr(name,p.read_bytes())
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for name,p in selected.items():assert z.read(name)==p.read_bytes()
 info={'at':t(),'members':len(selected),'bytes':archive.stat().st_size,'sha256':sha(archive),'allCompleteMembersCRCPhysicalEqual':True,'fixed42StartsPassed':True,'baseline2ActualFailuresPreserved':True,'benign1003Games':benign,'newCompletedQualifiedRounds':0,'newNoGainStreak':0,'freshCapture14Pending':True,'originalCurrentFullPending':True,'noNewNativeTiming':True}
 (job/'historical/followup-initial-presence-20261009.json').write_text(json.dumps(info,indent=2)+'\n')
 (job/'NEXT.md').write_text("""# G03 initial presence follow-up
Owner codex-pack-followup-20261009; branchjob/G03-pack-the-hold-followup-20261009.
Claim main05c80d00797671f9fbe548fa7654df3c1325d31c, actual13:33:01.795599Z,
ownrow13:32:58Z/all foreign rows/tree equal/G10 BLOCKED preserved/lease released.
Branch was created from exact claimed main; exact original Ready PR3/41c5dbd
source was copied with every canonical Git blob/physical SHA match; old inputs
unchanged. Source-only provenance8085df9f follows claimed main. Original Ready3,
its historical R10–12 stop and every prior raw failure remain unchanged.

Original README/RULES/JOBS, contract, job rules/PROOF/BOTS/LOOP/ASSUMPTIONS read.
Two independently authored pinned geometry/search sources reread live. A shallow
object-boundary merge assumption and actual promisor503 copy failure are retained;
physical preserved Ready source resolved access without changing credentials.

Actual real defect: initial state always selected disconnected seat0; connected
people could not pack or sample a bot and waited45s. All unavailable initial
rosters also spent an empty packing turn. Actual42-state matrix retained; old
two negative tests fail0pass/2fail. Original build had an extra observer reporter
assumption (# versus actual ℹ); all2474 input bytes equal, only byte-identical
play rebuild timestamp changed. Original FAILED wrapper and precise saved-only
supplement retained; actual processes naturally empty/no signals.
Fix: first connected initial seat packs immediately with full original timer;
none available enters inspection. No generator, solver, strategy, RNG or scoring
change. Permanent508 roster-mask/reconnection tests plus all original focused
checks13pass/0fail. Strict build naturally CLOSED13:52:22.545079Z/all2472
non-output inputs frozen/348012544B<512MiB; declared page549225B is rebuilt.
Actual fixed42-state controls2pass/0fail and extra1003 complete original/fixed
benign games12167 events/118392 views/12167 bots/results exactly equal,
peakstate4390B. Whole gzip8675839B/SHA0937cf70d975e7f9923aef749abb737d8382a7520898e289396a8edd912c754a.
Actual natural closure13:56:17.333050Z/all2509 source/runtime/self+compiled
inputs equal/peak276951040B<512MiB180s/no signals/no browsers.

Full current checks remain PENDING. Original capture13 is source-bound history
after code changes; mandatory current capture14 references are updated, never
fallback to stale13. Capture14 not yet recorded; full npm test cannot qualify
until actual new source-bound clip exists. Checksum coverage adds ZIP without
removing any prior data/media entries. All proof/failures/helpers in historical/
followup-initial-presence-20261009.zip; every member full CRC/physical comparison.
No current original full/native acceptance or qualified KEEP round is inferred.
New completed0/no-gain streak0; original player stop stays historical.
NEXT: saved-only Python full benign EOF/referee; fresh finite capture-only14
proposal/source/resources/actual root coordination before any local browser;
original full core/property/7000 rosters/two leagues/25 mutations/data regens/
disk1800 native intervals/all source guards/corruption controls/whole uploaded
artifact and public HTML. Open supplemental Draft against preserved Ready3.
After genuine new green, re-read job/five weaknesses/fix worst/measure/log/push
until THREE new consecutive no-player-gain rounds. No unchanged timing retry,
clock/threshold/corpus weakening or source-after-Ready/merge.
Re-verify when web works: human difficulty remains unmeasured; prior blocked
ArXiv/Wikipedia/MathWorld were not read. Phone is CPU4x emulation, not real hardware.
Preserve all unique G10 licensed files/data/deps and literal BLOCKED main row.
""")
 with (job/'ASSUMPTIONS.md').open('a') as f:f.write("""
## 2026-10-09 lawful initial-presence follow-up
Fresh lowest G03 row and all three matching branch committers were >6h old;
lower claims fresh. Main claim05c80 actual13:33:01.795599/fullreadback02.348923.
Original Ready3 remains unchanged; new branch starts claimed main. Exact job
and workflow bytes copied from preserved physical Ready sources, validated to
canonical Git blob hashes with all original physical inputs unchanged.
Initial borrowed shallow metadata lacked its old boundary; failed merge assumption
and promisor503 were preserved. No credentials/proxy changes or forced Git push.
The old negative tests actually fail; a separate wrapper reporter assumption
fails afterward (# versus ℹ), and intentional byte-identical page rebuild changes
mtime. Saved-output supplement establishes all source bytes equal/actual natural
empty groups; original broad false flags stay untouched.
Only initialization changes. Current source-bound capture14 and full original
checks remain required; old capture13 stays preserved and cannot qualify new core.
No human solve-rate, phone hardware, native timing gain or new KEEP qualification.
""")
 with (job/'LOOP.md').open('a') as f:f.write("""
Pre-green initial-presence repair | five gaps: initial disconnected seat; all-unavailable init; reconnection; current capture binding; human difficulty | actual42-state matrix/2old negative failures→2fixed passes;508 mask/reconnection regression/13focused pass;1003 complete benign games12167events/118392views/bots/results exactly unchanged | real startup gain, full original/currentcapture14 pending, new qualified rounds0/no-gain streak0; preserve original R10–12 stop and every failure.
""")
 with (job/'VERIFY.md').open('a') as f:f.write("""
## Initial presence follow-up, 2026-10-09
Exact commands/specs/helpers/whole raw/failures/source guards in historical/
followup-initial-presence-20261009.zip, all members full CRC/physical equality.
Original shipped51 hashes/strict compile/build pass. Actual old42-state controls
node --test G03-initial-start-negative-20261009.mjs: EXIT1/two fail/zero pass.
Wrapper literal reporter assumption fails; separate saved-output reader confirms
all2474 source/runtime/self bytes unchanged, only byte-identical play output
mtime changed, all groups empty/no signals. Original FAILED receipt preserved.
Fixed strict compile/offline build/13 focused checks pass/all2472 frozen
non-output guards; intentional page rebuild549225B/SHA928958719234ad28ae13326953953d350fac4c52233ed8b5dee67f94a7d2f697.
Fixed42 controls two pass/zero fail;1003 additional complete seeded benign games,
12167 transitions/bots,118392 views,all initial/final/results exact,max4390B;
whole8675839B gzip SHA0937cf70d975e7f9923aef749abb737d8382a7520898e289396a8edd912c754a.
Natural13:56:17.333050Z/all2509 inputs/peak276951040B<512MiB180s/no signals.
Original exactsolver/certificate/data/samplers/bot strategy remain unchanged.
New capture14/current original full and independent whole official receipt
remain pending; no local browser or sampled frame retry has been run.
""")
 with (job/'SOURCES.md').open('a') as f:f.write("""
2026-10-09 follow-up re-read both pinned Dijkstra solver.py and semiexp naive.rs
live through the configured GitHub connection. Legal transformations, bounds,
collision rejection and finite exhaustive enumeration corroborate the same
original mechanics. No external code/art/content copied. Initial-presence
defect is an actual observation from this original core, not a research claim.
""")
 node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
 run('regenerate-and-checksum',[node,'scripts/generate.mjs'],job);run('exact-all-hashes',[node,'scripts/check-hashes.mjs'],job)
 assert run('immutable-original-game-data',['git','diff','--','jobs/G03-pack-the-hold/data','jobs/G03-pack-the-hold/fixtures','jobs/G03-pack-the-hold/schemas','jobs/G03-pack-the-hold/src/tiers.ts','jobs/G03-pack-the-hold/manifest.json','contract'])==b''
 assert remote() is None
 run('stage',['git','add','--','jobs/G03-pack-the-hold'])
 run('commit',['git','commit','-m','G03: skip initially disconnected packing seats'])
 head=run('new-head',['git','rev-parse','HEAD']).decode().strip();assert run('parent',['git','rev-parse','HEAD^']).decode().strip()==parent and remote() is None
 run('normal-source-push',['git','push','origin','HEAD:refs/heads/'+branch]);pushed=steps[-1]['closedAt'];assert remote()==head;readback=t();assert run('clean',['git','status','--porcelain'])==b''
 actual=datetime.datetime.fromisoformat(pushed);previous=datetime.datetime.fromisoformat('2026-10-09T13:33:01.795599+00:00');delta=(actual-previous).total_seconds();status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':t(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':start,'closedAt':t(),'parent':parent,'sourceHead':locals().get('head'),'branch':branch,'actualNormalSourcePushClosedAt':locals().get('pushed'),'exactRemoteReadbackClosedAt':locals().get('readback'),'cadenceFromClaimSeconds':locals().get('delta'),'early25TargetPassed':locals().get('delta',99999)<=1500,'early25LatenessSeconds':max(0,locals().get('delta',1500)-1500),'hard30LimitPassed':locals().get('delta',99999)<=1800,'hard30LatenessSeconds':max(0,locals().get('delta',1800)-1800),'nextEarly25Utc':(actual+datetime.timedelta(seconds=1500)).isoformat() if 'actual' in locals() else None,'nextHard30Utc':(actual+datetime.timedelta(seconds=1800)).isoformat() if 'actual' in locals() else None,'publicArchive':locals().get('info'),'qualifiedNewRounds':0,'noGainStreak':0,'currentFullOriginalAccepted':False,'capture14Pending':True,'noNewBrowserOrNativeTiming':True,'noForcePush':True,'steps':steps}
 (base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='steps'}),flush=True)

