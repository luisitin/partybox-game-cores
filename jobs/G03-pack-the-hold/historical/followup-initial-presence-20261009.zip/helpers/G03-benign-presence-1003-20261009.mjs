import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {createWriteStream,writeFileSync,readFileSync} from 'node:fs';
import {createGzip} from 'node:zlib';
import {once} from 'node:events';
import {finished} from 'node:stream/promises';
import {createHash} from 'node:crypto';
const oldRoot=pathToFileURL('/dev/shm/G03-compiled-original-baseline-20261009/');
const newRoot=pathToFileURL('/dev/shm/game-cores-G03-followup-20261009/jobs/G03-pack-the-hold/.build/');
const old=await import(new URL('jobs/G03-pack-the-hold/src/core.js',oldRoot)),fixed=await import(new URL('jobs/G03-pack-the-hold/src/core.js',newRoot));
const {createRng}=await import(new URL('contract/rng.js',oldRoot));
const sampler=createRng(0x6030040),seeds=new Set([1,2,3]);while(seeds.size<1003)seeds.add(sampler.int(0,0xffffffff));
const output=process.env.G03_RAW_OUTPUT,gzip=createGzip({level:9}),file=createWriteStream(output);gzip.pipe(file);
let events=0,views=0,botInputs=0,maxBytes=0;
for(const seed of seeds){
 const count=2+seed%7,players=Array.from({length:count},(_,i)=>({id:'p'+i,name:'Player '+(i+1),avatarId:''+i,connected:true}));
 const context={players,settings:{rounds:1+seed%3,turnSeconds:seed%2?20:60,difficulty:1+seed%10,allowFlip:Boolean(seed%2)},seed,now:1000};
 let a=old.game.init(context),b=fixed.game.init(context);assert.deepEqual(a,b);
 const record={seed,count,context,initialOld:a,initialFixed:b,steps:[]};
 for(let step=1;a.phase.id!=='done';step++){
  assert.ok(step<=100);const id=a.order[a.seat];
  const ma=old.game.bot.sampleInput(a,id,createRng(step),'normal'),mb=fixed.game.bot.sampleInput(b,id,createRng(step),'normal');assert.deepEqual(ma,mb);botInputs++;
  const event=ma?{type:'input',playerId:id,input:ma,now:a.phase.startedAt+1}:{type:'timer',phaseId:a.phase.id,startedAt:a.phase.startedAt,now:a.phase.deadline};
  a=old.game.reduce(a,event);b=fixed.game.reduce(b,event);assert.deepEqual(a,b);events++;maxBytes=Math.max(maxBytes,Buffer.byteLength(JSON.stringify(b)));assert.ok(maxBytes<=262144);
  const tvA=old.game.tvView(a),tvB=fixed.game.tvView(b);assert.deepEqual(tvA,tvB);views++;
  const ca=[],cb=[];for(const who of [...a.order,'spectator','__proto__','constructor']){const x=old.game.controllerView(a,who),y=fixed.game.controllerView(b,who);assert.deepEqual(x,y);ca.push(x);cb.push(y);views++;}
  record.steps.push({event,old:a,fixed:b,oldTV:tvA,fixedTV:tvB,oldControllers:ca,fixedControllers:cb,oldBot:ma,fixedBot:mb});
 }
 record.oldResults=old.game.results(a);record.fixedResults=fixed.game.results(b);assert.deepEqual(record.oldResults,record.fixedResults);
 if(!gzip.write(JSON.stringify(record)+'\n'))await once(gzip,'drain');
}
gzip.end();await finished(file);
const raw=readFileSync(output),summary={status:'PASS',closedAt:new Date().toISOString(),completeGames:1003,additionalSamplerSeed:0x6030040,originalSamplersChanged:false,legalEvents:events,viewComparisons:views,botComparisons:botInputs,maxStateBytes:maxBytes,allCompleteInitialStatesAndLegalTransitionsViewsBotsResultsEqual:true,rawGzipBytes:raw.length,rawGzipSHA256:createHash('sha256').update(raw).digest('hex'),noBrowserOrPerformanceTiming:true};
writeFileSync(process.env.G03_SUMMARY_OUTPUT,JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(summary));

