"""Independent whole PNG CRC/inflate and full WebM decode; no resampling."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import binascii, json, struct, subprocess, sys, zlib

JOB = Path('/dev/shm/game-cores-G03-followup-20261009/jobs/G03-pack-the-hold')
OUT = Path(sys.argv[1])
def row(path):
    data = path.read_bytes(); s = path.stat()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha256(data).hexdigest(), 'stat': [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]}
paths = sorted((JOB / '.tmp/capture').glob('*.png'))
assert [p.name for p in paths] == [f'{i:03}.png' for i in range(36)]
video = JOB / 'media/milestone-14.webm'; report_path = JOB / 'media/capture-14-report.json'
inputs = paths + [video, report_path, JOB / 'media/packing-desktop-14.png']
before = [row(p) for p in inputs]
pngs = []
for path in paths + [JOB / 'media/packing-desktop-14.png']:
    data = path.read_bytes(); assert data[:8] == b'\x89PNG\r\n\x1a\n'
    cursor = 8; chunks = []; idat = bytearray(); ihdr = None
    while cursor < len(data):
        length = struct.unpack('>I', data[cursor:cursor + 4])[0]; kind = data[cursor + 4:cursor + 8]; payload = data[cursor + 8:cursor + 8 + length]
        assert len(payload) == length and cursor + 12 + length <= len(data)
        crc = struct.unpack('>I', data[cursor + 8 + length:cursor + 12 + length])[0]
        assert binascii.crc32(kind + payload) & 0xffffffff == crc
        chunks.append(kind.decode('ascii'))
        if kind == b'IHDR': assert ihdr is None; ihdr = struct.unpack('>IIBBBBB', payload)
        if kind == b'IDAT': idat.extend(payload)
        cursor += length + 12
        if kind == b'IEND': assert payload == b'' and cursor == len(data); break
    assert chunks[0] == 'IHDR' and chunks[-1] == 'IEND' and ihdr is not None
    width, height, depth, colour, compression, filtering, interlace = ihdr
    assert (width, height, depth, compression, filtering, interlace) == (1280, 900, 8, 0, 0, 0) and colour in (2, 6)
    inflater = zlib.decompressobj(); pixels = inflater.decompress(bytes(idat)); pixels += inflater.flush()
    assert inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail
    stride = width * (3 if colour == 2 else 4) + 1
    assert len(pixels) == height * stride and all(pixels[y * stride] in range(5) for y in range(height))
    pngs.append({**row(path), 'width': width, 'height': height, 'allChunksCRCPassed': True, 'completeInflatedScanlineBytes': len(pixels), 'allOriginalPixelsPresentNoResampling': True})
probe = subprocess.run(['/usr/bin/ffprobe', '-v', 'error', '-count_frames', '-show_streams', '-show_format', '-of', 'json', str(video)], capture_output=True, timeout=25)
(OUT / 'independent-ffprobe.stdout').write_bytes(probe.stdout); (OUT / 'independent-ffprobe.stderr').write_bytes(probe.stderr)
assert probe.returncode == 0 and not probe.stderr
metadata = json.loads(probe.stdout); streams = metadata['streams']; assert len(streams) == 1
stream = streams[0]
assert stream['codec_name'] == 'vp9' and stream['codec_type'] == 'video' and (stream['width'], stream['height']) == (1280, 900)
assert stream['nb_read_frames'] == '36' and stream['r_frame_rate'] == '10/1' and stream['avg_frame_rate'] == '10/1'
assert abs(float(metadata['format']['duration']) - 3.6) < 1e-8 and int(metadata['format']['size']) == video.stat().st_size < 10_000_000
decode = subprocess.run(['/usr/bin/ffmpeg', '-v', 'error', '-i', str(video), '-map', '0:v:0', '-f', 'framemd5', '-'], capture_output=True, timeout=25)
(OUT / 'independent-full-frame-md5.stdout').write_bytes(decode.stdout); (OUT / 'independent-full-frame-md5.stderr').write_bytes(decode.stderr)
assert decode.returncode == 0 and not decode.stderr
frames = [line for line in decode.stdout.decode().splitlines() if line and not line.startswith('#')]
assert len(frames) == 36
native_frame_bytes = {'yuv420p': 1728000, 'yuv422p': 2304000, 'yuv444p': 3456000, 'gbrp': 3456000, 'yuva420p': 2880000, 'gbrap': 4608000, 'yuv420p10le': 3456000, 'yuv444p10le': 6912000, 'gbrp10le': 6912000}[stream['pix_fmt']]
assert '#dimensions 0: 1280x900' in decode.stdout.decode(), 'Full original native decoded dimensions'
for i, line in enumerate(frames):
    fields = [x.strip() for x in line.split(',')]
    assert len(fields) == 6 and int(fields[0]) == 0 and int(fields[1]) == i and int(fields[2]) == i and int(fields[3]) == 1 and int(fields[4]) == native_frame_bytes and len(fields[5]) == 32
report = json.loads(report_path.read_text()); assert report['videoBytes'] == video.stat().st_size and report['videoSha256'] == row(video)['sha256']
after = [row(p) for p in inputs]; assert after == before
receipt = {'status': 'PASS', 'closedAt': datetime.now(timezone.utc).isoformat(), 'wholeInputEOFBeforeAfterEqual': True, 'inputs': before, 'complete36OriginalPNGs': pngs[:36], 'desktopPNG': pngs[-1], 'wholeWebMBytes': video.stat().st_size, 'wholeWebMSHA256': row(video)['sha256'], 'completeNativeDecodedFrames': 36, 'nativePixelFormat': stream['pix_fmt'], 'decodedBytesPerCompleteFrame': native_frame_bytes, 'width': 1280, 'height': 900, 'originalEncodedFps': 10, 'seconds': 3.6, 'noCropResizeResampleOrFiltering': True, 'scope': 'Saved actual image/video contents only; separate10fps encoding is not real-time rendering acceptance.'}
(OUT / 'whole-capture-reader.json').write_text(json.dumps(receipt, indent=2) + '\n'); print(json.dumps({k: v for k, v in receipt.items() if k not in ['inputs', 'complete36OriginalPNGs', 'desktopPNG']}))
