"""One explicitly granted current-source UI capture; no frame-rate sampling."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import ctypes, json, os, signal, subprocess, sys, time, traceback

BASE = Path(__file__).resolve().parent
READY = BASE / 'ready.json'
raw = json.loads(READY.read_text())
JOB = Path(raw['job'])
REPO = JOB.parent.parent
OUT = Path(raw['output'])
started = None
before = None
child = None
samples = []
steps = []
signals = []
closure = None
failed = True
whole_began = time.monotonic()

def utc(): return datetime.now(timezone.utc).isoformat()
def write(name, value): (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
def digest(path):
    h = sha256()
    with path.open('rb') as source:
        while block := source.read(1 << 20): h.update(block)
    return h.hexdigest()
def row(path):
    path = path.absolute(); s = path.stat()
    return {'path': str(path), 'resolved': str(path.resolve()), 'bytes': s.st_size, 'sha256': digest(path), 'stat': [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]}
def freeze():
    assert subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == raw['head']
    assert digest(BASE / 'freeze-spec.json') == raw['freezeSpecSha256']
    spec = json.loads((BASE / 'freeze-spec.json').read_text())
    actual = {label: row(Path(saved['path'])) for label, saved in spec['files'].items()}
    assert actual == spec['files'], 'Full physical source/runtime/self/input drift'
    for root, inventory in spec['inventories'].items():
        observed = sorted(str(p) for p in Path(root).rglob('*') if p.is_file())
        assert observed == inventory, 'Installed runtime inventory drift: ' + root
    assert digest(READY) == grant['readySha256'], 'Exact granted READY changed'
    return {'head': raw['head'], 'specSha256': raw['freezeSpecSha256'], 'readySha256': digest(READY), 'files': actual}
def resources():
    root = Path('/sys/fs/cgroup')
    maximum = int((root / 'memory.max').read_text()); current = int((root / 'memory.current').read_text())
    stat = {k: int(v) for k, v in (line.split() for line in (root / 'memory.stat').read_text().splitlines())}
    clean = max(0, stat['active_file'] + stat['inactive_file'] - stat['file_dirty'] - stat['file_writeback'])
    credit = min(raw['maxOrdinaryCleanCreditBytes'], clean)
    disk = os.statvfs(OUT)
    return {'at': utc(), 'cgroupMaxBytes': maximum, 'cgroupCurrentBytes': current, 'ordinaryCleanLRUBytes': clean, 'boundedCleanCreditBytes': credit, 'shmemExcludedBytes': stat['shmem'], 'dirtyWritebackSlabExcluded': True, 'potentialCapacityBytes': maximum - current + credit, 'requiredCapacityBytes': raw['ownedRssBytes'] + raw['newOutputReservationBytes'] + raw['sharedReserveBytes'], 'diskFreeBytes': disk.f_bavail * disk.f_frsize, 'requiredDiskBytes': raw['newOutputReservationBytes'], 'noEvictionDropOrColdCacheClaim': True}
def descendants():
    rows = {}
    for p in Path('/proc').glob('[0-9]*/stat'):
        try:
            text = p.read_text(); fields = text[text.rfind(')') + 2:].split()
            rows[int(p.parent.name)] = {'pid': int(p.parent.name), 'ppid': int(fields[1]), 'pgid': int(fields[2]), 'state': fields[0], 'startTicks': int(fields[19]), 'rssBytes': int(fields[21]) * os.sysconf('SC_PAGE_SIZE')}
        except (OSError, ValueError, IndexError): pass
    owned = {os.getpid()}; changed = True
    while changed:
        previous = len(owned); owned.update(pid for pid, r in rows.items() if r['ppid'] in owned); changed = len(owned) != previous
    return [rows[pid] for pid in sorted(owned - {os.getpid()}) if pid in rows]
def reap():
    reaped = []
    while True:
        try: pid, code = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError: break
        if pid == 0: break
        reaped.append({'pid': pid, 'waitStatus': code})
    return reaped
def close_owned(force):
    reaped = []; until = time.monotonic() + 5
    while time.monotonic() < until:
        reaped.extend(reap())
        if not descendants(): return {'remaining': [], 'signals': [], 'reaped': reaped, 'natural': True}
        time.sleep(.025)
    if not force: raise AssertionError('Successful child left owned detached descendants')
    issued = []
    for sig in (signal.SIGTERM, signal.SIGKILL):
        for saved in descendants():
            if saved['state'] == 'Z': continue
            current = next((r for r in descendants() if r['pid'] == saved['pid']), None)
            if current is not None and current['startTicks'] == saved['startTicks']:
                try:
                    os.kill(saved['pid'], sig); issued.append({'at': utc(), 'pid': saved['pid'], 'startTicks': saved['startTicks'], 'signal': sig.name})
                except ProcessLookupError: pass
        until = time.monotonic() + 3
        while time.monotonic() < until:
            reaped.extend(reap())
            if not descendants(): break
            time.sleep(.025)
    signals.extend(issued)
    remaining = descendants()
    assert not remaining, 'Actual owned descendants failed finite cleanup'
    return {'remaining': remaining, 'signals': issued, 'reaped': reaped, 'natural': not issued}
def launch(name, argv, limit):
    global child, closure
    at = utc(); begin = time.monotonic()
    env = dict(os.environ, PATH=str(Path(raw['node']).parent) + ':/usr/bin:/bin', TZ='UTC', LANG='C.UTF-8', TMPDIR=str(OUT / 'runtime-tmp'), G03_CHROME=raw['chrome'], PYTHONDONTWRITEBYTECODE='1')
    for key in ['G03_VISUAL_MODE', 'G03_FRAME_BARRIER_DIR']: env.pop(key, None)
    with (OUT / (name + '.stdout')).open('xb') as out, (OUT / (name + '.stderr')).open('xb') as err:
        child = subprocess.Popen(argv, cwd=JOB, env=env, stdout=out, stderr=err, start_new_session=True)
        while True:
            owned = descendants(); rss = sum(r['rssBytes'] for r in owned)
            samples.append({'at': utc(), 'phase': name, 'owned': owned, 'sampledRssBytes': rss})
            assert rss <= raw['ownedRssBytes'], 'Declared sampled owned RSS bound exceeded'
            assert resources()['potentialCapacityBytes'] > raw['sharedReserveBytes'], 'Declared shared potential reserve unavailable'
            code = child.poll()
            if code is not None: break
            assert time.monotonic() - begin <= limit, 'Declared finite child wall bound exceeded'
            time.sleep(.025)
        assert child.wait(timeout=2) == 0, 'Actual required child failed: ' + name
    elapsed = time.monotonic() - begin
    assert elapsed <= limit, 'Final natural child interval exceeded declared bound'
    closure = close_owned(False)
    steps.append({'name': name, 'argv': argv, 'startedAt': at, 'closedAt': utc(), 'actualExitCode': code, 'actualChildSeconds': elapsed, 'declaredChildSeconds': limit, 'closure': closure})
    child = None
def deadline(*_): raise TimeoutError('Declared finite whole capture proof bound exceeded')

if __name__ == '__main__':
    assert OUT.is_dir() and not any(OUT.iterdir()), 'Unique output must remain empty; preserve every outcome'
    grant = json.loads((BASE / 'grant.json').read_text())
    assert grant['status'] == 'ROOT_GRANTED' and grant['head'] == raw['head'] and grant['nonce'] == raw['nonce'] and grant['readySha256'] == digest(READY)
    assert raw['captureArgv'] == [raw['node'], 'scripts/visual.mjs', '--capture-only', '--record', '--milestone', '14']
    assert ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) == 0
    signal.signal(signal.SIGALRM, deadline); signal.alarm(raw['wholeSeconds']); started = utc()
    try:
        before = freeze(); write('freeze-before.json', before)
        initial = resources(); write('resources-before.json', initial)
        assert initial['potentialCapacityBytes'] > initial['requiredCapacityBytes'] and initial['diskFreeBytes'] > initial['requiredDiskBytes'], 'Fresh prospective resource gate unavailable: no browser launch'
        for relative in ['media/capture-14-report.json', 'media/milestone-14.webm', 'media/packing-desktop-14.png', '.tmp/chrome', '.tmp/capture']:
            assert not (JOB / relative).exists(), 'Never overwrite any prior actual capture input/output: ' + relative
        (OUT / 'runtime-tmp').mkdir()
        launch('actual-original-capture14', raw['captureArgv'], raw['captureChildSeconds'])
        launch('original-independent-capture-verifier', [raw['node'], 'scripts/verify-visual.mjs', '--capture-report', 'media/capture-14-report.json'], 30)
        launch('original-25-capture-corruptions', [raw['node'], '--test', 'scripts/verify-capture.test.mjs'], 30)
        launch('independent-whole-png-and-video-reader', [sys.executable, str(BASE / 'whole-capture-reader.py'), str(OUT)], 60)
        report = json.loads((JOB / 'media/capture-14-report.json').read_text())
        assert report['status'] == 'passed' and report['kind'] == 'capture-only' and report['desktop'] is None and report['phone'] is None
        assert report['fileOpened'] and report['serving'] == 'disk' and report['runtimeExceptions'] == 0 and report['externalRequests'] == 0
        assert report['sourceHashesStart'] == report['sourceHashesEnd'] and len(report['sourceHashesStart']) == 28
        final = freeze(); assert final == before; write('freeze-final.json', {'at': utc(), 'equalBefore': True, 'actual': final})
        assert time.monotonic() - whole_began <= raw['wholeSeconds'], 'Final complete proof exceeded whole wall bound'
        failed = False
    except BaseException as error:
        write('failure.json', {'at': utc(), 'errorType': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc(), 'scope': 'Actual unmeasured capture/proof failure; no game FPS, qualified KEEP or no-gain conclusion.'})
    finally:
        signal.alarm(0)
        try:
            if child is not None:
                if child.poll() is None: failed = True
                closure = close_owned(True)
                child.poll()
            assert not descendants(), 'Actual final owned descendant tree nonempty'
            after = freeze(); write('always-final-guards.json', {'at': utc(), 'equalBefore': before is not None and after == before, 'actual': after})
            if before is None or after != before: failed = True
        except BaseException as error:
            failed = True; write('finalization-failure.json', {'at': utc(), 'error': str(error), 'traceback': traceback.format_exc()})
        write('rss-samples.json', {'sampledPeakBytes': max((r['sampledRssBytes'] for r in samples), default=0), 'samples': samples, 'scope': 'Complete transitive subreaper-owned descendants including detached groups, actual25ms sleeps plus scan/loop cost; sampled peak only.'})
        whole_elapsed = time.monotonic() - whole_began
        if whole_elapsed > raw['wholeSeconds']:
            failed = True; write('whole-budget-failure.json', {'at': utc(), 'actualWholeSeconds': whole_elapsed, 'declaredWholeSeconds': raw['wholeSeconds'], 'scope': 'Final complete freeze/reader/process/RSS proof exceeded immutable whole budget; no pass.'})
        receipt = {'status': 'CLOSED_FAILED' if failed else 'CLOSED_PASS', 'startedAt': started, 'closedAt': utc(), 'head': raw['head'], 'nonce': raw['nonce'], 'steps': steps, 'finalOwnedDescendants': descendants(), 'controllerForcedSignals': signals, 'naturalClosure': not failed and not signals and not descendants(), 'guardRows': len(before['files']) if before else None, 'wholeSeconds': whole_elapsed, 'wholeBudgetSatisfied': whole_elapsed <= raw['wholeSeconds'], 'qualifiedKeepRounds': 0, 'noGainStreak': 0, 'scope': 'One exact original current-source capture-only14; all36 actual original PNGs and whole native WebM decoded independently. No native RAF sampling/performance acceptance, no retry or source adoption inferred.'}
        write('controller.json', receipt); print(json.dumps(receipt), flush=True)
        sys.exit(1 if failed else 0)
