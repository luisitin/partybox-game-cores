"""Saved-only independent full1003-record referee; no game rerun or clock."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import gzip, json, math

RAW = Path('/dev/shm/G03-fixed-presence-actual-controls-20261009/actual-benign-complete-games.jsonl.gz')
SUMMARY = RAW.parent / 'actual-benign-summary.json'
OUT = Path('/dev/shm/G03-benign-whole-saved-reader-20261009')
def row(path):
    h = sha256()
    with path.open('rb') as stream:
        while block := stream.read(1 << 20): h.update(block)
    s = path.stat(); return {'path': str(path), 'bytes': s.st_size, 'sha256': h.hexdigest(), 'stat': [s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns]}
before = [row(RAW), row(SUMMARY)]
summary = json.loads(SUMMARY.read_text())
assert before[0]['bytes'] == summary['rawGzipBytes'] == 8675839
assert before[0]['sha256'] == summary['rawGzipSHA256'] == '0937cf70d975e7f9923aef749abb737d8382a7520898e289396a8edd912c754a'
def mix(seed, step):
    h = (seed ^ (((step + 0x632be5ab) * 0x9e3779b1) & 0xffffffff)) & 0xffffffff
    h = ((h ^ (h >> 16)) * 0x85ebca6b) & 0xffffffff
    h = ((h ^ (h >> 13)) * 0xc2b2ae35) & 0xffffffff
    h = (h ^ (h >> 16)) & 0xffffffff
    h = ((h ^ (h >> 15)) * 0x2c1b3c6d) & 0xffffffff
    h = ((h ^ (h >> 12)) * 0x297a2d39) & 0xffffffff
    return (h ^ (h >> 15)) & 0xffffffff
seeds = [1, 2, 3]; seen = set(seeds); step = 0
while len(seeds) < 1003:
    seed = mix(0x6030040, step); step += 1
    if seed not in seen: seen.add(seed); seeds.append(seed)
events = 0; views = 0; bots = 0; games = 0; decoded_bytes = 0; max_state = 0
def invalid_constant(value): raise AssertionError('Non-finite JSON constant: ' + value)
def finite(value):
    if isinstance(value, float): assert math.isfinite(value)
    elif isinstance(value, dict):
        for child in value.values(): finite(child)
    elif isinstance(value, list):
        for child in value: finite(child)
with gzip.open(RAW, 'rb') as stream:
    for line in stream:
        assert line.endswith(b'\n') and games < 1003
        decoded_bytes += len(line); record = json.loads(line, parse_constant=invalid_constant); finite(record)
        seed = seeds[games]; count = 2 + seed % 7
        assert record['seed'] == seed and record['count'] == count
        context = record['context']
        assert context['seed'] == seed and context['now'] == 1000
        assert context['settings'] == {'rounds': 1 + seed % 3, 'turnSeconds': 20 if seed % 2 else 60, 'difficulty': 1 + seed % 10, 'allowFlip': bool(seed % 2)}
        ids = [f'p{i}' for i in range(count)]
        assert context['players'] == [{'id': pid, 'name': f'Player {i + 1}', 'avatarId': str(i), 'connected': True} for i, pid in enumerate(ids)]
        assert record['initialOld'] == record['initialFixed']
        previous = record['initialOld']; assert previous['order'] == ids and previous['seat'] == 0 and previous['phase']['id'] == 'pack'
        assert 1 <= len(record['steps']) <= 100
        for saved in record['steps']:
            assert previous['phase']['id'] != 'done'
            old, fixed = saved['old'], saved['fixed']; assert old == fixed
            assert saved['oldBot'] == saved['fixedBot']; bots += 1
            bot = saved['oldBot']; event = saved['event']; phase = previous['phase']
            expected = {'type': 'input', 'playerId': previous['order'][previous['seat']], 'input': bot, 'now': phase['startedAt'] + 1} if bot is not None else {'type': 'timer', 'phaseId': phase['id'], 'startedAt': phase['startedAt'], 'now': phase['deadline']}
            assert event == expected and math.isfinite(event['now'])
            assert old['rng'] == fixed['rng'] and old['order'] == fixed['order'] == ids
            assert saved['oldTV'] == saved['fixedTV']; views += 1
            assert len(saved['oldControllers']) == len(saved['fixedControllers']) == count + 3
            for left, right in zip(saved['oldControllers'], saved['fixedControllers']): assert left == right; views += 1
            size = len(json.dumps(fixed, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode())
            assert size <= 262144; max_state = max(max_state, size); events += 1; previous = old
        assert previous['phase']['id'] == 'done'
        assert record['oldResults'] == record['fixedResults']
        assert set(record['oldResults']['scores']) == set(ids)
        assert set(x['playerId'] for x in record['oldResults']['ranking']) == set(ids)
        games += 1
assert games == summary['completeGames'] == 1003
assert events == summary['legalEvents'] == 12167 and bots == summary['botComparisons'] == 12167 and views == summary['viewComparisons'] == 118392
assert max_state == summary['maxStateBytes'] == 4390
after = [row(RAW), row(SUMMARY)]; assert before == after
receipt = {'status': 'PASS', 'closedAt': datetime.now(timezone.utc).isoformat(), 'wholeGzipPhysicalEOFAndBeforeAfterEqual': True, 'gzipCRCAndISIZEValidatedByCompleteReader': True, 'completeDecompressedBytes': decoded_bytes, 'completeGames': games, 'independentAdditionalSamplerSeed': 0x6030040, 'all1003OrderedSeedsIndependentlyDerivedFromOriginalMurmurMix': True, 'allCompleteInitialStatesEventsStateRNGTVControllerBotsResultsEqual': True, 'eventComparisons': events, 'viewComparisons': views, 'botComparisons': bots, 'maxStateBytes': max_state, 'inputs': before, 'scope': 'Independent Python reader of every saved original/fixed record and physical gzip EOF; no new core execution/browser/native clock or fresh original full/KEEP qualification.'}
(OUT / 'whole-referee.json').write_text(json.dumps(receipt, indent=2) + '\n'); print(json.dumps({k: v for k, v in receipt.items() if k != 'inputs'}))
