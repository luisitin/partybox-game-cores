from pathlib import Path
import subprocess,datetime,json,traceback
repo=Path('/tmp/G10-main-refresh-0511');base=Path('/dev/shm/G03-main-refresh-b141-20261009');base.mkdir(exist_ok=False)
expected='185bbfa6a4ff07ecd0d00c2cee066444b5658f3a';steps=[];status='CLOSED_FAILED';t=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(name,args):
 start=t();p=subprocess.run(args,cwd=repo,capture_output=True,timeout=60)
 (base/(name+'.stdout')).write_bytes(p.stdout);(base/(name+'.stderr')).write_bytes(p.stderr)
 steps.append({'name':name,'argv':args,'startedAt':start,'closedAt':t(),'actualExitCode':p.returncode})
 assert p.returncode==0,(name,p.stderr.decode(errors='replace'));return p.stdout
start=t()
try:
 assert run('pre-clean',['git','status','--porcelain']).strip()==b''
 assert run('fresh-main',['git','ls-remote','origin','refs/heads/main']).decode().split()[0]==expected,'Exclusive expected-main lease drifted'
 run('fetch',['git','fetch','origin','main'])
 assert run('fetched-sha',['git','rev-parse','FETCH_HEAD']).decode().strip()==expected
 run('normal-ff',['git','merge','--ff-only','FETCH_HEAD'])
 before=run('immutable-before',['git','show',expected+':CLAIMS.md'])
 assert (repo/'CLAIMS.md').read_bytes()==before and b'G10 BLOCKED\n' in before
 lines=before.decode().splitlines(keepends=True);assert sum(x.startswith('G03 ') for x in lines)==1
 clock=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ');ownrow='G03 '+clock+' codex-pack-followup-20261009'
 after=''.join(ownrow+'\n' if x.startswith('G03 ') else x for x in lines).encode()
 assert b''.join(x for x in before.splitlines(keepends=True) if not x.startswith(b'G03 '))==b''.join(x for x in after.splitlines(keepends=True) if not x.startswith(b'G03 '))
 (base/'CLAIMS.before').write_bytes(before);(base/'CLAIMS.after').write_bytes(after);(repo/'CLAIMS.md').write_bytes(after)
 run('add',['git','add','CLAIMS.md']);run('commit',['git','commit','-m','claim G03'])
 head=run('head',['git','rev-parse','HEAD']).decode().strip()
 assert run('exact-parent',['git','rev-parse','HEAD^']).decode().strip()==expected
 assert run('only-claims',['git','diff','--name-only',expected,head]).decode().splitlines()==['CLAIMS.md']
 assert run('exact-message',['git','log','-1','--format=%s']).decode().strip()=='claim G03'
 assert run('expected-prepush',['git','ls-remote','origin','refs/heads/main']).decode().split()[0]==expected
 run('normal-push',['git','push','origin','main']);pushed=steps[-1]['closedAt']
 assert run('exact-readback',['git','ls-remote','origin','refs/heads/main']).decode().split()[0]==head;remote=steps[-1]['closedAt']
 run('readback-fetch',['git','fetch','origin','main'])
 assert run('exact-readback-file',['git','show','FETCH_HEAD:CLAIMS.md'])==after
 assert run('final-clean',['git','status','--porcelain']).strip()==b''
 status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':t(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':start,'closedAt':t(),'expectedMain':expected,'head':locals().get('head'),'ownRow':locals().get('ownrow'),'actualNormalPushClosedAt':locals().get('pushed'),'exactRemoteReadbackClosedAt':locals().get('remote'),'allOtherRowsByteEqual':status=='CLOSED_PASS','allOtherTreeFilesEqual':status=='CLOSED_PASS','g10BlockedAndG07FinalPreserved':status=='CLOSED_PASS','normalFastForwardOnly':True,'expectedHeadRecheckedBeforePush':True,'sourceHead':'b141979b40d2a9c72261c783deeccd5091a3e9d1','leaseReleased':status=='CLOSED_PASS','steps':steps}
 (base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='steps'}),flush=True)

