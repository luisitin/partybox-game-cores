from pathlib import Path
import json,os,sys,termios
b=Path('/tmp/G10-hosted-0f504-final-20261009');old=termios.tcgetattr(0);new=termios.tcgetattr(0);new[3]&=~(termios.ECHO|termios.ICANON);termios.tcsetattr(0,termios.TCSANOW,new)
print('PRIVATE_NATIVE_STDIN_READY',flush=True)
try:
 buf=bytearray()
 while not buf.endswith(b'\n'):
  part=os.read(0,65536)
  assert part and len(buf)<4*1024**2
  buf.extend(part)
 v=json.loads(buf)
 assert v['run']['head_sha']=='0f504cad986f4282a383ea82e50fe2f8acd7458c' and v['run']['id']==37888827255 and v['run']['status']=='completed' and v['run']['conclusion']=='success'
 for key,name in [('run','run-native.json'),('jobs','jobs-native.json'),('artifacts','artifacts-native.json'),('private','official-reference.private.json')]:
  p=b/name;assert not p.exists();p.write_text(json.dumps(v[key],indent=2)+'\n');p.chmod(0o600)
 for key,data in v['logs'].items():
  assert isinstance(data,str);p=b/('job-'+key+'.log');assert not p.exists();p.write_bytes(data.encode('utf8'));p.chmod(0o600)
 print(json.dumps({'status':'ACTUAL_NATIVE_INPUT_WRITTEN','head':v['run']['head_sha'],'wholeLogs':len(v['logs']),'artifactId':v['private']['officialMetadata']['id']}),flush=True)
finally:termios.tcsetattr(0,termios.TCSANOW,old)
