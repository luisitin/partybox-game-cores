"""Finite untimed continuation of already received genuine original archive; no redownload/browser."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from zipfile import ZipFile
import ctypes,importlib.util,json,os,signal,sys,traceback
JOB=Path.cwd();CODE=JOB/'.work/hosted-0f504-current56';BASE=Path('/tmp/G10-hosted-0f504-final-20261009');CURRENT='56db9298847ff312860bed8e71f32f2ac76bd41f';ACCEPTED='0f504cad986f4282a383ea82e50fe2f8acd7458c'
def utc():return datetime.now(timezone.utc).isoformat()
def digest(p):
 h=sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
def row(p):
 p=Path(p).absolute();s=p.stat();return {'path':str(p),'sha256':digest(p),'identity':{'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}}
def write(n,v):
 p=BASE/n;assert not p.exists(),'Preserve every original outcome: '+n;p.write_text(json.dumps(v,indent=2)+'\n')
def deadline(*_):raise TimeoutError('Original finite600s resumed proof bound exceeded')
signal.signal(signal.SIGALRM,deadline);signal.alarm(600);assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
spec=importlib.util.spec_from_file_location('original_receiver',CODE/'receive-complete.py');orig=importlib.util.module_from_spec(spec);spec.loader.exec_module(orig)
s=importlib.util.spec_from_file_location('original_groups',orig.HELPER);orig.group_helper=importlib.util.module_from_spec(s);s.loader.exec_module(orig.group_helper)
expected=json.loads((BASE/'resume-execution-freeze.json').read_text())
def frozen():
 assert orig.subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=JOB).decode().strip()==CURRENT
 assert digest(BASE/'resume-execution-freeze.json')==expected_spec_sha
 v={k:row(r['path']) for k,r in expected['files'].items()};assert v==expected['files'],'Resumed self/source/input/runtime identity drift'
 assert orig.freeze()==json.loads((BASE/'execution-freeze-finally.json').read_text())['actual']
 return {'resumeSpecSha256':expected_spec_sha,'files':v,'original19Freeze':orig.freeze()}
expected_spec_sha=digest(BASE/'resume-execution-freeze.json');started=utc();before=None;failed=False
try:
 before=frozen();write('resume-freeze-before.json',before)
 original_failure=json.loads((BASE/'failure.json').read_text());assert original_failure['error']=='audit-git-guards'
 assert "can't open file '/tmp/G10-hosted-0f504-final-20261009/audit-git-guards.py'" in (BASE/'audit-git-guards.stderr').read_text()
 reception=json.loads((BASE/'zip-integrity.json').read_text());assert reception['status']=='PASS' and reception['sourceHead']==ACCEPTED and reception['workflowRunId']==37888827255 and reception['artifactId']==11598287117
 assert (BASE/'complete.zip').stat().st_size==10671040 and digest(BASE/'complete.zip')=='d6168fa8f37367596489ca5063f1b95476272257f51614b22dac1275a4c36b99'
 closure=json.loads((BASE/'download-closure.json').read_text());assert closure['actualExitCode']==0 and closure['natural'] and not closure['actualRemainingGroup']
 with ZipFile(BASE/'complete.zip') as z:
  assert len(z.infolist())==239 and z.testzip() is None
 assert not (BASE/'historical-git-guards.json').exists() and not (BASE/'independent-complete-evidence.json').exists(),'Do not overwrite any real reader result'
 orig.launch('audit-git-guards-resume',[sys.executable,str(CODE/'audit-git-guards.py')],120)
 assert frozen()==before
 orig.launch('independent-complete-resume',[str(orig.NODE),str(CODE/'validate-complete.mjs')],180)
 assert frozen()==before
 actual=json.loads((BASE/'independent-complete-evidence.json').read_text());assert actual['status']=='PASS' and actual['head']==ACCEPTED and actual['workflowRunId']=='37888827255' and actual['stageGuardCount']==349
 physical=JOB/'.work/play-full-candidate-b4.html';assert physical.stat().st_size==1390846291 and digest(physical)=='b4f5267561bd95d68455ea5a83b936692b246d1a8ed936199c820e430a2da3eb'
except BaseException as e:
 failed=True;write('resume-failure.json',{'status':'FAILED','at':utc(),'errorType':type(e).__name__,'error':str(e),'traceback':traceback.format_exc()});raise
finally:
 try:
  after=frozen();assert before is not None and after==before;write('resume-freeze-finally.json',{'status':'PASS','closedAt':utc(),'actual':after})
 except BaseException as e:
  failed=True;write('resume-freeze-finally.json',{'status':'FAILED','closedAt':utc(),'errorType':type(e).__name__,'error':str(e)})
 r={'status':'CLOSED_FAILED' if failed else 'CLOSED_PASS','startedAt':started,'closedAt':utc(),'acceptedHead':ACCEPTED,'currentCheckout':CURRENT,'artifactId':11598287117,'workflowRunId':37888827255,'originalWholeWallSeconds':600,'fullFinalFreezePassed':not failed,'scope':'Finite untimed continuation after real complete HTTP200/ZIP239CRC pass but wrong helper output path. Original receipt/code/stdout/error retained. No redownload/browser/performance trial; unchanged original full reader inventory/gates. Separate success requires349 guards/six-doc bridge/all4000records/all2400intervals/full clips/source/runtime/self freezes and natural closed child groups. No candidate/native/KEEP gain.'};write('resume-controller.json',r);signal.alarm(0);print(json.dumps(r),flush=True)
 if failed:sys.exit(1)
