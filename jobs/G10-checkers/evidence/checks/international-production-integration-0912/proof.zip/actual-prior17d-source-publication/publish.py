from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,signal,os,traceback
base=Path('/tmp/G10-source-checkpoint-0851')
branch='job/G10-checkers-complete-20261008'
old='7fb35165949521cbe84e98605228f9b60c85d896'
started=datetime.now(timezone.utc).isoformat();children=[];status='CLOSED_FAILED'
def utc():return datetime.now(timezone.utc).isoformat()
def members(group):
 rows=[]
 for p in Path('/proc').glob('[0-9]*/stat'):
  try:
   s=p.read_text();c=s[s.rfind(')')+2:].split()
   if int(c[2])==group:rows.append({'pid':int(p.parent.name),'state':c[0]})
  except (OSError,ValueError,IndexError):pass
 return rows
def run(name,args,limit=120):
 r={'name':name,'command':args,'startedAt':utc(),'signals':[]};children.append(r)
 with (base/(name+'.stdout')).open('wb') as out,(base/(name+'.stderr')).open('wb') as err:
  child=subprocess.Popen(args,stdout=out,stderr=err,start_new_session=True)
  try:child.wait(timeout=limit);r['natural']=True
  finally:
   if child.poll() is None or members(child.pid):
    r['natural']=False
    for sig in [signal.SIGTERM,signal.SIGKILL]:
     if child.poll() is None or members(child.pid):
      try:os.killpg(child.pid,sig);r['signals'].append({'signal':sig.name,'at':utc()})
      except ProcessLookupError:pass
      try:child.wait(timeout=3)
      except subprocess.TimeoutExpired:pass
   child.wait(timeout=3);r.update({'closedAt':utc(),'exitCode':child.returncode,'remainingGroup':members(child.pid)})
 assert child.returncode==0 and r['natural'] and not r['remainingGroup'],r
 return (base/(name+'.stdout')).read_text()
try:
 assert json.loads((base/'final-source-proof.json').read_text())['status']=='CLOSED_PASS'
 assert run('pre-head',['git','rev-parse','HEAD']).strip()==old
 assert run('pre-branch',['git','branch','--show-current']).strip()==branch
 run('diff-check',['git','diff','--check'])
 run('add',['git','add','README.md','ASSUMPTIONS.md','LOOP.md','NEXT.md','SHA256SUMS.txt','VERIFY.md','evidence/checks/current7fb-and-international-integration-0851'])
 run('commit',['git','commit','-m','G10 verify original evidence and bind International startup patch'])
 head=run('post-head',['git','rev-parse','HEAD']).strip();assert head!=old
 run('push',['git','push','https://github.com/luisitin/partybox-game-cores.git',branch])
 pushed=next(x['closedAt'] for x in children if x['name']=='push')
 assert run('remote-readback',['git','ls-remote','https://github.com/luisitin/partybox-game-cores.git','refs/heads/'+branch]).split()[0]==head
 assert run('final-status',['git','status','--porcelain']).strip()==''
 interval=(datetime.fromisoformat(pushed)-datetime.fromisoformat('2026-10-09T08:26:38.304900+00:00')).total_seconds()
 status='CLOSED_PASS'
except BaseException as error:
 (base/'publish-failure.json').write_text(json.dumps({'at':utc(),'type':type(error).__name__,'error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':started,'closedAt':utc(),'oldHead':old,'head':locals().get('head'),'actualPushClosedAt':locals().get('pushed'),'sourceIntervalSeconds':locals().get('interval'),'hardCadenceMissSeconds':max(0,locals().get('interval',0)-1800),'children':children,'scope':'Normal material source push with genuine whole original a2d/current7fb and exact7fb official/fullnative/game/raw/frame/clip acceptance, full CRC/EOF/original readers/23physical guards/natural closures and a concrete byte-bound two-file startup integration draft. All old failed/unexecuted protocols and0824 executed raw receipts preserved with explicit prose erratum. Final supported original --sources/all349 unchanged runtime/source checks passed before commit; expected-parent normal FF with exact remote readback/clean worktree. This new head exactfull remains pending; private native experiment remains unadopted/unqualified pending independent parent review/new production checks.'}
 (base/'push-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
