"""One finite untimed strict compile and full original offline product build."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import ctypes, importlib.util, json, os, signal, subprocess, sys, time, traceback

JOB = Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers')
BASE = Path('/tmp/G10-integrated-offline-build-17d-20261009')
WORK = BASE / 'isolated-job'
NODE = JOB / '.work/memory-json-private/node22/runtime/bin/node'
HELPER = JOB / '.work/hosted-df-memory-parts-cd9/receive.py'
HTML = WORK / 'play.html'
OWNED_RSS_ENVELOPE = 1610612736
NEW_OUTPUT_RESERVATION = 1610612736
SHARED_RESERVE = 1610612736
WHOLE_WALL_SECONDS = 600
EXPECTED_HTML_BYTES = 1390847100
EXPECTED_HTML_SHA = 'b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2'
EXPECTED_HEAD = '17d6ff6cb34146e4f593c9c12d7167a87b39c99d'
env = dict(os.environ, GIT_DIR='/tmp/G10-local-d619-independent-20261009/repo/.git', GIT_WORK_TREE=str(JOB.parent.parent), GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1', TZ='UTC')
def utc(): return datetime.now(timezone.utc).isoformat()
def write(name, value): (BASE / name).write_text(json.dumps(value, indent=2) + '\n')
def digest(path):
    h = sha256()
    with path.open('rb') as source:
        while block := source.read(1 << 20): h.update(block)
    return h.hexdigest()
def identity(path):
    s = path.stat(); return {'dev': s.st_dev, 'ino': s.st_ino, 'bytes': s.st_size, 'mtimeNs': s.st_mtime_ns, 'ctimeNs': s.st_ctime_ns}
def resources():
    c = Path('/sys/fs/cgroup'); data = {k: int(v) for k, v in (line.split() for line in (c / 'memory.stat').read_text().splitlines())}
    maximum = int((c / 'memory.max').read_text()); current = int((c / 'memory.current').read_text())
    # Conservative accounting: explicitly subtract every SHMEM byte even from
    # the active/inactive-file sum. No slab/dirty/writeback or cache eviction.
    clean = max(0, data.get('active_file', 0) + data.get('inactive_file', 0) - data.get('shmem', 0) - data.get('file_dirty', 0) - data.get('file_writeback', 0))
    disk = os.statvfs(BASE)
    return {'actualUTC': utc(), 'cgroupMaxBytes': maximum, 'cgroupCurrentBytes': current, 'ordinaryCleanConservativeBytes': clean, 'boundedCleanCreditBytes': min(5 * 1024**3, clean), 'shmemExcludedBytes': data.get('shmem', 0), 'potentialCapacityBytes': maximum - current + min(5 * 1024**3, clean), 'tmpFreeBytes': disk.f_bavail * disk.f_frsize, 'requiredCapacityBytes': OWNED_RSS_ENVELOPE + NEW_OUTPUT_RESERVATION + SHARED_RESERVE, 'requiredDiskBytes': NEW_OUTPUT_RESERVATION + 128 * 1024**2}
def proc_rows():
    rows = {}
    for path in Path('/proc').glob('[0-9]*/stat'):
        try:
            text = path.read_text(); columns = text[text.rfind(')') + 2:].split()
            rows[int(path.parent.name)] = {'pid': int(path.parent.name), 'parent': int(columns[1]), 'state': columns[0], 'group': int(columns[2]), 'rssBytes': int(columns[21]) * os.sysconf('SC_PAGE_SIZE')}
        except (OSError, ValueError, IndexError): pass
    return rows
def owned(root):
    rows = proc_rows(); selected = {root}; changed = True
    while changed:
        changed = False
        for pid, row in rows.items():
            if row['parent'] in selected and pid not in selected: selected.add(pid); changed = True
    return [rows[pid] for pid in selected if pid in rows]
def launch(name, args, cwd, limit, extra_env=None):
    at = utc(); samples = []; child = None; failed = False; code = None; began = time.monotonic()
    with (BASE / (name + '.stdout')).open('xb') as output, (BASE / (name + '.stderr')).open('xb') as error:
        try:
            child = subprocess.Popen(args, cwd=cwd, env=dict(env, **(extra_env or {})), stdout=output, stderr=error, start_new_session=True)
            while True:
                rows = owned(child.pid); rss = sum(row['rssBytes'] for row in rows)
                samples.append({'observedAt': utc(), 'ownedRssBytes': rss, 'owned': rows})
                assert rss <= OWNED_RSS_ENVELOPE, 'Prospective owned-descendant RSS envelope exceeded'
                code = child.poll()
                if code is not None: break
                assert time.monotonic() - began <= limit, 'Finite untimed child wall bound exceeded'
                time.sleep(0.05)
        except BaseException: failed = True; raise
        finally:
            closure = groups.close_worker_group(child, failed) if child else None
            write(name + '-closure.json', {'startedAt': at, 'closedAt': utc(), 'childWallSeconds': limit, 'rssEnvelopeBytes': OWNED_RSS_ENVELOPE, 'sampledPeakOwnedRssBytes': max((s['ownedRssBytes'] for s in samples), default=0), 'rssSamplingScope': 'Actual 50ms sleep plus scan/loop cost, sampled peak only; no exact frequency or instantaneous maximum claim.', 'closure': closure})
            write(name + '-rss.json', samples)
    assert code == 0 and closure['natural'] and not closure['actualRemainingGroup'], name

def main():
    def deadline(signum, frame): raise TimeoutError('Untimed full product build whole wall bound exceeded')
    signal.signal(signal.SIGALRM, deadline); signal.alarm(WHOLE_WALL_SECONDS)
    assert ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) == 0
    started = utc(); resource = resources(); write('resources-before.json', resource)
    assert resource['potentialCapacityBytes'] > resource['requiredCapacityBytes'] and resource['tmpFreeBytes'] > resource['requiredDiskBytes']
    assert subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD'], cwd=JOB, env=env).decode().strip() == EXPECTED_HEAD
    original = json.loads(Path('/tmp/G10-hosted-7fb-current7fb-20261009/extracted/.work/checks/stage-node.json').read_text())['sourceGuardsAfter']; assert len(original) == 349
    original.update({'src/browser.ts': 'bf8b12c6a389daa050f70f602e53480b506c0f4810288c24ebb6810a6aa477cf', 'scripts/build.mjs': '4d1ce03c9c546dac6d0763aca705f2555c638234f820f71dc5f93c1837c53885'})
    files = {relative: JOB / relative for relative in original}
    extras = {'controller': Path(__file__).resolve(), 'node': NODE, 'python': Path(sys.executable).resolve(), 'groupHelper': HELPER, 'typescriptCompiler': JOB / 'node_modules/typescript/lib/tsc.js', 'esbuildLibrary': JOB / 'node_modules/esbuild/lib/main.js', 'esbuildExecutable': JOB / 'node_modules/@esbuild/linux-x64/bin/esbuild', 'corpusPackHelper': JOB / 'scripts/corpus-pack.mjs'}
    files.update({name: path for name, path in extras.items()})
    def freeze():
        result = {}
        for name, path in files.items():
            sha = digest(path)
            if name in original: assert sha == original[name], 'Original source/runtime drift: ' + name
            result[name] = {'path': str(path), 'sha256': sha, 'identity': identity(path)}
        return result
    before = freeze(); write('source-self-runtime-before.json', before)
    assert before['node']['sha256'] == '8142d37c6f2f372ef040419e7a111a6baf17df89f8078d02447d6c639ae20c1d'
    old_html = JOB / '.work/play-full-candidate-b4.html'; old_stat = identity(old_html)
    assert old_stat['bytes'] == 1390846291 and digest(old_html) == 'b4f5267561bd95d68455ea5a83b936692b246d1a8ed936199c820e430a2da3eb'
    WORK.mkdir(exist_ok=False); (WORK / 'scripts').mkdir()
    for relative in ['scripts/build.mjs', 'scripts/corpus-pack.mjs']:
        raw = (JOB / relative).read_bytes(); (WORK / relative).write_bytes(raw)
    for name in ['src', 'data', 'node_modules', 'LICENSE']:
        (WORK / name).symlink_to(JOB / name, target_is_directory=(JOB / name).is_dir())
    write('isolated-input-layout.json', {'sourceReadOnlyByBuilder': ['src', 'data', 'node_modules', 'LICENSE'], 'originalSourceBeforeAfterEnforced': True, 'copiedExactScripts': ['scripts/build.mjs', 'scripts/corpus-pack.mjs'], 'allWrites': str(WORK), 'note': 'No permission/mtime/inode change is made to originals; canonical builder only opens source/data/deps for reading and writes new output in isolated/tmp.'})
    launch('strict-typescript', [str(NODE), 'node_modules/typescript/bin/tsc', '--noEmit'], JOB, 120)
    assert freeze() == before
    launch('complete-original-product-build', [str(NODE), 'scripts/build.mjs'], WORK, 300, {'G10_BUILD_BROWSER_ONLY': '1', 'G10_HTML_OUT': str(HTML)})
    assert HTML.stat().st_size == EXPECTED_HTML_BYTES and digest(HTML) == EXPECTED_HTML_SHA, 'Actual full product HTML differs from canonical measured candidate'
    actual_corpus = json.loads((WORK / 'dist/corpus-pack.json').read_text()); canonical_corpus = json.loads((JOB / '.work/international-ready-private/generated/dist/corpus-pack.json').read_text())
    assert actual_corpus == canonical_corpus, 'All original worker/data pack manifests must remain exactly equal'
    for variant, expected in actual_corpus['workers'].items():
        path = WORK / ('dist/worker-' + variant + '.mjs'); assert path.stat().st_size == expected['bytes'] and digest(path) == expected['sha256']
    assert (WORK / 'THIRD-PARTY-LICENSES.txt').read_bytes() == (JOB / '.work/international-ready-private/generated/THIRD-PARTY-LICENSES.txt').read_bytes()
    assert identity(old_html) == old_stat and digest(old_html) == 'b4f5267561bd95d68455ea5a83b936692b246d1a8ed936199c820e430a2da3eb'
    after = freeze(); assert after == before; write('source-self-runtime-final.json', {'status': 'PASS', 'closedAt': utc(), 'actual': after})
    write('controller.json', {'status': 'CLOSED_PASS', 'startedAt': started, 'closedAt': utc(), 'parentHead': EXPECTED_HEAD, 'fullActualHTMLPath': str(HTML), 'fullActualHTMLBytes': HTML.stat().st_size, 'fullActualHTMLSha256': EXPECTED_HTML_SHA, 'sourceRuntimeOriginalGuards': 349, 'intentionalCanonicalSourceChanges': ['src/browser.ts', 'scripts/build.mjs'], 'originalOtherGuardsUnchanged': 347, 'allSourceSelfRuntimeRows': len(before), 'allBeforeAfterEqual': before == after, 'originalUniqueHTMLStatUnchanged': True, 'physicalWorkerAndCorpusAndLicensesEqualCanonical': True, 'licensedFiles': 41, 'licensedParts': 1304, 'licensedDataBytes': 1006478762, 'scope': 'Actual strict original TypeScript compiler and canonical full offline product build through physical EOF/SHA, original full licensed data/workers/licenses intact. Untimed only: no browser/native observations/new player gain/retry. Existing independently accepted candidate measurements now bind the actual integrated source/output; fresh integrated original full CI/raw/frame/clip/delivery acceptance remains mandatory before qualified KEEP/Ready/done.'})
    print(json.dumps({'status': 'CLOSED_PASS', 'closedAt': utc(), 'htmlPath': str(HTML), 'htmlBytes': EXPECTED_HTML_BYTES, 'htmlSha256': EXPECTED_HTML_SHA, 'guardRows': len(before)}), flush=True)

if __name__ == '__main__':
    spec = importlib.util.spec_from_file_location('bounded_groups', HELPER); groups = importlib.util.module_from_spec(spec); spec.loader.exec_module(groups)
    try: main()
    except BaseException as error:
        write('failure.json', {'status': 'FAILED', 'closedAt': utc(), 'errorType': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc(), 'scope': 'Actual failed untimed product build preserved; no game/FPS/no-gain inference.'}); raise
    finally: signal.alarm(0)
