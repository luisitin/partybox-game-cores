from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256
from datetime import datetime, timezone
import json, shutil

JOB = Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers')
BASE = Path('/tmp/G10-product-checkpoint-0912')
OUT = JOB / 'evidence/checks/international-production-integration-0912'
build = Path('/tmp/G10-integrated-offline-build-17d-20261009')
actual = json.loads((build / 'controller.json').read_text()); owner = json.loads((build / 'owner-closure.json').read_text())
assert actual['status'] == 'CLOSED_PASS' and actual['allBeforeAfterEqual'] and actual['allSourceSelfRuntimeRows'] == 1341
assert owner['closure']['natural'] and owner['closure']['actualExitCode'] == 0 and not owner['closure']['actualRemainingGroup']
peer = Path('/tmp/G10-root-independent-native-review-20261009.json'); supplement = Path('/tmp/G10-root-native-peer-bridge-supplement-20261009.json')
sup = json.loads(supplement.read_text()); assert sup['originalReceiptPreservedByteExact'] and sup['all26WholeMembersRereadCRCAndOriginalHashesEqual']
assert sha256(peer.read_bytes()).hexdigest() == sup['originalReceiptSha256']
files = {}
for root, label in [(build, 'actual-untimed-full-product-build'), (Path('/tmp/G10-production-integration-17d-20261009'), 'actual-exact-two-file-adoption'), (Path('/tmp/G10-source-runtime-7fb-to17d-20261009'), 'fresh-original349-current17d-bridge'), (JOB / '.work/bridge-7fb-to17d-0859', 'fresh-bridge-source')]:
    for path in root.iterdir():
        if path.is_file(): files[label + '/' + path.name] = path
for name in ['dist/corpus-pack.json', 'THIRD-PARTY-LICENSES.txt']:
    files['actual-full-product-output-reports/' + name] = build / 'isolated-job' / name
for path in [peer, supplement, Path('/tmp/G10-root-independent-native-review-20261009.py'), Path('/tmp/G10-root-native-peer-bridge-supplement-20261009.py')]:
    if path.exists(): files['independent-peer-review-and-explicit-22-of26-erratum/' + path.name] = path
for name in ['final-source-proof.py', 'final-source-proof.json', 'publish.py', 'push-receipt.json']:
    files['actual-prior17d-source-publication/' + name] = Path('/tmp/G10-source-checkpoint-0851') / name
files['checkpoint-generator.actual.py'] = Path(__file__).resolve()
members = {}; zpath = BASE / 'proof.zip'
with ZipFile(zpath, 'x', ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(files.items()):
        raw = path.read_bytes(); archive.writestr(name, raw); members[name] = {'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}
assert zpath.stat().st_size < 3 * 1024**2
with ZipFile(zpath) as archive: assert archive.testzip() is None and len(archive.infolist()) == len(members)
meta = {'status': 'EXACT_REVIEWED_STARTUP_FIX_INTEGRATED_AND_PHYSICAL_FULL_BUILD_PASS_NEW_ORIGINAL_FULL_PENDING', 'builtAt': datetime.now(timezone.utc).isoformat(), 'proofZipBytes': zpath.stat().st_size, 'proofZipSha256': sha256(zpath.read_bytes()).hexdigest(), 'members': members, 'actualFullBuild': actual, 'rootMeasurementReview': {'originalReceiptSha256': sup['originalReceiptSha256'], 'supplementPreservesOriginalAndCorrectsPhysicalComparisonScope': True, 'originalAll26CRCAnd22Physical': True, 'freshRemainingFourPhysicalAt': sup['naturallyClosedAt']}, 'qualification': 'Root independently accepted both early firstlegal observations; product exact source applied09:03:16.651677 and complete physical output proved. Fresh integrated original full CI/native/raw/frame/clip/whole evidence and delivery remain mandatory before qualified KEEP gain/Ready/done. No new native timing comparison/retry.'}
OUT.mkdir(exist_ok=False); shutil.copyfile(zpath, OUT / 'proof.zip')
(OUT / 'archive.json').write_text(json.dumps(meta, indent=2) + '\n')
(OUT / 'README.md').write_text('# Actual International startup production integration\n\nThe exact reviewed two-file patch is now applied. Original strict TypeScript and the complete original offline builder passed; the actual physical1,390,847,100-byte output matches the measured canonical candidate SHA b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2. All1,341 source/self/compiler/runtime rows stayed equal, with precisely the two canonical source changes and347 original guards unchanged. All41 licensed files/1304parts/full six-piece data/workers/licenses stay exact; the older unique1.39GB file was preserved byte/stat unchanged. Large output is retained in/tmp and is not duplicated into the almost-full overlay.\n\nThe archive preserves the original independent accepted observation receipt and its explicit22physical/all26CRC scope correction. A fresh supplement actually compared the remainingfour complete bridge files without rewriting the earlier timestamp. Both observed startup gains are independently accepted; new integrated original full CI and delivery still gate qualified KEEP gain/Ready/done. No timing retry or new browser trial ran.\n')
text = '''# International startup fix integrated; fresh original production checks pending — 2026-10-09 09:12 UTC

The EXACT canonical two-file product patch was applied09:03:16.651677 after genuine exact7fb complete original acceptance, independent peer acceptance of BOTH observed early firstlegal gains, and a fresh accepted7fb→current17d immutable/physical349-source/runtime plus six-current-document bridge. Actual source is now browserbf8b12c6a389daa050f70f602e53480b506c0f4810288c24ebb6810a6aa477cf and builder4d1ce03c9c546dac6d0763aca705f2555c638234f820f71dc5f93c1837c53885, byte-identical to the measured canonical candidate. The fix announces International worker readiness after the complete real dictionary payload, and waits for valid missing source blocks only while the parser is loading. Original malformed/corrupt requests still fail; after parser completion original missing-data rejection remains unchanged. Core, strategy,6000-node budget, all six-piece source classes, original worker data, clocks and licenses remain unchanged.

Actual strict pinned Node22 TypeScript command `node node_modules/typescript/bin/tsc --noEmit` naturally passed09:09:27.712012, empty group/no signals, sampled peak289,529,856bytes. The EXACT original production builder ran in an isolated/tmp job with read-only source/data/dependency access and all output in/tmp, naturally passed09:09:40.761867, EXIT0/empty group/no signals/adopted esbuild process reaped with waitStatus0, sampled peak570,482,688bytes below the prospective1.5GiB owned compiler envelope. Actual full physical page is `/tmp/G10-integrated-offline-build-17d-20261009/isolated-job/play.html`,1,390,847,100bytes SHA256 b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2, equal to the complete canonical measured candidate through EOF. All actual worker outputs, complete corpus-pack manifest and license bytes equal canonical output:41licensed files/1304parts/1,006,478,762original licensed bytes. All1,341 source/self/compiler/declaration/runtime rows before==after, comprising349 original guards with EXACT two declared canonical source changes/347 unchanged. Old unique1,390,846,291-byte HTML SHA/stat stayed unchanged. Full controllerPASS09:09:46.807467 and natural ownerclosure09:09:47.240367.

The untimed build prospectively reserved1.5GiB owned compiler RSS,1.5GiB new physical/tmp outputs and1.5GiB shared reserve. Fresh09:09:13.440435 capacity5,629,337,600>4,831,838,208bytes and/tmpfree4,116,688,896>1,744,830,464bytes passed. It conservatively subtracted allSHMEM even from active/inactive-file sum, dirty/writeback excluded, cleancredit capped5GiB, no slab/cache eviction/cold-cache claim. This resource accounting is more conservative than the native protocol's ordinary active/inactive-file accounting; all original native360/440/540s/4.5GiB RSS/25ms observer/BOTH500ms gates remained unchanged. The build is untimed product/source verification, not another browser performance trial or a failed/no-gain round. First unexecuted build draft is preserved alongside the strengthened whole compiler-package guards.

ROOT independently accepted the one actual changed native experiment08:56:23.269203: desktop22,411.100→4,894ms (17,517.100ms observed reduction), phoneCPU4 82,975.800→9,503.5ms (73,472.300ms), both candidate firstlegal beforeDOMContentLoaded/baseline after and original500ms gates. Full4HTTP EOF/source hashes,8 original legal/state+independent6000-node detailedreport/RNG/sample-input replays,2751native source/runtime/self rows and natural closure passed; real native290,623.673423ms/independent Popen→exit306,260.740776ms stayed within360,000ms; sampled owned peak4,192,538,624bytes. This accepts those declared-profile observed measurements only, with no new timing retry, physical-phone/population/cold-cache/FPS claim.

The first peer receipt read/CRC/hashed all26 archive members but physically compared22 native/protocol members; its original all26physical label was an overclaim. Fresh supplement09:09:30.093653 actually compared the remaining4 complete bridge files, reread all26CRC/hashes and preserved all8 inputs. The original receipt SHA dafa565d69b44dacac2e8e1593aadf43c771a540d4b7a3d48b4f116b9131c807 remains byte-exact with explicit correction and fresh later timestamp. Original review/source/failed trials/fixtures and every old unexecuted protocol remain intact.

Fresh pre-adoption accepted7fb→17d bridge naturally PASS09:01:31.620453/all349including206 currentimmutable+physical originals/143runtime and6current immutable docs, all6helper/runtime/source inputs unchanged, group[]/no signals. Actual prior proof source17d6ff6cb34146e4f593c9c12d7167a87b39c99d normalpush08:56:39.975502/cleanread08:56:41.548222 had an honest1.670602second hard cadence miss; actual supported final source checks completed08:56:35.149706 and were not truncated. Own G10 mainrow92d0bf46eabf16a235a212f9c05c66a3b76526a3 against fresh3dea, row08:58:53Z, normalpush08:58:56.062312/readback-clean08:58:57.185993, allother rows/tree unchanged, lease released. The new proof-only17d workflow remains separately pending; it does not block this actual source fix because genuine7fb full plus current349/docs bridge established the unchanged implementation before adoption.

Renewed KEEP round1 is IN_PROGRESS: the worst startup weakness is fixed and measurements independently accepted, but0qualified player gains/0completed rounds/0consecutive no-gain until the newly integrated production original full workflow/whole official artifact/native/game/raw/frame/clip/source and delivery checks pass. PR10 Draft/open/unmerged. Permanent single-file full Release delivery is still open; configured native GitHub CLI now successfully reads this public repo and reports pushpermission, without manual credential recovery/injection. A qualified full Release upload can use the newly proved physical1.39GB file after original integrated gates. Existing temporary artifacts expire in seven days; exact new production standalone delivery remains independently pending. No unique source/data/raw/old page/proof/dependency was deleted or replaced.

Next: run the original supported final hash generator and `integrity.mjs --sources` against the NEW actual complete physical HTML, enforce only the exact2canonical source edits+347unchanged original guards, and normal-push this source milestone. Accept every actual new integrated original workflow stage and genuine whole official evidence through the unchanged reader adapted only for exact new source/output identity. Do not inherit new production acceptance from old7fb; any later comparison requires its own finite declared protocol/root grant. Once original integrated checks/delivery pass, qualify round1's actual gain, provide permanent full-page delivery and continue binding KEEP until three genuine consecutive no-player-gain rounds.

## Earlier checkpoints retained as history

'''
for name in ['NEXT.md', 'VERIFY.md']:
    path = JOB / name; path.write_text(text + path.read_text())
for name in ['LOOP.md', 'ASSUMPTIONS.md']:
    path = JOB / name; path.write_text(path.read_text() + '\n2026-10-09 09:12UTC — Renewed KEEP round1 IN_PROGRESS: exact International readiness/block-loading product fix applied09:03:16.651677, independently accepted controlled observed gains17,517.100ms desktop/73,472.300ms phoneCPU4; actual strict TypeScript and physical full1,390,847,100-byte canonical rebuild/all1,341 guards/natural closure PASS09:09:47.240367. Root22physical/all26CRC initial overclaim explicitly supplemented with fresh remaining4physical09:09:30, original bytes preserved. Fresh integrated original full CI and delivery still pending;0qualifiedgains/0completed/0consecutive no-gain.\n')
readme = '''# G10 Checkers

American8×8 and International10×10 for two seats, hot-seat or bots.
Both include all licensed2–6-piece endgame databases and draw rules.
The strong bot keeps its original6000-node alpha-beta search.

The reviewed startup fix lets either variant prepare its bot while the
complete offline page is still loading. International requests wait for
their actual source blocks; the complete data and search stay intact.
One controlled desktop/phoneCPU4 comparison observed the first legal
International move17.5s/73.5s sooner. Detailed evidence is in VERIFY.md.
The fix is integrated and its strict compiler/full offline build passed.
Fresh integrated original full CI, delivery and KEEP qualification remain
pending. PR #10 stays Draft/open; this is not a completion claim.

Requires Node22.16+ and pinned package-lock.json. From this directory:

```sh
npm ci --ignore-scripts
npm test
```

One read-only workflow runs Node, both2000-game leagues and original
browser checks on separate Ubuntu runners, each with a30-minute timeout.
All current stages, source hashes and original workloads must pass.
Download all four G10-standalone-part artifacts from that exact successful
run, extract into one folder and use their identical manifest/helper:

```sh
python3 standalone-parts.py join standalone-parts.json play.html
```

Open the resulting single play.html from disk; it makes no runtime calls.
Current integrated full page:1,390,847,100bytes; actual SHA-256:
b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2.
Historical full baseline:1,390,846,291bytes; SHA-256:
b4f5267561bd95d68455ea5a83b936692b246d1a8ed936199c820e430a2da3eb.
Artifacts expire after seven days; permanent Release delivery is pending.
Tracked play.html is the older2–5-piece baseline. Rebuild the full current
page with G10_HTML_OUT=/tmp/play-current.html npm run build, with enough
free disk and memory. All old failures and actual receipts stay preserved.

American data terms require Chinook/University of Alberta acknowledgement
and prohibit database sale. Ed Gilbert permits International distribution.
Original terms and Boost notices accompany source data and the full page.
Read RULES.md,SOURCES.md,CONFLICTS.md,VERIFY.md,BOTS.md and NEXT.md.
'''
assert len(readme.splitlines()) < 60; (JOB / 'README.md').write_text(readme)
print(json.dumps({'status': 'ACTUAL_INTEGRATED_PRODUCT_PROOF_PUBLIC_WRITES_CLOSED', 'closedAt': datetime.now(timezone.utc).isoformat(), 'archiveBytes': meta['proofZipBytes'], 'archiveSha256': meta['proofZipSha256'], 'members': len(members)}), flush=True)
