from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,zipfile
job=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers');base=job/'.work/international-ready-private/native-deferred-bounded-currenta2d';actual=Path('/tmp/G10-international-first-legal-deferred-bounded-a2d-20261009');draft=Path('/tmp/G10-integration-draft-7fb-20261009');archive=job/'evidence/checks/international-native-deferred-a2d-0824/proof.zip';out=Path('/tmp/G10-root-independent-native-review-20261009.json')
assert not out.exists();started=datetime.now(timezone.utc).isoformat()
inputs=[archive,Path(__file__).resolve(),*list(base.glob('*.json')),base/'observe.mjs',base/'controller.py',actual/'controller.json',actual/'actual/report.json',actual/'rss-samples.json',actual/'freeze-before.json',actual/'freeze-finally.json',actual/'actual/server.stdout',draft/'apply.patch',draft/'browser.ts',draft/'build.mjs',draft/'report.json',draft/'owner-closure.json']
freeze=lambda:{str(p):sha256(p.read_bytes()).hexdigest() for p in inputs};before=freeze()
assert archive.stat().st_size==764452 and before[str(archive)]=='719401b35bfe153e26907923b353209ad27dad411566ab36a69a5958f75ebfd3'
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==26 and len(set(z.namelist()))==26 and z.testzip() is None
 members={n:z.read(n) for n in z.namelist()}
 for n,b in members.items():
  if n.startswith('actual-one-native-experiment/'):assert b==(actual/n.removeprefix('actual-one-native-experiment/')).read_bytes()
  elif n.startswith('exact-granted-protocol/'):assert b==(base/n.removeprefix('exact-granted-protocol/')).read_bytes()
 hashes={n:sha256(b).hexdigest() for n,b in members.items()}
read=lambda p:json.loads(p.read_text());ready=read(base/'ready.json');spec=read(base/'freeze-spec.json');grant=read(base/'grant.json');c=read(actual/'controller.json');r=read(actual/'actual/report.json');b=read(actual/'freeze-before.json');f=read(actual/'freeze-finally.json');rss=read(actual/'rss-samples.json')
assert before[str(base/'ready.json')]=='cfc67179e9c9e933cd60b64930b6aeae99227303e4b137d4f6a871ce53c5769d' and before[str(base/'freeze-spec.json')]=='d52175aeee163c69e45e775d97dac4ab3bfcaefe34f1779ab3efe3b39ca35be2'
assert before[str(base/'observe.mjs')]=='1819b33b6d9525c02139e2c78655959ba85e56bbc407009304e7f1cea103a8fb' and before[str(base/'controller.py')]=='445b965d6fc8338acdab33665c89b6839e00b045213a9de22051eb72d6ecb9c4'
assert grant['status']=='ROOT_GRANTED' and ready['head']==c['head']==r['head']==grant['head']=='a2d7609eed63308290b3e8dee7e491d1896ef6d0'
assert ready['nonce']==grant['nonce']==c['rootGrantNonce']==r['rootGrantNonce'];assert grant['readySha256']==r['readySha256']==before[str(base/'ready.json')]
assert f['status']=='PASS' and f['actual']==b and b['files']==spec['files'] and len(b['files'])==2751
assert c['status']=='CLOSED_PASS' and c['fullFinalFreezePassed'];assert c['closure']['natural'] and c['closure']['actualExitCode']==0 and not c['closure']['actualRemainingGroup'] and not c['closure']['groupSignals'];assert c['closure']['allDetachedDescendants']['natural'] and not c['closure']['allDetachedDescendants']['signals'] and not c['closure']['allDetachedDescendants']['actualRemainingOwnedDescendants']
assert 0<=c['independentNativeDriverIntervalMs']<=360000 and 0<=r['nativeDriverElapsedMs']<=360000 and r['wholeNativeBudgetSatisfied'];assert c['nativeWaitBudgetSeconds']==360 and c['nativeChildWallBoundSeconds']==440 and c['wholeWallLimitSeconds']==540 and c['rssEnvelopeBytes']==4831838208 and c['sharedReserveBytes']==1610612736
assert rss['observedPeakSampledOwnedDescendantRssBytes']==max(x['actualSampledOwnedDescendantRssBytes'] for x in rss['samples'])<=4831838208
ack=read(actual/'browser-http-closure-ack.json');assert ack==r['beforePureCoreActualDescendantClosure'] and ack['status']=='ACTUAL_OWNED_DESCENDANTS_ONLY_NATIVE_NODE' and len(ack['processes'])==1 and ack['processes'][0]['pid']==ack['nodePid'] and ack['nonce']==ready['nonce'];assert r['pureReplayAfterAllBrowserAndServerClosures'] and r['serverClosure']=={'code':0,'signal':None}
lines=[json.loads(x) for x in (actual/'actual/server.stdout').read_text().splitlines()];last=lines[-1];assert lines[0]['status']=='LISTENING' and last['status']=='CLOSED' and len(last['requests'])==4
assert [x['variant'] for x in last['requests']]==['baseline','candidate','candidate','baseline'];assert [x['arm'] for x in r['profiles']]==['baseline','candidate','candidate','baseline'];assert len(r['profiles'])==4
for x in last['requests']:
 assert x['status']=='EMITTED_VERIFIED';expected=(r['baselineBytes'],r['baselineSha256']) if x['variant']=='baseline' else (r['candidateBytes'],r['candidateSha256']);assert (x['bytes'],x['wholeSha256'])==expected
gains=[]
for name in ['desktop','phone']:
 old=next(x for x in r['profiles'] if x['name']==name and x['arm']=='baseline');new=next(x for x in r['profiles'] if x['name']==name and x['arm']=='candidate')
 for x in [old,new]:
  assert not x['errors'] and not x['failedRequests'] and x['loaded']['readyState']=='complete' and x['loaded']['host']['preparedVariants']=={'american':True,'international':True};assert len(x['observer']['games'])==2 and all(y['trusted'] for y in x['observer']['events'])
  assert x['rate']==(1 if name=='desktop' else 4)
 for index in range(2):
  a=old['observer']['games'][index]['firstMove'];d=new['observer']['games'][index]['firstMove'];assert a['state']['ply']==d['state']['ply']==1 and a['host']['lastBotReport']==d['host']['lastBotReport'] and a['host']['botCursor']==d['host']['botCursor']
 a=old['observer']['games'][0]['firstMove'];d=new['observer']['games'][0]['firstMove'];gain=a['at']-d['at'];assert gain>=500 and d['at']<new['observer']['domContentLoaded']['at'] and new['observer']['games'][0]['clickAt']<new['observer']['domContentLoaded']['at'] and new['observer']['internationalBotStartEnabled']['at']<new['observer']['domContentLoaded']['at'] and a['at']>=old['observer']['domContentLoaded']['at'];gains.append({'name':name,'baselineObservedFirstLegalMs':a['at'],'candidateObservedFirstLegalMs':d['at'],'observedReductionMs':gain})
assert r['status']=='PASS' and r['playerGainPredicate'] and r['auditOutcome']=='PLAYER_GAIN_PREDICATE_PASSED_PENDING_INDEPENDENT_VALIDATION';assert (actual/'native.stderr').stat().st_size==(actual/'actual/server.stderr').stat().st_size==0
integration=read(draft/'report.json');owner=read(draft/'owner-closure.json');assert integration['status']=='PASS' and integration['before']==integration['after'] and owner['closure']['natural'] and not owner['closure']['actualRemainingGroup'];assert before[str(draft/'apply.patch')]=='e8733632021d8b272f2d73aa1b31d81c5b5c3d1696528d57fc427bd69077f8e3';assert before[str(draft/'browser.ts')]=='bf8b12c6a389daa050f70f602e53480b506c0f4810288c24ebb6810a6aa477cf' and before[str(draft/'build.mjs')]=='4d1ce03c9c546dac6d0763aca705f2555c638234f820f71dc5f93c1837c53885'
assert freeze()==before
receipt={'status':'ROOT_INDEPENDENT_SAVED_NATIVE_MEASUREMENT_ACCEPTED','startedAt':started,'naturallyClosedAt':datetime.now(timezone.utc).isoformat(),'sourceHead':ready['head'],'rootGrantNonce':ready['nonce'],'archiveSha256':before[str(archive)],'archiveBytes':764452,'all26WholeMembersReadCRCAndPhysicalByteEqual':True,'wholeMemberSha256':hashes,'all2751RecordedBeforeFinallySpecRowsIdentical':True,'allReaderInputsUnchanged':True,'readerInputCount':len(inputs),'nativeElapsedMs':r['nativeDriverElapsedMs'],'independentPopenToExitMs':c['independentNativeDriverIntervalMs'],'sampledPeakOwnedRssBytes':rss['observedPeakSampledOwnedDescendantRssBytes'],'rssSamples':len(rss['samples']),'gains':gains,'integrationPatchSha256':before[str(draft/'apply.patch')],'scope':'Fresh independent saved-only peer read; root already statically read all exact native code/protocol and full integration diff. Accept BOTH observed early-legal gains with unchanged full HTTP streams/search budget/equivalent bot reports/RNG/legal-state replay/natural empty closure/source guards. No timing rerun, clock substitution, physical-phone/population/cold-cache/FPS claim. Current7fb whole original still separately mandatory before product adoption; integrated production/new originalfull mandatory before qualified KEEP/Ready/done.'}
out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='wholeMemberSha256'}))
