from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,zipfile
old=Path('/tmp/G10-root-independent-native-review-20261009.json');bridge=Path('/tmp/G10-source-runtime-14e-toa2d-20261009');archive=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers/evidence/checks/international-native-deferred-a2d-0824/proof.zip');out=Path('/tmp/G10-root-native-peer-bridge-supplement-20261009.json')
assert not out.exists();started=datetime.now(timezone.utc).isoformat();names=['owner-closure.json','historical-git-guards.json','audit.stderr','audit.stdout'];inputs=[old,archive,Path(__file__).resolve(),*[bridge/n for n in names]]
freeze=lambda:{str(p):sha256(p.read_bytes()).hexdigest() for p in inputs};before=freeze();original=json.loads(old.read_text());checks={}
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==26 and len(set(z.namelist()))==26 and z.testzip() is None
 for n in z.namelist():assert sha256(z.read(n)).hexdigest()==original['wholeMemberSha256'][n]
 for n in names:
  member='current349-sixdoc-bridge/'+n;raw=z.read(member);physical=(bridge/n).read_bytes();assert raw==physical
  checks[member]={'actualPhysicalSource':str(bridge/n),'bytes':len(raw),'sha256':sha256(raw).hexdigest(),'wholeByteEqual':True}
 assert not z.read('current349-sixdoc-bridge/audit.stderr')
 json.loads(z.read('current349-sixdoc-bridge/owner-closure.json'));json.loads(z.read('current349-sixdoc-bridge/historical-git-guards.json'))
assert before==freeze()
receipt={'status':'ROOT_FRESH_FOUR_BRIDGE_PHYSICAL_BYTE_EQUAL_SUPPLEMENT_AND_PRECISE_ERRATUM','startedAt':started,'naturallyClosedAt':datetime.now(timezone.utc).isoformat(),'originalReceiptSha256':before[str(old)],'originalReceiptPreservedByteExact':True,'erratum':'Original08:56:23 receipt field all26WholeMembersReadCRCAndPhysicalByteEqual overclaimed its original physical comparison scope. That run read/CRC/hashed all26, but physically compared only22 native/protocol members. This fresh supplement now compares the remaining4 complete actual bridge files. No earlier timestamp or original field is silently rewritten.','originalScope':{'wholeMembersReadCRCAndHashed':26,'physicalMembersExplicitlyCompared':22},'supplement':checks,'all26WholeMembersRereadCRCAndOriginalHashesEqual':True,'allEightSupplementInputsUnchanged':before==freeze(),'scope':'Saved-only fresh physical binding; no native timing retry, no current349 source rerun or integrated-production full qualification. Prior independent observed gains remain accepted; new integrated original full remains mandatory before qualified KEEP/Ready.'}
out.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
