"""ONE root-granted finite native pair; source guards outside timing, no retries."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ctypes,importlib.util,json,os,signal,subprocess,sys,time,traceback
JOB=Path.cwd();BASE=JOB/'.work/international-ready-private/native-current-0f504-tmp'
OUT=Path('/tmp/G10-international-first-legal-0f504-20261009')
HEAD='0f504cad986f4282a383ea82e50fe2f8acd7458c';NODE=JOB/'.work/memory-json-private/node22/runtime/bin/node'
RSS_ENVELOPE=4608*1024**2;SHARED_RESERVE=1536*1024**2;MAX_CLEAN_FILE_CREDIT=4*1024**3
WHOLE_SECONDS=540;NATIVE_CHILD_SECONDS=440
started=None;child=None;before=None;failed=False;closure=None;samples=[]
def utc():return datetime.now(timezone.utc).isoformat()
def digest(p):
 h=sha256()
 with p.open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
def row(p):
 p=p.absolute();s=p.stat();return {'path':str(p),'resolved':str(p.resolve()),'sha256':digest(p),'identity':{'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}}
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def freeze(ready):
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==HEAD
 assert digest(BASE/'freeze-spec.json')==ready['freezeSpecSha256'],'Root-pinned frozen spec changed'
 spec=json.loads((BASE/'freeze-spec.json').read_text());actual={label:row(Path(r['path'])) for label,r in spec['files'].items()};assert actual==spec['files'],'Source/self/runtime/binary/input identity drift'
 for root,names in spec['inventories'].items():
  observed=[]
  for folder,dirs,files_ in os.walk(root,followlinks=True):
   for name in files_:
    p=Path(folder)/name
    if p.is_file():observed.append(str(p))
  assert sorted(observed)==names,'Installed/browser inventory drift: '+root
 assert ready['head']==HEAD and digest(BASE/'ready.json')==ready['expectedReadySha256FromGrant']
 for p,v in ready['fileHashes'].items():assert digest(Path(p))==v,p
 return {'specSha256':digest(BASE/'freeze-spec.json'),'files':actual,'readySha256':digest(BASE/'ready.json')}
def resources():
 p=Path('/sys/fs/cgroup');maximum=int((p/'memory.max').read_text());current=int((p/'memory.current').read_text());v={a:int(b) for a,b in (line.split() for line in (p/'memory.stat').read_text().splitlines())}
 clean=max(0,v['inactive_file']+v['active_file']-v.get('file_dirty',0)-v.get('file_writeback',0));credit=min(clean,MAX_CLEAN_FILE_CREDIT)
 stat=os.statvfs(OUT)
 return {'maxBytes':maximum,'currentBytes':current,'actualHeadroomBytes':maximum-current,'cleanOrdinaryFilePagesBytes':clean,'boundedPotentialReclaimCreditBytes':credit,'potentialCapacityBytes':maximum-current+credit,'diskFreeBytes':stat.f_bavail*stat.f_frsize,'note':'Only ordinary clean active/inactive file pages count as potentially reclaimable; shared-memory pages/dirty pages excluded. No page-cache eviction/drop, no cold-cache claim. Actual owned RSS monitored; resource failure makes ONE trial fail, never retry.'}
def descendants(parent):
 allrows={}
 for p in Path('/proc').glob('[0-9]*/stat'):
  try:
   v=p.read_text();f=v[v.rfind(')')+2:].split();rss_bytes=0
   if f[0]!='Z':rss_bytes=next(int(x.split()[1])*1024 for x in (p.parent/'status').read_text().splitlines() if x.startswith('VmRSS:'))
   allrows[int(p.parent.name)]={'pid':int(p.parent.name),'ppid':int(f[1]),'pgid':int(f[2]),'state':f[0],'startTicks':int(f[19]),'rssBytes':rss_bytes}
  except (OSError,ValueError,IndexError,StopIteration):pass
 owned={parent};changed=True
 while changed:
  previous=len(owned);owned.update(pid for pid,r in allrows.items() if r['ppid'] in owned);changed=len(owned)!=previous
 return [allrows[p] for p in sorted(owned-{parent}) if p in allrows]
def sampled_rss():
 rows=descendants(os.getpid());return {'at':utc(),'processes':rows,'actualSampledOwnedDescendantRssBytes':sum(r['rssBytes'] for r in rows)}
def reap_adopted():
 reaped=[]
 while True:
  try:pid,status=os.waitpid(-1,os.WNOHANG)
  except ChildProcessError:break
  if pid==0:break
  reaped.append({'pid':pid,'waitStatus':status})
 return reaped
def close_descendants(failure):
 signals=[];reaped=[]
 for sig in [signal.SIGTERM,signal.SIGKILL]:
  rows=descendants(os.getpid());live=[r for r in rows if r['state']!='Z']
  if live:
   assert failure,'Successful native child left active detached descendants; whole trial fails'
   for r in live:
    actual=next((v for v in descendants(os.getpid()) if v['pid']==r['pid']),None)
    if actual is not None and actual['startTicks']==r['startTicks']:
     try:os.kill(r['pid'],sig);signals.append({'pid':r['pid'],'startTicks':r['startTicks'],'signal':sig.name,'at':utc()})
     except ProcessLookupError:pass
   stop=time.monotonic()+3
   while time.monotonic()<stop and any(r['state']!='Z' for r in descendants(os.getpid())):time.sleep(.05)
  reaped.extend(reap_adopted())
 remaining=descendants(os.getpid());assert not remaining,'Actual owned detached descendants did not close'
 return {'actualRemainingOwnedDescendants':remaining,'signals':signals,'reapedAdopted':reaped,'natural':not signals}
def deadline(*_):raise TimeoutError('Finite540s entire granted native proof limit exceeded')
if __name__=='__main__':
 signal.signal(signal.SIGALRM,deadline);signal.alarm(WHOLE_SECONDS)
 assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
 grant=json.loads((BASE/'grant.json').read_text());raw=json.loads((BASE/'ready.json').read_text())
 assert grant['status']=='ROOT_GRANTED' and grant['head']==HEAD and grant['nonce']==raw['nonce'] and grant['readySha256']==digest(BASE/'ready.json')
 assert raw['outputRoot']==str(OUT) and OUT.is_dir() and not any(OUT.iterdir()),'Fresh private output directory must remain empty'
 ready={**raw,'expectedReadySha256FromGrant':grant['readySha256']};started=utc();helper=Path(raw['groupHelperPath']);assert digest(helper)=='dc9b18ff9f62430b51538c96f82cf691813f0ef3ff28a88112a70e67736fc241';s=importlib.util.spec_from_file_location('groups',helper);groups=importlib.util.module_from_spec(s);s.loader.exec_module(groups)
 try:
  assert not (OUT/'actual').exists() and not (OUT/'controller.json').exists(),'Preserve ONE original outcome; no unchanged timing retry'
  before=freeze(ready);write('freeze-before.json',before)
  initial=resources();assert initial['potentialCapacityBytes']>RSS_ENVELOPE+SHARED_RESERVE and initial['diskFreeBytes']>128*1024**2+16*1024**2
  write('resources-before.json',initial)
  with (OUT/'native.stdout').open('wb') as out,(OUT/'native.stderr').open('wb') as err:
   env={'PATH':'/usr/bin:/bin','TZ':'UTC','LANG':'C.UTF-8','G10_NATIVE_GRANT_NONCE':raw['nonce']}
   child=subprocess.Popen([str(NODE),str(BASE/'observe.mjs')],cwd=JOB,env=env,stdout=out,stderr=err,start_new_session=True)
   deadline_at=time.monotonic()+NATIVE_CHILD_SECONDS
   while child.poll() is None:
    observed=sampled_rss();samples.append(observed);assert observed['actualSampledOwnedDescendantRssBytes']<=RSS_ENVELOPE,'Actual owned native descendants including detached Chromium exceeded declared4.5GiB envelope'
    capacity=resources();assert capacity['potentialCapacityBytes']>SHARED_RESERVE,'Declared shared potential memory reserve disappeared'
    assert time.monotonic()<deadline_at,'Finite440s native child bound exceeded'
    time.sleep(.1)
   assert child.wait(timeout=3)==0,'Actual first native diagnostic failed; no unchanged retry'
  closure=groups.close_worker_group(child,False);assert closure['natural'] and not closure['actualRemainingGroup'];closure['allDetachedDescendants']=close_descendants(False)
  result=json.loads((OUT/'actual/report.json').read_text());assert result['status']=='PASS' and len(result['profiles'])==4
  assert (OUT/'native.stderr').stat().st_size==0
 except BaseException as e:
  failed=True;write('failure.json',{'status':'FAILED','at':utc(),'errorType':type(e).__name__,'error':str(e),'traceback':traceback.format_exc()});raise
 finally:
  try:
   if child is not None and closure is None:closure=groups.close_worker_group(child,True)
   if child is not None:closure['allDetachedDescendants']=close_descendants(failed)
   after=freeze(ready);assert before is not None and after==before
   write('freeze-finally.json',{'status':'PASS','closedAt':utc(),'actual':after})
  except BaseException as e:
   failed=True;write('freeze-finally.json',{'status':'FAILED','closedAt':utc(),'error':str(e)})
  write('rss-samples.json',{'observedPeakSampledOwnedDescendantRssBytes':max((r['actualSampledOwnedDescendantRssBytes'] for r in samples),default=0),'samples':samples,'scope':'Actual sampled complete transitive owned descendants including detached Chromium RSS100ms, not an exact instantaneous peak guarantee.'})
  result=json.loads((OUT/'actual/report.json').read_text()) if (OUT/'actual/report.json').exists() else None
  r={'status':'CLOSED_FAILED' if failed else 'CLOSED_PASS','startedAt':started,'closedAt':utc(),'head':HEAD,'rootGrantNonce':raw['nonce'],'actualNativeResult':result and {'status':result['status'],'playerGainPredicate':result.get('playerGainPredicate'),'gains':result.get('gains')},'closure':closure,'fullFinalFreezePassed':not failed,'nativeWaitBudgetSeconds':360,'nativeChildWallBoundSeconds':NATIVE_CHILD_SECONDS,'wholeWallLimitSeconds':WHOLE_SECONDS,'rssEnvelopeBytes':RSS_ENVELOPE,'sharedReserveBytes':SHARED_RESERVE,'scope':'ONE root-granted native International four-arm pair. No unchanged retries. Gain accepted only if both prospective predicates pass, whole original source/HTTP/legal/bot equivalence valid, natural empty-group closure and full final source/self/runtime freeze.'};write('controller.json',r);signal.alarm(0);print(json.dumps(r),flush=True)
  if failed:sys.exit(1)
