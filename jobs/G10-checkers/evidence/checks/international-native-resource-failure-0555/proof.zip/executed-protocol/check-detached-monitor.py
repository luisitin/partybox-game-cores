"""Untimed finite positive/negative lifecycle controls; never a browser trial."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ctypes,importlib.util,json,os,subprocess,sys,time,signal
BASE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('unexecuted_proposal',BASE/'controller.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
before={p.name:sha256(p.read_bytes()).hexdigest() for p in [BASE/'controller.py',Path(__file__)]};results=[]
started=datetime.now(timezone.utc).isoformat();signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('Finite15s detached monitor controls')));signal.alarm(15)
try:
 for name,duration,natural in [('natural',2,True),('failed-fixture-cleanup',60,False)]:
  target="import os,time; x=bytearray(8*1024*1024); print(os.getpid(),flush=True); time.sleep("+str(duration)+")"
  launcher="import subprocess,sys; p=subprocess.Popen([sys.executable,'-c',"+repr(target)+"],start_new_session=True); p.wait()"
  with (BASE/(name+'.stdout')).open('wb') as out,(BASE/(name+'.stderr')).open('wb') as err:
   child=subprocess.Popen([sys.executable,'-c',launcher],stdout=out,stderr=err,start_new_session=True)
   deadline=time.monotonic()+5
   while (BASE/(name+'.stdout')).stat().st_size==0:assert time.monotonic()<deadline;time.sleep(.02)
   detached=int((BASE/(name+'.stdout')).read_text().strip());snap=m.sampled_rss();rows=snap['processes'];leader=next(r for r in rows if r['pid']==child.pid);leaf=next(r for r in rows if r['pid']==detached)
   assert leaf['pgid']!=leader['pgid'] and leaf['rssBytes']>8*1024**2
   group_only=sum(r['rssBytes'] for r in rows if r['pgid']==child.pid);assert snap['actualSampledOwnedDescendantRssBytes']>group_only+8*1024**2
   if natural:
    assert child.wait(timeout=5)==0;closed=m.close_descendants(False);assert closed['natural'] and not closed['actualRemainingOwnedDescendants']
   else:
    closed=m.close_descendants(True);assert closed['signals'] and not closed['actualRemainingOwnedDescendants'];child.poll()
   results.append({'name':name,'status':'PASS','snapshot':snap,'wrongPgidOnlyBytes':group_only,'detachedLeafPid':detached,'closed':closed,'scope':'Deliberately controlled lifecycle fixture; not product/native player benchmark'})
 assert before=={p.name:sha256(p.read_bytes()).hexdigest() for p in [BASE/'controller.py',Path(__file__)]}
finally:signal.alarm(0)
report={'status':'PASS','startedAt':started,'closedAt':datetime.now(timezone.utc).isoformat(),'controls':results,'unchangedControllerSelfSha256':before,'scope':'Actual untimed finite two lifecycle controls prove detached descendant RSS inclusion and natural versus failure-only cleanup. Deliberately wrong PGID-only sum misses>8MiB in each real fixture. No native browser, elapsed player trial or gain.'};(BASE/'detached-controls.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'PASS','closedAt':report['closedAt'],'controls':len(results)}))
