"""Prepare exact immutable/current runtime READY; never starts native trial."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,os,subprocess,sys,uuid
JOB=Path.cwd();BASE=JOB/'.work/international-ready-private/native-current-961';HEAD='961d99254b06047922d93718d971b5b26c931264'
def digest(p):
 h=sha256()
 with p.open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
def row(p):
 p=p.absolute();s=p.stat();return {'path':str(p),'resolved':str(p.resolve()),'sha256':digest(p),'identity':{'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}}
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==HEAD
assert subprocess.check_output(['git','status','--porcelain'],text=True).strip()==''
assert not (BASE/'ready.json').exists(),'Never overwrite a prepared original READY'
oldspec=json.loads((JOB/'.work/international-ready-private/producer-spec-current-4369.json').read_text());files={}
for label,r in oldspec['files'].items():
 p=Path(r['path']);current=row(p)
 if label.startswith('doc:'):
  assert p.read_bytes()==subprocess.check_output(['git','cat-file','blob',HEAD+':jobs/G10-checkers/'+label.removeprefix('doc:')])
 else:assert current['sha256']==r['sha256'],label
 files[label]=current
roots=[JOB/'node_modules',Path('/home/agent/.cache/ms-playwright/chromium-1194'),Path('/home/agent/.cache/ms-playwright/chromium_headless_shell-1194')];inventories={}
for root in roots:
 paths=[]
 for folder,dirs,names in os.walk(root,followlinks=True):
  for name in names:
   p=Path(folder)/name
   if p.is_file():paths.append(str(p))
 inventories[str(root)]=sorted(paths)
 if root==roots[0]:assert inventories[str(root)]==oldspec['installedLogicalFiles']
 else:
  assert paths
  for path in paths:files['browser:'+path]=row(Path(path))
extra=[BASE/'controller-exact-closed-lifecycle-tested.py',BASE/'controller-guard-only-derivation.diff',BASE/'controller-guard-only-derivation.json',Path(__file__),BASE/'controller.py',BASE/'observe.mjs',BASE/'check-detached-monitor.py',BASE/'detached-controls.json',JOB/'.work/international-ready-private/delta-controls-4369.json',JOB/'.work/international-ready-private/generated/raw-output.json',JOB/'.work/international-ready-private/generated/candidate-bootstrap.js',JOB/'.work/international-ready-private/international-ready-marker.html',JOB/'.work/international-ready-private/http-current-72/server.mjs',JOB/'.work/international-ready-private/http-current-72/controller.json',JOB/'.work/hosted-72-final/controller.json',JOB/'.work/hosted-72-final/execution-freeze-finally.json',JOB/'.work/hosted-72-final/historical-git-guards.json',JOB/'.work/hosted-72-final/independent-complete-evidence.json',JOB/'.work/play-full-candidate-b4.html']
for p in extra:files['native:'+str(p)]=row(p)
controls=json.loads((BASE/'detached-controls.json').read_text());assert controls['status']=='PASS' and len(controls['controls'])==2
assert controls['unchangedControllerSelfSha256']['controller.py']!=digest(BASE/'controller.py'),'Controller gained inventory guard after initial closed lifecycle controls; record exact delta and recheck before grant'
proof=json.loads((JOB/'.work/hosted-72-final/controller.json').read_text());assert proof['status']=='CLOSED_PASS' and proof['head']=='72c2a917561f3ab5d4324554a1b40d06db1bc47f'
freeze=json.loads((JOB/'.work/hosted-72-final/execution-freeze-finally.json').read_text());assert freeze['status']=='PASS'
for p,v in files.items():assert row(Path(v['path']))==v,p
spec={'head':HEAD,'preparedAt':datetime.now(timezone.utc).isoformat(),'files':files,'inventories':inventories};(BASE/'freeze-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
ready={'status':'READY_NOT_RUN','preparedAt':datetime.now(timezone.utc).isoformat(),'nonce':'G10-international-first-legal-'+str(uuid.uuid4()),'head':HEAD,'acceptedNativeArtifactHead':'72c2a917561f3ab5d4324554a1b40d06db1bc47f','acceptedNativeArtifactId':11596193345,'acceptedNativeArtifactSha256':'ff597185bd68f2ac5862aabac1edef7c0007d16644884ee89015ec453e27fa33','explicitCurrentRuntimeGuardCount':349,'currentImmutableDocs':6,'frozenFiles':len(files),'browserFileCounts':{k:len(v) for k,v in inventories.items() if 'ms-playwright' in k},'fileHashes':{v['path']:v['sha256'] for v in files.values()},'freezeSpecSha256':digest(BASE/'freeze-spec.json'),'manifestPath':str(JOB/'.work/international-ready-private/delta-controls-4369.json'),'serverPath':str(JOB/'.work/international-ready-private/http-current-72/server.mjs'),'groupHelperPath':str(JOB/'.work/hosted-df-memory-parts-cd9/receive.py'),'wholeTrialTimeoutMs':360000,'controllerWholeWallSeconds':540,'nativeChildWallSeconds':440,'ownedDescendantRssEnvelopeBytes':3*1024**3,'sharedReserveBytes':1536*1024**2,'maxPotentialCleanFileCreditBytes':4*1024**3,'diskReservePlusSmallReceiptsBytes':(128+16)*1024**2,'successPredicate':'Both profiles candidate trusted first legal International move before DOMContentLoaded and at least500ms earlier than baseline; baseline after DOMContentLoaded, exact bot report/cursor and replay equality; whole original EOF, zero page/request errors, natural process closure and all frozen inputs','scope':'Prepared only, no browser/trial executed. Four-arm desktop baseline/candidate then4x phone candidate/baseline, full licensed raw streams. A root grant pins exact ready SHA/nonce/current head after fresh global quiet and resource recheck. The controller includes all detached Chromium descendants in RSS and natural closure; closed earlier two lifecycle fixtures tested the graph/cleanup before an additional installed-inventory guard. No full output allocation, fake clock/DOM/core/setState, unchanged timing retry, cold-cache, FPS or hardware maximum claim.'};(BASE/'ready.json').write_text(json.dumps(ready,indent=2)+'\n');print(json.dumps({k:v for k,v in ready.items() if k not in ['fileHashes']},indent=2));print('READY_SHA256:'+digest(BASE/'ready.json'))
