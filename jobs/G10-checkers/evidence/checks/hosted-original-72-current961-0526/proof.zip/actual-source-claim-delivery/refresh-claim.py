from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,signal,os,traceback
base=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers/.work/current-proof-checkpoint-0508')
repo=Path('/tmp/G10-main-refresh-0511');children=[];started=datetime.now(timezone.utc).isoformat();status='CLOSED_FAILED'
def utc():return datetime.now(timezone.utc).isoformat()
def members(group):
 rows=[]
 for p in Path('/proc').glob('[0-9]*/stat'):
  try:
   s=p.read_text();c=s[s.rfind(')')+2:].split()
   if int(c[2])==group:rows.append({'pid':int(p.parent.name),'state':c[0]})
  except (OSError,ValueError,IndexError):pass
 return rows
def run(name,args):
 r={'name':name,'command':args,'startedAt':utc(),'signals':[]};children.append(r)
 with (base/('main-'+name+'.stdout')).open('wb') as out,(base/('main-'+name+'.stderr')).open('wb') as err:
  child=subprocess.Popen(args,cwd=repo,stdout=out,stderr=err,start_new_session=True)
  try:child.wait(timeout=120);r['natural']=True
  finally:
   if child.poll() is None or members(child.pid):
    r['natural']=False
    for sig in [signal.SIGTERM,signal.SIGKILL]:
     if child.poll() is None or members(child.pid):
      try:os.killpg(child.pid,sig);r['signals'].append({'signal':sig.name,'at':utc()})
      except ProcessLookupError:pass
      try:child.wait(timeout=3)
      except subprocess.TimeoutExpired:pass
   child.wait(timeout=3);r.update({'closedAt':utc(),'exitCode':child.returncode,'remainingGroup':members(child.pid)})
 assert child.returncode==0 and r['natural'] and not r['remainingGroup'],r
 return (base/('main-'+name+'.stdout')).read_text()
try:
 assert json.loads((base/'push-receipt.json').read_text())['status']=='CLOSED_PASS'
 assert run('status-before',['git','status','--porcelain']).strip()==''
 assert run('branch',['git','branch','--show-current']).strip()=='main'
 run('pull',['git','pull','--ff-only','origin','main'])
 beforeHead=run('before-head',['git','rev-parse','HEAD']).strip()
 path=repo/'CLAIMS.md';before=path.read_bytes();lines=before.splitlines(keepends=True)
 ids=[i for i,line in enumerate(lines) if line.split() and line.split()[0]==b'G10'];assert len(ids)==1
 claimTime=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ');lines[ids[0]]=f'G10 {claimTime} codex-audit\n'.encode()
 after=b''.join(lines);assert [x for x in before.splitlines(keepends=True) if not (x.split() and x.split()[0]==b'G10')]==[x for x in after.splitlines(keepends=True) if not (x.split() and x.split()[0]==b'G10')]
 path.write_bytes(after);run('diff-check',['git','diff','--check'])
 assert run('changed',['git','diff','--name-only']).splitlines()==['CLAIMS.md']
 run('add',['git','add','CLAIMS.md']);run('commit',['git','commit','-m','claim G10'])
 head=run('head',['git','rev-parse','HEAD']).strip();run('push',['git','push','origin','main'])
 assert run('remote-readback',['git','ls-remote','origin','refs/heads/main']).split()[0]==head
 assert run('immutable-claims',['git','show',head+':CLAIMS.md']).encode()==after
 assert run('status-after',['git','status','--porcelain']).strip()==''
 status='CLOSED_PASS'
except BaseException as error:
 (base/'main-claim-failure.json').write_text(json.dumps({'at':utc(),'type':type(error).__name__,'error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':started,'closedAt':utc(),'beforeHead':locals().get('beforeHead'),'head':locals().get('head'),'claimTime':locals().get('claimTime'),'onlyG10Changed':status=='CLOSED_PASS','allOtherRowsByteEqual':status=='CLOSED_PASS','children':children,'scope':'Exclusive root-granted normal fast-forward G10-only main claim refresh after meaningful961d whole HTTP byte-proof source checkpoint; remote and immutable readback. Lease free only after actual closure.'}
 (base/'main-claim-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
