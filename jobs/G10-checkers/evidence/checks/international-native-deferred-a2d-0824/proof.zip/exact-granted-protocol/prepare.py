from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,os,subprocess,sys,uuid
JOB=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers');BASE=JOB/'.work/international-ready-private/native-deferred-bounded-currenta2d';HEAD='a2d7609eed63308290b3e8dee7e491d1896ef6d0';META=Path('/tmp/G10-local-d619-independent-20261009/repo/.git');OUT=Path('/tmp/G10-international-first-legal-deferred-bounded-a2d-20261009')
def digest(p):
 h=sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
def row(p):
 p=Path(p).absolute();s=p.stat();return {'path':str(p),'resolved':str(p.resolve()),'sha256':digest(p),'identity':{'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}}
def git(*args):return subprocess.check_output(['git','--git-dir='+str(META),'--work-tree='+str(JOB.parent.parent),*args],cwd=JOB,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain').strip()
assert not (BASE/'ready.json').exists() and not (BASE/'freeze-spec.json').exists()
assert OUT.is_dir() and not any(OUT.iterdir())
old=json.loads(Path('/tmp/G10-hash-memory-inquiry-56db-20261009/spec.json').read_text());files={};inventories=old['inventories']
for key,r in old['files'].items():
 actual=row(r['path'])
 if key.startswith('doc:'):assert sha256(git('cat-file','blob',HEAD+':jobs/G10-checkers/'+key[4:])).hexdigest()==actual['sha256']
 else:assert actual==r,key
 files[key]=actual
bridge=Path('/tmp/G10-source-runtime-14e-toa2d-20261009');b=json.loads((bridge/'historical-git-guards.json').read_text());assert b['status']=='PASS' and b['currentCheckoutPreserved']==HEAD and b['acceptedHead']=='14e739004efa2c27972bda6103ce2d81450a048c' and b['sourceGuardCount']==349 and len(b['sixCurrentDocumentationGitBridge'])==6
accepted=Path('/tmp/G10-hosted-14e-currenta2d-20261009');a=json.loads((accepted/'controller.json').read_text());assert a['status']=='CLOSED_PASS' and a['head']==b['acceptedHead']
extra=[*BASE.glob('*'),JOB/'.work/international-ready-private/native-deferred-bounded-current14e/observe.mjs',JOB/'.work/international-ready-private/native-deferred-bounded-current14e/controller.py',JOB/'.work/international-ready-private/native-deferred-bounded-current14e/ready.json',JOB/'.work/international-ready-private/native-deferred-bounded-current14e/freeze-spec.json',META/'HEAD',META/'refs/heads/job/G10-checkers-complete-20261008',META/'index',META/'config',META/'objects/info/alternates',JOB/'.work/international-ready-private/delta-controls-4369.json',JOB/'.work/international-ready-private/generated/raw-output.json',JOB/'.work/international-ready-private/generated/candidate-bootstrap.js',JOB/'.work/international-ready-private/international-ready-marker.html',JOB/'.work/international-ready-private/http-current-72/server.mjs',JOB/'.work/international-ready-private/http-current-72/controller.json',JOB/'.work/bridge-14e-toa2d-0802/audit.py',JOB/'.work/bridge-14e-toa2d-0802/identity-output-scope-only.diff',JOB/'.work/bridge-14e-toa2d-0802/additional-current-immutable-and-physical-source-guards.diff',*bridge.glob('*.json'),bridge/'audit.stdout',bridge/'audit.stderr',accepted/'controller.json',accepted/'execution-freeze-finally.json',accepted/'independent-complete-evidence.json',accepted/'historical-git-guards.json',accepted/'zip-integrity.json',accepted/'owner-closure.json']
for suffix in ['', '-v2','-v3']:
 root=Path('/tmp/G10-deferred-closure-barrier-controls-1120'+suffix+'-20261009')
 for folder,_,names in os.walk(root):
  for name in names:extra.append(Path(folder)/name)
for root in [Path('/tmp/G10-deferred-core-replay-d619-20261009'),Path('/tmp/G10-deferred-core-replay-d619-v2-20261009')]:
 for folder,_,names in os.walk(root):
  for name in names:extra.append(Path(folder)/name)
for root in [Path('/tmp/G10-native-budget-controls-14e-20261009'),Path('/tmp/G10-deferred-closure-barrier-controls-14e-bounded-v1-20261009')]:
 for folder,_,names in os.walk(root):
  for name in names:extra.append(Path(folder)/name)
for folder,_,names in os.walk(accepted):
 for name in names:
  p=Path(folder)/name
  if name!='official-reference.private.json':extra.append(p)
for p in extra:
 if p.is_file():files['prospective:'+str(p)]=row(p)
controls=json.loads(Path('/tmp/G10-deferred-closure-barrier-controls-14e-bounded-v1-20261009/controls.json').read_text());assert controls['status']=='PASS' and controls['sourceRuntimeByteEqual'] and len(controls['controls'])==2 and all(x['closure']['natural'] for x in controls['controls'])
for root,names in inventories.items():
 observed=[]
 for folder,_,names_ in os.walk(root,followlinks=True):
  for name in names_:
   p=Path(folder)/name
   if p.is_file():observed.append(str(p))
 assert sorted(observed)==names
for k,r in files.items():assert row(r['path'])==r,k
spec={'head':HEAD,'preparedAt':datetime.now(timezone.utc).isoformat(),'files':files,'inventories':inventories,'metadataSource':'Independent /tmp Git metadata; original full physical inputs; original owned/shared metadata unchanged','scope':'Fresh prospective SAME full licensed payload/source/runtime/six immutablea2d docs, actual saved8 replay proof plus barrier fixtures/failed predecessors. NO native execution. Source/full runtime accepted14e explicitly bridged toa2d; exacta2d whole proof still separate required before exact root grant.'};(BASE/'freeze-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
budget=json.loads(Path('/tmp/G10-native-budget-controls-14e-20261009/controls.json').read_text());assert budget['status']=='PASS' and budget['allByteEqual']
oldready=json.loads((JOB/'.work/international-ready-private/native-current-0f504-tmp/ready.json').read_text())
ready={**oldready,'experimentalEligibilityOnly':'Root maygrant exactlyfrozen currenta2d experimental protocol after accepted14e whole/349+sixa2d docs/currentREADY/resource/quiet/staticreview. Currenta2d fulloriginal remains separatepending, experiment doesnotinheritthatacceptance orqualifiedKEEP/adoption/done.','status':'READY_NOT_RUN_PENDING_EXACT_CURRENT_FULL_AND_ROOT_GRANT','head':HEAD,'outputRoot':str(OUT),'preparedAt':datetime.now(timezone.utc).isoformat(),'nonce':'G10-international-deferred-bounded-actual-closure-'+str(uuid.uuid4()),'acceptedNativeArtifactHead':b['acceptedHead'],'acceptedNativeArtifactId':11602463170,'acceptedNativeArtifactSha256':'007bc499ea8daa9b27b6ac08eed6322ab3525d9db580ef8713da2bd489edaa94','explicitCurrentRuntimeGuardCount':349,'currentImmutableDocs':6,'frozenFiles':len(files),'fileHashes':{r['path']:r['sha256'] for r in files.values()},'freezeSpecSha256':digest(BASE/'freeze-spec.json'),'browserFileCounts':{k:len(v) for k,v in inventories.items() if 'ms-playwright' in k},'materialSchedulingProof':'Saved real historical8 games all2370EOF/full originallegal/state/detailed6000report/RNG/sampleInput canonicaldc268a96e9dbdb1515813824ad0dd47ca80d25dffde1cdfa09485ef3519db621; final2384PASS/naturalboth. First extra preclick assumption failure retained. New closure method genuine latched detached-process controls PASS with source/runtime before==after; both original invalid fixture failures retained. Final native performance.now<=360000ms AFTER all pure imports/replays and independent controller actual Popen-to-Node-exit monotonic interval<=360000ms strengthened with actual constant-boundary/syntax/schema checks; prospective1120 gap preserved UNEXECUTED.','processBarrierBeforePureCore':'All4awaited context/browser closes, wholeHTTPserver closed EXIT0/EOF first. Fresh root controller transitive subreaper /proc must contain only original native Node (adopted zombies reaped individually, no signals), nonce/PID/head-bound ack before same completefullcore+samebots imports. Finite10s within unchanged original360s budget; extra lifecycle predicate strengthens observation validity.','exactCurrentOriginalWorkflowRun':37901846896,'exactCurrentOriginalFullAcceptance':'PENDING; no metadata-only/native/clock/gain inference','lastGenuineOriginalFullAcceptance':{'head':'14e739004efa2c27972bda6103ce2d81450a048c','runId':37899274656,'officialArtifactId':11602463170,'officialBytes':10716756,'officialSha256':'007bc499ea8daa9b27b6ac08eed6322ab3525d9db580ef8713da2bd489edaa94','naturalOwnerClosedAt':'2026-10-09T07:59:23.683643+00:00','all349AndCurrentA2dSixDocsExplicitBridge':True},'finalNativeBudgetPredicate':'Same360000ms native performance.now elapsed check AFTER all full-core imports/all8replays plus independent controller actual monotonic interval immediately beforePopen through naturalexit<=360000ms (100ms poll conservative upperbound inclstartup/hash/observer/browser/EOF/barrier/replay). Same440s child/540s controller; no original gate relaxed.','auditOutcomeSemantics':'PASS is valid audit completed. False playerGainPredicate explicitly AUDIT_COMPLETED_NO_PLAYER_GAIN; failed/resource/budget/unexecuted trials count as neither accepted player gain nor formal no-gain KEEP. True predicate pending independent validity/adoption review.','scope':'UNEXECUTED prospective materially changed allocation schedule only. Original0f504 resource-failed outcome/cap4.5GiB/360/440/540/native25ms observer/seed6000/fulllicensedbytes/crossoverworkload/BOTHprofile500ms unchanged. No retries unchanged timing; root must statically read whole corrected141driver/141controller and identity-only/final-budget diffs/proof, independently accept genuine exacta2d complete original full result, verify fresh quiet/resources/currentREADY SHA/nonce before an exact distinct one-attempt grant. No Ready-to-merge/adoption/KEEP gain.'}
assert ready['ownedDescendantRssEnvelopeBytes']==4831838208 and ready['wholeTrialTimeoutMs']==360000 and ready['nativeChildWallSeconds']==440 and ready['controllerWholeWallSeconds']==540
(BASE/'ready.json').write_text(json.dumps(ready,indent=2)+'\n')
r={'status':ready['status'],'preparedAt':ready['preparedAt'],'head':HEAD,'nonce':ready['nonce'],'readySha256':digest(BASE/'ready.json'),'controllerSha256':digest(BASE/'controller.py'),'driverSha256':digest(BASE/'observe.mjs'),'specSha256':digest(BASE/'freeze-spec.json'),'frozenFiles':len(files),'outputEmpty':not any(OUT.iterdir()),'exactCurrentOriginalFullAcceptance':'PENDING'}
(BASE/'prepare-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
