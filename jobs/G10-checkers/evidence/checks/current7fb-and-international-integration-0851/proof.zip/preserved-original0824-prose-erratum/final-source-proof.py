from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import subprocess,json,os,traceback,signal,time
base=Path('/tmp/G10-source-checkpoint-0824');node=Path('.work/memory-json-private/node22/runtime/bin/node')
def utc():return datetime.now(timezone.utc).isoformat()
def digest(path):
 h=sha256()
 with path.open('rb') as source:
  while b:=source.read(1<<20):h.update(b)
 return h.hexdigest()
def members(group):
 rows=[]
 for q in Path('/proc').glob('[0-9]*/stat'):
  try:
   v=q.read_text();cols=v[v.rfind(')')+2:].split()
   if int(cols[2])==group:rows.append({'pid':int(q.parent.name),'state':cols[0]})
  except (OSError,ValueError,IndexError):pass
 return rows
started=utc();before=digest(node);assert before=='8142d37c6f2f372ef040419e7a111a6baf17df89f8078d02447d6c639ae20c1d';children=[];status='CLOSED_FAILED'
try:
 env=os.environ.copy();env['G10_HTML_PATH']='.work/play-full-candidate-b4.html'
 for name,args in [('hashes-final',[str(node),'scripts/hashes.mjs']),('integrity-final',[str(node),'scripts/integrity.mjs','--sources'])]:
  record={'name':name,'command':args,'startedAt':utc(),'signals':[]};children.append(record)
  with (base/(name+'.stdout')).open('wb') as out,(base/(name+'.stderr')).open('wb') as err:
   child=subprocess.Popen(args,env=env,stdout=out,stderr=err,start_new_session=True)
   code=None
   try:code=child.wait(timeout=120);record['natural']=True
   finally:
    remaining=members(child.pid)
    if child.poll() is None or remaining:
     record['natural']=False
     try:os.killpg(child.pid,signal.SIGTERM);record['signals'].append({'signal':'SIGTERM','at':utc()})
     except ProcessLookupError:pass
     try:child.wait(timeout=3)
     except subprocess.TimeoutExpired:pass
     if members(child.pid):
      try:os.killpg(child.pid,signal.SIGKILL);record['signals'].append({'signal':'SIGKILL','at':utc()})
      except ProcessLookupError:pass
    child.wait(timeout=3);record.update({'closedAt':utc(),'exitCode':child.returncode,'remainingGroup':members(child.pid)})
  assert code==0 and record['natural'] and not record['remainingGroup']
 assert (base/'integrity-final.stdout').read_text().startswith('PASS: checksums, authoritative schemas/manifest')
 assert (base/'integrity-final.stderr').stat().st_size==0 and digest(node)==before
 guards=json.loads(Path('.work/hosted-df-browser/extracted/.work/checks/stage-browser.json').read_text())['sourceGuardsAfter'];assert len(guards)==349
 for relative,expected in guards.items():assert digest(Path(relative))==expected,relative
 changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
 untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
 for x in changed+untracked:
  y=x.removeprefix('jobs/G10-checkers/')
  assert y in ['README.md','ASSUMPTIONS.md','LOOP.md','NEXT.md','SHA256SUMS.txt','VERIFY.md'] or y.startswith('evidence/checks/international-native-deferred-a2d-0824/'),x
 status='CLOSED_PASS'
except BaseException as error:
 (base/'final-source-failure.json').write_text(json.dumps({'status':'FAILED','at':utc(),'type':type(error).__name__,'error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':started,'closedAt':utc(),'children':children,'nodeBeforeSha256':before,'nodeAfterSha256':digest(node),'finalManifestSha256':digest(Path('SHA256SUMS.txt')),'originalDfActualRuntimeSourceGuardCount':349,'originalImplementationUnchanged':status=='CLOSED_PASS','scope':'Final original checksum generator after every document/evidence write; exact supported original --sources proof, all349 actual df runtime/source hashes unchanged, changed tracked/untracked paths limited to README/ASSUMPTIONS/LOOP/NEXT/VERIFY plus checksum and the exact international-native-deferred-a2d-0824 actual materially corrected final360000ms native and independent controller predicates plus constantboundary/schema/actual latched process-closure controls and349physical/currentimmutable/sixdoc bridge; exact14e completewholeproof pending at publication, genuine1120 historicalwholeproof preserved with every failure retained. Current-head independent fullCI/artifact reception remain separate.'};(base/'final-source-proof.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
