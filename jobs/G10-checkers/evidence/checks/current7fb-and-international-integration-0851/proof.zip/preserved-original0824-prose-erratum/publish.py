from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,signal,os,traceback
base=Path('/tmp/G10-source-checkpoint-0824')
branch='job/G10-checkers-complete-20261008'
old='a2d7609eed63308290b3e8dee7e491d1896ef6d0'
started=datetime.now(timezone.utc).isoformat();children=[];status='CLOSED_FAILED'
def utc():return datetime.now(timezone.utc).isoformat()
def members(group):
 rows=[]
 for p in Path('/proc').glob('[0-9]*/stat'):
  try:
   s=p.read_text();c=s[s.rfind(')')+2:].split()
   if int(c[2])==group:rows.append({'pid':int(p.parent.name),'state':c[0]})
  except (OSError,ValueError,IndexError):pass
 return rows
def run(name,args,limit=120):
 r={'name':name,'command':args,'startedAt':utc(),'signals':[]};children.append(r)
 with (base/(name+'.stdout')).open('wb') as out,(base/(name+'.stderr')).open('wb') as err:
  child=subprocess.Popen(args,stdout=out,stderr=err,start_new_session=True)
  try:child.wait(timeout=limit);r['natural']=True
  finally:
   if child.poll() is None or members(child.pid):
    r['natural']=False
    for sig in [signal.SIGTERM,signal.SIGKILL]:
     if child.poll() is None or members(child.pid):
      try:os.killpg(child.pid,sig);r['signals'].append({'signal':sig.name,'at':utc()})
      except ProcessLookupError:pass
      try:child.wait(timeout=3)
      except subprocess.TimeoutExpired:pass
   child.wait(timeout=3);r.update({'closedAt':utc(),'exitCode':child.returncode,'remainingGroup':members(child.pid)})
 assert child.returncode==0 and r['natural'] and not r['remainingGroup'],r
 return (base/(name+'.stdout')).read_text()
try:
 assert json.loads((base/'final-source-proof.json').read_text())['status']=='CLOSED_PASS'
 assert run('pre-head',['git','rev-parse','HEAD']).strip()==old
 assert run('pre-branch',['git','branch','--show-current']).strip()==branch
 run('diff-check',['git','diff','--check'])
 run('add',['git','add','README.md','ASSUMPTIONS.md','LOOP.md','NEXT.md','SHA256SUMS.txt','VERIFY.md','evidence/checks/international-native-deferred-a2d-0824'])
 run('commit',['git','commit','-m','G10 preserve actual controlled International experiment'])
 head=run('post-head',['git','rev-parse','HEAD']).strip();assert head!=old
 run('push',['git','push','https://github.com/luisitin/partybox-game-cores.git',branch])
 pushed=next(x['closedAt'] for x in children if x['name']=='push')
 assert run('remote-readback',['git','ls-remote','https://github.com/luisitin/partybox-game-cores.git','refs/heads/'+branch]).split()[0]==head
 assert run('final-status',['git','status','--porcelain']).strip()==''
 interval=(datetime.fromisoformat(pushed)-datetime.fromisoformat('2026-10-09T07:55:30.018863+00:00')).total_seconds()
 status='CLOSED_PASS'
except BaseException as error:
 (base/'publish-failure.json').write_text(json.dumps({'at':utc(),'type':type(error).__name__,'error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':started,'closedAt':utc(),'oldHead':old,'head':locals().get('head'),'actualPushClosedAt':locals().get('pushed'),'sourceIntervalSeconds':locals().get('interval'),'hardCadenceMissSeconds':max(0,locals().get('interval',0)-1800),'children':children,'scope':'Normal material source push with exact new native-final360000ms and independent monotonic predicate source, actual constantboundary/schema/closure controls and349currentphysical/immutable/sixdocs bridge, all oldfailures retained. Original14e all4checks metadataSUCCESS butdelivery/wholebody/originalreader acceptance remain separatepending; genuine1120 actualwhole official/raw/frame/clip proof alreadypreserved after original final supported source checks; exact remote readback and clean working tree. New head full native acceptance remains pending; no production adoption or player gain.'}
 (base/'push-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
