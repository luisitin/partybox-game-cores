from pathlib import Path
import importlib.util,subprocess,json,datetime,os
job=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers');base=Path('/tmp/G10-integration-draft-7fb-20261009')
s=importlib.util.spec_from_file_location('groups',job/'.work/hosted-df-memory-parts-cd9/receive.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
env=dict(os.environ,GIT_DIR='/tmp/G10-local-d619-independent-20261009/repo/.git',GIT_WORK_TREE=str(job.parent.parent),GIT_OPTIONAL_LOCKS='0')
start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=None;failed=False
with (base/'owner.stdout').open('xb') as out,(base/'owner.stderr').open('xb') as err:
 try:
  p=subprocess.Popen(['/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12',str(base/'prove.py')],cwd=job,env=env,stdout=out,stderr=err,start_new_session=True);print(json.dumps({'status':'STARTED_UNTIMED_CANONICAL_PRODUCT_DIFF_BINDING','startedAt':start,'actualControllerPID':p.pid}),flush=True);code=p.wait(timeout=130)
 except BaseException:failed=True;raise
 finally:
  c=g.close_worker_group(p,failed) if p else None;r={'startedAt':start,'closedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'closure':c};(base/'owner-closure.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
assert code==0 and c['natural'] and not c['actualRemainingGroup'];print('ACTUAL_UNTIMED_OWNER_EXIT0_NATURAL',flush=True)
