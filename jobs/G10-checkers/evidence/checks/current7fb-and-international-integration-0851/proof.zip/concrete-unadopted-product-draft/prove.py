"""Untimed exact product-diff binding; never changes production source."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json, difflib, os, subprocess

JOB = Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers')
BASE = Path('/tmp/G10-integration-draft-7fb-20261009')
PRIVATE = JOB / '.work/international-ready-private'
HEAD = '7fb35165949521cbe84e98605228f9b60c85d896'
PYTHON = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
paths = {
    'self': Path(__file__).resolve(), 'python': PYTHON,
    'originalBrowser': JOB / 'src/browser.ts',
    'originalBuilder': JOB / 'scripts/build.mjs',
    'candidateBrowser': PRIVATE / 'browser-candidate.ts',
    'candidateBuilder': PRIVATE / 'build-candidate.mjs',
    'originalCandidateBrowserDiff': PRIVATE / 'browser-candidate.diff',
    'originalCandidateBuilderDiff': PRIVATE / 'build-candidate.diff',
    'candidateRawProducerReceipt': PRIVATE / 'generated/raw-output.json',
    'candidateCorpusManifest': PRIVATE / 'generated/dist/corpus-pack.json',
    'candidateOriginalDeltaProof': PRIVATE / 'delta-controls-4369.json',
    'candidateQueueBehaviorControls': PRIVATE / 'queue-controls.json',
    'nativeControllerReceipt': Path('/tmp/G10-international-first-legal-deferred-bounded-a2d-20261009/controller.json'),
    'nativeReady': PRIVATE / 'native-deferred-bounded-currenta2d/ready.json',
    'historicalWholeOriginalReceipt': Path('/tmp/G10-hosted-a2d-current7fb-20261009/controller.json'),
    'historicalWholeOriginalReader': Path('/tmp/G10-hosted-a2d-current7fb-20261009/independent-complete-evidence.json'),
}
def utc(): return datetime.now(timezone.utc).isoformat()
def row(path):
    s = path.stat(); h = sha256()
    with path.open('rb') as stream:
        while block := stream.read(1 << 20): h.update(block)
    return {'path': str(path), 'sha256': h.hexdigest(), 'identity': {'dev': s.st_dev, 'ino': s.st_ino, 'bytes': s.st_size, 'mtimeNs': s.st_mtime_ns, 'ctimeNs': s.st_ctime_ns}}
def freeze(): return {name: row(path) for name, path in paths.items()}
started = utc(); before = freeze(); status = 'FAILED'; calls = []
env = dict(os.environ, GIT_DIR='/tmp/G10-local-d619-independent-20261009/repo/.git', GIT_WORK_TREE=str(JOB.parent.parent), GIT_OPTIONAL_LOCKS='0')
def git(args):
    at = utc(); p = subprocess.run(['/usr/bin/git', *args], cwd=JOB, env=env, capture_output=True, timeout=15)
    calls.append({'args': args, 'startedAt': at, 'closedAt': utc(), 'exitCode': p.returncode})
    assert p.returncode == 0 and not p.stderr, 'Git read failed'
    return p.stdout
try:
    assert git(['rev-parse', 'HEAD']).decode().strip() == HEAD
    assert git(['status', '--porcelain']).strip() == b''
    for name, relative in [('originalBrowser', 'src/browser.ts'), ('originalBuilder', 'scripts/build.mjs')]:
        original = git(['show', HEAD + ':jobs/G10-checkers/' + relative])
        assert original == paths[name].read_bytes(), 'Working original differs from immutable current source'
    raw = json.loads(paths['candidateRawProducerReceipt'].read_text())
    delta = json.loads(paths['candidateOriginalDeltaProof'].read_text())
    controls = json.loads(paths['candidateQueueBehaviorControls'].read_text())
    corpus = json.loads(paths['candidateCorpusManifest'].read_text())
    native = json.loads(paths['nativeControllerReceipt'].read_text())
    historical = json.loads(paths['historicalWholeOriginalReader'].read_text())
    assert raw['originalProductionBuilderSha256'] == before['originalBuilder']['sha256']
    assert raw['canonicalCandidateBuilderSha256'] == before['candidateBuilder']['sha256']
    assert raw['candidateBrowserSourceSha256'] == before['candidateBrowser']['sha256'] == controls['candidateSha256']
    assert controls['acceptedSourceSha256'] == before['originalBrowser']['sha256']
    assert controls['status'] == delta['status'] == historical['status'] == 'PASS'
    assert len(controls['controls']) == 12 and all(x['status'] == 'PASS' for x in controls['controls'])
    assert historical['head'] == 'a2d7609eed63308290b3e8dee7e491d1896ef6d0' and historical['currentCheckoutPreserved'] == HEAD
    assert native['status'] == 'CLOSED_PASS' and native['actualNativeResult']['playerGainPredicate']
    assert native['fullFinalFreezePassed'] and native['closure']['natural']
    assert raw['outputSha256'] == 'b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2'
    assert raw['outputBytes'] == 1390847100 and delta['baseSha256'] == 'b4f5267561bd95d68455ea5a83b936692b246d1a8ed936199c820e430a2da3eb'
    assert corpus['internationalOriginal']['maximumPieces'] == 6 and corpus['internationalOriginal']['parts'] == 1304
    assert len(corpus['internationalOriginal']['files']) == 41 and corpus['internationalOriginal']['dataBytes'] == 1006478762
    marker = 'if(name===\'tunstall-v2\')await append("<script>document.dispatchEvent(new Event(\'g10-international-worker-ready\'));</script>\\n");'
    original_builder = paths['originalBuilder'].read_text(); candidate_builder = paths['candidateBuilder'].read_text()
    assert candidate_builder.count(marker) == 1 and candidate_builder.replace(marker, '') == original_builder
    assert candidate_builder.index(marker) > candidate_builder.index("compressed.toString('base64')")
    assert candidate_builder.index(marker) < candidate_builder.index('for(const part of sourceParts)')
    drafts = []; diffs = []
    for name, dest, original_name in [('candidateBrowser', 'browser.ts', 'originalBrowser'), ('candidateBuilder', 'build.mjs', 'originalBuilder')]:
        raw_source = paths[name].read_bytes(); output = BASE / dest
        with output.open('xb') as stream: stream.write(raw_source)
        drafts.append(row(output))
        relative = 'src/browser.ts' if dest == 'browser.ts' else 'scripts/build.mjs'
        diff = ''.join(difflib.unified_diff(paths[original_name].read_text().splitlines(True), raw_source.decode().splitlines(True), fromfile='a/jobs/G10-checkers/' + relative, tofile='b/jobs/G10-checkers/' + relative))
        diffs.append(diff)
    with (BASE / 'apply.patch').open('x') as stream: stream.write(''.join(diffs))
    assert freeze() == before, 'Original/candidate/proof/self input drift'
    assert git(['status', '--porcelain']).strip() == b''
    status = 'PASS'
    result = {'status': status, 'startedAt': started, 'closedAt': utc(), 'currentHead': HEAD, 'before': before, 'after': freeze(), 'gitReadClosures': calls, 'concreteProductDrafts': drafts, 'patch': row(BASE / 'apply.patch'), 'candidateRawBytes': raw['outputBytes'], 'candidateRawSha256': raw['outputSha256'], 'historicalOriginalAcceptedHead': historical['head'], 'historicalOriginalCurrentDocBridge': historical['currentCheckoutPreserved'], 'scope': 'Untimed canonical exact integration-source binding. Concrete two-file draft is byte-identical to the canonical full producer and measured candidate source; original immutable current files remain unchanged. Existing 12 behavior controls/full byte-delta/native trial/full historical original receiver are referenced with frozen hashes, not rerun or reinterpreted. Exact current7fb original full, parent independent native review and actual adoption/new production checks remain required; zero qualified KEEP gains.'}
    (BASE / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': status, 'closedAt': result['closedAt'], 'currentHead': HEAD, 'candidateBrowserSha256': before['candidateBrowser']['sha256'], 'candidateBuilderSha256': before['candidateBuilder']['sha256'], 'productPatchSha256': result['patch']['sha256'], 'frozenFiles': len(before), 'productionUnchanged': True}), flush=True)
except BaseException as error:
    (BASE / 'failure.json').write_text(json.dumps({'status': 'FAILED', 'startedAt': started, 'closedAt': utc(), 'error': str(error), 'before': before, 'after': freeze()}, indent=2) + '\n')
    raise
