"""Publish actual original whole acceptance plus a byte-bound product draft."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from hashlib import sha256
from datetime import datetime, timezone
import json, shutil

JOB = Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers')
BASE = Path('/tmp/G10-checkpoint-0851')
OUT = JOB / 'evidence/checks/current7fb-and-international-integration-0851'
receivers = [
    ('historical-a2d-current7fb', Path('/tmp/G10-hosted-a2d-current7fb-20261009'), JOB / '.work/hosted-a2d-current7fb'),
    ('exact-current7fb', Path('/tmp/G10-hosted-7fb-current7fb-20261009'), JOB / '.work/hosted-7fb-current7fb'),
]
def utc(): return datetime.now(timezone.utc).isoformat()
def digest(path):
    h = sha256()
    with path.open('rb') as stream:
        while block := stream.read(1 << 20): h.update(block)
    return h.hexdigest()
def clean(value):
    if isinstance(value, dict):
        return {k: ('[public personal email omitted; actual original retained privately]' if k == 'email' and isinstance(v, str) and v else clean(v)) for k, v in value.items()}
    if isinstance(value, list): return [clean(v) for v in value]
    return value

files = {}; receipts = []
for label, actual, source in receivers:
    owner = json.loads((actual / 'owner-closure.json').read_text())
    control = json.loads((actual / 'controller.json').read_text())
    zip_proof = json.loads((actual / 'zip-integrity.json').read_text())
    reader = json.loads((actual / 'independent-complete-evidence.json').read_text())
    final = json.loads((actual / 'execution-freeze-finally.json').read_text())
    before = json.loads((actual / 'execution-freeze-before.json').read_text())
    assert owner['closure']['natural'] and owner['closure']['actualExitCode'] == 0 and not owner['closure']['actualRemainingGroup']
    assert control['status'] == 'CLOSED_PASS' and reader['status'] == 'PASS' and final['status'] == 'PASS'
    assert before == final['actual'] == json.loads((actual / 'execution-freeze-after.json').read_text())
    assert len(before['files']) == 23 and reader['stageGuardCount'] == 349 and zip_proof['safeUniqueMembers'] == 239
    assert reader['currentCheckoutPreserved'] == '7fb35165949521cbe84e98605228f9b60c85d896'
    official = actual / 'complete.zip'
    assert official.stat().st_size == zip_proof['zipBytes'] and digest(official) == zip_proof['zipSha256']
    receipts.append({'label': label, 'actualOwnerClosedAt': owner['closedAt'], 'originalAcceptedHead': reader['head'], 'currentDocRuntimeBridge': reader['currentCheckoutPreserved'], 'workflowRunId': zip_proof['workflowRunId'], 'officialArtifactId': zip_proof['artifactId'], 'actualWholeOfficialBytes': zip_proof['zipBytes'], 'actualWholeOfficialSha256': zip_proof['zipSha256'], 'actualWholeOfficialPath': str(official), 'actualOriginalReaderClosedAt': reader['closedAt'], 'fullPhysicalSelfFreezeRows': len(before['files']), 'officialBodyArchiveScope': 'Actual full HTTP body retained unchanged at the physical path above. Public small archive contains every native log/original reader/full CRC/EOF/source/runtime/closure receipt, while the already received complete official body is not duplicated because overlay has only about10MiB free. No body acceptance is inferred from metadata.'})
    for path in actual.iterdir():
        if path.is_file() and 'private' not in path.name and path.name != 'complete.zip': files[label + '/actual/' + path.name] = path
    for path in source.iterdir():
        if path.is_file(): files[label + '/unchanged-original-reader/' + path.name] = path

draft = Path('/tmp/G10-integration-draft-7fb-20261009')
binding = json.loads((draft / 'report.json').read_text())
assert binding['status'] == 'PASS' and binding['before'] == binding['after']
for path in draft.iterdir():
    if path.is_file(): files['concrete-unadopted-product-draft/' + path.name] = path
for name in ['final-source-proof.py', 'final-source-proof.json', 'publish.py', 'push-receipt.json']:
    files['preserved-original0824-prose-erratum/' + name] = Path('/tmp/G10-source-checkpoint-0824') / name
erratum = {
    'status': 'EXPLICIT_SCOPE_ERRATUM_ORIGINAL_BYTES_PRESERVED', 'recordedAt': utc(),
    'affectedOriginalFiles': ['/tmp/G10-source-checkpoint-0824/final-source-proof.py', '/tmp/G10-source-checkpoint-0824/final-source-proof.json', '/tmp/G10-source-checkpoint-0824/publish.py', '/tmp/G10-source-checkpoint-0824/push-receipt.json'],
    'actualScope': 'Those executed0824 scripts/receipts inherited0752 prose saying14e whole pending and1120 historical, although actual source was a2d, actual native protocol/complete trial had naturally closed08:23:12.909783, and genuine14e whole original had already closed07:59:23.683643 with explicit currenta2d bridge. The concrete source/docs/native grant/controller/archive and parent hash/readback fields remain definitive. Actual publication was7fb35165949521cbe84e98605228f9b60c85d896 at08:26:38.304900 after final source checks; exact hard cadence miss68.286037seconds. a2d original whole was genuinely accepted only later08:34:05.254852. This correction does not rewrite any executed source/raw receipt, infer earlier acceptance, or qualify the private gain.'
}
(BASE / '0824-scope-erratum.json').write_text(json.dumps(erratum, indent=2) + '\n')
files['explicit0824-erratum.json'] = BASE / '0824-scope-erratum.json'
files['checkpoint-generator.actual.py'] = Path(__file__).resolve()
zpath = BASE / 'proof.zip'; members = {}
with ZipFile(zpath, 'x', ZIP_DEFLATED, compresslevel=6) as archive:
    for name, path in sorted(files.items()):
        raw = path.read_bytes(); record = {'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}
        if name.endswith('/run-native.json'):
            record['originalPrivateNativeInputSha256'] = record['sha256']; raw = (json.dumps(clean(json.loads(raw))) + '\n').encode()
            record.update({'bytes': len(raw), 'sha256': sha256(raw).hexdigest(), 'publicPersonalEmailValuesOmitted': True})
        archive.writestr(name, raw); members[name] = record
assert zpath.stat().st_size < 3 * 1024**2
with ZipFile(zpath) as archive: assert archive.testzip() is None and len(archive.infolist()) == len(members)
meta = {'status': 'GENUINE_WHOLE_ORIGINALS_AND_CANONICAL_UNADOPTED_PRODUCT_DRAFT', 'builtAt': utc(), 'proofZipBytes': zpath.stat().st_size, 'proofZipSha256': digest(zpath), 'members': members, 'actualOriginalAcceptances': receipts, 'concreteProductBinding': binding, 'scopeErratum': erratum, 'adoptionAndKEEP': 'Pending parent independent native validation and product adoption/new production checks. Renewed round1 IN_PROGRESS;0completed/0qualifiedgains/0consecutive no-gain. No unchanged timing retry or new browser run.'}
OUT.mkdir(exist_ok=False); shutil.copyfile(zpath, OUT / 'proof.zip')
(OUT / 'archive.json').write_text(json.dumps(meta, indent=2) + '\n')
(OUT / 'README.md').write_text('# Genuine current original checks and concrete startup fix\n\nThe small archive contains both actual whole original acceptances, every native log and immutable reader/source/closure receipt, plus the canonical two-file product patch. Complete official ZIP bodies remain unchanged at the recorded physical paths; original size/SHA and all239 safe unique CRC/EOF checks were actually verified. They are not duplicated into the almost-full overlay.\n\nThe faster-start candidate remains private and unadopted pending independent native review and actual product adoption/new original production checks. The patch matches the exact measured/full-output candidate; full41 licensed files,1304parts, all six-piece data, worker bytes,6000-node strategy and clocks stay intact. Renewed KEEP round1 IN_PROGRESS,zero qualified gains or completed no-gain rounds. The original failed resource trial and all failed fixtures/old unexecuted protocols remain unchanged.\n\nThe copied0824 raw receipt scope labels are explicitly corrected without rewriting executed scripts/receipts. Actual7fb push08:26:38.304900 was68.286037seconds late; no timestamp or earlier acceptance is inferred.\n')
exact = receipts[1]; historical = receipts[0]
text = f'''# Complete original verification and concrete International startup patch — 2026-10-09 08:51 UTC

Genuine exact7fb original run{exact['workflowRunId']} / official{exact['officialArtifactId']} passed through actual HTTP200 whole body ({exact['actualWholeOfficialBytes']} bytes; SHA256 {exact['actualWholeOfficialSha256']}),239 safe unique ZIP CRC/EOF checks and the unchanged complete original reader. The owner naturally closed{exact['actualOwnerClosedAt']}, EXIT0, empty child group and no signals. All349 original immutable/runtime guards plus six current Git documents,91tests,25assertion-killed mutants,7000matrix games,1003seeds,10000independent move-oracle cases,4000true-terminal games/all80 byte-equal original raw files,60browser checks/all2400 original native intervals/2404timestamps and complete original/excerpt clips passed. All23 physical/self/runtime/input/isolated-metadata guards stayed equal before/after/final. Genuine historical a2d whole proof closed{historical['actualOwnerClosedAt']} with an explicit current7fb source/doc bridge; it remains separate from exact7fb acceptance.

The one changed-scheduling International startup experiment naturally passed08:23:12.909783. Observed first legal move reductions were17,517.100ms desktop and73,472.300ms phoneCPU4; both candidates played before DOMContentLoaded and passed the original500ms gates. All4 complete HTTP EOF/source hashes,8 original legal/state+independent6000-node fullreport/RNG/sample-input replays,2751final guards and natural empty descendant closure passed under unchanged360/440/540s and4.5GiB RSS limits. These observations remain a private unadopted candidate pending the parent's independent review and actual production integration/new original checks. No new native timing trial or unchanged retry ran.

Concrete patch evidence is in evidence/checks/current7fb-and-international-integration-0851/proof.zip. Untimed exact source binding passed08:43:47.000613 with all16 input/self/proof hashes unchanged and natural closure08:43:47.681428. Patch SHA256 e8733632021d8b272f2d73aa1b31d81c5b5c3d1696528d57fc427bd69077f8e3. Browser candidate bf8b12c6a389daa050f70f602e53480b506c0f4810288c24ebb6810a6aa477cf; builder4d1ce03c9c546dac6d0763aca705f2555c638234f820f71dc5f93c1837c53885, both byte-identical to the measured full producer candidate. Production remains unchanged. Complete41 licensed files/1304parts/1,006,478,762licensed bytes, all six-piece search data, original workers/licenses/6000-node strategy remain intact.

The source-proof/publication scripts and raw receipts from08:24 inherited07:52 scope prose; their exact original bytes are archived with an explicit correction. Actual source was a2d and complete native experiment already passed; genuine14e whole had closed07:59:23.683643, while genuine a2d whole was accepted only08:34:05.254852. Actual7fb normal push08:26:38.304900/clean readback08:26:42.677816 had a68.286037second hard cadence miss. Own-row mainb133350f2b9aacd1fb64975780224c257019658d refreshed08:29:52Z, normalpush08:29:54.486566/cleanread08:29:55.780561; all other rows/tree equal and lease released. Earlier failed trial/fixtures and all old unexecuted protocols are retained unchanged.

Renewed KEEP round1 remains IN_PROGRESS:0completed,0qualified player gains,0consecutive no-gain rounds. PR10 Draft/open/unmerged. Persistent single-file full offline Release delivery and binding KEEP through three consecutive genuine no-player-gain rounds remain open. Unique1.39GB original licensed HTML/all data/raw/proofs/dependencies remain untouched. Overlay had10,706,944bytes free at08:45; actual complete official ZIP bodies remain retained in/tmp, while the small public archive publishes every original reader/native log/EOF/CRC/source/closure receipt with exact body hashes. No deletion, fake completion, clock/workload/gate relaxation or gain qualification is inferred.

Resume: obtain parent independent native review, adopt only the exact canonical two-file patch after that gate, run every original new production check and delivery check, then continue KEEP. This material proof publication changes HEAD, so its new exact full original workflow remains separately pending; accepted7fb becomes historical with unchanged-runtime/current-document bridge required. Any new native timing protocol still requires its own fresh binding and explicit parent quiet grant.

## Earlier checkpoints retained as history

'''
for name in ['NEXT.md', 'VERIFY.md']:
    path = JOB / name; path.write_text(text + path.read_text())
for name in ['LOOP.md', 'ASSUMPTIONS.md']:
    path = JOB / name; path.write_text(path.read_text() + '\n2026-10-09 08:51UTC: genuine a2d/current7fb and exact7fb whole original acceptances archived; canonical source-bound two-file startup patch remains private/unadopted pending independent parent review/new production checks. Actual0824 receipt prose erratum preserved without rewriting raw bytes. KEEP round1 IN_PROGRESS/0completed/0qualifiedgains/0consecutive no-gain.\n')
print(json.dumps({'status': 'MATERIAL_PUBLIC_WRITES_CLOSED', 'closedAt': utc(), 'archiveBytes': meta['proofZipBytes'], 'archiveSha256': meta['proofZipSha256'], 'members': len(members)}), flush=True)
