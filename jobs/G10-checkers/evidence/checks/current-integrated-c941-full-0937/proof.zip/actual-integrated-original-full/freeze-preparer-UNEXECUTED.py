from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json
job=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers')
base=Path('/tmp/G10-hosted-c941-currentc941-20261009')
code=job/'.work/hosted-c941-currentc941'
oldbase=Path('/tmp/G10-hosted-7fb-current7fb-20261009')
expected=json.loads((oldbase/'execution-freeze.json').read_text())
oldjobs=json.loads((oldbase/'jobs-native.json').read_text())['jobs']
newjobs=json.loads((base/'jobs-native.json').read_text())['jobs']
assert len(newjobs)==5 and all(x['status']=='completed' and x['conclusion']=='success' for x in newjobs)
oldbyname={j['name']:j['id'] for j in oldjobs}
newbyname={j['name']:j['id'] for j in newjobs}
assert set(oldbyname)==set(newbyname)
idmap={str(v):str(newbyname[k]) for k,v in oldbyname.items()}
def digest(p):
 h=sha256()
 with p.open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
def row(p):
 p=p.absolute();s=p.stat()
 return {'path':str(p),'sha256':digest(p),'identity':{'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}}
files={}
for label,r in expected['files'].items():
 path=Path(r['path'])
 if str(path).startswith(str(oldbase)+'/'):path=base/path.name
 if label.startswith('job-'):label='job-'+idmap[label[4:]];path=base/(label+'.log')
 if label in ['controller','auditor','reader']:path=code/{'controller':'receive-complete.py','auditor':'audit-git-guards.py','reader':'validate-complete.mjs'}[label]
 files[label]=row(path)
assert len(files)==23
assert files['node']['sha256']=='8142d37c6f2f372ef040419e7a111a6baf17df89f8078d02447d6c639ae20c1d'
assert files['python']['sha256']=='fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7'
assert files['groupHelper']['sha256']=='dc9b18ff9f62430b51538c96f82cf691813f0ef3ff28a88112a70e67736fc241'
expected.update({'head':'c941c1bb18ccb37525c2e37248b0380ab1682e07','workflowRunId':37910650486,'currentCheckout':'c941c1bb18ccb37525c2e37248b0380ab1682e07','files':files,'scope':'Genuine exact new integrated c941 original whole hosted native/game/raw/frames/clips reception, original349 source/runtime/six-doc bindings. Original complete reader assertions/workloads/gates/inventory unchanged; only exact new HEAD/run/code/output identity/prose. The actual complete canonical physical page has1390847100 bytes/b85a828 SHA.23 source/self/input/runtime/binary/native-log/privateconfig/isolatedmetadata guards. No new native comparison, automatic KEEP qualification or permanent delivery acceptance.'})
(base/'execution-freeze.json').write_text(json.dumps(expected,indent=2)+'\n')
print(json.dumps({'status':'ACTUAL_COMPLETE_CURRENT_RECEIVER_FROZEN','frozenAt':datetime.now(timezone.utc).isoformat(),'head':expected['head'],'runId':expected['workflowRunId'],'frozenFiles':len(files),'controllerSha256':files['controller']['sha256'],'readerSha256':files['reader']['sha256']}),flush=True)
