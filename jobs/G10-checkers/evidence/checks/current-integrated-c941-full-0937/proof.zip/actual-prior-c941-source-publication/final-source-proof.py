from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import subprocess,json,os,traceback,signal,time
base=Path('/tmp/G10-product-source-checkpoint-0912');node=Path('.work/memory-json-private/node22/runtime/bin/node')
def utc():return datetime.now(timezone.utc).isoformat()
def digest(path):
 h=sha256()
 with path.open('rb') as source:
  while b:=source.read(1<<20):h.update(b)
 return h.hexdigest()
def members(group):
 rows=[]
 for q in Path('/proc').glob('[0-9]*/stat'):
  try:
   v=q.read_text();cols=v[v.rfind(')')+2:].split()
   if int(cols[2])==group:rows.append({'pid':int(q.parent.name),'state':cols[0]})
  except (OSError,ValueError,IndexError):pass
 return rows
started=utc();before=digest(node);assert before=='8142d37c6f2f372ef040419e7a111a6baf17df89f8078d02447d6c639ae20c1d';children=[];status='CLOSED_FAILED'
try:
 env=os.environ.copy();env['G10_HTML_PATH']='/tmp/G10-integrated-offline-build-17d-20261009/isolated-job/play.html'
 for name,args in [('hashes-final',[str(node),'scripts/hashes.mjs']),('integrity-final',[str(node),'scripts/integrity.mjs','--sources'])]:
  record={'name':name,'command':args,'startedAt':utc(),'signals':[]};children.append(record)
  with (base/(name+'.stdout')).open('wb') as out,(base/(name+'.stderr')).open('wb') as err:
   child=subprocess.Popen(args,env=env,stdout=out,stderr=err,start_new_session=True)
   code=None
   try:code=child.wait(timeout=120);record['natural']=True
   finally:
    remaining=members(child.pid)
    if child.poll() is None or remaining:
     record['natural']=False
     try:os.killpg(child.pid,signal.SIGTERM);record['signals'].append({'signal':'SIGTERM','at':utc()})
     except ProcessLookupError:pass
     try:child.wait(timeout=3)
     except subprocess.TimeoutExpired:pass
     if members(child.pid):
      try:os.killpg(child.pid,signal.SIGKILL);record['signals'].append({'signal':'SIGKILL','at':utc()})
      except ProcessLookupError:pass
    child.wait(timeout=3);record.update({'closedAt':utc(),'exitCode':child.returncode,'remainingGroup':members(child.pid)})
  assert code==0 and record['natural'] and not record['remainingGroup']
 assert (base/'integrity-final.stdout').read_text().startswith('PASS: checksums, authoritative schemas/manifest')
 assert (base/'integrity-final.stderr').stat().st_size==0 and digest(node)==before
 guards=json.loads(Path('.work/hosted-df-browser/extracted/.work/checks/stage-browser.json').read_text())['sourceGuardsAfter'];assert len(guards)==349
 assert 'src/browser.ts' in guards and 'scripts/build.mjs' in guards
 guards.update({'src/browser.ts':'bf8b12c6a389daa050f70f602e53480b506c0f4810288c24ebb6810a6aa477cf','scripts/build.mjs':'4d1ce03c9c546dac6d0763aca705f2555c638234f820f71dc5f93c1837c53885'})
 for relative,expected in guards.items():assert digest(Path(relative))==expected,relative
 assert digest(Path(env['G10_HTML_PATH']))=='b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2'
 changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
 untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
 for x in changed+untracked:
  y=x.removeprefix('jobs/G10-checkers/')
  assert y in ['README.md','ASSUMPTIONS.md','LOOP.md','NEXT.md','SHA256SUMS.txt','VERIFY.md','src/browser.ts','scripts/build.mjs'] or y.startswith('evidence/checks/international-production-integration-0912/'),x
 status='CLOSED_PASS'
except BaseException as error:
 (base/'final-source-failure.json').write_text(json.dumps({'status':'FAILED','at':utc(),'type':type(error).__name__,'error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':started,'closedAt':utc(),'children':children,'nodeBeforeSha256':before,'nodeAfterSha256':digest(node),'finalManifestSha256':digest(Path('SHA256SUMS.txt')),'originalDfActualRuntimeSourceGuardCount':349,'originalPureCoreStrategyCorpusRuntimeUnchanged':status=='CLOSED_PASS','intentionalCanonicalSourceEdits':['src/browser.ts','scripts/build.mjs'],'otherOriginalGuardsUnchanged':347,'scope':'Final original checksum generator after exact canonical two-file product fix/all evidence/docs writes; supported original --sources against NEW complete physical1,390,847,100-byte HTML/b85a828 SHA. All349 original source/runtime guards enforced with precisely2canonical source edits and347unchanged, exact changed paths/docs/evidence whitelist. Fresh strict compiler/full original physical rebuild and all1341source/compiler/self rows/natural closure passed. Both independently accepted native measurements and explicit original22physical/all26CRC review erratum+remaining4fresh physical supplement archived. New integrated source original full CI/native/raw/frame/clip/whole official/delivery acceptance remains mandatory before qualified KEEP/Ready/done; no new timing trial/retry.'};(base/'final-source-proof.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
