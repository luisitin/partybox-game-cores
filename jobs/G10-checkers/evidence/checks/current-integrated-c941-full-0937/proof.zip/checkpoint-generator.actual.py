from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from hashlib import sha256
from datetime import datetime,timezone
import json,re,shutil
JOB=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers')
BASE=Path('/tmp/G10-integrated-whole-checkpoint-0937')
HOST=Path('/tmp/G10-hosted-c941-currentc941-20261009')
OUT=JOB/'evidence/checks/current-integrated-c941-full-0937'
def load(name):return json.loads((HOST/name).read_text())
accepted=load('controller.json');whole=load('independent-complete-evidence.json');owner=load('owner-closure.json');zipproof=load('zip-integrity.json')
assert accepted['status']=='CLOSED_PASS' and accepted['head']=='c941c1bb18ccb37525c2e37248b0380ab1682e07'
assert whole['status']=='PASS' and whole['stageGuardCount']==349 and whole['htmlBytes']==1390847100 and whole['sourceSha256']=='b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2'
assert owner['closure']['natural'] and owner['closure']['actualExitCode']==0 and not owner['closure']['actualRemainingGroup']
assert load('execution-freeze-finally.json')['status']=='PASS'
assert load('execution-freeze-after.json')==load('execution-freeze-before.json')==load('execution-freeze-finally.json')['actual']
assert len(load('execution-freeze-before.json')['files'])==23 and zipproof['allMemberCRC']=='PASS'
files={}
for path in HOST.iterdir():
 if path.is_file() and path.name not in ['official-reference.private.json','complete.zip']:files['actual-integrated-original-full/'+path.name]=path
for path in (JOB/'.work/hosted-c941-currentc941').iterdir():
 if path.is_file():files['original-full-reader-exact-new-output-rebinding/'+path.name]=path
for name in ['final-source-proof.py','final-source-proof.json','publish.py','push-receipt.json']:
 files['actual-prior-c941-source-publication/'+name]=Path('/tmp/G10-product-source-checkpoint-0912')/name
files['actual-current-own-main-claim-receipt.json']=Path('/tmp/G10-main-refresh-c941-0924')/'receipt.json'
if not files['actual-current-own-main-claim-receipt.json'].is_file():del files['actual-current-own-main-claim-receipt.json']
files['checkpoint-generator.actual.py']=Path(__file__).resolve()
members={};omissions=[]
email=re.compile(rb'[A-Za-z0-9.!#$%&\'*+/=?^_{}|~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+')
zpath=BASE/'proof.zip'
with ZipFile(zpath,'x',ZIP_DEFLATED,compresslevel=6) as archive:
 for name,path in sorted(files.items()):
  original=path.read_bytes();published,count=email.subn(b'PUBLIC_EMAIL_REMOVED',original)
  if count:omissions.append({'member':name,'originalPrivateBytes':len(original),'originalPrivateSha256':sha256(original).hexdigest(),'emailValuesOmitted':count,'publicBytes':len(published),'publicSha256':sha256(published).hexdigest()})
  archive.writestr(name,published);members[name]={'bytes':len(published),'sha256':sha256(published).hexdigest()}
assert zpath.stat().st_size<2*1024**2
with ZipFile(zpath) as archive:assert archive.testzip() is None and len(archive.infolist())==len(members)
meta={'status':'GENUINE_INTEGRATED_C941_COMPLETE_ORIGINAL_ACCEPTED_DELIVERY_KEEP_PENDING','builtAt':datetime.now(timezone.utc).isoformat(),'head':accepted['head'],'workflowRunId':37910650486,'actualOriginalOwnerNaturallyClosedAt':owner['closedAt'],'officialWholeZip':zipproof,'originalFullIndependentReader':whole,'proofZipBytes':zpath.stat().st_size,'proofZipSha256':sha256(zpath.read_bytes()).hexdigest(),'members':members,'publicHygieneOmissions':omissions,'scope':'Genuine new integrated original whole artifact/239safeCRC/native/game/raw/frame/clip/349source/sixdocs/23self-input-runtime closures accepted. Actual raw complete official ZIP and original unredacted native logs remain physically preserved in/tmp. Two canonical product-source changes/347 original guards unchanged. Independently accepted observed both-profile gain is integrated; qualified KEEP remains pending exact current permanent full standalone delivery. No new timing retry, metadata-only artifact acceptance, or formal no-gain round.'}
OUT.mkdir(exist_ok=False);shutil.copyfile(zpath,OUT/'proof.zip')
(OUT/'archive.json').write_text(json.dumps(meta,indent=2)+'\n')
(OUT/'README.md').write_text('# Complete original checks on the integrated startup fix\n\nThe integrated c941 code passed the complete original hosted checks. The actual official archive was downloaded through EOF, checked for its full byte count/SHA, and all safe unique members were read through CRC. The original independent reader verified all game/raw/browser/clip/source assertions; all23 frozen helper/runtime/native/input/isolated Git rows stayed equal with natural empty-group closure. Only exact new commit/run/output identity rebinding changed the original reader.\n\nThe complete offline output is1,390,847,100bytes/b85a828 SHA and matches the independently reviewed startup candidate. Permanent full single-file Release delivery remains pending and the KEEP round is not yet qualified. The complete official ZIP and original unredacted native logs are retained in/tmp; public email omissions are explicit with original private byte hashes. No new browser clock comparison ran.\n')
text=f"""# Integrated startup fix: complete original checks passed; permanent delivery pending

The real two-file International readiness/loading-block fix is on public commit c941c1bb18ccb37525c2e37248b0380ab1682e07, actually pushed09:20:24.319432 with exact clean remote readback09:20:25.573093. Original strict TypeScript and the full physical offline builder passed naturally09:09:47.240367. The actual complete page remains1,390,847,100bytes SHA256 b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2; all41 licensed files/1304parts/full six-piece corpus/workers/licenses are unchanged. The measured canonical browser/build source hashes are bf8b12c6a389daa050f70f602e53480b506c0f4810288c24ebb6810a6aa477cf and4d1ce03c9c546dac6d0763aca705f2555c638234f820f71dc5f93c1837c53885. No new product-source edit happened at this proof checkpoint.

Genuine new integrated original run37910650486/all5 stages SUCCESS has now been accepted through actual whole official artifact{zipproof['artifactId']}: {zipproof['zipBytes']}bytes SHA256 {zipproof['zipSha256']}, {zipproof['safeUniqueMembers']}safe unique members/fullCRC/EOF. Original full reader PASS{whole['closedAt']} verifies all349 current immutable/runtime source guards and six current immutable docs;91 tests/25 assertion-killed mutants/7000 matrix games/1003 property seeds/10000 move-oracle cases;4000 true-terminal league games/all80 original-gold raw files;2400 strict original native frame intervals/2404 real timestamps/60 functional checks/all original and excerpt clips decoded. Final23 source/self/runtime/binary/native-log/private-reference/isolated-metadata rows before==after==finally. Owner NATURAL EXIT0/group[]/no signals closed{owner['closedAt']}. This is genuine new production acceptance, separate from historical7fb or pipeline metadata; it is not a new clock comparison.

Root's authoritative saved-only consolidated peer09:16:54.675952 physically compared all26 complete original native/protocol/bridge archive members, revalidated all2751 trial rows/whole4HTTP/full8 legal+6000-node botreport/RNG/state replays/BOTH before-DCL500ms gates and kept26 actual reader inputs equal. Accepted observed first-legal gains are17,517.100ms desktop and73,472.300ms phoneCPU4, scoped only to the declared native comparison. Earlier first22physical/all26CRC and supplement7inputs/eight-label overclaims remain explicitly preserved and corrected without rewriting original timestamps. Resource-failed0-arm trial and all old unexecuted/failure protocols remain unchanged.

PR10 remains Draft/open/unmerged. The current permanent single-file full Release is PREPARED ONLY at/tmp/G10-permanent-release-c941-20261009, no Release/upload/public byte acceptance exists yet. Installed configured gh read-only capability and existing-release inventory passed; no manual credential reading/recovery/injection. Proposed new exact-c941 tag is G10-checkers-c941c1b-20261009, using existing complete physical/tmp output with no second1.39GB allocation. After creation/upload at exact qualified source, require actual asset metadata bytes/SHA and stream the complete real public HTTP body through EOF/SHA with bounded resource/process/source controls. Current newly uploaded four-part bodies remain separately unreceived; historicaldf delivery cannot qualify the new output.

Renewed KEEP round1 remains IN_PROGRESS,0qualified player gains/0completed rounds/0consecutive no-gain until actual complete current standalone delivery. This proof checkpoint is neither a player gain nor a no-gain round. Once current delivery passes, qualify the actual worst startup fix and continue binding ranked-five KEEP reviews until3consecutive honest no-player-gain rounds. All current runtime/core/strategy/seed6000/corpus/clocks/performance gates remain unchanged. Unique old1.39GB original licensed HTML/data/raw/proofs/dependencies and shared Git metadata are preserved.

This documentation/evidence-only publication will change branch HEAD; accepted integrated c941 becomes historical with exact unchanged349 source/runtime and six-current-document Git bridge required. A new exact-head original workflow remains separate. No changed-production acceptance may be inherited from c941 if any product/runtime/corpus/assertion differs. A future native timing experiment still requires its own finite declared source/self/resource/quiet protocol and exact root grant.

## Earlier checkpoints retained as history

"""
for name in ['NEXT.md','VERIFY.md']:
 path=JOB/name;path.write_text(text+path.read_text())
line=f"\n2026-10-09 integrated c941 original full — Actual complete original run37910650486/official{zipproof['artifactId']} whole{zipproof['zipBytes']}B/{zipproof['zipSha256']}/{zipproof['safeUniqueMembers']}CRC/full349+6docs/all4000raw/native2400frames+60functional/fullclips accepted naturally{owner['closedAt']}, final23 frozen rows equal. Product startup fix and root independently accepted gains present; exact current permanent standalone delivery still pending. KEEP round1 IN_PROGRESS/0qualifiedgains/0completed/0consecutive no-gain; this proof checkpoint is neither gain nor no-gain.\n"
for name in ['LOOP.md','ASSUMPTIONS.md']:
 path=JOB/name;path.write_text(path.read_text()+line)
readme=(JOB/'README.md').read_text()
readme=readme.replace('Fresh integrated original full CI, delivery and KEEP qualification remain\npending. PR #10 stays Draft/open; this is not a completion claim.','The complete integrated original CI/native/game/raw/media/source checks\npassed. Permanent full standalone delivery and KEEP qualification remain\npending. PR #10 stays Draft/open; this is not a completion claim.')
assert len(readme.splitlines())<60;(JOB/'README.md').write_text(readme)
print(json.dumps({'status':'ACTUAL_INTEGRATED_FULL_PROOF_WRITES_CLOSED','closedAt':datetime.now(timezone.utc).isoformat(),'archiveBytes':meta['proofZipBytes'],'archiveSha256':meta['proofZipSha256'],'members':len(members),'actualOriginalOwnerClosedAt':owner['closedAt']}),flush=True)
