from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,signal,os,traceback
base=Path('.work/current-proof-checkpoint-0616')
branch='job/G10-checkers-complete-20261008'
old='56db9298847ff312860bed8e71f32f2ac76bd41f'
started=datetime.now(timezone.utc).isoformat();children=[];status='CLOSED_FAILED'
def utc():return datetime.now(timezone.utc).isoformat()
def members(group):
 rows=[]
 for p in Path('/proc').glob('[0-9]*/stat'):
  try:
   s=p.read_text();c=s[s.rfind(')')+2:].split()
   if int(c[2])==group:rows.append({'pid':int(p.parent.name),'state':c[0]})
  except (OSError,ValueError,IndexError):pass
 return rows
def run(name,args,limit=120):
 r={'name':name,'command':args,'startedAt':utc(),'signals':[]};children.append(r)
 with (base/(name+'.stdout')).open('wb') as out,(base/(name+'.stderr')).open('wb') as err:
  child=subprocess.Popen(args,stdout=out,stderr=err,start_new_session=True)
  try:child.wait(timeout=limit);r['natural']=True
  finally:
   if child.poll() is None or members(child.pid):
    r['natural']=False
    for sig in [signal.SIGTERM,signal.SIGKILL]:
     if child.poll() is None or members(child.pid):
      try:os.killpg(child.pid,sig);r['signals'].append({'signal':sig.name,'at':utc()})
      except ProcessLookupError:pass
      try:child.wait(timeout=3)
      except subprocess.TimeoutExpired:pass
   child.wait(timeout=3);r.update({'closedAt':utc(),'exitCode':child.returncode,'remainingGroup':members(child.pid)})
 assert child.returncode==0 and r['natural'] and not r['remainingGroup'],r
 return (base/(name+'.stdout')).read_text()
try:
 assert json.loads((base/'final-source-proof.json').read_text())['status']=='CLOSED_PASS'
 assert run('pre-head',['git','rev-parse','HEAD']).strip()==old
 assert run('pre-branch',['git','branch','--show-current']).strip()==branch
 run('diff-check',['git','diff','--check'])
 run('add',['git','add','README.md','ASSUMPTIONS.md','LOOP.md','NEXT.md','SHA256SUMS.txt','VERIFY.md','evidence/checks/hosted-original-0f504-current56-0616','evidence/checks/hash-memory-inquiry-0616'])
 run('commit',['git','commit','-m','G10 verify complete original checks and diagnose replay import memory'])
 head=run('post-head',['git','rev-parse','HEAD']).strip();assert head!=old
 run('push',['git','push','origin',branch])
 pushed=next(x['closedAt'] for x in children if x['name']=='push')
 assert run('remote-readback',['git','ls-remote','origin','refs/heads/'+branch]).split()[0]==head
 assert run('final-status',['git','status','--porcelain']).strip()==''
 interval=(datetime.fromisoformat(pushed)-datetime.fromisoformat('2026-10-09T05:57:19.720225+00:00')).total_seconds()
 status='CLOSED_PASS'
except BaseException as error:
 (base/'publish-failure.json').write_text(json.dumps({'at':utc(),'type':type(error).__name__,'error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':started,'closedAt':utc(),'oldHead':old,'head':locals().get('head'),'actualPushClosedAt':locals().get('pushed'),'sourceIntervalSeconds':locals().get('interval'),'hardCadenceMissSeconds':max(0,locals().get('interval',0)-1800),'children':children,'scope':'Normal material source push with genuine original0f complete official/native/raw/frame/clip proof with explicit current56 source bridge plus actual untimed pre-hash allocation controls and every failed outcome retained after original final supported source checks; exact remote readback and clean working tree. New head full native acceptance remains pending; no production adoption or player gain.'}
 (base/'push-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
