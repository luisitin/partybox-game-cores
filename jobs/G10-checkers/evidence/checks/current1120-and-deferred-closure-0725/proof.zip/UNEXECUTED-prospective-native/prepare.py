from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,os,subprocess,sys,uuid
JOB=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers');BASE=JOB/'.work/international-ready-private/native-deferred-closure-current1120';HEAD='1120b00f4773f1f44e880e00d917c49ea036f8be';META=Path('/tmp/G10-local-d619-independent-20261009/repo/.git');OUT=Path('/tmp/G10-international-first-legal-deferred-closure1120-20261009')
def digest(p):
 h=sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
def row(p):
 p=Path(p).absolute();s=p.stat();return {'path':str(p),'resolved':str(p.resolve()),'sha256':digest(p),'identity':{'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}}
def git(*args):return subprocess.check_output(['git','--git-dir='+str(META),'--work-tree='+str(JOB.parent.parent),*args],cwd=JOB,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))
assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain').strip()
assert not (BASE/'ready.json').exists() and not (BASE/'freeze-spec.json').exists()
assert OUT.is_dir() and not any(OUT.iterdir())
old=json.loads(Path('/tmp/G10-hash-memory-inquiry-56db-20261009/spec.json').read_text());files={};inventories=old['inventories']
for key,r in old['files'].items():
 actual=row(r['path'])
 if key.startswith('doc:'):assert sha256(git('cat-file','blob',HEAD+':jobs/G10-checkers/'+key[4:])).hexdigest()==actual['sha256']
 else:assert actual==r,key
 files[key]=actual
bridge=Path('/tmp/G10-source-runtime-56-to1120-20261009');b=json.loads((bridge/'historical-git-guards.json').read_text());assert b['status']=='PASS' and b['currentCheckoutPreserved']==HEAD and b['acceptedHead']=='56db9298847ff312860bed8e71f32f2ac76bd41f' and b['sourceGuardCount']==349 and len(b['sixCurrentDocumentationGitBridge'])==6
accepted=Path('/tmp/G10-hosted-56db-current-d619-20261009');a=json.loads((accepted/'controller.json').read_text());assert a['status']=='CLOSED_PASS' and a['head']==b['acceptedHead']
extra=[*BASE.glob('*'),META/'HEAD',META/'refs/heads/job/G10-checkers-complete-20261008',META/'index',META/'config',META/'objects/info/alternates',JOB/'.work/international-ready-private/delta-controls-4369.json',JOB/'.work/international-ready-private/generated/raw-output.json',JOB/'.work/international-ready-private/generated/candidate-bootstrap.js',JOB/'.work/international-ready-private/international-ready-marker.html',JOB/'.work/international-ready-private/http-current-72/server.mjs',JOB/'.work/international-ready-private/http-current-72/controller.json',JOB/'.work/bridge-56-to1120-0712/audit.py',JOB/'.work/bridge-56-to1120-0712/identity-output-scope-only.diff',*bridge.glob('*.json'),bridge/'audit.stdout',bridge/'audit.stderr',accepted/'controller.json',accepted/'execution-freeze-finally.json',accepted/'independent-complete-evidence.json',accepted/'historical-git-guards.json',accepted/'zip-integrity.json',accepted/'owner-closure.json']
for suffix in ['', '-v2','-v3']:
 root=Path('/tmp/G10-deferred-closure-barrier-controls-1120'+suffix+'-20261009')
 for folder,_,names in os.walk(root):
  for name in names:extra.append(Path(folder)/name)
for root in [Path('/tmp/G10-deferred-core-replay-d619-20261009'),Path('/tmp/G10-deferred-core-replay-d619-v2-20261009')]:
 for folder,_,names in os.walk(root):
  for name in names:extra.append(Path(folder)/name)
for p in extra:
 if p.is_file():files['prospective:'+str(p)]=row(p)
controls=json.loads(Path('/tmp/G10-deferred-closure-barrier-controls-1120-v3-20261009/controls.json').read_text());assert controls['status']=='PASS' and controls['sourceRuntimeByteEqual'] and len(controls['controls'])==2 and all(x['closure']['natural'] for x in controls['controls'])
for root,names in inventories.items():
 observed=[]
 for folder,_,names_ in os.walk(root,followlinks=True):
  for name in names_:
   p=Path(folder)/name
   if p.is_file():observed.append(str(p))
 assert sorted(observed)==names
for k,r in files.items():assert row(r['path'])==r,k
spec={'head':HEAD,'preparedAt':datetime.now(timezone.utc).isoformat(),'files':files,'inventories':inventories,'metadataSource':'Independent /tmp Git metadata; original full physical inputs; original owned/shared metadata unchanged','scope':'Fresh prospective SAME full licensed payload/source/runtime/six immutable1120 docs, actual saved8 replay proof plus barrier fixtures/failed predecessors. NO native execution. Source/full runtime accepted56 explicitly bridged to1120; exact1120 whole proof still separate required before exact root grant.'};(BASE/'freeze-spec.json').write_text(json.dumps(spec,indent=2)+'\n')
oldready=json.loads((JOB/'.work/international-ready-private/native-current-0f504-tmp/ready.json').read_text())
ready={**oldready,'status':'READY_NOT_RUN_PENDING_EXACT_CURRENT_FULL_AND_ROOT_GRANT','head':HEAD,'outputRoot':str(OUT),'preparedAt':datetime.now(timezone.utc).isoformat(),'nonce':'G10-international-deferred-actual-closure-'+str(uuid.uuid4()),'acceptedNativeArtifactHead':b['acceptedHead'],'acceptedNativeArtifactId':11598986877,'acceptedNativeArtifactSha256':'4297256e84c5426884a6850fb4dd31d105e1b109f533e301714a88b20d8ffb0b','explicitCurrentRuntimeGuardCount':349,'currentImmutableDocs':6,'frozenFiles':len(files),'fileHashes':{r['path']:r['sha256'] for r in files.values()},'freezeSpecSha256':digest(BASE/'freeze-spec.json'),'browserFileCounts':{k:len(v) for k,v in inventories.items() if 'ms-playwright' in k},'materialSchedulingProof':'Saved real historical8 games all2370EOF/full originallegal/state/detailed6000report/RNG/sampleInput canonicaldc268a96e9dbdb1515813824ad0dd47ca80d25dffde1cdfa09485ef3519db621; final2384PASS/naturalboth. First extra preclick assumption failure retained. New closure method genuine latched detached-process controls PASS with source/runtime before==after; both original invalid fixture failures retained.','processBarrierBeforePureCore':'All4awaited context/browser closes, wholeHTTPserver closed EXIT0/EOF first. Fresh root controller transitive subreaper /proc must contain only original native Node (adopted zombies reaped individually, no signals), nonce/PID/head-bound ack before same completefullcore+samebots imports. Finite10s within unchanged original360s budget; extra lifecycle predicate strengthens observation validity.','exactCurrentOriginalWorkflowRun':37896292665,'exactCurrentOriginalFullAcceptance':'PENDING; no metadata-only/native/clock/gain inference','scope':'UNEXECUTED prospective materially changed allocation schedule only. Original0f504 resource-failed outcome/cap4.5GiB/360/440/540/native25ms observer/seed6000/fulllicensedbytes/crossoverworkload/BOTHprofile500ms unchanged. No retries unchanged timing; root must statically read whole new137driver/136controller/proof, independently accept genuine exact1120 complete original full result, verify fresh quiet/resources/currentREADY SHA/nonce before an exact distinct one-attempt grant. No Ready-to-merge/adoption/KEEP gain.'}
assert ready['ownedDescendantRssEnvelopeBytes']==4831838208 and ready['wholeTrialTimeoutMs']==360000 and ready['nativeChildWallSeconds']==440 and ready['controllerWholeWallSeconds']==540
(BASE/'ready.json').write_text(json.dumps(ready,indent=2)+'\n')
r={'status':ready['status'],'preparedAt':ready['preparedAt'],'head':HEAD,'nonce':ready['nonce'],'readySha256':digest(BASE/'ready.json'),'controllerSha256':digest(BASE/'controller.py'),'driverSha256':digest(BASE/'observe.mjs'),'specSha256':digest(BASE/'freeze-spec.json'),'frozenFiles':len(files),'outputEmpty':not any(OUT.iterdir()),'exactCurrentOriginalFullAcceptance':'PENDING'}
(BASE/'prepare-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
