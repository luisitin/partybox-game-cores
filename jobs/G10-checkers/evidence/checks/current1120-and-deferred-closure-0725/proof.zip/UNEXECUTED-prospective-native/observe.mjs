// ONE genuine native-clock, trusted first-legal International comparison.
// Complete honest HTTP streams; no fake clocks/state/DOM/event/readiness.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createInterface} from 'node:readline';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {chromium} from 'playwright';
import {setTimeout as pause} from 'node:timers/promises';
const directory=resolve('.work/international-ready-private/native-deferred-closure-current1120');
const ready=JSON.parse(await readFile(directory+'/ready.json','utf8'));
assert.equal(process.version,'v22.16.0');
const grant=process.env.G10_NATIVE_GRANT_NONCE;assert(grant&&grant===ready.nonce,'Fresh exact root grant required');
const hash=async path=>{const h=createHash('sha256');for await(const bytes of createReadStream(path))h.update(bytes);return h.digest('hex');};
for(const [path,expected] of Object.entries(ready.fileHashes))assert.equal(await hash(path),expected,path);
const manifest=JSON.parse(await readFile(ready.manifestPath,'utf8'));
assert.equal(manifest.head,'4369bbdd1f71f34960893afd1ba456fee8e24ecd');
assert.equal(await hash(manifest.basePath),manifest.baseSha256);
assert.equal(ready.head,'1120b00f4773f1f44e880e00d917c49ea036f8be');
assert.equal(ready.wholeTrialTimeoutMs,360000);
assert.equal(ready.successPredicate,'Both profiles candidate trusted first legal International move before DOMContentLoaded and at least500ms earlier than baseline; baseline after DOMContentLoaded, exact bot report/cursor and replay equality; whole original EOF, zero page/request errors, natural process closure and all frozen inputs');
const out=ready.outputRoot+'/actual';assert.equal(ready.outputRoot,'/tmp/G10-international-first-legal-deferred-closure1120-20261009');await mkdir(out); // No overwrite/retry of this one outcome.
const report={status:'RUNNING',startedAt:new Date().toISOString(),rootGrantNonce:grant,readySha256:await hash(directory+'/ready.json'),head:ready.head,deltaOriginHead:manifest.head,baselineBytes:manifest.baseBytes,baselineSha256:manifest.baseSha256,candidateBytes:manifest.resultBytes,candidateSha256:manifest.resultSha256,profiles:[],scope:'ONE four-arm trusted first-legal International bot comparison; full licensed data, original6k search budget/seed/workers/clocks and honest whole HTTP EOF. Native25ms read-only observation provides an upper bound, not exact earliest completion. No cold-cache, FPS, population/hardware promise or final offline acceptance.'};
const began=performance.now(),remaining=()=>Math.max(1,Math.floor(ready.wholeTrialTimeoutMs-(performance.now()-began)));
let server,lines=[],serverErrors='',browser,serverClosed,failure;
const save=()=>writeFile(out+'/report.json',JSON.stringify(report,null,2)+'\n');
const select=async(page,selector,key,value)=>{await page.locator(selector).click({timeout:Math.min(30000,remaining())});await page.locator(selector).press(key,{timeout:Math.min(30000,remaining())});await page.locator(selector).press('Enter',{timeout:Math.min(30000,remaining())});assert.equal(await page.locator(selector).inputValue(),value);};
try{
 server=spawn(process.execPath,[ready.serverPath],{cwd:process.cwd(),stdio:['ignore','pipe','pipe']});
 serverClosed=new Promise(resolve=>server.once('close',(code,signal)=>resolve({code,signal})));
 const reader=createInterface({input:server.stdout});
 const listening=new Promise((resolve,reject)=>{reader.on('line',line=>{lines.push(line);try{const row=JSON.parse(line);if(row.status==='LISTENING')resolve(row);}catch(error){reject(error);}});server.once('error',reject);serverClosed.then(result=>reject(new Error('Server stopped before LISTENING: '+JSON.stringify(result))));});
 server.stderr.on('data',data=>{serverErrors+=data.toString();});const launch=await listening;
 assert.equal(launch.manifestSha256,await hash(ready.manifestPath));const url='http://127.0.0.1:'+launch.port;
 for(const profile of [{name:'desktop',width:1920,height:1080,rate:1,arms:['baseline','candidate']},{name:'phone',width:390,height:844,rate:4,arms:['candidate','baseline']}]){
  for(const arm of profile.arms){
   browser=await chromium.launch({headless:true,timeout:remaining(),args:['--no-sandbox','--disable-dev-shm-usage']});
   if(report.browserVersion)assert.equal(browser.version(),report.browserVersion);else report.browserVersion=browser.version();
   const context=await browser.newContext({viewport:{width:profile.width,height:profile.height},reducedMotion:'reduce'}),page=await context.newPage(),errors=[],requests=[],failedRequests=[];
   page.on('pageerror',error=>errors.push(String(error)));page.on('request',request=>requests.push(request.url()));page.on('requestfailed',request=>failedRequests.push({url:request.url(),failure:request.failure()}));
   await page.addInitScript(({lastIntl})=>{
    const o={timeOrigin:performance.timeOrigin,events:[],internationalBotStartEnabled:null,internationalMarker:null,domContentLoaded:null,load:null,games:[]};window.__G10_INTL_OBSERVER__=o;
    const enabled=()=>{if(o.internationalBotStartEnabled)return;const n=document.getElementById('start');if(!n||n.disabled||document.getElementById('variant')?.value!=='international'||document.getElementById('seat-0')?.value!=='sharp'||document.getElementById('seat-1')?.value!=='human')return;const r=n.getBoundingClientRect(),host=window.__G10?.host();if(!r.width||!r.height||host?.botsPrepared!==true)return;o.internationalBotStartEnabled={at:performance.now(),readyState:document.readyState,rendered:true,inViewport:r.top<innerHeight&&r.bottom>0&&r.left<innerWidth&&r.right>0,host};};
    new MutationObserver(enabled).observe(document,{subtree:true,childList:true,attributes:true,attributeFilter:['disabled']});
    document.addEventListener('change',()=>queueMicrotask(enabled),true);
    document.addEventListener('g10-international-worker-ready',()=>{o.internationalMarker={at:performance.now(),readyState:document.readyState,dictionaryEncodedBytes:document.getElementById('g10-corpus-tunstall-v2')?.textContent.length,lastInternationalPartPresent:!!document.getElementById(lastIntl)};queueMicrotask(()=>{o.internationalMarker.hostAfter=window.__G10.host();enabled();});});
    document.addEventListener('DOMContentLoaded',()=>{o.domContentLoaded={at:performance.now(),readyState:document.readyState};queueMicrotask(()=>{o.domContentLoaded.hostAfter=window.__G10.host();});},{once:true});
    window.addEventListener('load',()=>{o.load={at:performance.now(),readyState:document.readyState};},{once:true});
    for(const type of ['click','change','keydown'])document.addEventListener(type,e=>{const id=e.target?.id;if(!id||!['start','seat-0','variant','new-game'].includes(id))return;o.events.push({type,id,at:performance.now(),trusted:e.isTrusted,key:e.key??null,value:e.target.value??null});if(type==='click'&&id==='start'&&!e.target.disabled){enabled();o.games.push({clickAt:performance.now(),trusted:e.isTrusted,readyState:document.readyState,variant:document.getElementById('variant').value,host:window.__G10.host(),beforeState:window.__G10.getState(),firstMove:null});}},true);
    setInterval(()=>{const g=o.games.at(-1);if(!g||g.firstMove)return;const s=window.__G10?.getState();if(s?.ply>=1)g.firstMove={at:performance.now(),readyState:document.readyState,state:s,host:window.__G10.host()};},25);
   },{lastIntl:manifest.international.parts.at(-1).id});
   page.setDefaultTimeout(Math.min(30000,remaining()));const cdp=await context.newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate:profile.rate});
   const navigationStarted=performance.now();await page.goto(url+'/'+arm+'.html',{waitUntil:'commit',timeout:remaining()});const commitWallMs=performance.now()-navigationStarted;
   await page.waitForFunction(()=>!!window.__G10,null,{timeout:remaining()});
   const initial=await page.evaluate(()=>({at:performance.now(),readyState:document.readyState,host:window.__G10.host(),disabled:document.getElementById('start').disabled}));
   await select(page,'#seat-0','End','sharp');await select(page,'#variant','End','international');
   await page.waitForFunction(()=>!document.getElementById('start').disabled,null,{timeout:remaining()});await page.locator('#start').click();
   await page.waitForFunction(()=>!!window.__G10_INTL_OBSERVER__.games[0]?.firstMove,null,{timeout:remaining()});const internationalWallMs=performance.now()-navigationStarted;
   await page.waitForLoadState('load',{timeout:remaining()});
   const loaded=await page.evaluate(()=>({readyState:document.readyState,host:window.__G10.host(),loadingNoteHidden:document.getElementById('loading-note').hidden}));
   assert.equal(loaded.readyState,'complete');assert.equal(loaded.host.botsPrepared,true);assert.equal(loaded.loadingNoteHidden,true);assert.deepEqual(loaded.host.preparedVariants,{american:true,international:true});
   await page.locator('#new-game').click();await select(page,'#variant','Home','american');assert.equal(await page.locator('#start').isDisabled(),false);await page.locator('#start').click();
   await page.waitForFunction(()=>!!window.__G10_INTL_OBSERVER__.games[1]?.firstMove,null,{timeout:remaining()});
   const observer=await page.evaluate(()=>window.__G10_INTL_OBSERVER__);
   assert(observer.internationalBotStartEnabled);assert(observer.internationalBotStartEnabled.at<=observer.games[0].clickAt);assert.equal(observer.games.length,2);assert(observer.events.every(row=>row.trusted));assert(observer.events.some(row=>row.type==='change'&&row.id==='seat-0'&&row.value==='sharp'));
   assert.equal(observer.games[1].readyState,'complete');
   for(const [index,variant] of ['international','american'].entries()){
    const g=observer.games[index],f=g.firstMove;assert(g.trusted);assert.equal(g.variant,variant);assert.equal(g.beforeState,null);assert.equal(f.state.variant,variant);assert.equal(f.state.ply,1);assert.equal(f.host.workerVariant,variant);assert.equal(f.host.workerStarts,index+1);assert.equal(f.host.workerReady,true);assert(f.host.lastBotReport);assert.equal(f.state.moveLog.length,1);assert.equal(f.state.lastMove.playerId,'seat-0');

   }
   if(arm==='candidate'){const m=observer.internationalMarker;assert(m);assert.equal(m.readyState,'loading');assert.equal(m.dictionaryEncodedBytes,16388);assert.equal(m.lastInternationalPartPresent,false);assert.deepEqual(m.hostAfter.preparedVariants,{american:true,international:true});}
   else assert.equal(observer.internationalMarker,null);
   assert.equal(errors.length,0,errors.join('\n'));assert.equal(failedRequests.length,0,JSON.stringify(failedRequests));assert(requests.filter(x=>/^https?:/.test(x)).every(x=>x===url+'/'+arm+'.html'));
   report.profiles.push({...profile,arms:undefined,arm,commitWallMs,internationalWallMs,initial,loaded,observer,errors,requests,failedRequests});await save();console.log(JSON.stringify({phase:'ARM_CLOSED',profile:profile.name,arm,firstInternationalMoveMs:observer.games[0].firstMove.at,firstInternationalMoveReadyState:observer.games[0].firstMove.readyState,fullLoadMs:observer.load.at,remainingMs:remaining()}));
   await context.close();await browser.close();browser=null;
  }
 }
 const gains=[];
 for(const name of ['desktop','phone']){
  const b=report.profiles.find(r=>r.name===name&&r.arm==='baseline'),c=report.profiles.find(r=>r.name===name&&r.arm==='candidate');
  for(let i=0;i<2;i++){assert.deepEqual(b.observer.games[i].firstMove.host.lastBotReport,c.observer.games[i].firstMove.host.lastBotReport);assert.deepEqual(b.observer.games[i].firstMove.host.botCursor,c.observer.games[i].firstMove.host.botCursor);}
  const first=b.observer.games[0].firstMove,changed=c.observer.games[0].firstMove;
  const pass=changed.at<c.observer.domContentLoaded.at&&c.observer.games[0].clickAt<c.observer.domContentLoaded.at&&c.observer.internationalBotStartEnabled.at<c.observer.domContentLoaded.at&&first.at>=b.observer.domContentLoaded.at&&first.at-changed.at>=500;
  gains.push({name,baselineObservedFirstLegalMs:first.at,candidateObservedFirstLegalMs:changed.at,observedReductionMs:first.at-changed.at,candidateBeforeDOMContentLoaded:changed.at<c.observer.domContentLoaded.at,baselineAfterDOMContentLoaded:first.at>=b.observer.domContentLoaded.at,pass});
 }
 report.gains=gains;report.playerGainPredicate=gains.every(r=>r.pass);report.status='PASS';
}catch(error){report.status='FAIL';report.failure=String(error);failure=error;await save();}
finally{
 if(browser)await browser.close();await save();
 try{
  if(server){if(server.exitCode===null&&server.signalCode===null){const launch=JSON.parse(lines.find(line=>JSON.parse(line).status==='LISTENING'));await fetch('http://127.0.0.1:'+launch.port+'/close',{method:'POST'});}report.serverClosure=await serverClosed;await writeFile(out+'/server.stdout',lines.join('\n')+'\n');await writeFile(out+'/server.stderr',serverErrors);const closed=JSON.parse(lines.at(-1));assert.equal(closed.status,'CLOSED');assert.equal(closed.finalSourceSha256,manifest.baseSha256);if(report.status==='PASS'){assert.equal(closed.requests.length,4);assert(closed.requests.every(r=>r.status==='EMITTED_VERIFIED'));assert.equal(report.serverClosure.code,0);assert.equal(report.serverClosure.signal,null);assert.equal(serverErrors,'');}}
  for(const [path,expected] of Object.entries(ready.fileHashes))assert.equal(await hash(path),expected,path);assert.equal(await hash(manifest.basePath),manifest.baseSha256);
 }catch(error){report.status='FAIL';report.closureFailure=String(error);failure??=error;}
 report.closedAt=new Date().toISOString();await save();
}

// Material prospective change: no full pure-core import overlaps any live browser/server.
if(!failure){
 try{
  assert.equal(browser,null);assert.deepEqual(report.serverClosure,{code:0,signal:null});
  assert.equal(report.profiles.length,4);
  const closureRequest={status:'ALL_FOUR_BROWSER_ARMS_AND_HTTP_SERVER_CLOSED',nonce:grant,nodePid:process.pid,head:ready.head};
  await writeFile(ready.outputRoot+'/browser-http-closure-request.json',JSON.stringify(closureRequest)+'\n',{flag:'wx'});
  const closureDeadline=performance.now()+Math.min(10000,remaining());let closureAck;
  while(!closureAck){
   assert(performance.now()<closureDeadline&&remaining()>1,'Original360s native budget or finite10s actual-descendant closure barrier exceeded');
   try{closureAck=JSON.parse(await readFile(ready.outputRoot+'/browser-http-closure-ack.json','utf8'));}catch(error){if(error.code!=='ENOENT')throw error;await pause(25);}
  }
  assert.equal(closureAck.status,'ACTUAL_OWNED_DESCENDANTS_ONLY_NATIVE_NODE');
  assert.equal(closureAck.nonce,grant);assert.equal(closureAck.nodePid,process.pid);
  assert.equal(closureAck.controllerPid,Number(process.env.G10_PARENT_CONTROLLER_PID));
  assert.equal(closureAck.processes.length,1);assert.equal(closureAck.processes[0].pid,process.pid);
  report.beforePureCoreActualDescendantClosure=closureAck;await save();
  const {init,reduce,controllerView,turnId,createRng,sampleInput}=await import('../../../dist/core.mjs');
  const {searchMove}=await import('../../../dist/bots.mjs');
  for(const profile of report.profiles){
   for(const [index,variant] of ['international','american'].entries()){
    const g=profile.observer.games[index],f=g.firstMove;assert.equal(f.state.variant,variant);
    const s=f.state,players=s.order.map(id=>s.players[id]),original=init({players,seed:20261008,now:g.clickAt,settings:s.settings}),legal=controllerView(original,turnId(original)).legalMoves;assert(legal.some(m=>JSON.stringify(m)===JSON.stringify(s.lastMove.move)));
    const replay=reduce(original,{type:'input',playerId:turnId(original),input:{type:'move',path:s.lastMove.move.path},now:f.at});
    for(const key of ['board','side','ply','settings','lastMove','moveLog','quietPlies','repetition','drawWindows','rng','winner','endReason'])assert.deepEqual(s[key],replay[key],key);
    const detailedRng=createRng(20261008),detailed=searchMove(original,original.settings,detailedRng,'sharp');
    assert.deepEqual(detailed,f.host.lastBotReport);assert.deepEqual(detailedRng.state(),f.host.botCursor);
    const pureRng=createRng(20261008),input=sampleInput(original,turnId(original),pureRng,'sharp');
    assert.deepEqual(input,{type:'move',path:detailed.move.path});assert.deepEqual(pureRng.state(),f.host.botCursor);

   }
  }
  report.pureReplayAfterAllBrowserAndServerClosures=true;
 }catch(error){report.status='FAIL';report.replayFailure=String(error);failure=error;}
 report.closedAt=new Date().toISOString();await save();
}

if(failure)throw failure;
console.log(JSON.stringify({status:report.status,closedAt:report.closedAt,playerGainPredicate:report.playerGainPredicate,gains:report.gains}));
