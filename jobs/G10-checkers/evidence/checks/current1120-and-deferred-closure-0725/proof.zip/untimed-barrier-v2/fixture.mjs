import {readFile,writeFile} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {setTimeout as pause} from 'node:timers/promises';
const [root,mode,nonce,head]=process.argv.slice(2);
if(mode==='naturally-exited-adopted-detached'){
 const code="const {spawn}=require('node:child_process');const x=spawn(process.execPath,['-e','setTimeout(()=>process.exit(0),650)'],{detached:true,stdio:'ignore'});x.unref();console.log(JSON.stringify({actualDetachedPid:x.pid}));";
 const p=spawn(process.execPath,['-e',code],{detached:true,stdio:['ignore','pipe','pipe']});
 p.stdout.pipe(process.stdout);p.stderr.pipe(process.stderr);
 await new Promise((resolve,reject)=>{p.once('error',reject);p.once('close',(c,s)=>c===0&&s===null?resolve():reject(new Error('Intermediate fixture failed')));});
}
await writeFile(root+'/browser-http-closure-request.json',JSON.stringify({status:'ALL_FOUR_BROWSER_ARMS_AND_HTTP_SERVER_CLOSED',nonce,nodePid:process.pid,head})+'\n',{flag:'wx'});
for(let i=0;i<400;i++){try{const a=JSON.parse(await readFile(root+'/browser-http-closure-ack.json','utf8'));if(a.nodePid!==process.pid||a.nonce!==nonce)throw Error('Wrong actual ack');console.log(JSON.stringify({status:'ACTUAL_FIXTURE_ACK_RECEIVED',mode,nodePid:process.pid}));process.exit(0);}catch(e){if(e.code!=='ENOENT')throw e;await pause(10);}}
throw Error('Finite4s untimed lifecycle fixture ack bound exceeded');
