from pathlib import Path
from hashlib import sha256
import ctypes,datetime,importlib.util,json,os,signal,subprocess,sys,time,traceback
JOB=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers');CODE=JOB/'.work/international-ready-private/native-deferred-closure-current1120';BASE=Path('/tmp/G10-deferred-closure-barrier-controls-1120-20261009');BASE.mkdir(exist_ok=False)
NODE=JOB/'.work/memory-json-private/node22/runtime/bin/node'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):return sha256(p.read_bytes()).hexdigest()
before={str(p):digest(p) for p in [CODE/'controller.py',CODE/'observe.mjs',NODE,Path(sys.executable).resolve()]}
assert before[str(NODE)]=='8142d37c6f2f372ef040419e7a111a6baf17df89f8078d02447d6c639ae20c1d'
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
s=importlib.util.spec_from_file_location('actual_prospective_controller',CODE/'controller.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
s=importlib.util.spec_from_file_location('actual_group_helper',JOB/'.work/hosted-df-memory-parts-cd9/receive.py');g=importlib.util.module_from_spec(s);s.loader.exec_module(g)
worker="""import {readFile,writeFile} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {setTimeout as pause} from 'node:timers/promises';
const [root,mode,nonce,head]=process.argv.slice(1);
if(mode==='naturally-exited-adopted-detached'){
 const code="const {spawn}=require('node:child_process');const x=spawn(process.execPath,['-e','setTimeout(()=>process.exit(0),650)'],{detached:true,stdio:'ignore'});x.unref();console.log(JSON.stringify({actualDetachedPid:x.pid}));";
 const p=spawn(process.execPath,['-e',code],{detached:true,stdio:['ignore','pipe','pipe']});
 p.stdout.pipe(process.stdout);p.stderr.pipe(process.stderr);
 await new Promise((resolve,reject)=>{p.once('error',reject);p.once('close',(c,s)=>c===0&&s===null?resolve():reject(new Error('Intermediate fixture failed')));});
}
await writeFile(root+'/browser-http-closure-request.json',JSON.stringify({status:'ALL_FOUR_BROWSER_ARMS_AND_HTTP_SERVER_CLOSED',nonce,nodePid:process.pid,head})+'\\n',{flag:'wx'});
for(let i=0;i<400;i++){try{const a=JSON.parse(await readFile(root+'/browser-http-closure-ack.json','utf8'));if(a.nodePid!==process.pid||a.nonce!==nonce)throw Error('Wrong actual ack');console.log(JSON.stringify({status:'ACTUAL_FIXTURE_ACK_RECEIVED',mode,nodePid:process.pid}));process.exit(0);}catch(e){if(e.code!=='ENOENT')throw e;await pause(10);}}
throw Error('Finite4s untimed lifecycle fixture ack bound exceeded');
"""
(BASE/'fixture.mjs').write_text(worker);results=[];started=utc();status='FAILED'
def alarm(*_):raise TimeoutError('Finite30s whole untimed lifecycle control deadline exceeded')
signal.signal(signal.SIGALRM,alarm);signal.alarm(30)
try:
 for mode in ['only-native-node','naturally-exited-adopted-detached']:
  out=BASE/mode;out.mkdir();m.OUT=out;nonce='UNTIMED_FIXTURE_ONLY_'+mode;p=None;ack=None;samples=[];closed=None
  with (out/'stdout').open('wb') as stdout,(out/'stderr').open('wb') as stderr:
   try:
    p=subprocess.Popen([str(NODE),str(BASE/'fixture.mjs'),str(out),mode,nonce,m.HEAD],cwd=JOB,stdout=stdout,stderr=stderr,start_new_session=True)
    stop=time.monotonic()+10
    while ack is None:
     assert time.monotonic()<stop
     rows=m.descendants(os.getpid());samples.append({'at':utc(),'processes':rows})
     ack=m.ack_browser_http_closure(p.pid,nonce)
     if ack is None:time.sleep(.01)
    assert p.wait(timeout=10)==0
   finally:closed=g.close_worker_group(p,False) if p else None
  assert closed['natural'] and closed['actualExitCode']==0 and not closed['actualRemainingGroup'];assert (out/'stderr').stat().st_size==0
  assert ack['processes']==[x for x in ack['processes'] if x['pid']==p.pid] and len(ack['processes'])==1
  blocked=[r for s in samples for r in s['processes'] if r['pid']!=p.pid and r['state']!='Z']
  if mode!='only-native-node':assert blocked and any(r['pgid']!=p.pid for r in blocked),'Real detached live-process block must be observed';assert ack['reapedNaturallyExited'],'Real adopted zombie must be naturally reaped before ack'
  assert not m.descendants(os.getpid())
  results.append({'mode':mode,'status':'PASS','nonce':nonce,'actualPid':p.pid,'actualFreshAck':ack,'blockedActualDetachedBeforeAck':bool(blocked),'closure':closed,'samples':samples})
  (out/'actual-control.json').write_text(json.dumps(results[-1],indent=2)+'\n')
 assert {p:digest(Path(p)) for p in before}==before
 status='PASS'
except BaseException as e:(BASE/'failure.json').write_text(json.dumps({'at':utc(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 signal.alarm(0);after={p:digest(Path(p)) for p in before};r={'status':status,'startedAt':started,'closedAt':utc(),'sourceRuntimeBefore':before,'sourceRuntimeAfter':after,'sourceRuntimeByteEqual':after==before,'controls':[{k:v for k,v in x.items() if k!='samples'} for x in results],'scope':'Finite UNTImED unit control of actual prospective subreaper closure barrier; plain pinned Node fixtures only. No real browser/HTTP/arms/clock/player observation/READY/grant/native trial. Synthetic request explicitly fixture only; genuine /proc verifies actual detached groups and adopted zombie reaping before ack. Existing full2384/input2370 saved-game proof separate. Future native output remains empty and every old failure intact.'};(BASE/'controls.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['controls','sourceRuntimeBefore','sourceRuntimeAfter']}),flush=True)
