from pathlib import Path
from datetime import datetime,timezone
import importlib.util,json,subprocess,os
base=Path('/tmp/G10-permanent-release-postfailure-source-proof-20261009');base.mkdir(exist_ok=False)
source=Path('/tmp/G10-permanent-release-c941-20261009')
started=datetime.now(timezone.utc).isoformat()
s=importlib.util.spec_from_file_location('actual_permanent_delivery_postfailure_guard',source/'controller.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
ready=m.freeze();assert len(m.owned())==1
receipt={'status':'PASS','startedAt':started,'closedAt':datetime.now(timezone.utc).isoformat(),'currentCheckpoint':ready['currentCheckpoint'],'qualifiedProductHead':ready['qualifiedProductHead'],'all33SourceSelfRuntimeInputsEqualReady':len(ready['files'])==33,'all349OriginalRuntimeGuardsEqual':len(ready['sourceGuards'])==349,'sixCurrentImmutableGitDocsEqual':True,'newCompletePhysicalAssetBytes':m.BYTES,'newCompletePhysicalAssetSha256':m.SHA,'originalUniqueBaselineFrozenAndUnchanged':True,'actualOwnedProcesses':m.owned(),'scope':'Fresh actual full source/self/runtime/asset guard after failed Release upload, separately timestamped. First original upload401/failure/body/READY/protocol untouched; no permanent delivery, new native timing, adopted-gain or no-gain inference.'}
(base/'actual-source-self-runtime-after-failure.json').write_text(json.dumps(receipt,indent=2)+'\n')
p=subprocess.Popen(['/usr/bin/gh','api','--hostname','github.com','repos/luisitin/partybox-game-cores/releases/407784797'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);out,err=p.communicate(timeout=30)
(base/'actual-draft-after-controls.json').write_bytes(out);(base/'actual-draft-after-controls.stderr').write_bytes(err)
assert p.returncode==0
release=json.loads(out);assert release['id']==407784797 and release['draft'] and release['target_commitish']==m.HEAD and release['assets']==[]
receipt['actualDraftStillUnpublishedAndEmpty']=True;receipt['actualDraftReadbackAt']=datetime.now(timezone.utc).isoformat();(base/'actual-source-self-runtime-after-failure.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='actualOwnedProcesses'}),flush=True)
