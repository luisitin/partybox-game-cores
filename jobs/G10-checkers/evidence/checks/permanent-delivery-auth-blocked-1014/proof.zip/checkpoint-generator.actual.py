from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from hashlib import sha256
from datetime import datetime,timezone
import json,re,shutil
JOB=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers')
BASE=Path('/tmp/G10-delivery-blocked-checkpoint-1014')
OUT=JOB/'evidence/checks/permanent-delivery-auth-blocked-1014'
release=Path('/tmp/G10-permanent-release-c941-20261009')
post=Path('/tmp/G10-permanent-release-postfailure-source-proof-pinned-20261009')
actual=json.loads((release/'failure.json').read_text());assert actual['status']=='FAILED' and actual['error']=='upload-existing-full-file'
guard=json.loads((post/'actual-source-self-runtime-after-failure.json').read_text());assert guard['status']=='PASS' and guard['all33SourceSelfRuntimeInputsEqualReady'] and guard['all349OriginalRuntimeGuardsEqual'] and guard['actualDraftStillUnpublishedAndEmpty']
files={}
for root,label in [(release,'actual-first-full-release-protocol'),(Path('/tmp/G10-permanent-release-configured-api-control-20261009'),'actual-changed-client76byte-control'),(post,'actual-fresh-pinned-postfailure-source-guard'),(Path('/tmp/G10-permanent-release-postfailure-source-proof-20261009'),'preserved-first-wrong-runtime-rejection'),(Path('/tmp/G10-source-runtime-c941-to16fc-20261009'),'fresh-c941-current16fc-original349-sixdocs-bridge'),(JOB/'.work/bridge-c941-to16fc-0951','fresh-source-bridge-code')]:
 for path in root.iterdir():
  if path.is_file():files[label+'/'+path.name]=path
for name in ['final-source-proof.py','final-source-proof.json','publish.py','push-receipt.json']:files['actual-prior16fc-source-publication/'+name]=Path('/tmp/G10-integrated-whole-source-checkpoint-0937')/name
files['checkpoint-generator.actual.py']=Path(__file__).resolve()
email=re.compile(rb'[A-Za-z0-9.!#$%&\'*+/=?^_{}|~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+')
members={};omissions=[];zpath=BASE/'proof.zip'
with ZipFile(zpath,'x',ZIP_DEFLATED,compresslevel=6) as archive:
 for name,path in sorted(files.items()):
  raw=path.read_bytes();published,count=email.subn(b'PUBLIC_EMAIL_REMOVED',raw)
  if count:omissions.append({'member':name,'originalPrivateSha256':sha256(raw).hexdigest(),'emailValuesOmitted':count})
  archive.writestr(name,published);members[name]={'bytes':len(published),'sha256':sha256(published).hexdigest()}
assert zpath.stat().st_size<2*1024**2
with ZipFile(zpath) as archive:assert archive.testzip() is None and len(archive.infolist())==len(members)
meta={'status':'BLOCKED_PERMANENT_UPLOAD_HOST_AUTHENTICATION','builtAt':datetime.now(timezone.utc).isoformat(),'proofZipBytes':zpath.stat().st_size,'proofZipSha256':sha256(zpath.read_bytes()).hexdigest(),'members':members,'publicHygieneOmissions':omissions,'actualFirstFailure':actual,'freshPostfailureSourceGuard':guard,'scope':'Existing configured gh release upload and changed configured gh api76-byte sidecar both received uploads.github.com HTTP401 Bad credentials. API draft create/read works, actual draft407784797 remains unpublished/empty; no full/public asset body/EOF/SHA delivery. Current genuine c941 original full checks and physical full page remain intact, explicit349/current6docs/33self-runtime before/after guard. No manual credentials or new native timing, no qualified KEEP or no-gain round.'}
OUT.mkdir(exist_ok=False);shutil.copyfile(zpath,OUT/'proof.zip');(OUT/'archive.json').write_text(json.dumps(meta,indent=2)+'\n')
(OUT/'README.md').write_text('# Permanent delivery blocked at the upload host\n\nThe game passed its complete original checks. The permanent single-file upload failed at uploads.github.com with HTTP401 Bad credentials. A changed standard configured gh api path failed the same way on a76-byte checksum sidecar; it was not a file-size test failure. API draft creation/readback worked, and actual draft407784797 remains private/unpublished with zero assets. No credential was read, injected, recovered or changed.\n\nFresh postfailure guards verified all349 source/runtime rows, six current Git documents,33 ready-bound code/input/runtime files, both complete physical HTML hashes and old unique baseline identity. The archive preserves every actual original failure/control/raw output/READY/resource/process/source receipt and first unexecuted protocol. Wrong runtime and over-broad whole-stat preparer failures are preserved separately and count as no player gain/no-gain. See BLOCKED.md and NEXT.md.\n')
blocked="""# BLOCKED: permanent standalone download

Only permanent delivery is blocked. The game and original full checks passed on integrated commit c941c1bb18ccb37525c2e37248b0380ab1682e07.

Host needed: uploads.github.com.

- Existing configured gh release upload failed at10:02:35.674909 UTC with HTTP401 Bad credentials.
- The standard configured gh api POST path also failed at10:07:55.132480 UTC on a76-byte exact checksum sidecar. Both actual errors are preserved.
- API draft creation and readback work. Owned draft407784797 remains unpublished with zero assets; this is not a public download. No login, credential recovery or token injection was attempted.
- Fresh actual source/self/runtime/full-file verification passed10:12:09.717486: all349 rows/current six Git docs/33 ready inputs unchanged. The complete1,390,847,100-byte HTML remains in/tmp, SHA256 b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2. Original unique baseline is untouched.
- Complete original run37910650486/official11607094152 whole9,929,288B/SHA64775ea3842308e05324d5858eb4e04049b4e4c8f43b8257253626382607fb44/239CRC/native/game/raw/clips/source accepted naturally09:48:49.399880. That pass does not prove public delivery.
- PR10 stays Draft/open/unmerged. KEEP round1 remains in progress:0qualified gains/0completed/0consecutive no-gain, despite independently accepted observed startup reductions17.517s/73.472s.

Resume only when existing configured upload-host authorization is available. Read NEXT.md and all original failures first. Reuse or carefully update only this owned empty draft after fresh exact349/six-doc/physical-file/self-runtime guards; do not rerun the obsolete create-new/no-existing-tag protocol unchanged. GitHub's draft remains untagged: an actual10:13:36 read returned no matching tag. Verify the exact c941 tag AFTER publication, then require actual public full asset HTTP200/EOF/byte/SHA and natural child closure before delivery/KEEP qualification. Preserve all old files and proof. No new native timing comparison is authorized.
"""
(JOB/'BLOCKED.md').write_text(blocked)
text="""# Delivery blocked; complete game checks preserved

Permanent single-file Release delivery is BLOCKED at uploads.github.com. Existing configured native gh full-file upload receivedHTTP401 Bad credentials10:02:35.674909; changed standard gh api upload of a76-byte checksum sidecar received the same40110:07:55.132480. No authentication recovery, token reading/injection or login was attempted. API draft creation/readback succeeded; actual owned draft407784797 is still unpublished with zero assets. No permanent public file/HTTP body/EOF/SHA delivery is claimed. Root exhausted connector tool search and found no Release upload mutation capability.

Genuine integrated c941 original full acceptance remains valid: run37910650486/official11607094152 actual whole9,929,288bytes SHA64775ea3842308e05324d5858eb4e04049b4e4c8f43b8257253626382607fb44/239safeCRC/EOF, all349/sixdocs/91tests/25mutants/7000matrix/1003seeds/10000oracle/4000true-terminalgames/all80goldraw/native2400intervals2404timestamps/60functionals/alloriginal+excerptclips, final23 unchanged and natural empty-group closure09:48:49.399880. The exact reviewed two-file product fix is integrated, root independent all26physical native peer passed09:16:54.675952, observed firstlegal reductions17,517.100ms desktop/73,472.300ms phoneCPU4. These source/game/native passes remain distinct from the actual delivery failure.

The full tested physical file remains/tmp/G10-integrated-offline-build-17d-20261009/isolated-job/play.html,1,390,847,100bytes SHA b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2. Old unique1,390,846,291-byte/b4f526 baseline, all licensed data/workers/licenses/proofs/raw/dependencies are preserved. Fresh c941→current16fc all349 immutable+physical206/143runtime andsix current Git docs naturally passed09:52:23.373247. After failed upload and sidecar, exact pinned source/self/runtime/full-file guard passed10:12:09.717486:33 READY rows/all349/current six immutable docs/new physical candidate and old baseline identity unchanged. No live delivery child remains; failed full uploadEXIT1/group[]/no signals is not natural PASS.

The first unexecuted Release controller and its prospective tag-collision guard remain unchanged. Actual metadata corruption controls passed4 positives/15 rejections before upload. First READY preparation whole-stat equality rejection and one later system-python alias rejection are preserved with their original code/errors; corrected checks keep every declared immutable dev/inode/size/mtime/ctime/SHA field and use exact pinned Python. Neither failure is a game defect or formal no-gain round. Original1200whole/600upload/300public EOF/1GiB-owned+1.5GiB-shared network protocol was finite, with no new browser/native timing. Actual network resource capacity7,803,092,992>2,684,354,560 required; SHMEM excluded, ordinaryclean bounded5GiB, no slab/cache eviction/cold claim.

Source16fc263293ae40e6d3a2cd7b3b73ecf2db987aaa actually normalpushed09:50:17.749138/exact remote09:50:18.965223/clean09:50:19.724474:1,793.429706seconds/HARDPASS0miss,6.570294s margin; early target missed293.429706s during whole/source proof, no truncation. Own main5b5ec5fa3dc9d592953ebbc0ea129e0f62cb353c parentcbc254e280aba755d73df33b10973deee4db176c, row09:54:30Z/normalpush09:54:32.487776/readback-clean09:54:33.968293, every other row/tree equal and lease released. This next source checkpoint must set only G10's CLAIMS row to literal G10 BLOCKED under parent lease, then move to the next fresh eligible job per the binding queue.

PR10 remains Draft/open/unmerged. KEEP round1 stays IN_PROGRESS/0qualified gains/0completed/0consecutive no-gain. Public body delivery and original KEEP through3 consecutive honest no-player-gain rounds remain unfinished. Resume from BLOCKED.md only when the existing upload-host authorization is available. Reuse the exact owned empty draft after fresh source/docs/physical/runtime guards, verify actual c941 tag after publishing (draft actual matching-ref read wasempty10:13:36), then fully stream actual public HTTP200/EOF/SHA before qualification. Do not rerun obsolete protocol or retry unchanged native timings. No manual credential recovery, deleting original proof or falseReady.

## Earlier checkpoints retained as history

"""
for name in ['NEXT.md','VERIFY.md']:
 p=JOB/name;p.write_text(text+p.read_text())
for name in ['LOOP.md','ASSUMPTIONS.md']:
 p=JOB/name;p.write_text(p.read_text()+'\n2026-10-09 delivery BLOCKED — configured full upload401 and changed configured-api76B sidecar401; private owned draft407784797 remains empty/unpublished. Fresh actual349/sixdocs/33self-runtime/full physical-file guardPASS10:12:09.717486, complete originalc941 proof preserved. No public delivery/qualified KEEP gain or no-gain round; round1 IN_PROGRESS/0completed/0qualified/0consecutive no-gain. Source/main BLOCKED handoff follows binding queue.\n')
readme=(JOB/'README.md').read_text().replace('The complete integrated original CI/native/game/raw/media/source checks\npassed. Permanent full standalone delivery and KEEP qualification remain\npending. PR #10 stays Draft/open; this is not a completion claim.','The complete original CI/native/game/raw/media/source checks passed.\nPermanent full standalone delivery is BLOCKED: uploads.github.com rejects\nconfigured credentials (HTTP401). See BLOCKED.md. KEEP remains unfinished;\nPR #10 stays Draft/open; this is not a completion claim.')
assert len(readme.splitlines())<60;(JOB/'README.md').write_text(readme)
print(json.dumps({'status':'ACTUAL_DELIVERY_BLOCKED_PUBLIC_PROOF_WRITES_CLOSED','closedAt':datetime.now(timezone.utc).isoformat(),'archiveBytes':meta['proofZipBytes'],'archiveSha256':meta['proofZipSha256'],'members':len(members)}),flush=True)
