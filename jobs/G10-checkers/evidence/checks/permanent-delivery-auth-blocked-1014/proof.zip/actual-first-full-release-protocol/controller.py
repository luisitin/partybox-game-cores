"""Finite permanent single-file delivery; never launches a browser or benchmark.
Execution requires genuine integrated original full acceptance and a fresh exact
source/runtime/current-document bridge. Existing configured gh auth only.
"""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ctypes,importlib.util,json,os,selectors,signal,subprocess,sys,time,traceback,shutil
BASE=Path('/tmp/G10-permanent-release-c941-20261009')
JOB=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers')
HOST=Path('/tmp/G10-hosted-c941-currentc941-20261009')
ASSET=Path('/tmp/G10-integrated-offline-build-17d-20261009/isolated-job/play.html')
HEAD='c941c1bb18ccb37525c2e37248b0380ab1682e07'
REPO='luisitin/partybox-game-cores'
TAG='G10-checkers-c941c1b-20261009'
BYTES=1390847100
SHA='b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2'
RSS_LIMIT=1073741824
RESERVE=1610612736
BLOCK=1048576
WHOLE_SECONDS=1200
HELPER=JOB/'.work/hosted-df-memory-parts-cd9/receive.py'
def utc():return datetime.now(timezone.utc).isoformat()
def write(name,value):(BASE/name).write_text(json.dumps(value,indent=2)+'\n')
def digest(path):
 h=sha256()
 with path.open('rb') as f:
  while b:=f.read(BLOCK):h.update(b)
 return h.hexdigest()
def identity(p):
 s=p.stat();return {'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}
def owned():
 table={}
 for p in Path('/proc').glob('[0-9]*/stat'):
  try:
   s=p.read_text();c=s[s.rfind(')')+2:].split();table[int(p.parent.name)]={'ppid':int(c[1]),'state':c[0],'startTicks':int(c[19]),'rssBytes':int(c[21])*os.sysconf('SC_PAGE_SIZE')}
  except (OSError,ValueError,IndexError):pass
 selected={os.getpid()};changed=True
 while changed:
  changed=False
  for pid,r in table.items():
   if r['ppid'] in selected and pid not in selected:selected.add(pid);changed=True
 return [{'pid':pid,**table[pid]} for pid in sorted(selected) if pid in table]
def sample():
 rows=owned();rss=sum(r['rssBytes'] for r in rows);samples.append({'at':utc(),'rssBytes':rss,'processes':rows});assert rss<=RSS_LIMIT,'Declared 1GiB delivery-owned RSS exceeded'
 return rss
def freeze():
 ready=json.loads((BASE/'ready.json').read_text())
 assert ready['qualifiedProductHead']==HEAD
 assert subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=JOB.parent.parent,timeout=10).decode().strip()==ready['currentCheckpoint']
 assert Path(sys.executable).resolve()==Path(ready['files']['python']['path']).resolve()
 assert ready['files']['controller']['path']==str(Path(__file__).resolve())
 for label,row in ready['files'].items():
  p=Path(row['path']);actual={'path':str(p),'sha256':digest(p),'identity':identity(p)};assert actual==row and identity(p)==row['identity'],'Frozen delivery drift: '+label
 for rel,expected in ready['sourceGuards'].items():assert digest(JOB/rel)==expected,rel
 bridge=json.loads(Path(ready['files']['sourceBridge']['path']).read_text())
 assert bridge['status']=='PASS' and bridge['acceptedHead']==HEAD and bridge['currentCheckoutPreserved']==ready['currentCheckpoint'] and bridge['sourceGuardCount']==349
 for row in bridge['sixCurrentDocumentationGitBridge']:
  p=JOB.parent.parent/row['path'];assert digest(p)==row['currentGitSha256'];assert p.read_bytes()==subprocess.check_output(['/usr/bin/git','cat-file','blob',ready['currentCheckpoint']+':'+row['path']],cwd=JOB,timeout=15)
 assert identity(ASSET)==ready['assetIdentity'] and digest(ASSET)==SHA and ASSET.stat().st_size==BYTES and identity(ASSET)==ready['assetIdentity']
 accepted=json.loads((HOST/'controller.json').read_text());whole=json.loads((HOST/'independent-complete-evidence.json').read_text());close=json.loads((HOST/'owner-closure.json').read_text())
 assert accepted['status']=='CLOSED_PASS' and accepted['head']==HEAD and whole['status']=='PASS' and whole['head']==HEAD and whole['htmlBytes']==BYTES and whole['sourceSha256']==SHA and whole['stageGuardCount']==349
 assert close['closure']['natural'] and close['closure']['actualExitCode']==0 and not close['closure']['actualRemainingGroup']
 return ready
def run(name,args,bound):
 failed=False;child=None;start=utc();closure=None
 with (BASE/(name+'.stdout')).open('xb') as out,(BASE/(name+'.stderr')).open('xb') as err:
  try:
   child=subprocess.Popen(args,cwd=JOB,stdout=out,stderr=err,start_new_session=True)
   end=time.monotonic()+bound
   while child.poll() is None:
    sample();assert time.monotonic()<end,'Declared '+name+' finite deadline exceeded'
    try:child.wait(timeout=.2)
    except subprocess.TimeoutExpired:pass
   assert child.returncode==0,name
  except BaseException:failed=True;raise
  finally:
   if child:closure=groups.close_worker_group(child,failed);write(name+'-closure.json',{'startedAt':start,'closedAt':utc(),'pid':child.pid,'declaredSeconds':bound,**closure})
 assert closure['natural'] and not closure['actualRemainingGroup'] and len(owned())==1,name+' descendants remain'
 return (BASE/(name+'.stdout')).read_bytes()
def select_asset(raw):
 release=json.loads(raw);assert release['tag_name']==TAG and release['target_commitish']==HEAD
 assets=[a for a in release['assets'] if a['name']=='play.html'];assert len(assets)==1
 asset=assets[0];assert asset['state']=='uploaded' and asset['size']==BYTES and asset['digest']=='sha256:'+SHA
 assert asset['browser_download_url']=='https://github.com/'+REPO+'/releases/download/'+TAG+'/play.html'
 return release,asset
def receive(url):
 start=utc();child=None;failed=False;count=0;h=sha256();closure=None
 with (BASE/'public-download.stderr').open('xb') as err:
  try:
   child=subprocess.Popen(['/usr/bin/curl','--silent','--show-error','--fail','--location','--connect-timeout','15','--max-time','300','--retry','0','--max-filesize',str(BYTES),'--write-out','%{stderr}\nG10_HTTP_STATUS:%{http_code}\n','--output','-',url],stdout=subprocess.PIPE,stderr=err,start_new_session=True)
   selector=selectors.DefaultSelector();selector.register(child.stdout,selectors.EVENT_READ);end=time.monotonic()+305
   while True:
    sample();assert time.monotonic()<end,'Declared whole public EOF deadline exceeded'
    if not selector.select(timeout=.2):continue
    b=os.read(child.stdout.fileno(),BLOCK)
    if not b:break
    count+=len(b);assert count<=BYTES,'Public body exceeds exact complete payload'
    h.update(b)
   selector.close();child.stdout.close();assert child.wait(timeout=5)==0
   statuses=[s.removeprefix('G10_HTTP_STATUS:') for s in (BASE/'public-download.stderr').read_text().splitlines() if s.startswith('G10_HTTP_STATUS:')]
   assert statuses==['200'] and count==BYTES and h.hexdigest()==SHA,'Public asset HTTP/EOF/byte/SHA mismatch'
  except BaseException:failed=True;raise
  finally:
   if child:
    if child.stdout and not child.stdout.closed:child.stdout.close()
    closure=groups.close_worker_group(child,failed)
    write('public-download-closure.json',{'startedAt':start,'closedAt':utc(),'pid':child.pid,'actualReceivedBytes':count,'actualReceivedSha256':h.hexdigest(),'noSecondPhysicalPayloadAllocation':True,**closure})
 assert closure['natural'] and not closure['actualRemainingGroup'] and len(owned())==1
 write('public-whole-asset.json',{'status':'PASS','startedAt':start,'closedAt':utc(),'url':url,'httpStatus':200,'bytes':count,'sha256':h.hexdigest(),'scope':'Actual complete real PUBLIC Release HTTP body streamed through EOF/SHA, bounded1MiB sink. No new benchmark/browser or duplicate1.39GB allocation.'})
def main():
 def alarm(signum,frame):raise TimeoutError('Declared whole permanent delivery deadline exceeded')
 signal.signal(signal.SIGALRM,alarm);signal.alarm(WHOLE_SECONDS)
 assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
 started=utc();ready=freeze();write('source-self-runtime-before.json',ready)
 assert shutil.which('gh')=='/usr/bin/gh' and shutil.which('curl')=='/usr/bin/curl'
 stat={k:int(v) for k,v in (line.split() for line in Path('/sys/fs/cgroup/memory.stat').read_text().splitlines())}
 limit=int(Path('/sys/fs/cgroup/memory.max').read_text());current=int(Path('/sys/fs/cgroup/memory.current').read_text())
 ordinary=max(0,stat['active_file']+stat['inactive_file']-stat['file_dirty']-stat['file_writeback']);credit=min(ordinary,5*1024**3);capacity=limit-current+credit
 assert capacity>RSS_LIMIT+RESERVE
 disk=os.statvfs(BASE);assert disk.f_bavail*disk.f_frsize>128*1024**2
 write('resource-before.json',{'at':utc(),'memoryMax':limit,'memoryCurrent':current,'ordinaryCleanBytes':ordinary,'bounded5GiBCredit':credit,'shmemExcludedBytes':stat['shmem'],'potentialCapacity':capacity,'requiredOwnedPlusReserve':RSS_LIMIT+RESERVE,'tmpFreeBytes':disk.f_bavail*disk.f_frsize,'scope':'Untimed finite network delivery1GiB-owned/1.5GiB-shared resource gate; no shmem/dirty/writeback/slab credit, no eviction/cold-cache claim; original native performance gates unchanged.'})
 inventory=json.loads(run('preflight-releases',['/usr/bin/gh','api','repos/'+REPO+'/releases?per_page=100'],30));assert all(r['tag_name']!=TAG for r in inventory),'Do not reuse or overwrite actual Release'
 tags=json.loads(run('preflight-tag-prefix',['/usr/bin/gh','api','repos/'+REPO+'/git/matching-refs/tags/'+TAG],30));assert all(t['ref']!='refs/tags/'+TAG for t in tags),'Do not reuse an existing actual tag'
 run('create-draft',['/usr/bin/gh','release','create',TAG,'--repo',REPO,'--draft','--prerelease','--target',HEAD,'--title','American and International checkers: tested offline build','--notes-file',str(BASE/'notes.md')],60)
 run('upload-existing-full-file',['/usr/bin/gh','release','upload',TAG,str(ASSET),'--repo',REPO],600)
 release,asset=select_asset(run('uploaded-release-metadata',['/usr/bin/gh','api','repos/'+REPO+'/releases/tags/'+TAG],30));assert release['draft'] and release['prerelease']
 tag=json.loads(run('actual-tag-ref',['/usr/bin/gh','api','repos/'+REPO+'/git/ref/tags/'+TAG],30));assert tag['object']['type']=='commit' and tag['object']['sha']==HEAD
 run('publish-verified-upload',['/usr/bin/gh','release','edit',TAG,'--repo',REPO,'--draft=false','--latest=false'],60)
 published,asset=select_asset(run('published-release-metadata',['/usr/bin/gh','api','repos/'+REPO+'/releases/tags/'+TAG],30));assert not published['draft'] and published['prerelease']
 receive(asset['browser_download_url'])
 assert freeze()==ready
 write('source-self-runtime-after.json',ready)
 write('controller.json',{'status':'CLOSED_PASS','startedAt':started,'closedAt':utc(),'sourceHead':HEAD,'currentCheckpoint':ready['currentCheckpoint'],'releaseId':published['id'],'tag':TAG,'assetId':asset['id'],'publicUrl':asset['browser_download_url'],'actualBytes':BYTES,'actualSha256':SHA,'sampledOwnedPeakRssBytes':max(x['rssBytes'] for x in samples),'sourceSelfRuntimeBeforeAfterEqual':True,'scope':'Genuine permanent single-file exact qualified integrated full offline delivery; actual configured-gh draft/upload/tag/meta/publication and full public HTTP EOF/SHA with349runtime/current6docs/self inputs unchanged/natural empty descendants. No original gate weakening/new timing trial or automatic KEEP-round completion.'})
 print(json.dumps({'status':'CLOSED_PASS','closedAt':utc(),'url':asset['browser_download_url'],'bytes':BYTES,'sha256':SHA}),flush=True)
samples=[]
s=importlib.util.spec_from_file_location('groups',HELPER);groups=importlib.util.module_from_spec(s);s.loader.exec_module(groups)
if __name__=='__main__':
 try:main()
 except BaseException as error:write('failure.json',{'status':'FAILED','closedAt':utc(),'type':type(error).__name__,'error':str(error),'traceback':traceback.format_exc(),'scope':'Actual permanent delivery failure preserved; no false complete public byte acceptance/KEEP qualification.'});raise
 finally:
  signal.alarm(0);write('rss-samples.json',{'samples':samples,'scope':'Actual sampled owned-process RSS during untimed delivery; not an instantaneous peak or guaranteed sampling cadence.'})
