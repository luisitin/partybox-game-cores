# American and International checkers
Download play.html and open it from disk. The game works offline, with no setup or runtime network access.

American 8×8 and International 10×10 checkers, forced captures and multi-jumps, kings, draw rules, and a deterministic alpha-beta bot with the complete licensed 2–6-piece endgame corpus.

The complete endgame data makes this file about 1.39 GB. Allow time for the download and for the first opening. The International worker can become ready before the browser finishes parsing the rest of the file.

Source commit: c941c1bb18ccb37525c2e37248b0380ab1682e07
play.html bytes: 1390847100
SHA-256: b85a8288345c8e0040d523e3998d31216aa61b6872c8e3bc76313944802dd1b2

The source folder includes third-party data attribution and full licenses; the offline file embeds them as well.
