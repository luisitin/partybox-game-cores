from pathlib import Path
from datetime import datetime,timezone
from hashlib import sha256
import json,os,shutil
job=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers');base=Path('/tmp/G10-permanent-release-c941-20261009');host=Path('/tmp/G10-hosted-c941-currentc941-20261009')
bridge=Path('/tmp/G10-source-runtime-c941-to16fc-20261009/historical-git-guards.json')
b=json.loads(bridge.read_text());assert b['status']=='PASS' and b['acceptedHead']=='c941c1bb18ccb37525c2e37248b0380ab1682e07' and b['currentCheckoutPreserved']=='16fc263293ae40e6d3a2cd7b3b73ecf2db987aaa'
stage=json.loads((host/'extracted/.work/checks/stage-node.json').read_text());guards=stage['sourceGuardsAfter'];assert len(guards)==349 and stage['sourceGuardsBefore']==guards
def row(p):
 p=p.absolute();s=p.stat();h=sha256()
 with p.open('rb') as f:
  while block:=f.read(1048576):h.update(block)
 after=p.stat(); assert (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns)==(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 return {'path':str(p),'sha256':h.hexdigest(),'identity':{'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}}
paths={'controller':base/'controller.py','originalUnexecutedController':base/'controller-UNEXECUTED.py','prospectiveTagGuard':base/'prospective-tag-guard.json','metadataControls':base/'metadata-controls.json','notes':base/'notes.md','proposal':base/'proposal.json','sourceBridge':bridge,'sourceBridgeCode':job/'.work/bridge-c941-to16fc-0951/audit.py','sourceBridgeClosure':bridge.parent/'owner-closure.json','groupHelper':job/'.work/hosted-df-memory-parts-cd9/receive.py','python':Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12'),'gh':Path('/usr/bin/gh'),'curl':Path('/usr/bin/curl'),'git':Path('/usr/bin/git'),'node22':job/'.work/memory-json-private/node22/runtime/bin/node','qualifiedOriginalCompleteController':host/'controller.json','qualifiedOriginalCompleteReaderReceipt':host/'independent-complete-evidence.json','qualifiedOriginalWholeZipReceipt':host/'zip-integrity.json','qualifiedOriginalOwnerClosure':host/'owner-closure.json','qualifiedOriginalNodeStage':host/'extracted/.work/checks/stage-node.json','qualifiedOriginalFinalFreeze':host/'execution-freeze-finally.json','qualifiedWholeOfficialZip':host/'complete.zip','originalUniqueBaselineHtml':job/'.work/play-full-candidate-b4.html'}
gitbase=Path('/tmp/G10-local-d619-independent-20261009/repo/.git')
for label,relative in [('isolatedGitHEAD','HEAD'),('isolatedGitBranch','refs/heads/job/G10-checkers-complete-20261008'),('isolatedGitIndex','index'),('isolatedGitAlternates','objects/info/alternates')]:paths[label]=gitbase/relative
for doc in b['sixCurrentDocumentationGitBridge']:paths['currentDoc-'+Path(doc['path']).name]=job.parent.parent/doc['path']
files={name:row(p) for name,p in paths.items()}
assert files['controller']['sha256']=='6e83926c19af33a95a604a8bc724ff8b9489819d197bc9132b5446bf2327b2e8'
assert files['originalUniqueBaselineHtml']['sha256']=='b4f5267561bd95d68455ea5a83b936692b246d1a8ed936199c820e430a2da3eb'
asset=Path('/tmp/G10-integrated-offline-build-17d-20261009/isolated-job/play.html');s=asset.stat()
ready={'status':'FROZEN_UNEXECUTED_PERMANENT_DELIVERY_READY','preparedAt':datetime.now(timezone.utc).isoformat(),'qualifiedProductHead':'c941c1bb18ccb37525c2e37248b0380ab1682e07','currentCheckpoint':'16fc263293ae40e6d3a2cd7b3b73ecf2db987aaa','files':files,'sourceGuards':guards,'assetIdentity':{'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns},'scope':'Exact genuinely qualified c941 product/current16fc unchanged349/six immutable-doc bridge; existing physical full1,390,847,100-byte/b85a828 offline asset, no second giant allocation. Finite one protocol1200whole/600upload/300public EOF/1GiBowned+1.5GiBreserve/source-self-runtime guards and natural empty-child closures. Standard installed configured gh auth only; no recovery or injected credentials, no new browser/native timing or automatic KEEP completion.'}
(base/'ready.json').write_text(json.dumps(ready,indent=2)+'\n')
print(json.dumps({'status':ready['status'],'preparedAt':ready['preparedAt'],'frozenFiles':len(files),'runtimeSourceGuards':len(guards),'currentCheckpoint':ready['currentCheckpoint'],'readySha256':sha256((base/'ready.json').read_bytes()).hexdigest(),'scope':ready['scope']}),flush=True)
