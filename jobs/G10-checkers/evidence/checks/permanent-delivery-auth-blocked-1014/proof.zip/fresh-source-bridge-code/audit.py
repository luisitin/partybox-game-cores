from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import posixpath
import subprocess

HEAD = 'c941c1bb18ccb37525c2e37248b0380ab1682e07'
base = Path('/tmp/G10-source-runtime-c941-to16fc-20261009')
started = datetime.now(timezone.utc).isoformat()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == '16fc263293ae40e6d3a2cd7b3b73ecf2db987aaa'
receipt = json.loads((base / 'extracted/.work/checks/stage-node.json').read_text())
assert receipt['sourceCommit'] == HEAD and receipt['workflowRunId'] == '37910650486'
guards = receipt['sourceGuardsAfter']
assert receipt['sourceGuardsBefore'] == guards and len(guards) == 349
tracked = set(subprocess.check_output(['git', 'ls-tree', '--full-tree', '-r', '--name-only', HEAD], text=True).splitlines())
original, generated = [], []
for relative, expected in guards.items():
    path = posixpath.normpath('jobs/G10-checkers/' + relative)
    digest = sha256()
    if path in tracked:
        process = subprocess.Popen(['git', 'cat-file', 'blob', HEAD + ':' + path], stdout=subprocess.PIPE)
        while block := process.stdout.read(1024 * 1024):
            digest.update(block)
        assert process.wait() == 0 and digest.hexdigest() == expected, path
        assert sha256(subprocess.check_output(['git','cat-file','blob','16fc263293ae40e6d3a2cd7b3b73ecf2db987aaa'+':'+path])).hexdigest()==expected, 'Current immutable Git original changed: '+path
        current_physical=sha256()
        with Path(relative).open('rb') as current_source:
            while block := current_source.read(1024 * 1024):current_physical.update(block)
        assert current_physical.hexdigest()==expected, 'Current physical original changed: '+relative
        original.append(path)
    else:
        with Path(relative).open('rb') as source:
            while block := source.read(1024 * 1024):
                digest.update(block)
        assert digest.hexdigest() == expected, relative
        generated.append(relative)
assert len(original) == 206 and len(generated) == 143
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == '16fc263293ae40e6d3a2cd7b3b73ecf2db987aaa'
docs=[]
for name in ['README.md','VERIFY.md','NEXT.md','LOOP.md','ASSUMPTIONS.md','SHA256SUMS.txt']:
    path='jobs/G10-checkers/'+name
    accepted_bytes=subprocess.check_output(['git','cat-file','blob',HEAD+':'+path])
    current_bytes=subprocess.check_output(['git','cat-file','blob','16fc263293ae40e6d3a2cd7b3b73ecf2db987aaa'+':'+path])
    assert Path(name).read_bytes()==current_bytes
    docs.append({'path':path,'acceptedGitSha256':sha256(accepted_bytes).hexdigest(),'currentGitSha256':sha256(current_bytes).hexdigest(),'workingBytesMatchCurrentGit':True,'equalToAccepted':accepted_bytes==current_bytes})
result = {'currentCheckoutPreserved':'16fc263293ae40e6d3a2cd7b3b73ecf2db987aaa','sixCurrentDocumentationGitBridge':docs,'status': 'PASS', 'startedAt': started, 'closedAt': datetime.now(timezone.utc).isoformat(),
          'acceptedHead': HEAD, 'sourceGuardCount': len(guards),
          'gitTrackedOriginalBytes': original, 'generatedRuntimePathsRequireCurrentByteMatch': generated,
          'scope': 'Genuine acceptedc941 original349 Node-stage guards with all206 current16fc immutable Git plus physical original bytes and143 generated/runtime hashes; explicit six current16fc docs working==immutableGit outside349 guard set. Only unchanged source/runtime bridge, not a new full workflow, production adoption or player gain.'}
(base / 'historical-git-guards.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'head': HEAD, 'originalGitFiles': len(original),
                  'generatedRuntimeFiles': len(generated), 'closedAt': result['closedAt']}))
