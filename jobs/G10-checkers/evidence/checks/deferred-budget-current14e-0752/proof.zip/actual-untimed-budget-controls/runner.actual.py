from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ast,difflib,json,subprocess,time,sys,importlib.util,traceback
job=Path('/workspace/game-cores-G10-audit-worker/jobs/G10-checkers')
source=job/'.work/international-ready-private/native-deferred-bounded-current14e'
old=job/'.work/international-ready-private/native-deferred-closure-current1120'
out=Path('/tmp/G10-native-budget-controls-14e-20261009');out.mkdir(exist_ok=False)
node=job/'.work/memory-json-private/node22/runtime/bin/node'
t=lambda:datetime.now(timezone.utc).isoformat()
sha=lambda p:sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in [source/'observe.mjs',source/'controller.py',old/'observe.mjs',old/'controller.py',old/'ready.json',old/'freeze-spec.json',node,Path(sys.executable).resolve()]}
s=importlib.util.spec_from_file_location('actual_group_helper',job/'.work/hosted-df-memory-parts-cd9/receive.py');groups=importlib.util.module_from_spec(s);s.loader.exec_module(groups)
steps=[]
def child(name,argv):
 started=t();p=None;closure=None
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  try:
   p=subprocess.Popen(argv,cwd=job,stdout=stdout,stderr=stderr,start_new_session=True)
   assert p.wait(timeout=15)==0,name
  finally:
   if p:closure=groups.close_worker_group(p,p.poll()!=0)
 steps.append({'name':name,'argv':argv,'startedAt':started,'closedAt':t(),'closure':closure})
 assert closure['natural'] and closure['actualExitCode']==0 and not closure['actualRemainingGroup']
 assert (out/(name+'.stderr')).stat().st_size==0
 return (out/(name+'.stdout')).read_text()
started=t();status='FAILED'
try:
 driver=(source/'observe.mjs').read_text();controller=(source/'controller.py').read_text()
 tree=ast.parse(controller);compile(tree,str(source/'controller.py'),'exec')
 child('actual-driver-node-syntax',[str(node),'--check',str(source/'observe.mjs')])
 needle="  report.nativeDriverElapsedMs=performance.now()-began;"
 begin=driver.index(needle);end=driver.index("  report.pureReplayAfterAllBrowserAndServerClosures=true;",begin)
 actual=driver[begin:end]
 assert actual.count('performance.now()')==1
 assertion=actual.splitlines()[1]
 outcome=actual.splitlines()[3]
 fixture="import assert from 'node:assert/strict';\nconst ready={wholeTrialTimeoutMs:360000};\nconst outcomes=[];\nfor(const value of [0,359999.9,360000,360000.0001,-1,NaN,Infinity]){const report={nativeDriverElapsedMs:value};let accepted=true;try{"+assertion+"}catch(error){assert(error instanceof assert.AssertionError);accepted=false;}assert.equal(accepted,Number.isFinite(value)&&value>=0&&value<=360000);outcomes.push({value:String(value),accepted});}\nfor(const playerGainPredicate of [false,true]){const report={playerGainPredicate};"+outcome+"assert.equal(report.auditOutcome,playerGainPredicate?'PLAYER_GAIN_PREDICATE_PASSED_PENDING_INDEPENDENT_VALIDATION':'AUDIT_COMPLETED_NO_PLAYER_GAIN');}\nconsole.log(JSON.stringify({status:'PASS',constantFixtureOnly:true,nativeClockRead:false,actualAssertion:"+json.dumps(assertion)+",outcomes}));\n"
 (out/'driver-actual-final-assertion-constant-fixture.mjs').write_text(fixture)
 native_results=json.loads(child('actual-driver-final-budget-boundaries',[str(node),str(out/'driver-actual-final-assertion-constant-fixture.mjs')]))
 matches=[x for x in ast.walk(tree) if isinstance(x,ast.Assert) and isinstance(x.msg,ast.Constant) and x.msg.value=='Independent entire native-driver monotonic interval exceeded unchanged360000ms budget']
 assert len(matches)==1
 actual_assert=ast.Module(body=matches,type_ignores=[]);assert_code=compile(actual_assert,'actual-controller-budget-assertion','exec')
 boundary=[]
 for value in [0,359999.9,360000,360000.0001]:
  accepted=True
  try:exec(assert_code,{'nativeDriverIntervalMs':value,'raw':{'wholeTrialTimeoutMs':360000}})
  except AssertionError:accepted=False
  assert accepted==(value<=360000)
  boundary.append({'constantFixtureIntervalMs':value,'accepted':accepted})
 (out/'actual-controller-independent-budget-boundaries.json').write_text(json.dumps({'status':'PASS','nativeClockRead':False,'actualAssertSource':ast.get_source_segment(controller,matches[0]),'constantBoundaries':boundary},indent=2)+'\n')
 oldready=json.loads((old/'ready.json').read_text())
 assert oldready['wholeTrialTimeoutMs']==360000 and oldready['nativeChildWallSeconds']==440 and oldready['controllerWholeWallSeconds']==540 and oldready['ownedDescendantRssEnvelopeBytes']==4831838208
 for line in ["RSS_ENVELOPE=4608*1024**2;SHARED_RESERVE=1536*1024**2;MAX_CLEAN_FILE_CREDIT=5*1024**3","WHOLE_SECONDS=540;NATIVE_CHILD_SECONDS=440"]:
  assert line in controller and line in (old/'controller.py').read_text()
 for line in ["const began=performance.now(),remaining=()=>Math.max(1,Math.floor(ready.wholeTrialTimeoutMs-(performance.now()-began)));","first.at-changed.at>=500","await page.addInitScript"]:
  assert line in driver and line in (old/'observe.mjs').read_text()
 assert 'ready.wholeTrialTimeoutMs,360000' in driver
 assert not any(Path('/tmp/G10-international-first-legal-deferred-bounded14e-20261009').iterdir())
 assert {p:sha(Path(p)) for p in before}==before
 status='PASS'
except BaseException as error:
 (out/'failure.json').write_text(json.dumps({'at':t(),'error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 after={p:sha(Path(p)) for p in before}
 result={'status':status,'startedAt':started,'closedAt':t(),'sourceRuntimeBefore':before,'sourceRuntimeAfter':after,'allByteEqual':after==before,'steps':steps,'scope':'Untimed actual final-budget syntax/constant-boundary/schema and label controls only. Original driver never executed; no performance.now/date timing substitution in any actual native run, no browser/replay/HTTP/trial/grant/gain. Old UNEXECUTED1120 sources/READY/spec unchanged; new future native output empty. Original360/440/540/4.5GiB/500ms/observer lines unchanged.'}
 (out/'controls.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ['sourceRuntimeBefore','sourceRuntimeAfter','steps']}),flush=True)
