"""ONE finite untimed complete HTTP byte check. No browser/timing/adoption."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ctypes,importlib.util,json,os,signal,subprocess,sys,time,traceback,urllib.request
JOB=Path.cwd();BASE=JOB/'.work/international-ready-private';OUT=BASE/'http-current-72'
HEAD='72c2a917561f3ab5d4324554a1b40d06db1bc47f';NODE=JOB/'.work/memory-json-private/node22/runtime/bin/node'
def utc():return datetime.now(timezone.utc).isoformat()
def digest(p):
 h=sha256()
 with p.open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
def row(p):
 p=p.absolute();s=p.stat();return {'path':str(p),'resolved':str(p.resolve()),'sha256':digest(p),'identity':{'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}}
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def alarm(*_):raise TimeoutError('Declared finite 180-second whole untimed proof limit')
signal.signal(signal.SIGALRM,alarm);signal.alarm(180)
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
spec=json.loads((BASE/'producer-spec-current-4369.json').read_text());manifest=json.loads((BASE/'delta-controls-4369.json').read_text());files={}
started=utc();child=None;before=None;failed=False;closure=None;report={'status':'RUNNING','startedAt':started,'head':HEAD,'requests':[]}
try:
 assert not (OUT/'controller.json').exists(),'Preserve actual attempt; never overwrite'
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==HEAD
 changed=subprocess.check_output(['git','diff','--name-only','474c1a64b3a8f69b81b3bd60f0a55f2782dc8d1f',HEAD],text=True).splitlines()
 for p in changed:assert p in ['jobs/G10-checkers/'+n for n in ['README.md','VERIFY.md','NEXT.md','LOOP.md','ASSUMPTIONS.md','SHA256SUMS.txt']] or p.startswith('jobs/G10-checkers/evidence/checks/'),p
 for label,old in spec['files'].items():
  p=Path(old['path']);r=row(p)
  if label.startswith('doc:'):
   name=label.removeprefix('doc:');assert p.read_bytes()==subprocess.check_output(['git','cat-file','blob',HEAD+':jobs/G10-checkers/'+name])
  else:assert r['sha256']==old['sha256'],'Actual saved bytes drifted: '+label
  files[label]=r
 extras=[Path(__file__),OUT/'server.mjs',OUT/'server-derivation.diff',BASE/'delta-controls-4369.json',BASE/'generated/raw-output.json',BASE/'generated/candidate-bootstrap.js',BASE/'international-ready-marker.html',Path(manifest['basePath'])]
 for p in extras:files['http:'+str(p)]=row(p)
 def freeze():
  assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==HEAD
  actual={k:row(Path(v['path'])) for k,v in files.items()};assert actual==files,'Source/self/runtime identity changed'
  installed=[]
  for folder,dirs,names in os.walk(JOB/'node_modules',followlinks=True):
   for name in names:
    p=Path(folder)/name
    if p.is_file():installed.append(str(p))
  assert sorted(installed)==spec['installedLogicalFiles']
  return actual
 before=freeze();write('freeze-before.json',before)
 assert digest(NODE)=='8142d37c6f2f372ef040419e7a111a6baf17df89f8078d02447d6c639ae20c1d'
 assert digest(OUT/'server.mjs')=='63c8ede344b56519ad9697a428aa73996dfc4c84bbaea638ceb5bc1d7847fc65'
 memory=Path('/sys/fs/cgroup');headroom=int((memory/'memory.max').read_text())-int((memory/'memory.current').read_text());assert headroom>512*1024**2+1536*1024**2
 disk=os.statvfs(OUT);free=disk.f_bavail*disk.f_frsize;assert free>128*1024**2+16*1024**2
 report.update({'frozenFiles':len(files),'originalSourceGuards':349,'currentDocs':6,'immutableRuntimePathBridge':changed,'memoryHeadroomBefore':headroom,'diskFreeBefore':free,'declaredWallLimitSeconds':180})
 helper=Path(spec['files']['helper']['path']);assert digest(helper)=='dc9b18ff9f62430b51538c96f82cf691813f0ef3ff28a88112a70e67736fc241';s=importlib.util.spec_from_file_location('groups',helper);groups=importlib.util.module_from_spec(s);s.loader.exec_module(groups)
 with (OUT/'server.stdout').open('wb') as out,(OUT/'server.stderr').open('wb') as err:
  child=subprocess.Popen([str(NODE),str(OUT/'server.mjs')],cwd=JOB,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','TZ':'UTC'},stdout=out,stderr=err,start_new_session=True)
  deadline=time.monotonic()+40
  while True:
   lines=(OUT/'server.stdout').read_text().splitlines()
   if lines:break
   assert child.poll() is None,'Actual server stopped before listening'
   assert time.monotonic()<deadline,'Finite server readiness budget exceeded'
   time.sleep(.05)
  launch=json.loads(lines[0]);assert launch['status']=='LISTENING' and launch['manifestSha256']==digest(BASE/'delta-controls-4369.json')
  for variant,n,expected in [('baseline',manifest['baseBytes'],manifest['baseSha256']),('candidate',manifest['resultBytes'],manifest['resultSha256'])]:
   h=sha256();count=0
   with urllib.request.urlopen('http://127.0.0.1:'+str(launch['port'])+'/'+variant+'.html',timeout=45) as response:
    assert response.status==200 and int(response.headers['Content-Length'])==n and response.headers['Content-Type']=='text/html; charset=utf-8' and response.headers.get('Content-Encoding') is None
    while b:=response.read(1<<20):h.update(b);count+=len(b)
   assert count==n and h.hexdigest()==expected,'Actual complete HTTP bytes differ'
   report['requests'].append({'variant':variant,'actualBytesThroughEOF':count,'sha256':h.hexdigest(),'closedAt':utc()})
  with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:'+str(launch['port'])+'/close',method='POST'),timeout=20) as response:assert response.read()==b'Closing'
  assert child.wait(timeout=45)==0
 closure=groups.close_worker_group(child,False);assert closure['natural'] and not closure['actualRemainingGroup']
 lines=(OUT/'server.stdout').read_text().splitlines();closed=json.loads(lines[-1]);assert closed['status']=='CLOSED' and closed['finalSourceSha256']==manifest['baseSha256'] and len(closed['requests'])==2
 for actual,emitted in zip(report['requests'],closed['requests']):assert emitted['status']=='EMITTED_VERIFIED' and emitted['variant']==actual['variant'] and emitted['bytes']==actual['actualBytesThroughEOF'] and emitted['wholeSha256']==actual['sha256']
 assert (OUT/'server.stderr').stat().st_size==0
 report.update({'status':'CLOSED_PASS','closure':closure,'wholeHTTPBaselineAndCandidateIndependentEOFMatchCanonicalProducer':True,'scope':'Actual finite untimed complete HTTP baseline/candidate byte delivery on exact current72; all349 original guards/six current immutable docs/full installed aliases/self/runtime unchanged. No browser, native timing, offline acceptance, source adoption, player gain or KEEP completion.'})
except BaseException as e:
 failed=True;report.update({'status':'CLOSED_FAILED','errorType':type(e).__name__,'error':str(e),'traceback':traceback.format_exc()});raise
finally:
 try:
  if child is not None and closure is None:
   s=importlib.util.spec_from_file_location('groups',Path(spec['files']['helper']['path']));g=importlib.util.module_from_spec(s);s.loader.exec_module(g);closure=g.close_worker_group(child,True)
  report['closure']=closure
  after=freeze() if before is not None else None
  assert after is not None and after==before,'Whole fails if final freeze unavailable or changed'
  write('freeze-finally.json',{'status':'PASS','closedAt':utc(),'actual':after});report['fullBeforeAfterFinallyFrozen']=True
 except BaseException as e:
  failed=True;report.update({'status':'CLOSED_FAILED','finalFreezeFailure':str(e)})
  write('freeze-finally.json',{'status':'FAILED','closedAt':utc(),'error':str(e)})
 signal.alarm(0);report['closedAt']=utc();write('controller.json',report);print(json.dumps({k:v for k,v in report.items() if k!='immutableRuntimePathBridge'}),flush=True)
 if failed:sys.exit(1)
