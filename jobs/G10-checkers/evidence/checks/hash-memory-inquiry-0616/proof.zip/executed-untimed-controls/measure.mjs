// Untimed integrity-only allocation inquiry. No browser/timer/game execution.
import assert from 'node:assert/strict';
import {createReadStream} from 'node:fs';
import {readFile,open} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {init,reduce,controllerView,turnId} from '../../dist/core.mjs';
assert([init,reduce,controllerView,turnId].every(value=>typeof value==='function'));
assert.equal(process.version,'v22.16.0');
const mode=process.argv[2];assert(['original-stream','reused-buffer'].includes(mode));
const spec=JSON.parse(await readFile(process.argv[3],'utf8'));
const original=async path=>{const h=createHash('sha256');for await(const bytes of createReadStream(path))h.update(bytes);return h.digest('hex');};
const buffer=mode==='reused-buffer'?Buffer.alloc(1024*1024):null;
async function reused(path){const handle=await open(path,'r'),hash=createHash('sha256');try{for(;;){const {bytesRead}=await handle.read(buffer,0,buffer.length,null);if(bytesRead===0)break;hash.update(buffer.subarray(0,bytesRead));}return hash.digest('hex');}finally{await handle.close();}}
let index=0;
for(const [label,row] of Object.entries(spec.inputFiles)){
 const actual=await(mode==='original-stream'?original(row.path):reused(row.path));assert.equal(actual,row.sha256,label);
 console.log(JSON.stringify({index:index++,label,path:row.path,sha256:actual,bytes:row.identity.bytes,status:'ACTUAL_FULL_SHA_EOF_MATCH'}));
}
console.log(JSON.stringify({status:'ALL_INPUTS_SHA_EOF_PASS',mode,inputs:index,scope:'Untimed hash-only inquiry over exact source/runtime/aliases; same pure core import, one process per method, no browser/game/FPS/first-move/cold-cache/timing/retry/adoption or KEEP result.'}));
