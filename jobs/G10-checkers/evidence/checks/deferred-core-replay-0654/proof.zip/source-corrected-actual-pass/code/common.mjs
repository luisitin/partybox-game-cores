// Untimed replay scheduling comparison. Reads already closed genuine native observations only.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
assert.equal(process.version,'v22.16.0');
export async function collect(){
 const spec=JSON.parse(await readFile(process.argv[2],'utf8'));
 let matches=0;
 for(const [label,row] of Object.entries(spec.inputFiles)){
  const h=createHash('sha256');let bytes=0;
  for await(const block of createReadStream(row.path)){h.update(block);bytes+=block.length;}
  assert.equal(h.digest('hex'),row.sha256,label);assert.equal(bytes,row.identity.bytes,label);matches++;
 }
 const actual=JSON.parse(await readFile(spec.savedNativeReportPath,'utf8'));
 assert.equal(actual.status,'PASS');assert.equal(actual.profiles.length,4);assert(actual.closedAt&&actual.serverClosure.code===0&&actual.serverClosure.signal===null);
 assert.equal(actual.profiles.flatMap(p=>p.observer.games).length,8);
 assert.deepEqual(actual.profiles.map(p=>[p.name,p.arm]),[['desktop','baseline'],['desktop','candidate'],['phone','candidate'],['phone','baseline']]);
 for(const p of actual.profiles){assert.equal(p.errors.length,0);assert.equal(p.failedRequests.length,0);assert.equal(p.observer.games.length,2);assert(p.observer.events.every(e=>e.trusted));}
 console.log(JSON.stringify({phase:'SAVED_CLOSED_ALL_FOUR_NATIVE_ARMS_COLLECTED',actualHistoricalClosedAt:actual.closedAt,actualFullShaEofMatches:matches,scope:'Old genuine closed saved observations only; no native/browser launch or timing claim.'}));
 return {spec,actual,matches};
}
export async function replay(inputs,core,bots,mode){
 const {spec,actual,matches}=inputs;const {init,reduce,controllerView,turnId,createRng,sampleInput}=core;
 assert([init,reduce,controllerView,turnId,createRng,sampleInput,bots.searchMove].every(v=>typeof v==='function'));
 const rows=[];
 for(const p of actual.profiles){
  for(const [index,variant] of ['american','international'].entries()){
   const g=p.observer.games[index],f=g.firstMove,s=f.state;
   assert(g.trusted);assert.equal(g.variant,variant);assert.equal(g.beforeState,null);assert.equal(s.variant,variant);assert.equal(s.ply,1);
   assert.equal(f.host.workerVariant,variant);assert.equal(f.host.workerStarts,index+1);assert.equal(f.host.workerReady,true);assert(f.host.lastBotReport);
   assert.equal(s.moveLog.length,1);assert.equal(s.lastMove.playerId,'seat-0');
   const original=init({players:s.order.map(id=>s.players[id]),seed:20261008,now:g.clickAt,settings:s.settings});
   const legal=controllerView(original,turnId(original)).legalMoves;
   assert(legal.some(m=>JSON.stringify(m)===JSON.stringify(s.lastMove.move)));
   const replayed=reduce(original,{type:'input',playerId:turnId(original),input:{type:'move',path:s.lastMove.move.path},now:f.at});
   const state={};
   for(const key of ['board','side','ply','settings','lastMove','moveLog','quietPlies','repetition','drawWindows','rng','winner','endReason']){
    assert.deepEqual(s[key],replayed[key],key);state[key]=replayed[key];
   }
   assert.deepEqual(g.host.botCursor,index===0?{seed:20261008,step:0}:p.observer.games[index-1].firstMove.host.botCursor);
   const detailedRng=createRng(20261008),report=bots.searchMove(original,original.settings,detailedRng,'sharp');
   assert.deepEqual(report,f.host.lastBotReport);assert.deepEqual(detailedRng.state(),f.host.botCursor);
   const pureRng=createRng(20261008),input=sampleInput(original,turnId(original),pureRng,'sharp');
   assert.deepEqual(input,{type:'move',path:report.move.path});assert.deepEqual(pureRng.state(),f.host.botCursor);
   rows.push({profile:p.name,arm:p.arm,variant,state,report,botCursor:detailedRng.state(),legalInput:input});
  }
 }
 for(const name of ['desktop','phone']){
  for(const variant of ['american','international']){
   const b=rows.find(r=>r.profile===name&&r.arm==='baseline'&&r.variant===variant),c=rows.find(r=>r.profile===name&&r.arm==='candidate'&&r.variant===variant);
   assert.deepEqual(b.report,c.report);assert.deepEqual(b.botCursor,c.botCursor);
  }
 }
 const payload={fullShaEofMatches:matches,historicalNativeReportClosedAt:actual.closedAt,replayedGames:8,variants:['american','international'],seed:20261008,originalStrongNodeBudget:6000,rows};
 const canonical=JSON.stringify(payload),digest=createHash('sha256').update(canonical).digest('hex');
 await writeFile(resolve(spec.outputRoot,mode+'-replay.json'),JSON.stringify({status:'PASS',mode,payload,canonicalSha256:digest},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({phase:'SAME_FULL_CORE_ALL_EIGHT_REPLAYS_PASS',mode,canonicalSha256:digest,replayedGames:8,scope:'Same complete licensed <=6piece corpus and original strong6000 seed20261008 search; all original legal/state plus independent full detailed bot report/RNG equality. No current native observation or player gain.'}));
}
