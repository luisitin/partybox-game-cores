"""One finite untimed saved-native full replay process per scheduling mode; original native failure immutable."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import ctypes,importlib.util,json,os,signal,subprocess,sys,time,traceback
JOB=Path.cwd();BASE=Path('/tmp/G10-deferred-core-replay-d619-v2-20261009');CODE=JOB/'.work/deferred-core-replay-currentd619-v2';HEAD='d61912087420a62b26bfed2f977799e529a37897';RSS_LIMIT=4608*1024**2;SHARED_RESERVE=1536*1024**2;CLEAN_CREDIT_CAP=5*1024**3
spec=json.loads((BASE/'spec.json').read_text());spec_sha=sha256((BASE/'spec.json').read_bytes()).hexdigest();started=None;records=[];failed=False
s=importlib.util.spec_from_file_location('actual_groups',JOB/'.work/hosted-df-memory-parts-cd9/receive.py');groups=importlib.util.module_from_spec(s);s.loader.exec_module(groups)
def utc():return datetime.now(timezone.utc).isoformat()
def digest(p):
 h=sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return h.hexdigest()
def row(p):
 p=Path(p).absolute();s=p.stat();return {'path':str(p),'resolved':str(p.resolve()),'sha256':digest(p),'identity':{'dev':s.st_dev,'ino':s.st_ino,'bytes':s.st_size,'mtimeNs':s.st_mtime_ns,'ctimeNs':s.st_ctime_ns}}
def write(n,v):
 p=BASE/n;assert not p.exists(),'Never overwrite an actual inquiry outcome';p.write_text(json.dumps(v,indent=2)+'\n')
def freeze():
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==HEAD
 assert digest(BASE/'spec.json')==spec_sha
 actual={label:row(r['path']) for label,r in spec['files'].items()};assert actual==spec['files']
 for root,names in spec['inventories'].items():
  observed=[]
  for folder,dirs,names_ in os.walk(root,followlinks=True):
   for name in names_:
    p=Path(folder)/name
    if p.is_file():observed.append(str(p))
  assert sorted(observed)==names
 return {'specSha256':spec_sha,'files':actual}
def resources():
 p=Path('/sys/fs/cgroup');maximum=int((p/'memory.max').read_text());current=int((p/'memory.current').read_text());v={a:int(b) for a,b in (x.split() for x in (p/'memory.stat').read_text().splitlines())};clean=max(0,v['inactive_file']+v['active_file']-v.get('file_dirty',0)-v.get('file_writeback',0));z=os.statvfs(BASE)
 return {'at':utc(),'rawHeadroomBytes':maximum-current,'cleanOrdinaryFileBytes':clean,'boundedPotentialCleanCreditBytes':min(clean,CLEAN_CREDIT_CAP),'potentialCapacityBytes':maximum-current+min(clean,CLEAN_CREDIT_CAP),'diskFreeBytes':z.f_bavail*z.f_frsize,'scope':'Same prospective5GiB ordinaryclean cap; excludes shared/dirty/writeback/slab. No cache eviction/drop/cold claim; no native elapsed work.'}
def rss(pid):
 try:return next(int(z.split()[1])*1024 for z in Path(f'/proc/{pid}/status').read_text().splitlines() if z.startswith('VmRSS:'))
 except (OSError,StopIteration):return 0

def deadline(*_):raise TimeoutError('Finite480s whole untimed inquiry bound exceeded')
signal.signal(signal.SIGALRM,deadline);signal.alarm(480);assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
started=utc();before=None
try:
 before=freeze();write('freeze-before.json',before)
 for mode in ['eager','deferred']:
  initial=resources();assert initial['potentialCapacityBytes']>RSS_LIMIT+SHARED_RESERVE and initial['diskFreeBytes']>128*1024**2+16*1024**2
  r={'mode':mode,'startedAt':utc(),'rssLimitBytes':RSS_LIMIT,'childWallLimitSeconds':180,'resourcesBefore':initial,'samples':[],'failure':None};records.append(r);child=None;closure=None
  try:
   with (BASE/(mode+'.stdout')).open('wb') as out,(BASE/(mode+'.stderr')).open('wb') as err:
    child=subprocess.Popen([str(JOB/'.work/memory-json-private/node22/runtime/bin/node'),str(CODE/(mode+'.mjs')),str(BASE/'spec.json')],cwd=JOB,env={'PATH':'/usr/bin:/bin','TZ':'UTC','LANG':'C.UTF-8','GIT_DIR':str(spec['gitDirectory']),'GIT_WORK_TREE':str(JOB.parent.parent),'GIT_OPTIONAL_LOCKS':'0'},stdout=out,stderr=err,start_new_session=True);stop=time.monotonic()+180
    while child.poll() is None:
     current=rss(child.pid);r['samples'].append({'at':utc(),'actualOwnedNodeRssBytes':current})
     if current>RSS_LIMIT:r['failure']='INCOMPLETE_DECLARED_MEMORY_BOUND';break
     if time.monotonic()>stop:r['failure']='INCOMPLETE_DECLARED_CHILD_TIMEOUT';break
     assert resources()['potentialCapacityBytes']>SHARED_RESERVE,'Untimed shared reserve lost';time.sleep(.1)
    if r['failure'] is None:assert child.wait(timeout=3)==0,'Actual hasher assertion/process failed'
  finally:
   if child is not None:closure=groups.close_worker_group(child,r['failure'] is not None);r['closure']=closure;r['closedAt']=utc();r['actualPeakSampledNodeRssBytes']=max((z['actualOwnedNodeRssBytes'] for z in r['samples']),default=0)
  lines=(BASE/(mode+'.stdout')).read_text().splitlines();observed=[json.loads(z) for z in lines]
  assert not closure['actualRemainingGroup']
  r['actualCompleteInputMatches']=observed[0]['actualFullShaEofMatches'] if observed else 0
  if r['failure'] is None:
   assert len(observed)==2 and observed[0]['phase']=='SAVED_CLOSED_ALL_FOUR_NATIVE_ARMS_COLLECTED' and observed[1]['phase']=='SAME_FULL_CORE_ALL_EIGHT_REPLAYS_PASS'
   actual=json.loads((BASE/(mode+'-replay.json')).read_text());assert actual['status']=='PASS' and actual['payload']['replayedGames']==8 and actual['payload']['fullShaEofMatches']==len(spec['inputFiles'])
   r['canonicalSha256']=actual['canonicalSha256']
   assert closure['natural'] and (BASE/(mode+'.stderr')).stat().st_size==0
  r['status']='CLOSED_FULL_EOF_PASS' if r['failure'] is None else 'CLOSED_INCOMPLETE_BOUND';write(mode+'-result.json',r)
  assert freeze()==before
 assert all(x['failure'] is None for x in records),'Both unchanged scheduling controls must completely pass'
 eager=json.loads((BASE/'eager-replay.json').read_text());deferred=json.loads((BASE/'deferred-replay.json').read_text());assert eager['payload']==deferred['payload'] and eager['canonicalSha256']==deferred['canonicalSha256'],'Eager/deferred full replay equivalence required'
except BaseException as e:
 failed=True;write('failure.json',{'status':'FAILED','at':utc(),'errorType':type(e).__name__,'error':str(e),'traceback':traceback.format_exc()});raise
finally:
 try:
  after=freeze();assert before is not None and after==before;write('freeze-finally.json',{'status':'PASS','closedAt':utc(),'actual':after})
 except BaseException as e:
  failed=True;write('freeze-finally.json',{'status':'FAILED','closedAt':utc(),'error':str(e)})
 r={'status':'CLOSED_FAILED' if failed else 'CLOSED_UNTIMED_REPLAY_EQUIVALENCE_PASS','startedAt':started,'closedAt':utc(),'head':HEAD,'inputFiles':len(spec['inputFiles']),'results':[{k:z for k,z in x.items() if k!='samples'} for x in records],'finalFreezePassed':not failed,'scope':'One bounded process per scheduling mode over saved genuinely closed old eight-game native report. Same full licensed core/6000node/seed/report/cursor/legal-state replay, whole input hashes; NO browser/native clock launch or new/current International gain. Original4.5GiB native failure and all exposed resource/time/gain/workload gates remain immutable; neither player gain nor no-gain KEEP round.'};write('controller.json',r);signal.alarm(0);print(json.dumps(r),flush=True)
 if failed:sys.exit(1)
