import {collect,replay} from './common.mjs';
const inputs=await collect();
const core=await import('../../dist/core.mjs');
const bots=await import('../../dist/bots.mjs');
await replay(inputs,core,bots,'deferred');
