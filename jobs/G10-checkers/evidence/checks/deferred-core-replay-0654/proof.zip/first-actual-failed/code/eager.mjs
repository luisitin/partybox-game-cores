import * as core from '../../dist/core.mjs';
import * as bots from '../../dist/bots.mjs';
import {collect,replay} from './common.mjs';
const inputs=await collect();
await replay(inputs,core,bots,'eager');
