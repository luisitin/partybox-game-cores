from pathlib import Path
import argparse
import contextlib
import datetime
import hashlib
import io
import json
import os
import ssl
import subprocess
import types
import urllib.request
import zipfile

PRIVATE=Path(__file__).resolve().parent
REPO=PRIVATE.parent/'repo'
SPEC_PATH=PRIVATE/'d01-official-ram-private-spec.json'
SPEC=json.loads(SPEC_PATH.read_text())
OUTPUT=PRIVATE/'d01-official-ram'
OUTPUT.mkdir(exist_ok=False)

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(value):
    return hashlib.sha256(value).hexdigest()
def identity(path):
    data=Path(path).read_bytes()
    return {'bytes':len(data),'sha256':sha(data)}

source=SPEC['source']
reader_path=REPO/'jobs/G01-dominoes/verify-worker-artifact.py'
reader=reader_path.read_bytes()
assert reader==subprocess.check_output(['git','show',source+':jobs/G01-dominoes/verify-worker-artifact.py'],cwd=REPO)
assert sha(reader)=='6a33c711fd5d3d17e34c714d0021cf6612783003dc23655c922800cb5fb57106'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==SPEC['currentCheckpointHead']
products=['ui.ts','play.html','core.ts','strong-bot.ts','strong-worker.ts','browser.ts','browser-evidence.ts','package.json','build.ts','shell.html']
product_before={name:identity(REPO/'jobs/G01-dominoes'/name) for name in products}
for name in products:
    assert (REPO/'jobs/G01-dominoes'/name).read_bytes()==subprocess.check_output(['git','show',source+':jobs/G01-dominoes/'+name],cwd=REPO)
native=SPEC['nativeLog'].encode('utf8')
native_path=OUTPUT/'native-full.log'
native_path.write_bytes(native)
receipt={'schema':'g01-official-complete-ram-loader/1','status':'STARTED','startedAt':now(),'source':source,'currentCheckpointHead':SPEC['currentCheckpointHead'],'run':SPEC['run'],'job':SPEC['job'],'artifactId':SPEC['artifactId'],'expectedBytes':SPEC['expectedBytes'],'expectedSha256':SPEC['expectedSha256'],'readerSource':identity(reader_path),'nativeLog':identity(native_path),'scope':'Exactly one HTTPS read into bounded RAM; unchanged official whole-artifact/source/native/36-frame reader; only small logs, bounded proof archive and decoder clip are written to independent /tmp. No browser/native-FPS retry or current-head full-CI transfer.'}
receipt_path=OUTPUT/'ram-loader-receipt.json'
receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
try:
    context=ssl.create_default_context()
    with urllib.request.urlopen(SPEC['downloadURL'],timeout=90,context=context) as response:
        data=response.read(SPEC['expectedBytes']+1)
    assert len(data)==SPEC['expectedBytes'],'Official full RAM byte count mismatch'
    assert sha(data)==SPEC['expectedSha256'],'Official full RAM digest mismatch'
    receipt['downloadClosedAt']=now()
    receipt['actualBytes']=len(data)
    receipt['actualSha256']=sha(data)
    class MemoryArtifact(io.BytesIO):
        def read_bytes(self):
            return self.getvalue()
    memory=MemoryArtifact(data)
    args=types.SimpleNamespace(artifact=memory,sha256=SPEC['expectedSha256'],source=source,run=str(SPEC['run']),repo=REPO,native_log=native_path)
    module=types.ModuleType('g01_unchanged_official_reader_ram_adapter')
    module.__file__=str(reader_path)
    exec(compile(reader,str(reader_path),'exec'),module.__dict__)
    class MemoryArgumentParser(argparse.ArgumentParser):
        def parse_args(self,*unused,**unused_kwargs):
            return args
    module.argparse=types.SimpleNamespace(ArgumentParser=MemoryArgumentParser)
    captured=io.StringIO()
    with contextlib.redirect_stdout(captured):
        module.main()
    actual_output=captured.getvalue()
    (OUTPUT/'unchanged-full-reader.log').write_text(actual_output)
    acceptance=json.loads(actual_output)
    assert acceptance['status']=='PASS' and acceptance['source']==source
    assert acceptance['run']==str(SPEC['run']) and acceptance['artifactSha256']==SPEC['expectedSha256']
    assert acceptance['actualDiskNavigation']=='PASS' and acceptance['realWorkerReplayCases']==16 and acceptance['realWorkerVariants']==5
    assert acceptance['rawIntervals']==600 and acceptance['timestampWitnesses']==602 and acceptance['actualDecodedFrames']==36
    assert product_before=={name:identity(REPO/'jobs/G01-dominoes'/name) for name in products}
    assert identity(reader_path)==receipt['readerSource']
    receipt['independentAcceptance']=acceptance
    receipt['independentReaderClosedAt']=now()
    public_metadata={key:SPEC[key] for key in ['source','currentCheckpointHead','run','job','artifactId','expectedBytes','expectedSha256','observedRunSuccessAt']}
    public_metadata['scope']='Actual complete official102MB held only in RAM; exact source d01 accepted. Latest source checkpoint d331 has identical ten product bytes but needs its own full CI. Signed URL omitted.'
    retained={}
    memory.seek(0)
    with zipfile.ZipFile(memory) as official:
        names=official.namelist()
        for name in names:
            if '/' not in name and not name.endswith('/'):
                retained['official-raw/'+name]=official.read(name)
        finish=json.loads(official.read('ci-finish.json'))
        start=json.loads(official.read('ci-start.json'))
        for name in start['mutableOutputPaths']:
            retained['actual-after/'+name]=official.read('after/'+name)
        browser=json.loads(official.read('browser-current.json'))
        receipt['actualNativeProfiles']=[{key:p[key] for key in ['name','viewport','throttle','fps','meanMs','p95Ms','p99Ms']} for p in browser['profiles']]
        clip=official.read('current-capture.webm')
        receipt['actualCurrentClip']={'bytes':len(clip),'sha256':sha(clip)}
    retained['native-full.log']=native
    retained['unchanged-reader.py']=reader
    retained['unchanged-reader-output.json']=actual_output.encode('utf8')
    retained['official-metadata-sanitized.json']=(json.dumps(public_metadata,indent=2)+'\n').encode('utf8')
    archive_path=OUTPUT/'d01-official-bounded-proof.zip'
    with zipfile.ZipFile(archive_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,value in retained.items():
            entry=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(entry,value)
    assert archive_path.stat().st_size<3_000_000
    with zipfile.ZipFile(archive_path) as archive:
        assert len(archive.namelist())==len(set(archive.namelist()))==len(retained)
        assert archive.testzip() is None
        for name,value in retained.items(): assert archive.read(name)==value
    receipt['boundedArchive']={'path':str(archive_path),**identity(archive_path),'exactMembers':len(retained),'scope':'Every top-level actual raw output and every mutable after-output; all immutable source bytes independently matched exact Git d01. Entire official archive was SHA/CRC checked in RAM, not written/extracted.'}
    receipt['all10CurrentProductFilesUnchanged']=True
    receipt['fullOfficialArchiveOnDisk']=False
    receipt['status']='PASS'
except BaseException as error:
    message=str(error).replace(SPEC['downloadURL'],'[redacted signed official artifact URL]')
    receipt['failure']={'type':type(error).__name__,'message':message,'httpStatus':getattr(error,'code',None)}
    receipt['status']='FAIL'
finally:
    receipt['naturallyClosedAt']=now()
    receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:receipt[key] for key in ['status','naturallyClosedAt','source','run','artifactId']}|{'checks':receipt.get('independentAcceptance',{}).get('checks'),'failureType':receipt.get('failure',{}).get('type'),'boundedArchive':receipt.get('boundedArchive'),'profiles':receipt.get('actualNativeProfiles')}))
raise SystemExit(0 if receipt['status']=='PASS' else 1)
