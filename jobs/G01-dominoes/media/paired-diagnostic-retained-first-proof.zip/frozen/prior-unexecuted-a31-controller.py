import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

OWNER_ROOT = Path('/workspace/game-cores-G01-queue-audit-20261008')
PRIVATE = Path(__file__).resolve().parent
ROOT = OWNER_ROOT / '.work/queue-audit-20261008/paired-diagnostic-clone/repo'
WORK = OWNER_ROOT / '.work/queue-audit-20261008'
READY_PATH = PRIVATE / 'root-gated-pair-ready.json'
MASTER_GRANT_PATH = PRIVATE / 'root-paired-diagnostic-first-grant.json'
RECEIPT_PATH = PRIVATE / 'root-gated-pair-first-controller.json'
PROOF_PATH = WORK / 'paired-worker-response-diagnostic-isolated.json'
LOG_PATH = PRIVATE / 'root-gated-pair-first.log'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity(path):
    actual = Path(path).resolve()
    data = actual.read_bytes()
    return {'path': str(actual), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def live_group(group):
    members = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            fields = (entry/'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group and fields[0] not in ['Z', 'X']:
                members.append(int(entry.name))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return members

def signal_group(group, value):
    try:
        os.killpg(group, value)
    except ProcessLookupError:
        pass

ready = json.loads(READY_PATH.read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=OWNER_ROOT).decode().strip() == ready['ownerHead']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip() == ready['sourceHead']
manifest_before = identity(READY_PATH)
controller_before = identity(__file__)
# All additions are prelaunch-only. Browser workload, predicates and raw logging are unchanged.
assert not RECEIPT_PATH.exists(), 'Once-only receipt already exists; never retry this controller'
assert not PROOF_PATH.exists(), 'Once-only diagnostic proof already exists; never overwrite it'
assert not LOG_PATH.exists(), 'Once-only child log already exists; preserve every prior attempt'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=Path(ready['publicCheckpointRoot'])).decode().strip() == ready['publicCheckpointHead']
for name in ready['currentProductBridge']:
    relative = 'jobs/G01-dominoes/' + name
    assert (OWNER_ROOT/relative).read_bytes() == (Path(ready['publicCheckpointRoot'])/relative).read_bytes()
assert identity(MASTER_GRANT_PATH)['bytes'] > 0, 'Actual /root master grant missing'
grant = json.loads(MASTER_GRANT_PATH.read_text())
assert grant['schema'] == 'g01-root-exclusive-paired-diagnostic-master-grant/1'
assert grant['issuer'] == '/root' and grant['status'] == 'GRANTED' and grant['oneRunOnly'] is True
assert grant['ready'] == manifest_before and grant['controller'] == controller_before
assert grant['harness'] == ready['harnessIdentity']
assert grant['preparedFromReadySha256'] == ready['preparedFromReadySha256']
assert grant['ownerHead'] == ready['ownerHead'] and grant['candidateHead'] == ready['sourceHead'] and grant['originalHead'] == ready['originalHead']
assert grant['publicCheckpointHead'] == ready['publicCheckpointHead']
assert grant['order'] == ready['order'] and grant['comparisonGates'] == ready['comparisonGates']
assert grant['allOwnersZeroAcknowledged'] is True and grant['allFreshFrozenInputsChecked'] is True
assert grant['unexpectedLiveProcesses'] == []
assert isinstance(grant['nonce'],str) and len(grant['nonce']) >= 16
issued = datetime.datetime.fromisoformat(grant['issuedAt'].replace('Z','+00:00'))
current = datetime.datetime.now(datetime.timezone.utc)
assert issued.tzinfo is not None and 0 <= (current-issued).total_seconds() <= 120, 'Master grant is stale/future'
# The unchanged9dc harness writes its raw trace into the original WORK directory.
# Refuse to start while ENOSPC could make that first raw capture disappear.
space = os.statvfs(WORK)
assert space.f_bavail*space.f_frsize >= ready['minimumOriginalWorkspaceAvailableBytes'], 'Insufficient original workspace raw-capture capacity'
master_grant_before = identity(MASTER_GRANT_PATH)

for group in ['sources', 'binaries']:
    for expected in ready[group].values():
        assert identity(expected['path']) == expected, ('READY drift', expected['path'])
receipt = {'schema': 'g01-root-gated-source-isolated-paired-native-worker-response-diagnostic-controller/1', 'scope': 'Exactlyone predeclared native first-strong-bot-move pair each TV/phone4x; original300 gates/local failure unchanged; no fullCI/file or distribution claim', 'startedAt': now(), 'ready': manifest_before, 'controllerBefore': controller_before, 'command': [ready['binaries']['node']['path'], str(WORK/'paired-worker-response-diagnostic-isolated.ts')], 'status': 'STARTED'}
receipt['rootMasterGrant'] = master_grant_before
receipt['masterGrantNonce'] = grant['nonce']
receipt['publicCheckpointHead'] = ready['publicCheckpointHead']
receipt_path = RECEIPT_PATH
# Exclusive creation closes the race between checking absence and launching a child.
with receipt_path.open('x') as initial:
    initial.write(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': 'STARTED', 'startedAt': receipt['startedAt'], 'command': receipt['command']}), flush=True)
environment = dict(os.environ)
environment.update(ready['environment'])
process = None
exit_code = None
receipt['naturalClosure'] = False
try:
    with LOG_PATH.open('w') as log:
        process = subprocess.Popen(receipt['command'], cwd=ROOT/'jobs/G01-dominoes', env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        receipt['childPid'] = process.pid
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        exit_code = process.wait(timeout=90)
        receipt['naturalClosure'] = True
except BaseException as error:
    receipt['failure'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    # Every post-spawn operation, including receipt writes, is within this cleanup.
    # Reap the actual child and close any still-live owned group before CLOSED/FAIL.
    if process is not None:
        running = process.poll() is None or bool(live_group(process.pid))
        if running:
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGTERM)
        try:
            exit_code = process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGKILL)
            exit_code = process.wait(timeout=10)
        deadline = time.monotonic() + 2
        while live_group(process.pid) and time.monotonic() < deadline:
            time.sleep(0.025)
        if live_group(process.pid):
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGKILL)
            deadline = time.monotonic() + 2
            while live_group(process.pid) and time.monotonic() < deadline:
                time.sleep(0.025)
        receipt['remainingOwnedLiveProcesses'] = live_group(process.pid)
        assert not receipt['remainingOwnedLiveProcesses'], 'Owned process group still live; no CLOSED/FAIL release'
        receipt['childClosedAt'] = now()
    else:
        receipt['naturalClosure'] = False
        receipt['remainingOwnedLiveProcesses'] = []
        receipt['childClosedAt'] = None
receipt['exitCode'] = exit_code
receipt['log'] = identity(LOG_PATH)
receipt['guardsAfter'] = {group: {name: identity(expected['path']) for name, expected in ready[group].items()} for group in ['sources', 'binaries']}
receipt['sourceAndBinaryGuardsPassed'] = receipt['guardsAfter'] == {group: ready[group] for group in ['sources', 'binaries']}
receipt['readyAfter'] = identity(READY_PATH)
receipt['controllerAfter'] = identity(__file__)
receipt['controllerAndReadyUnchanged'] = receipt['readyAfter'] == manifest_before and receipt['controllerAfter'] == controller_before
proof_path = PROOF_PATH
if proof_path.exists():
    receipt['actualProof'] = identity(proof_path)
    proof = json.loads(proof_path.read_text())
    receipt['proofStatus'] = proof.get('status')
    receipt['actualProofStatus'] = proof.get('status')
    try:
        import math
        from datetime import datetime as DateTime
        assert DateTime.fromisoformat(proof['startedAt'].replace('Z','+00:00')) >= DateTime.fromisoformat(receipt['startedAt'])
        assert proof['schema'] == 'g01-source-isolated-paired-native-worker-response-diagnostic/1'
        assert proof['candidate'] == ready['sourceHead'] and proof['original'] == ready['originalHead']
        assert proof['browserClosedAt'] and proof['sourcesBefore'] == proof['sourcesAfter']
        retained = list(proof.get('profiles', []))
        if 'partialFailureTrace' in proof:
            retained.append(proof['partialFailureTrace'])
        assert retained, 'No captured native raw trace; diagnostic retention not accepted'
        for sample in retained:
            trace, values = sample['trace'], sample['intervals']
            times = trace['timestamps']
            assert len(values) == max(0,len(times)-1)
            assert len(sample['timestampValueKinds']) == len(times)
            assert len(sample['intervalValueKinds']) == len(values)
            assert isinstance(sample['rawNumberKinds'],dict)
            for sequence, kinds in [(times,sample['timestampValueKinds']),(values,sample['intervalValueKinds'])]:
                for value, kind in zip(sequence,kinds):
                    assert kind in ['finite','NaN','+Infinity','-Infinity','-0']
                    if kind == 'finite':
                        assert isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)
                    elif kind == '-0':
                        assert value == 0
                    else:
                        assert value is None
            assert all('$/trace/timestamps/'+str(i) in sample['rawNumberKinds'] for i in range(len(times)))
            assert all('$/intervals/'+str(i) in sample['rawNumberKinds'] for i in range(len(values)))
        receipt['diagnosticRawRetentionAcceptance'] = {'status':'PASS','completeProfiles':len(proof.get('profiles',[])),'partialFailureTraceRetained':'partialFailureTrace' in proof,'scope':'All native values and invalid numeric kinds retained before assertions; retained failure is not native profile, pair or gain acceptance'}
    except BaseException as error:
        receipt['diagnosticRawRetentionAcceptance'] = {'status':'FAIL','type':type(error).__name__,'message':str(error)}
    try:
        import math
        from datetime import datetime as DateTime
        assert DateTime.fromisoformat(proof['startedAt'].replace('Z', '+00:00')) >= DateTime.fromisoformat(receipt['startedAt'])
        assert proof['schema'] == 'g01-source-isolated-paired-native-worker-response-diagnostic/1' and proof['status'] == 'PASS'
        assert proof['candidate'] == ready['sourceHead'] and proof['original'] == ready['originalHead']
        assert proof['order'] == ['tv baseline', 'tv candidate', 'phone candidate', 'phone baseline']
        assert proof['gates'] == ready['comparisonGates']
        assert proof['baseline'] == ready['originalPlayHtmlIdentity']
        assert proof['browserClosedAt'] and proof['errors'] == [] and proof['externalRequests'] == []
        assert proof['sourcesBefore'] == proof['sourcesAfter']
        for binary in ['node', 'chromium']:
            assert proof[binary+'Before'] == proof[binary+'After'] == ready['binaries'][binary]
        golden = ready['publishedGolden']
        assert proof['golden'] == golden
        assert len(proof['profiles']) == 4
        scenarios = [('tv', 'baseline', 1, {'width':1920, 'height':1080}), ('tv', 'candidate', 1, {'width':1920, 'height':1080}), ('phone', 'candidate', 4, {'width':390, 'height':844}), ('phone', 'baseline', 4, {'width':390, 'height':844})]
        for profile, (name, variant, rate, viewport) in zip(proof['profiles'], scenarios):
            assert profile['validation'] == 'PASS'
            assert profile['name'] == name and profile['variant'] == variant and profile['viewport'] == viewport
            assert profile['throttle'] == profile['actualCpuThrottleRate'] == rate and profile['clockInstalled'] is False
            assert profile['warmup'] == profile['filtered'] == 0
            trace, values = profile['trace'], profile['intervals']
            times = trace['timestamps']
            assert trace['trusted'] and trace['done'] and trace['tile'] == golden['reply']['input']['tile']
            assert trace['startedAt'] <= trace['firstTileAt'] <= times[-1]
            assert len(values) == len(times)-1 and len(values)>1
            assert all(math.isfinite(v) and v>0 and abs(v-(times[i+1]-times[i]))<1e-8 for i,v in enumerate(values))
            assert profile['intervalValueKinds'] == ['finite']*len(values)
            assert profile['timestampValueKinds'] == ['finite']*len(times)
            assert abs(profile['initialFrameLatencyMs']-(times[0]-trace['startedAt'])) < 1e-8
            assert profile['longestIntervalMs'] == max(values)
            assert abs(profile['moveLatencyMs'] - (trace['firstTileAt']-trace['startedAt'])) < 1e-8
            if variant == 'candidate':
                assert trace['workerRequests'][0] == golden['request'] and trace['workerReplies'][0] == golden['reply']
            else:
                assert trace['workerRequests'] == trace['workerReplies'] == []
        gains=[]
        for name in ['tv','phone']:
            before=next(p for p in proof['profiles'] if p['name']==name and p['variant']=='baseline')
            after=next(p for p in proof['profiles'] if p['name']==name and p['variant']=='candidate')
            reduction=1-after['longestIntervalMs']/before['longestIntervalMs']
            absolute=before['longestIntervalMs']-after['longestIntervalMs']
            regression=after['moveLatencyMs']/before['moveLatencyMs']-1
            gains.append({'name':name,'reduction':reduction,'absoluteReductionMs':absolute,'moveLatencyRegression':regression,'passed':reduction>=.2 and absolute>=50 and regression<=.2})
        assert proof['gains'] == gains
        expected = 'PASS' if all(g['passed'] for g in gains) else 'FAIL'
        assert proof['measuredGainAcceptance'] == expected
        receipt['nativeAcceptance'] = {'status':'PASS','scenarios':4,'allRawIntervals':sum(len(p['intervals']) for p in proof['profiles']),'gains':gains,'measuredGainAcceptance':expected,'scope':'Trial and all source/raw identities accepted; gain gate result preserved separately; original300 local failure remains'}
    except BaseException as error:
        receipt['nativeAcceptance'] = {'status': 'FAIL', 'type': type(error).__name__, 'message': str(error)}
        receipt['proofStatus'] = 'UNACCEPTED'
receipt['status'] = 'PASS' if exit_code == 0 and receipt['naturalClosure'] and not receipt.get('failure') and receipt['sourceAndBinaryGuardsPassed'] and receipt['controllerAndReadyUnchanged'] and receipt.get('proofStatus') == 'PASS' and receipt.get('diagnosticRawRetentionAcceptance',{}).get('status') == 'PASS' else 'FAIL'
receipt['masterGrantAfter'] = identity(MASTER_GRANT_PATH)
assert receipt['masterGrantAfter'] == master_grant_before, 'Master grant changed during trial'
receipt['controllerFinishedAt'] = now()
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ['status', 'childClosedAt', 'controllerFinishedAt', 'exitCode', 'naturalClosure', 'sourceAndBinaryGuardsPassed', 'controllerAndReadyUnchanged']}), flush=True)
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
