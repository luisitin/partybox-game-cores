// Private once-only native UI comparison. No production edits or fake clocks.
import {chromium} from '../../jobs/G01-dominoes/node_modules/playwright/index.mjs';
import {readFileSync,writeFileSync,realpathSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
const ownerRoot=resolve(import.meta.dirname,'../..'),root=resolve(ownerRoot,'.work/queue-audit-20261008/paired-diagnostic-clone/repo'),job=resolve(root,'jobs/G01-dominoes'),work=resolve(ownerRoot,'.work/queue-audit-20261008');
const identity=(path:string)=>{const actual=realpathSync(path),bytes=readFileSync(actual);return {path:actual,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};};
const git=(...args:string[])=>execFileSync('git',['-C',root,...args]);
const original='8c57376d817d1b34c165425cd8bf8d9ee219f7f6',candidate='2d30473e443565d033638fbb83851d9d82c5a87d';
assert.equal(git('rev-parse','HEAD').toString().trim(),candidate);
const baseline=git('show',`${original}:jobs/G01-dominoes/play.html`),current=readFileSync(resolve(job,'play.html'));
assert(current.equals(git('show',`${candidate}:jobs/G01-dominoes/play.html`)));
for(const path of ['jobs/G01-dominoes/core.ts','contract/rng.ts'])assert(git('show',`${original}:${path}`).equals(git('show',`${candidate}:${path}`)),'Original policy/RNG changed');
const previousProof=JSON.parse(readFileSync(resolve(job,'worker-functional-2ae0438.json'),'utf8'));
assert.equal(previousProof.status,'PASS');
const golden=previousProof.variants.find((v:{variant:string})=>v.variant==='actual UI');
assert(golden&&golden.request.seed===23&&golden.reply.input.type==='play'&&golden.reply.input.side==='right');
assert.equal(previousProof.sourcesBefore['play.html'].sha256,identity(resolve(job,'play.html')).sha256);
const executable=process.env.CHROMIUM_PATH??'/usr/lib/chromium/chromium';
const files=['ui.ts','core.ts','strong-bot.ts','strong-worker.ts','shell.html','build.ts','play.html','browser.ts','browser-evidence.ts','worker-functional-2ae0438.json','../../contract/rng.ts'];
const sourceMap=()=>Object.fromEntries(files.map(f=>[f,identity(resolve(job,f))]));
const result:Record<string,unknown>={schema:'g01-source-isolated-paired-native-worker-response-diagnostic/1',status:'STARTED',startedAt:new Date().toISOString(),original,candidate,baseline:{bytes:baseline.length,sha256:createHash('sha256').update(baseline).digest('hex')},sourcesBefore:sourceMap(),nodeBefore:identity(process.execPath),chromiumBefore:identity(executable),golden,order:['tv baseline','tv candidate','phone candidate','phone baseline'],metric:'All unfiltered native requestAnimationFrame intervals from trusted Start through the first legal strong-bot tile; longest interval is the declared responsiveness metric.',gates:{minimumLongestIntervalReduction:0.2,minimumAbsoluteReductionMs:50,maximumMoveLatencyRegression:0.2},scope:'Distinct logging-only diagnostic after the first failed baseline lost its offending raw trace; no original trial acceptance, adoption, original300/FPS, file://, fullCI, distribution or physical-phone claim',profiles:[]};
mkdirSync(work,{recursive:true});const report=resolve(work,'paired-worker-response-diagnostic-isolated.json'),save=()=>writeFileSync(report,JSON.stringify(result,null,2)+'\n');save();
const browser=await chromium.launch({headless:true,executablePath:executable,args:['--no-sandbox']});result.chromiumVersion=browser.version();
const errors:string[]=[],requests:string[]=[];
const classify=(value:number)=>Number.isNaN(value)?'NaN':value===Infinity?'+Infinity':value===-Infinity?'-Infinity':Object.is(value,-0)?'-0':'finite';
const rawNumberKinds=(value:unknown)=>{const result:Record<string,string>={};const visit=(value:unknown,path:string)=>{if(typeof value==='number')result[path]=classify(value);else if(value&&typeof value==='object')for(const [key,child] of Object.entries(value))visit(child,`${path}/${key}`);};visit(value,'$');return result;};
let activePage:import('../../jobs/G01-dominoes/node_modules/playwright/index.mjs').Page|null=null;let activeScenario:unknown=null;
type Trace={startedAt:number|null;trusted:boolean;timestamps:number[];firstTileAt:number|null;tile:number|null;workerRequests:unknown[];workerReplies:unknown[];done:boolean};
try{
 for(const [name,viewport,rate,order] of [['tv',{width:1920,height:1080},1,['baseline','candidate']],['phone',{width:390,height:844},4,['candidate','baseline']]] as const){
  for(const variant of order){
   const context=await browser.newContext({viewport}),page=await context.newPage();activePage=page;activeScenario={name,variant,viewport,throttle:rate};
   page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url());});
   await page.route('**/*',r=>/^https?:/.test(r.request().url())?r.abort():r.continue());
   await page.evaluate(()=>{
    const scope=globalThis as typeof globalThis&{__g01Response:Trace};
    scope.__g01Response={startedAt:null,trusted:false,timestamps:[],firstTileAt:null,tile:null,workerRequests:[],workerReplies:[],done:false};
    const OriginalWorker=Worker,trace=scope.__g01Response;
    scope.Worker=class extends OriginalWorker{
     constructor(url:string|URL,options?:WorkerOptions){super(url,options);this.addEventListener('message',event=>trace.workerReplies.push(structuredClone(event.data)));}
     override postMessage(message:unknown,transferOrOptions?:Transferable[]|StructuredSerializeOptions){trace.workerRequests.push(structuredClone(message));if(Array.isArray(transferOrOptions))super.postMessage(message,transferOrOptions);else super.postMessage(message,transferOrOptions);}
    };
   });
   await page.setContent((variant==='baseline'?baseline:current).toString('utf8'));
   await page.click('#houseRules summary');await page.selectOption('#opening','rotating');await page.selectOption('#seat-0','sharp');await page.selectOption('#seat-1','human');await page.fill('#seed','23');
   const cdp=await context.newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate});
   await page.evaluate(()=>{
    const trace=(globalThis as typeof globalThis&{__g01Response:Trace}).__g01Response;
    document.querySelector('#start')!.addEventListener('click',event=>{
     trace.startedAt=performance.now();trace.trusted=event.isTrusted;
     const observer=new MutationObserver(()=>{const tile=document.querySelector<HTMLElement>('#boardLayer .tile');if(tile&&trace.firstTileAt===null){trace.firstTileAt=performance.now();trace.tile=Number(tile.dataset.tile);}});
     observer.observe(document.querySelector('#boardLayer')!,{childList:true});
     const tick=(now:number)=>{trace.timestamps.push(now);if(trace.firstTileAt!==null){trace.done=true;observer.disconnect();}else requestAnimationFrame(tick);};requestAnimationFrame(tick);
    },{capture:true,once:true});
   });
   await page.click('#start');await page.waitForFunction(()=>(globalThis as typeof globalThis&{__g01Response:Trace}).__g01Response.done,undefined,{timeout:15_000});
   const trace:Trace=await page.evaluate(()=>(globalThis as typeof globalThis&{__g01Response:Trace}).__g01Response);
   const intervals=trace.timestamps.slice(1).map((v,i)=>v-trace.timestamps[i]!);
   const provisional={name,variant,viewport,throttle:rate,actualCpuThrottleRate:rate,clockInstalled:false,warmup:0,filtered:0,trace,intervals,intervalValueKinds:intervals.map(classify),timestampValueKinds:trace.timestamps.map(classify),longestIntervalMs:Math.max(...intervals),moveLatencyMs:trace.startedAt!==null&&trace.firstTileAt!==null?trace.firstTileAt-trace.startedAt:null,initialFrameLatencyMs:trace.startedAt!==null&&trace.timestamps.length?trace.timestamps[0]!-trace.startedAt:null,validation:'PENDING'};
   const retained={...provisional,rawNumberKinds:rawNumberKinds(provisional)}; (result.profiles as unknown[]).push(retained);save(); // Persist ALL raw data before EVERY native/output assertion.
   assert(trace.trusted&&trace.startedAt!==null&&trace.firstTileAt!==null&&trace.timestamps.length>2);assert.equal(trace.tile,golden.reply.input.tile);assert(trace.firstTileAt>=trace.startedAt);
   assert(intervals.every(v=>Number.isFinite(v)&&v>0));
   if(variant==='candidate'){assert.deepEqual(trace.workerRequests[0],golden.request);assert.deepEqual(trace.workerReplies[0],golden.reply);}else {assert.deepEqual(trace.workerRequests,[]);assert.deepEqual(trace.workerReplies,[]);}
   retained.validation='PASS';save();
   await page.click('#end');await context.close();activePage=null;activeScenario=null;
  }
 }
 assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 const profiles=result.profiles as {name:string;variant:string;longestIntervalMs:number;moveLatencyMs:number}[];
 const gains=['tv','phone'].map(name=>{const before=profiles.find(p=>p.name===name&&p.variant==='baseline')!,after=profiles.find(p=>p.name===name&&p.variant==='candidate')!,reduction=1-after.longestIntervalMs/before.longestIntervalMs,absoluteReductionMs=before.longestIntervalMs-after.longestIntervalMs,moveLatencyRegression=after.moveLatencyMs/before.moveLatencyMs-1;return {name,reduction,absoluteReductionMs,moveLatencyRegression,passed:reduction>=.2&&absoluteReductionMs>=50&&moveLatencyRegression<=.2};});
 result.gains=gains;result.measuredGainAcceptance=gains.every(g=>g.passed)?'PASS':'FAIL';result.status='PASS';result.finishedAt=new Date().toISOString();
 }catch(error){result.status='FAIL';result.failure=error instanceof Error?{name:error.name,message:error.message,stack:error.stack}:String(error);if(activePage){try{const trace:Trace=await activePage.evaluate(()=>(globalThis as typeof globalThis&{__g01Response:Trace}).__g01Response);const intervals=trace.timestamps.slice(1).map((v,i)=>v-trace.timestamps[i]!);const partial={scenario:activeScenario,trace,intervals,intervalValueKinds:intervals.map(classify),timestampValueKinds:trace.timestamps.map(classify)};result.partialFailureTrace={...partial,rawNumberKinds:rawNumberKinds(partial)};}catch(captureError){result.partialFailureTraceCaptureError=String(captureError);}}save();throw error;}
 finally{result.errors=errors;result.externalRequests=requests;try{await browser.close();result.browserClosedAt=new Date().toISOString();result.sourcesAfter=sourceMap();result.nodeAfter=identity(process.execPath);result.chromiumAfter=identity(executable);assert.deepEqual(result.sourcesAfter,result.sourcesBefore);assert.deepEqual(result.nodeAfter,result.nodeBefore);assert.deepEqual(result.chromiumAfter,result.chromiumBefore);}catch(error){result.status='FAIL';result.closureOrGuardFailure=String(error);throw error;}finally{save();}}
console.log('Exactly one predeclared native baseline/candidate pair per viewport closed; all raw intervals retained. Measured gain acceptance:',result.measuredGainAcceptance);
