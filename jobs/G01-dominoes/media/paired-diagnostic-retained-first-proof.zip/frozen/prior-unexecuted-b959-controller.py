import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

OWNER_ROOT = Path(__file__).resolve().parents[2]
ROOT = OWNER_ROOT / '.work/queue-audit-20261008/paired-diagnostic-clone/repo'
WORK = OWNER_ROOT / '.work/queue-audit-20261008'
READY_PATH = WORK / 'paired-worker-response-diagnostic-isolated-ready.json'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity(path):
    actual = Path(path).resolve()
    data = actual.read_bytes()
    return {'path': str(actual), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def live_group(group):
    members = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            fields = (entry/'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group and fields[0] not in ['Z', 'X']:
                members.append(int(entry.name))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return members

def signal_group(group, value):
    try:
        os.killpg(group, value)
    except ProcessLookupError:
        pass

ready = json.loads(READY_PATH.read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=OWNER_ROOT).decode().strip() == ready['ownerHead']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip() == ready['sourceHead']
manifest_before = identity(READY_PATH)
controller_before = identity(__file__)
for group in ['sources', 'binaries']:
    for expected in ready[group].values():
        assert identity(expected['path']) == expected, ('READY drift', expected['path'])
receipt = {'schema': 'g01-source-isolated-paired-native-worker-response-diagnostic-controller/1', 'scope': 'Exactlyone predeclared native first-strong-bot-move pair each TV/phone4x; original300 gates/local failure unchanged; no fullCI/file or distribution claim', 'startedAt': now(), 'ready': manifest_before, 'controllerBefore': controller_before, 'command': [ready['binaries']['node']['path'], str(WORK/'paired-worker-response-diagnostic-isolated.ts')], 'status': 'STARTED'}
receipt_path = WORK / 'paired-worker-response-diagnostic-isolated-first-controller.json'
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': 'STARTED', 'startedAt': receipt['startedAt'], 'command': receipt['command']}), flush=True)
environment = dict(os.environ)
environment.update(ready['environment'])
process = None
exit_code = None
receipt['naturalClosure'] = False
try:
    with (WORK / 'paired-worker-response-diagnostic-isolated-first.log').open('w') as log:
        process = subprocess.Popen(receipt['command'], cwd=ROOT/'jobs/G01-dominoes', env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        receipt['childPid'] = process.pid
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        exit_code = process.wait(timeout=90)
        receipt['naturalClosure'] = True
except BaseException as error:
    receipt['failure'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    # Every post-spawn operation, including receipt writes, is within this cleanup.
    # Reap the actual child and close any still-live owned group before CLOSED/FAIL.
    if process is not None:
        running = process.poll() is None or bool(live_group(process.pid))
        if running:
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGTERM)
        try:
            exit_code = process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGKILL)
            exit_code = process.wait(timeout=10)
        deadline = time.monotonic() + 2
        while live_group(process.pid) and time.monotonic() < deadline:
            time.sleep(0.025)
        if live_group(process.pid):
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGKILL)
            deadline = time.monotonic() + 2
            while live_group(process.pid) and time.monotonic() < deadline:
                time.sleep(0.025)
        receipt['remainingOwnedLiveProcesses'] = live_group(process.pid)
        assert not receipt['remainingOwnedLiveProcesses'], 'Owned process group still live; no CLOSED/FAIL release'
        receipt['childClosedAt'] = now()
    else:
        receipt['naturalClosure'] = False
        receipt['remainingOwnedLiveProcesses'] = []
        receipt['childClosedAt'] = None
receipt['exitCode'] = exit_code
receipt['log'] = identity(WORK/'paired-worker-response-diagnostic-isolated-first.log')
receipt['guardsAfter'] = {group: {name: identity(expected['path']) for name, expected in ready[group].items()} for group in ['sources', 'binaries']}
receipt['sourceAndBinaryGuardsPassed'] = receipt['guardsAfter'] == {group: ready[group] for group in ['sources', 'binaries']}
receipt['readyAfter'] = identity(READY_PATH)
receipt['controllerAfter'] = identity(__file__)
receipt['controllerAndReadyUnchanged'] = receipt['readyAfter'] == manifest_before and receipt['controllerAfter'] == controller_before
proof_path = WORK/'paired-worker-response-diagnostic-isolated.json'
if proof_path.exists():
    receipt['actualProof'] = identity(proof_path)
    proof = json.loads(proof_path.read_text())
    receipt['proofStatus'] = proof.get('status')
    receipt['actualProofStatus'] = proof.get('status')
    try:
        import math
        from datetime import datetime as DateTime
        assert DateTime.fromisoformat(proof['startedAt'].replace('Z','+00:00')) >= DateTime.fromisoformat(receipt['startedAt'])
        assert proof['schema'] == 'g01-source-isolated-paired-native-worker-response-diagnostic/1'
        assert proof['candidate'] == ready['sourceHead'] and proof['original'] == ready['originalHead']
        assert proof['browserClosedAt'] and proof['sourcesBefore'] == proof['sourcesAfter']
        retained = list(proof.get('profiles', []))
        if 'partialFailureTrace' in proof:
            retained.append(proof['partialFailureTrace'])
        assert retained, 'No captured native raw trace; diagnostic retention not accepted'
        for sample in retained:
            trace, values = sample['trace'], sample['intervals']
            times = trace['timestamps']
            assert len(values) == max(0,len(times)-1)
            assert len(sample['timestampValueKinds']) == len(times)
            assert len(sample['intervalValueKinds']) == len(values)
            assert isinstance(sample['rawNumberKinds'],dict)
            for sequence, kinds in [(times,sample['timestampValueKinds']),(values,sample['intervalValueKinds'])]:
                for value, kind in zip(sequence,kinds):
                    assert kind in ['finite','NaN','+Infinity','-Infinity','-0']
                    if kind == 'finite':
                        assert isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)
                    elif kind == '-0':
                        assert value == 0
                    else:
                        assert value is None
            assert all('$/trace/timestamps/'+str(i) in sample['rawNumberKinds'] for i in range(len(times)))
            assert all('$/intervals/'+str(i) in sample['rawNumberKinds'] for i in range(len(values)))
        receipt['diagnosticRawRetentionAcceptance'] = {'status':'PASS','completeProfiles':len(proof.get('profiles',[])),'partialFailureTraceRetained':'partialFailureTrace' in proof,'scope':'All native values and invalid numeric kinds retained before assertions; retained failure is not native profile, pair or gain acceptance'}
    except BaseException as error:
        receipt['diagnosticRawRetentionAcceptance'] = {'status':'FAIL','type':type(error).__name__,'message':str(error)}
    try:
        import math
        from datetime import datetime as DateTime
        assert DateTime.fromisoformat(proof['startedAt'].replace('Z', '+00:00')) >= DateTime.fromisoformat(receipt['startedAt'])
        assert proof['schema'] == 'g01-source-isolated-paired-native-worker-response-diagnostic/1' and proof['status'] == 'PASS'
        assert proof['candidate'] == ready['sourceHead'] and proof['original'] == ready['originalHead']
        assert proof['order'] == ['tv baseline', 'tv candidate', 'phone candidate', 'phone baseline']
        assert proof['gates'] == ready['comparisonGates']
        assert proof['baseline'] == ready['originalPlayHtmlIdentity']
        assert proof['browserClosedAt'] and proof['errors'] == [] and proof['externalRequests'] == []
        assert proof['sourcesBefore'] == proof['sourcesAfter']
        for binary in ['node', 'chromium']:
            assert proof[binary+'Before'] == proof[binary+'After'] == ready['binaries'][binary]
        golden = ready['publishedGolden']
        assert proof['golden'] == golden
        assert len(proof['profiles']) == 4
        scenarios = [('tv', 'baseline', 1, {'width':1920, 'height':1080}), ('tv', 'candidate', 1, {'width':1920, 'height':1080}), ('phone', 'candidate', 4, {'width':390, 'height':844}), ('phone', 'baseline', 4, {'width':390, 'height':844})]
        for profile, (name, variant, rate, viewport) in zip(proof['profiles'], scenarios):
            assert profile['validation'] == 'PASS'
            assert profile['name'] == name and profile['variant'] == variant and profile['viewport'] == viewport
            assert profile['throttle'] == profile['actualCpuThrottleRate'] == rate and profile['clockInstalled'] is False
            assert profile['warmup'] == profile['filtered'] == 0
            trace, values = profile['trace'], profile['intervals']
            times = trace['timestamps']
            assert trace['trusted'] and trace['done'] and trace['tile'] == golden['reply']['input']['tile']
            assert trace['startedAt'] <= trace['firstTileAt'] <= times[-1]
            assert len(values) == len(times)-1 and len(values)>1
            assert all(math.isfinite(v) and v>0 and abs(v-(times[i+1]-times[i]))<1e-8 for i,v in enumerate(values))
            assert profile['intervalValueKinds'] == ['finite']*len(values)
            assert profile['timestampValueKinds'] == ['finite']*len(times)
            assert abs(profile['initialFrameLatencyMs']-(times[0]-trace['startedAt'])) < 1e-8
            assert profile['longestIntervalMs'] == max(values)
            assert abs(profile['moveLatencyMs'] - (trace['firstTileAt']-trace['startedAt'])) < 1e-8
            if variant == 'candidate':
                assert trace['workerRequests'][0] == golden['request'] and trace['workerReplies'][0] == golden['reply']
            else:
                assert trace['workerRequests'] == trace['workerReplies'] == []
        gains=[]
        for name in ['tv','phone']:
            before=next(p for p in proof['profiles'] if p['name']==name and p['variant']=='baseline')
            after=next(p for p in proof['profiles'] if p['name']==name and p['variant']=='candidate')
            reduction=1-after['longestIntervalMs']/before['longestIntervalMs']
            absolute=before['longestIntervalMs']-after['longestIntervalMs']
            regression=after['moveLatencyMs']/before['moveLatencyMs']-1
            gains.append({'name':name,'reduction':reduction,'absoluteReductionMs':absolute,'moveLatencyRegression':regression,'passed':reduction>=.2 and absolute>=50 and regression<=.2})
        assert proof['gains'] == gains
        expected = 'PASS' if all(g['passed'] for g in gains) else 'FAIL'
        assert proof['measuredGainAcceptance'] == expected
        receipt['nativeAcceptance'] = {'status':'PASS','scenarios':4,'allRawIntervals':sum(len(p['intervals']) for p in proof['profiles']),'gains':gains,'measuredGainAcceptance':expected,'scope':'Trial and all source/raw identities accepted; gain gate result preserved separately; original300 local failure remains'}
    except BaseException as error:
        receipt['nativeAcceptance'] = {'status': 'FAIL', 'type': type(error).__name__, 'message': str(error)}
        receipt['proofStatus'] = 'UNACCEPTED'
receipt['status'] = 'PASS' if exit_code == 0 and receipt['naturalClosure'] and not receipt.get('failure') and receipt['sourceAndBinaryGuardsPassed'] and receipt['controllerAndReadyUnchanged'] and receipt.get('proofStatus') == 'PASS' and receipt.get('diagnosticRawRetentionAcceptance',{}).get('status') == 'PASS' else 'FAIL'
receipt['controllerFinishedAt'] = now()
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ['status', 'childClosedAt', 'controllerFinishedAt', 'exitCode', 'naturalClosure', 'sourceAndBinaryGuardsPassed', 'controllerAndReadyUnchanged']}), flush=True)
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
