from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import stat
import subprocess

PRIVATE=Path(__file__).resolve().parent
OWNER=Path('/workspace/game-cores-G01-queue-audit-20261008')
WORK=OWNER/'.work/queue-audit-20261008'
CLONE=WORK/'paired-diagnostic-clone/repo'
CURRENT=PRIVATE.parent/'repo'
MODULES=OWNER/'jobs/G01-dominoes/node_modules'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity(path):
    path=Path(path).resolve(strict=True)
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def replace_once(value,old,new):
    assert value.count(old)==1,old
    return value.replace(old,new)

def stable_stat(path):
    s=Path(path).lstat()
    return {name:getattr(s,name) for name in ['st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns']}

def link_chain(path):
    # Include ancestor symlinks and symlinks encountered through their targets.
    path=Path(os.path.abspath(path))
    pending=list(path.parts[1:])
    cursor=Path(path.anchor)
    links=[]
    while pending:
        piece=pending.pop(0)
        if piece=='.': continue
        if piece=='..': cursor=cursor.parent; continue
        cursor=cursor/piece
        if cursor.is_symlink():
            target=os.readlink(cursor)
            links.append({'path':str(cursor),'target':target,'lstat':stable_stat(cursor)})
            assert len(links)<=100,'Symlink cycle'
            if os.path.isabs(target):
                cursor=Path('/')
                pending=list(Path(target).parts[1:])+pending
            else:
                cursor=cursor.parent
                pending=list(Path(target).parts)+pending
    assert cursor==path.resolve(strict=True)
    return links

def resolution(path):
    path=Path(os.path.abspath(path))
    resolved=path.resolve(strict=True)
    return {'entryPath':str(path),'resolvedPath':str(resolved),'entryLstat':stable_stat(path),'targetLstat':stable_stat(resolved),'symlinkChain':link_chain(path),'content':identity(path)}

old_ready_path=PRIVATE/'root-gated-pair-ready.json'
old_controller_path=PRIVATE/'root-gated-pair-first-controller.py'
assert identity(old_ready_path)['sha256']=='d2ffc9a7fde6b878be6ed79cdbab200cc4c73538aef5a1064a1bdce16f5ae01f'
assert identity(old_controller_path)['sha256']=='a31eb6f285726f538046ea8f0f0639cc3c3a83ea23d357298c69ae6ec759bcd5'
ready=json.loads(old_ready_path.read_text())
assert identity(ready['harnessIdentity']['path'])==ready['harnessIdentity']
preserved=PRIVATE/'original-root-gated-202-unexecuted'
preserved.mkdir(exist_ok=False)
for p in [old_ready_path,old_controller_path]:
    q=preserved/p.name
    q.write_bytes(p.read_bytes())
    assert q.read_bytes()==p.read_bytes()

entries=sorted(MODULES.rglob('*'))
files=[p for p in entries if p.is_file()]
assert len(files)==1618
assert {p.name for p in MODULES.iterdir()}=={'zod','.bin','playwright-core','@esbuild','undici-types','.package-lock.json','playwright','esbuild','typescript','@types'}
tree={'root':str(MODULES),'rootLstat':stable_stat(MODULES),'entries':{str(p.relative_to(MODULES)):{'lstat':stable_stat(p),'symlinkTarget':os.readlink(p) if p.is_symlink() else None} for p in entries}}
aliases={}
for name,expected in ready['sources'].items():
    if name.startswith('candidate/'):
        path=CLONE/name[len('candidate/'):]
    elif name.startswith('owner/.work/'):
        path=WORK/name[len('owner/.work/'):]
    elif name.startswith('owner/'):
        path=OWNER/name[len('owner/'):]
    elif name.startswith('candidate-Git/'):
        path=CLONE/'.git'/name[len('candidate-Git/'):]
    else:
        path=Path(expected['path'])
    aliases[str(path)]=resolution(path)
for path in files:
    aliases[str(path)]=resolution(path)
for path in [CLONE/'jobs/G01-dominoes/node_modules/playwright/index.mjs',CLONE/'jobs/G01-dominoes/node_modules/playwright-core/index.js',MODULES/'playwright/index.mjs',MODULES/'playwright/index.js',MODULES/'playwright-core/index.js',MODULES/'playwright/package.json',MODULES/'playwright-core/package.json']:
    aliases[str(path)]=resolution(path)
for expected in ready['binaries'].values():
    aliases[expected['path']]=resolution(expected['path'])
inventory={'schema':'g01-complete-installed-input-alias-and-stat-manifest/1','preparedAt':now(),'scope':'Entire actual installed job node_modules tree, including both complete Playwright packages; all original candidate source aliases, import entry points, resolved real targets, every ancestor/target symlink chain and stable lstat fields. No browser is launched.','packageVersions':{name:json.loads((MODULES/name/'package.json').read_text())['version'] for name in ['playwright','playwright-core']},'tree':tree,'aliases':aliases,'actualImportEntry':str(MODULES/'playwright/index.mjs'),'completeInstalledFileCount':len(files),'completeInstalledContentBytes':sum(p.stat().st_size for p in files)}
inventory_path=PRIVATE/'complete-installed-pair-inputs.json'
inventory_path.write_text(json.dumps(inventory,indent=2)+'\n')

# All inserted checks occur before browser launch or after owned-group closure.
# The unchanged9dc program, browser workload/order/clocks/predicates/gain gates stay exact.
controller=old_controller_path.read_text()
controller=replace_once(controller,"import signal\n", "import signal\nimport stat\n")
controller=replace_once(controller,"'root-gated-pair-ready.json'", "'root-gated-complete-inputs-pair-ready.json'")
controller=replace_once(controller,"'root-paired-diagnostic-first-grant.json'", "'root-paired-diagnostic-complete-inputs-first-grant.json'")
controller=replace_once(controller,"'root-gated-pair-first-controller.json'", "'root-gated-complete-inputs-pair-first-controller.json'")
controller=replace_once(controller,"'root-gated-pair-first.log'", "'root-gated-complete-inputs-pair-first.log'")
verification='''def stable_stat(path):
    s=Path(path).lstat()
    return {name:getattr(s,name) for name in ['st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns']}

def actual_link_chain(path):
    path=Path(os.path.abspath(path))
    pending=list(path.parts[1:])
    cursor=Path(path.anchor)
    links=[]
    while pending:
        piece=pending.pop(0)
        if piece=='.': continue
        if piece=='..': cursor=cursor.parent; continue
        cursor=cursor/piece
        if cursor.is_symlink():
            target=os.readlink(cursor)
            links.append({'path':str(cursor),'target':target,'lstat':stable_stat(cursor)})
            assert len(links)<=100, 'Symlink cycle'
            if os.path.isabs(target):
                cursor=Path('/')
                pending=list(Path(target).parts[1:])+pending
            else:
                cursor=cursor.parent
                pending=list(Path(target).parts)+pending
    assert cursor==path.resolve(strict=True)
    return links

def check_complete_installed_inputs():
    expected=json.loads(Path(ready['installedInputManifest']['path']).read_text())
    tree=expected['tree']
    module_root=Path(tree['root'])
    actual_entries=sorted(module_root.rglob('*'))
    assert stable_stat(module_root)==tree['rootLstat'], 'Dependency root stat changed'
    assert {str(p.relative_to(module_root)) for p in actual_entries}==set(tree['entries']), 'Installed dependency inventory changed'
    for p in actual_entries:
        actual={'lstat':stable_stat(p),'symlinkTarget':os.readlink(p) if p.is_symlink() else None}
        assert actual==tree['entries'][str(p.relative_to(module_root))], ('Installed dependency stat/link changed',str(p))
    for path,expected_alias in expected['aliases'].items():
        actual_path=Path(path)
        resolved=actual_path.resolve(strict=True)
        assert str(resolved)==expected_alias['resolvedPath'], ('Input alias target changed',path)
        assert stable_stat(actual_path)==expected_alias['entryLstat'], ('Input entry stat changed',path)
        assert stable_stat(resolved)==expected_alias['targetLstat'], ('Input target stat changed',path)
        assert actual_link_chain(actual_path)==expected_alias['symlinkChain'], ('Input symlink chain changed',path)
        assert identity(actual_path)==expected_alias['content'], ('Resolved input bytes changed',path)
    return {'status':'PASS','installedFiles':expected['completeInstalledFileCount'],'aliases':len(expected['aliases']),'manifest':identity(ready['installedInputManifest']['path'])}

'''
controller=replace_once(controller,'ready = json.loads(READY_PATH.read_text())',verification+'ready = json.loads(READY_PATH.read_text())')
controller=replace_once(controller,"receipt = {'schema':", "complete_installed_before = check_complete_installed_inputs()\nreceipt = {'schema':")
controller=replace_once(controller,"receipt['rootMasterGrant'] = master_grant_before", "receipt['completeInstalledInputsBefore'] = complete_installed_before\nreceipt['rootMasterGrant'] = master_grant_before")
controller=replace_once(controller,"receipt['exitCode'] = exit_code", """try:
    receipt['completeInstalledInputsAfter'] = check_complete_installed_inputs()
    receipt['completeInstalledInputsPassed'] = receipt['completeInstalledInputsAfter'] == complete_installed_before
except BaseException as error:
    receipt['completeInstalledInputsPassed'] = False
    receipt['completeInstalledInputFailure'] = {'type':type(error).__name__,'message':str(error)}
receipt['exitCode'] = exit_code""")
controller=replace_once(controller,"and receipt['sourceAndBinaryGuardsPassed']", "and receipt['completeInstalledInputsPassed'] and receipt['sourceAndBinaryGuardsPassed']")
new_controller_path=PRIVATE/'root-gated-complete-inputs-pair-first-controller.py'
new_controller_path.write_text(controller)
ast.parse(controller)
sources=dict(ready['sources'])
sources['prelaunch/previous-202-ready']=identity(preserved/old_ready_path.name)
sources['prelaunch/current-complete-controller']=identity(new_controller_path)
sources['installed/complete-input-manifest']=identity(inventory_path)
for path in files:
    sources['installed/node_modules/'+str(path.relative_to(MODULES))]=identity(path)
new_ready={**ready,'preparedAt':now(),'schema':'g01-root-gated-complete-installed-source-isolated-paired-diagnostic-ready/1','sources':sources,'previousPrelaunchReady':identity(old_ready_path),'previousPrelaunchController':identity(old_controller_path),'installedInputManifest':identity(inventory_path),'completeInstalledFiles':len(files),'completeInstalledBytes':sum(p.stat().st_size for p in files),'launchPaths':{'controller':str(new_controller_path),'masterGrant':str(PRIVATE/'root-paired-diagnostic-complete-inputs-first-grant.json'),'receipt':str(PRIVATE/'root-gated-complete-inputs-pair-first-controller.json'),'proof':str(WORK/'paired-worker-response-diagnostic-isolated.json'),'log':str(PRIVATE/'root-gated-complete-inputs-pair-first.log')},'scope':ready['scope']+' Additional guards freeze all installed dependency files and explicit import/source aliases, symlink chains and stable lstat fields before launch and after full owned-group closure; this changes only guards, never the unchanged9dc workload or measurement.'}
new_ready_path=PRIVATE/'root-gated-complete-inputs-pair-ready.json'
new_ready_path.write_text(json.dumps(new_ready,indent=2)+'\n')
for group in ['sources','binaries']:
    for expected in new_ready[group].values():
        assert identity(expected['path'])==expected,expected['path']
for path,expected in aliases.items():
    assert resolution(path)==expected
assert tree=={'root':str(MODULES),'rootLstat':stable_stat(MODULES),'entries':{str(p.relative_to(MODULES)):{'lstat':stable_stat(p),'symlinkTarget':os.readlink(p) if p.is_symlink() else None} for p in sorted(MODULES.rglob('*'))}}
assert identity(old_ready_path)['sha256']=='d2ffc9a7fde6b878be6ed79cdbab200cc4c73538aef5a1064a1bdce16f5ae01f'
assert identity(old_controller_path)['sha256']=='a31eb6f285726f538046ea8f0f0639cc3c3a83ea23d357298c69ae6ec759bcd5'
assert identity(ready['harnessIdentity']['path'])==ready['harnessIdentity']
shape=json.loads((PRIVATE/'root-gated-pair-grant-shape.json').read_text())
shape.update({'ready':identity(new_ready_path),'controller':identity(new_controller_path)})
shape_path=PRIVATE/'root-gated-complete-inputs-pair-grant-shape.json'
shape_path.write_text(json.dumps(shape,indent=2)+'\n')
report={'schema':'g01-complete-input-prelaunch-freeze-result/1','status':'PASS_FIRST_UNEXECUTED','naturallyClosedAt':now(),'sourceGuards':len(sources),'binaryGuards':len(new_ready['binaries']),'installedFiles':len(files),'installedBytes':new_ready['completeInstalledBytes'],'aliases':len(aliases),'ready':identity(new_ready_path),'controller':identity(new_controller_path),'installedManifest':identity(inventory_path),'harness':identity(ready['harnessIdentity']['path']),'grantShape':str(shape_path),'originalWorkspaceAvailableBytes':os.statvfs(WORK).f_bavail*os.statvfs(WORK).f_frsize,'noBrowserLaunched':True,'prior202Preserved':True,'guardOnlyControllerChange':True}
(PRIVATE/'complete-input-freeze-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
