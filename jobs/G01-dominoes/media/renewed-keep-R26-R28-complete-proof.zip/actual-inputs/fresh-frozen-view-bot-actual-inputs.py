from pathlib import Path
import hashlib, json, os, re, shutil, stat, subprocess, sys, sysconfig

PRIVATE=Path(__file__).resolve().parent
REPO=PRIVATE.parent/'repo'

def stable_stat(path):
    value=Path(path).lstat()
    return {k:getattr(value,k) for k in ['st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns']}

def alias(path):
    path=Path(os.path.abspath(path)); resolved=path.resolve(strict=True)
    content=path.read_bytes()
    cursor=Path('/'); pending=list(path.parts[1:]); chain=[]
    while pending:
        part=pending.pop(0)
        if part=='.': continue
        if part=='..': cursor=cursor.parent; continue
        cursor=cursor/part
        if cursor.is_symlink():
            target=os.readlink(cursor); chain.append({'path':str(cursor),'target':target,'stat':stable_stat(cursor)})
            assert len(chain)<=100
            pending=list(Path(target).parts[1:] if os.path.isabs(target) else Path(target).parts)+pending
            cursor=Path('/') if os.path.isabs(target) else cursor.parent
    assert cursor==resolved
    return {'resolvedPath':str(resolved),'entryStat':stable_stat(path),'targetStat':stable_stat(resolved),'symlinkChain':chain,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}

def snapshot():
    paths=set()
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
    assert head=='48cb1b551365f613b65948fb640d3105f679f719'
    names=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','jobs/G01-dominoes','contract','.github/workflows/G01.yml','README.md','RULES.md','JOBS.md'],cwd=REPO,text=True).splitlines()
    for name in names:
        path=REPO/name
        assert path.read_bytes()==subprocess.check_output(['git','show',head+':'+name],cwd=REPO)
        paths.add(path)
    old=json.loads((PRIVATE/'privacy-veil-old949-negative-first-complete-inputs.json').read_text())
    installed_root=Path(old['tree']['root']); installed=list(installed_root.rglob('*'))
    installed_inventory={str(path.relative_to(installed_root)):{'stat':stable_stat(path),'symlinkTarget':os.readlink(path) if path.is_symlink() else None} for path in installed}
    for path in installed:
        if path.is_file(): paths.add(path)
    stdlib=Path(sysconfig.get_path('stdlib'))
    standard=[]
    for path in stdlib.rglob('*'):
        if 'site-packages' in path.relative_to(stdlib).parts: continue
        if path.is_file(): standard.append(path); paths.add(path)
    for module in list(sys.modules.values()):
        for name in ['__file__','__cached__']:
            origin=getattr(module,name,None)
            if origin and Path(origin).is_file(): paths.add(Path(origin))
    for folder in [Path(sysconfig.get_path('purelib')),Path(sysconfig.get_path('platlib'))]:
        if folder.is_dir():
            for path in folder.glob('*.pth'): paths.add(path)
    for path in (PRIVATE/'large-hand-fixture-first/repo').rglob('*'):
        if path.is_file() and 'node_modules' not in path.parts: paths.add(path)
    for name in ['frozen-view-bot-actual-operations-first.mjs','frozen-view-bot-actual-operations-first-controller.py','fresh-frozen-view-bot-actual-inputs.py']:
        paths.add(PRIVATE/name)
    binaries=[Path(sys.executable),Path('/usr/lib/chromium/chromium'),Path('/usr/lib/chromium/chrome_crashpad_handler')]+[Path(shutil.which(name)) for name in ['git','node','ffmpeg','ffprobe']]
    for path in binaries:
        paths.add(path)
        result=subprocess.run(['ldd',str(path.resolve())],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        for filename in re.findall(r'(/[A-Za-z0-9_./+\-]+)',result.stdout):
            if Path(filename).is_file(): paths.add(Path(filename))
    return {'head':head,'sourceFiles':len(names),'installedRoot':str(installed_root),'installedRootStat':stable_stat(installed_root),'installedInventory':installed_inventory,'installedFileAliases':sum(path.is_file() for path in installed),'pythonStandardLibraryFiles':len(standard),'aliases':{str(path):alias(path) for path in sorted(paths)},'scope':'Fresh observed aliases/stat/bytes after execution environment restart; current immutable Git source, complete installed tree, full Python standard library plus actual loaded external module/cache/pth inputs, exact helpers and actual Python/Git/cURL/decoder/shared libraries. No previous process identity reused.'}
