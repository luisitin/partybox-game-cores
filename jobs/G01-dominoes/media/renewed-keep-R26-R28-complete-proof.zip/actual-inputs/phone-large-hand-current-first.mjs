import {chromium} from '/workspace/game-cores-G01-queue-audit-20261008/jobs/G01-dominoes/node_modules/playwright/index.mjs';
import {readFileSync,writeFileSync,realpathSync,readdirSync,lstatSync,statSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {resolve,join} from 'node:path';
const privateRoot='/tmp/g01-current-838-proof-20261009/private',repo=resolve(privateRoot,'../repo'),job=join(repo,'jobs/G01-dominoes');
const source='48cb1b551365f613b65948fb640d3105f679f719';
const output=join(privateRoot,'phone-large-hand-current-first');mkdirSync(output);
const proofPath=join(output,'proof.json');
const identity=path=>{const target=realpathSync(path),bytes=readFileSync(target);return {path:target,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};};
const product=['ui.ts','play.html','core.ts','strong-bot.ts','strong-worker.ts','browser.ts','browser-evidence.ts','package.json','build.ts','shell.html','privacy-veil-check.ts'];
assert.equal(execFileSync('git',['-C',repo,'rev-parse','HEAD']).toString().trim(),source);
for(const name of product)assert(readFileSync(join(job,name)).equals(execFileSync('git',['-C',repo,'show',source+':jobs/G01-dominoes/'+name])));
const moduleRoot='/workspace/game-cores-G01-queue-audit-20261008/jobs/G01-dominoes/node_modules';
function installedMap(){const map={};const walk=dir=>{for(const entry of readdirSync(dir,{withFileTypes:true})){const path=join(dir,entry.name);if(entry.isDirectory())walk(path);else if(statSync(path).isFile()){const s=lstatSync(path);map[path]={content:identity(path),lstat:{dev:s.dev,ino:s.ino,mode:s.mode,size:s.size,nlink:s.nlink,mtimeMs:s.mtimeMs,ctimeMs:s.ctimeMs}};}}};walk(moduleRoot);return map;}
const sources=()=>Object.fromEntries([...product.map(n=>join(job,n)),join(repo,'contract/rng.ts'),import.meta.filename].map(path=>[path,identity(path)]));
const binaries=()=>({node:identity(process.execPath),chromium:identity('/usr/lib/chromium/chromium')});
const result={schema:'g01-four-human-phone-functional-proof/1',status:'STARTED',startedAt:new Date().toISOString(),source,scope:'FIRST distinct13-tile large-hand functional stress case146 selected from complete untimed5000-seed fixture scan; complete-round hot-seat audit for exact accepted380 player/current48cb source on390x844/4xCPU; Draw/Block, partners/individual and genuine motion. All raw/partial values retained before predicates. No simulated clocks, FPS/rAF sampling, oldfirstfourcase retry, historical-cause or performance claim.',navigation:'Exact source bytes page.setContent; no file:// claim',clockInstalled:false,sourcesBefore:sources(),binariesBefore:binaries(),installedBefore:installedMap(),cases:[],externalRequests:[],errors:[]};
const save=()=>writeFileSync(proofPath,JSON.stringify(result,null,2)+'\n');save();assert.equal(Object.keys(result.installedBefore).length,1618);
let browser=null,activePage=null,activeCase=null;
const snapshot=async(page,label)=>{const raw=await page.evaluate(()=>({observedAt:new Date().toISOString(),wallNow:Date.now(),nativePerformanceNow:performance.now(),veilAnimations:document.querySelector('#veil').getAnimations().map(a=>({playState:a.playState,currentTime:a.currentTime,finishCallbackPresent:typeof a.onfinish==='function'})),view:document.querySelector('#app').dataset.view,status:document.querySelector('#status').textContent,round:document.querySelector('#roundPill').textContent,veilVisible:!document.querySelector('#veil').hidden,privacy:document.querySelector('#privacy').innerText,privateTiles:[...document.querySelectorAll('#hand .hand-tile')].map(e=>({id:Number(e.dataset.tile),playable:e.classList.contains('playable')})),boardTiles:[...document.querySelectorAll('#boardLayer .tile')].map(e=>Number(e.dataset.tile)),seats:[...document.querySelectorAll('#seatsLayer .seat')].map(e=>({seat:Number(e.dataset.seat),name:e.querySelector('.who b span').textContent,count:Number(e.querySelector('.count').textContent),active:e.classList.contains('active'),faceTiles:e.querySelectorAll('[data-tile]').length})),stock:Number(document.querySelector('#yard b')?.textContent??0),handScrollWidth:document.querySelector('#hand').scrollWidth,handClientWidth:document.querySelector('#hand').clientWidth,handScrollLeft:document.querySelector('#hand').scrollLeft,roundEndVisible:!document.querySelector('#roundEnd').hidden,roundRows:document.querySelectorAll('#roundEnd .tally-row').length,roundFaceTiles:document.querySelectorAll('#roundEnd .tally-tiles .tile').length,viewport:{width:innerWidth,height:innerHeight},documentWidth:document.documentElement.scrollWidth,controls:[...document.querySelectorAll('#actions button,#privacy button,#end,#sound')].filter(e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden').map(e=>{const r=e.getBoundingClientRect();return {label:e.getAttribute('aria-label')??e.textContent,x:r.x,y:r.y,width:r.width,height:r.height};})}));activeCase.steps.push({label,raw});save();return raw;};
try{
 browser=await chromium.launch({headless:true,executablePath:'/usr/lib/chromium/chromium',args:['--no-sandbox']});result.chromiumVersion=browser.version();
 for(const scenario of [{mode:'draw',partners:false,motion:'no-preference',seed:146}]){
  activeCase={...scenario,viewport:{width:390,height:844},cpuThrottleRate:4,steps:[],status:'STARTED'};result.cases.push(activeCase);save();
  const context=await browser.newContext({viewport:activeCase.viewport,reducedMotion:scenario.motion});const page=await context.newPage();activePage=page;
  page.on('pageerror',e=>{result.errors.push(e.message);save();});page.on('request',r=>{if(/^https?:/.test(r.url())){result.externalRequests.push(r.url());save();}});
  await page.route('**/*',r=>/^https?:/.test(r.request().url())?r.abort():r.continue());
  await page.setContent(readFileSync(join(job,'play.html'),'utf8'));
  const cdp=await context.newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});
  await page.check('#players-4');for(let i=0;i<4;i++)await page.selectOption(`#seat-${i}`,'human');
  await page.setChecked('#partners',scenario.partners);await page.check('#mode-'+scenario.mode);await page.check('#target-250');
  await page.click('#houseRules summary');await page.selectOption('#opening','rotating');await page.fill('#seed',String(scenario.seed));await page.click('#start');
  let raw=await snapshot(page,'initial-private-handover');assert.equal(raw.view,'phone');assert.equal(raw.seats.length,4);assert.equal(raw.privateTiles.length,0);assert(raw.veilVisible);
  const knownHands=new Map();let actions=0,turns=0,draws=0,passes=0,maximumHand=0;
  const finalSummary=()=>({actions,turns,draws,passes,maximumHand,knownHands:Object.fromEntries(knownHands)});
  while(actions<100){
   if(raw.roundEndVisible)break;
   await page.locator('#privacy button').click();raw=await snapshot(page,'turn-'+turns+'-revealed');
   const active=raw.seats.filter(s=>s.active);assert.equal(active.length,1);
   const seat=active[0].seat;assert(raw.status.includes('Player '+(seat+1)));
   assert.equal(raw.privateTiles.length,active[0].count);assert.equal(raw.veilVisible,false);
   assert(raw.seats.every(s=>s.faceTiles===0));assert(raw.documentWidth<=390);
   assert(raw.controls.every(c=>c.x>=-1&&c.y>=-1&&c.x+c.width<=391&&c.y+c.height<=845),'visible controls must fit phone viewport');
   maximumHand=Math.max(maximumHand,raw.privateTiles.length);knownHands.set(seat,raw.privateTiles.map(x=>x.id));
   await page.getByRole('button',{name:'Hide my tiles',exact:true}).click();raw=await snapshot(page,'turn-'+turns+'-hidden');assert.equal(raw.privateTiles.length,0);assert(raw.veilVisible);
   await page.locator('#privacy button').click();raw=await snapshot(page,'turn-'+turns+'-revealed-again');
   assert.deepEqual(raw.privateTiles.map(x=>x.id),knownHands.get(seat),'same authorized hand must reappear');
   for(let drawn=0;drawn<=28;drawn++){
    const playable=page.locator('#hand .hand-tile.playable');
    if(await playable.count()){
     const selected=Number(await playable.first().getAttribute('data-tile'));await playable.first().click();
     if(await page.getByRole('button',{name:'Play on the right end',exact:true}).count())await page.getByRole('button',{name:'Play on the right end',exact:true}).first().click();
     knownHands.set(seat,knownHands.get(seat).filter(x=>x!==selected));actions++;
     raw=await snapshot(page,'turn-'+turns+'-played');assert(raw.boardTiles.includes(selected),'chosen legal tile must reach public board');break;
    }
    const pass=page.getByRole('button',{name:'Pass',exact:true}),draw=page.getByRole('button',{name:'Draw a tile',exact:true});
    if(await pass.count()){
     await pass.click();passes++;actions++;raw=await snapshot(page,'turn-'+turns+'-passed');break;
    }
    assert(await draw.count(),'active player must have a legal play, pass or draw');
    const priorIds=[...knownHands.get(seat)],priorStock=raw.stock;
    await draw.click();draws++;actions++;raw=await snapshot(page,'turn-'+turns+'-draw-'+drawn);
    assert.equal(raw.privateTiles.length,priorIds.length+1);assert.equal(raw.stock,priorStock-1);
    assert(priorIds.every(x=>raw.privateTiles.some(t=>t.id===x)));assert.equal(raw.veilVisible,false);
    knownHands.set(seat,raw.privateTiles.map(x=>x.id));maximumHand=Math.max(maximumHand,raw.privateTiles.length);
   }
   turns++;activeCase.summary=finalSummary();save();
   await page.waitForFunction(()=>!document.querySelector('#veil').hidden||!document.querySelector('#roundEnd').hidden,undefined,{timeout:4000});
   raw=await snapshot(page,'turn-'+turns+'-private-or-round-end');
   assert.equal(raw.privateTiles.length,0);
   if(!raw.roundEndVisible)assert(raw.veilVisible);
  }
  assert(raw.roundEndVisible,'complete seeded round must reach visible round-end sheet within100 legal actions');
  assert.equal(raw.roundRows,4);assert.equal(raw.privateTiles.length,0);assert.equal(raw.veilVisible,false);
  assert.equal(knownHands.size,4);
  const remaining=[...knownHands.values()].reduce((n,h)=>n+h.length,0);
  assert.equal(raw.roundFaceTiles,remaining,'public round sheet must reveal exactly all remaining actual hands');
  assert.equal(raw.boardTiles.length+remaining+raw.stock,28,'public board/revealed hands/stock conserve double-six set');
  const expectedPips=Object.fromEntries([...knownHands].map(([seat,hand])=>[seat,hand.reduce((sum,t)=>{let n=t;for(let a=0;a<=6;a++){const size=7-a;if(n<size)return sum+a+(a+n);n-=size;}throw new Error('Bad tile id');},0)]));
  await page.waitForFunction(expected=>[...document.querySelectorAll('#roundEnd .tally-row')].every((row,seat)=>Number(row.querySelector('.pp span').textContent)===expected[seat]),expectedPips,{timeout:4000});
  activeCase.expectedPips=expectedPips;activeCase.summary=finalSummary();save();
  await page.getByRole('button',{name:'Next round',exact:true}).click();
  await page.waitForFunction(()=>!document.querySelector('#veil').hidden&&!document.querySelector('#roundEnd').getClientRects().length,undefined,{timeout:4000});
  raw=await snapshot(page,'next-round-private-handover');
  assert.equal(raw.privateTiles.length,0);assert(raw.veilVisible);assert.equal(raw.roundEndVisible,false);
  activeCase.completeRoundAndNextPrivateHandover='PASS';
  await page.screenshot({path:join(output,`${scenario.mode}-${scenario.partners?'partners':'individual'}-${scenario.motion}.png`)});
  activeCase.status='PASS';save();await context.close();activePage=null;activeCase=null;
 }
 assert.equal(result.cases.length,1);assert.equal(result.cases[0].summary.maximumHand,13,'selected genuine seeded stress hand must reach13 tiles');assert.equal(result.cases[0].summary.draws,8);assert.deepEqual(result.externalRequests,[]);assert.deepEqual(result.errors,[]);result.status='PASS';result.finishedAt=new Date().toISOString();
}catch(error){result.status='FAIL';result.failure={type:error?.name??'Error',message:String(error?.message??error),stack:String(error?.stack??'')};if(activePage&&activeCase){try{await snapshot(activePage,'actual-partial-failure');}catch(e){result.partialSnapshotFailure=String(e);}}save();throw error;
}finally{
 try{if(browser){await browser.close();result.browserClosedAt=new Date().toISOString();}result.sourcesAfter=sources();result.binariesAfter=binaries();result.installedAfter=installedMap();save();assert.deepEqual(result.sourcesAfter,result.sourcesBefore);assert.deepEqual(result.binariesAfter,result.binariesBefore);assert.deepEqual(result.installedAfter,result.installedBefore);}catch(error){result.status='FAIL';result.guardOrClosureFailure=String(error);throw error;}finally{save();}
}
console.log(JSON.stringify({status:result.status,cases:result.cases.length,browserClosedAt:result.browserClosedAt,scope:result.scope}));
