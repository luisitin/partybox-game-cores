from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, zipfile

PRIVATE=Path(__file__).resolve().parent
REPO=PRIVATE.parent/'repo'
JOB=REPO/'jobs/G01-dominoes'
HEAD='380bc2b85620995152e57504e319062e69620133'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==HEAD

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity(path):
    raw=Path(path).read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}

reader=json.loads((PRIVATE/'380-official-ram-first/ram-loader-receipt.json').read_text())
controller=json.loads((PRIVATE/'380-official-ram-first-once-controller.json').read_text())
assert reader['status']==controller['status']=='PASS'
assert controller['naturalClosure'] and controller['exitCode']==0 and controller['remainingOwnedLiveProcesses']==[]
assert controller['freshCompleteInputs']['status']=='PASS'
assert reader['independentAcceptance']['checks']==1303
assert reader['actualBytes']==114796318 and reader['actualSha256']=='549e98a4d5dff8257666ae558b20d184f71aed7ddac933ed05b7b037fed23968'
proof=PRIVATE/'380-official-ram-first/380-official-bounded-proof.zip'
with zipfile.ZipFile(proof) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist())==len(set(archive.namelist()))==reader['boundedArchive']['exactMembers']
shutil.copyfile(proof,JOB/'media/privacy-veil-hosted-380bc2b-proof.zip')
assert identity(proof)==identity(JOB/'media/privacy-veil-hosted-380bc2b-proof.zip')

negative=json.loads((PRIVATE/'privacy-veil-old949-negative-first-controller.json').read_text())
review=json.loads((PRIVATE/'privacy-veil-old949-negative-first-review.json').read_text())
assert negative['status']=='FAIL' and negative['naturalClosure'] and negative['exitCode']==1
assert negative['remainingOwnedLiveProcesses']==[] and negative['completeInputGuardsPassed']
assert review['status']=='ORIGINAL_FAILURE_PRESERVED_NEGATIVE_CONTROL_REJECTS_OLD_CALLBACK'
assert review['actualControllerClosedAt']=='2026-10-09T04:36:13.599198+00:00'
payload={}
for suffix in ['controller.py','controller.json','controller.log','complete-inputs.json','ready.json','review.json']:
    name='privacy-veil-old949-negative-first-'+suffix
    payload['negative/'+name]=(PRIVATE/name).read_bytes()
clone=PRIVATE/'privacy-veil-old949-negative-first/repo'
for name in ['ui.ts','play.html','core.ts','strong-bot.ts','strong-worker.ts','browser.ts','browser-evidence.ts','package.json','build.ts','shell.html','privacy-veil-check.ts']:
    path=clone/'jobs/G01-dominoes'/name
    payload['negative/source/'+name]=path.read_bytes()
payload['negative/source/rng.ts']=(clone/'contract/rng.ts').read_bytes()
payload['negative/actual-real-waapi-raw.json']=(clone/'jobs/G01-dominoes/.tmp/privacy-veil-check.json').read_bytes()
for name in ['380-official-ram-first-once-controller.json','380-official-ram-first-once-controller.log','control-380-official-ram-first-once.py','accept-380-official-ram-first.py','fresh-380-reader-inputs.py','380-official-ram-first-fresh-inputs.json','380-reader-prelaunch-missing-file-controller.py','380-reader-prelaunch-missing-file.json']:
    payload['current-reader-inputs/'+name]=(PRIVATE/name).read_bytes()
payload['current-reader-inputs/ram-loader-receipt.json']=(PRIVATE/'380-official-ram-first/ram-loader-receipt.json').read_bytes()
negative_zip=JOB/'media/privacy-veil-old949-negative-complete-proof.zip'
with zipfile.ZipFile(negative_zip,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name,raw in payload.items():
        item=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0)); item.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(item,raw)
assert negative_zip.stat().st_size<3_000_000
with zipfile.ZipFile(negative_zip) as archive:
    assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))==len(payload)
    for name,raw in payload.items(): assert archive.read(name)==raw

summary={'schema':'g01-current-private-prompt-full-hosted-acceptance/1','status':'CURRENT_FULL_ACCEPTED_KEEP_CONTINUES','source':HEAD,'run':37884128914,'job':113670211296,'artifactId':11596133560,'officialBytes':reader['actualBytes'],'officialSha256':reader['actualSha256'],'actualWorkflowSuccessAt':'2026-10-09T04:52:25Z','independentChecks':1303,'wholeReaderNaturallyClosedAt':controller['naturallyClosedAt'],'completeInputGuardStatus':controller['freshCompleteInputs'],'actualAcceptance':reader['independentAcceptance'],'actualNativeProfiles':reader['actualNativeProfiles'],'fullOfficialArchiveOnDisk':False,'boundedOfficialProof':{'path':'media/privacy-veil-hosted-380bc2b-proof.zip',**identity(proof),'members':reader['boundedArchive']['exactMembers']},'old949Negative':{'baselineSource':'949dbcbd3a82882a6d69bb6c50ff8d735ca5d8dc','testSource':HEAD,'status':'ACTUAL_FAIL_PRESERVED','closedAt':negative['naturallyClosedAt'],'exitCode':1,'allInputGuardsPassed':True,'remainingOwnedLiveProcesses':[],'actualRawSteps':review['actualSteps'],'failure':review['actualFailure'],'archive':{'path':'media/'+negative_zip.name,**identity(negative_zip),'members':len(payload)}},'newDefaultRegression':'Exact full native npm chain invokes source-bound privacy-veil-check.ts before original byte-identical browser.ts; actual genuine native-animation private-prompt PASS sentence is retained in full current proof. Raw regression JSON was not in the original hosted upload path; no hosted raw DOM claim. Separate local first-current-source actual raw is in earlier public phone-veil-callback-fix-first-proof.zip.','renewedCompletedKeepRounds':1,'materialPrivacyImprovements':1,'consecutiveNoPlayerGainRounds':0,'scope':'Exact modified380 UI current full original pipeline/source/native/25 actual mutants/file:// privacy/real Worker/original600 frame intervals/602 stamps/36 complete VP9 frames accepted. The old callback loses the newlyopened prompt in FIRST new real-WAAPI negative control with unchanged seat/board. Separate older four-phone failure cause UNKNOWN. No FPS, physical phone, responsiveness gain or completed stopping condition claim.'}
(JOB/'privacy-veil-hosted-380bc2b.json').write_text(json.dumps(summary,indent=2)+'\n')
section='''## Current full privacy fix accepted; KEEP continues

Exact380bc2b full original workflow37884128914/job113670211296 SUCCEEDED
04:52:25UTC. Genuine official11596133560/114,796,318B/SHA549e98a4d5dff825
7666ae558b20d184f71aed7ddac933ed05b7b037fed23968 passed the BYTE-UNCHANGED
full reader1,303 checks. Outer naturally CLOSED05:02:44.578453UTC/exit0/group[].
Whole SHA/safe unique paths/CRC/all immutable Git bytes/full native npm/25 actual
mutants/real file:// private handover/16 real Worker replays/five actual variants/
600 original intervals/602 stamps/36 fully decoded VP9 frames PASS. Whole ZIP
was held in bounded RAM; complete bounded raw/mutable outputs/native/reader are
in media/privacy-veil-hosted-380bc2b-proof.zip. The fresh after-restart source,
installed aliases/Python stdlib/external startup modules/runtimes stayed exact.

FIRST new default real-WAAPI regression on exact old949 source genuinely FAILED
04:36:13.599198UTC/exit1. All complete input guards PASS/group[]: after actual
Reveal/Hide and353.5 native ms, the old finish callback hides the new prompt,
with samePlayer1/empty board/no hand exposed. New exact380 full original npm
invokes that regression before byte-unchanged original browser.ts, with its
actual native PASS sentence. Full hosted raw regression JSON was outside the
original upload path; no hosted raw DOM claim. Earlier first changed-source
four-case/real-WAAPI full raw is public. This controlled negative identifies
this callback defect; the older four-phone failure cause remains UNKNOWN.

privacy-veil-hosted-380bc2b.json records exact current proof and both complete
archives. Old949 FAIL/default regression/raw/controllers/complete inputs and the
reader's before-child-only helper namespace error are preserved byte-for-byte.
No original sampler/gate/clock changed; no native unchanged retry occurred.

Renewed completed KEEP1: bounded private-prompt reliability improvement now
qualified by complete current CI. Consecutive no-player-gain rounds0. PR11
stays draft until renewed substantive review reaches the binding three-round
no-player-gain condition. Original PR1 unchanged canonical8c/draft/unmerged.
Next: re-read G01/rankfive, examine the worst remaining testable weakness with
actual evidence, preserve every rejected attempt and log each measured round.
Old responsiveness native acceptance and both player-gain gates remain FAIL.

Last source push04:29:34.626379UTC; hard04:59:34.626379UTC was exceeded during
the execution-environment restart/resumption. Work actually resumed04:59:15UTC;
this preparation occurs after the deadline, with no backdated timestamp.
Read the next actual source-push receipt for exact interval and fresh cadence.
Main CLAIMS refresh requires the root-serialized exclusive ownG01row lease.

'''
path=JOB/'NEXT.md'; text=path.read_text(); marker='## Current private-hand prompt fix adopted in audit\n'; assert marker in text
path.write_text(text.replace(marker,section+'## Historical source-adoption checkpoint\n',1))
for name in ['VERIFY.md','HOSTED-WORKER-AUDIT.md','ASSUMPTIONS.md']:
    path=JOB/name; path.write_text(path.read_text().rstrip()+'\n\n'+section.rstrip()+'\n')
path=JOB/'README.md'; text=path.read_text().replace('Privacy prompt fix passes four-case/WAAPI checks; current full CI/KEEP pending.','Privacy prompt fix/current full CI and1,303-check whole proof PASS; KEEP pending.')
assert len(text.splitlines())<60; path.write_text(text)
path=JOB/'LOOP.md'; path.write_text(path.read_text().rstrip()+'\n\nR25, 2026-10-09: complete exact380 full CI/genuine1,303-check official proof validates the bounded obsolete-reveal-callback fix. FIRST old949 real-WAAPI new-regression negative FAIL353.5ms hides prompt; changed-source four-case16 human turns and same real-WAAPI/default full pipeline PASS. Older phone failure cause UNKNOWN, no response/FPS claim. Renewed completed rounds1/material privacy improvement1/no-player-gain streak0.\n')
path=JOB/'REVIEW.md'; path.write_text(path.read_text().rstrip()+'\n\nAfter exact380 full original current green and1,303-check genuine artifact acceptance, re-read binding G01: ranked weaknesses are complete four-human phone round/large-hand coverage; unestablished Strong response benefit (both original gain gates FAIL); bounded upstream strategy evidence; unmeasured background animation costs; unavailable physical-phone evidence. R25 private-prompt correction is a qualified bounded reliability gain, renewed no-gain streak0. The next testable weakness is full-round mobile handover and round-end presentation, retaining all native controls and no simulated clocks/FPS retry.\n')
subprocess.run(['node','checksums.ts'],cwd=JOB,check=True)
subprocess.run(['node','checksums.ts','--check'],cwd=JOB,check=True)
subprocess.run(['git','diff','--check'],cwd=REPO,check=True)
changed=subprocess.check_output(['git','status','--short'],cwd=REPO,text=True)
assert all(line[3:].startswith('jobs/G01-dominoes/') for line in changed.splitlines())
for name in ['ui.ts','play.html','core.ts','strong-bot.ts','strong-worker.ts','privacy-veil-check.ts','browser.ts','browser-evidence.ts','package.json','build.ts','shell.html']:
    assert (JOB/name).read_bytes()==subprocess.check_output(['git','show',HEAD+':jobs/G01-dominoes/'+name],cwd=REPO)
result={'status':'PASS_PREPARED','naturallyClosedAt':now(),'source':HEAD,'currentProof':summary['boundedOfficialProof'],'negativeProof':summary['old949Negative']['archive'],'gitStatus':changed,'scope':'Exact current whole official acceptance and real old-negative first proof/docs only; all current product/default test/sampler/source bytes unchanged.'}
(PRIVATE/'380-negative-public-preparation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
