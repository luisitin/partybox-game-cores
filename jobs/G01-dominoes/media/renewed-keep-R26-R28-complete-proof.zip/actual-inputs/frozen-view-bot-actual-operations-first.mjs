import {init,legal,reduce,observe,tvView,controllerView,game} from './large-hand-fixture-first/repo/jobs/G01-dominoes/core.ts';
import {createRng} from './large-hand-fixture-first/repo/contract/rng.ts';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/tmp/g01-current-838-proof-20261009';
const files=['core.ts','ui.ts','play.html','privacy-veil-check.ts'];
const record=()=>Object.fromEntries(files.map(name=>{const raw=readFileSync(`${root}/repo/jobs/G01-dominoes/${name}`);return [name,{bytes:raw.length,sha256:createHash('sha256').update(raw).digest('hex')}];}));
function freeze(value){if(value&&typeof value==='object'&&!Object.isFrozen(value)){Object.freeze(value);for(const part of Object.values(value))freeze(part);}return value;}
const seeds=[1,2,3];let value=0x6012701;
while(seeds.length<1003){value=(Math.imul(value,1664525)+1013904223)>>>0;if(value>3&&!seeds.includes(value))seeds.push(value);}
const report={schema:'g01-frozen-shipped-view-and-bot-operations-first/1',status:'STARTED',startedAt:new Date().toISOString(),source:'48cb1b551365f613b65948fb640d3105f679f719',sourcesBefore:record(),scope:'FIRST bounded frozen-state/hidden-substitution audit of actual shipped views and choose consumers; exports readonly observation endpoints are read only. Does not retry or reinterpret earlier deliberate JavaScript readonly-array mutation FAIL, native timing or historical phone failure.',seeds,counts:{frozenStates:0,hiddenSubstitutionPairs:0,deterministicEasyNormalCalls:0,deterministicSharpCalls:0,pureReducerTransitions:0},rows:[],failure:null};
const save=()=>writeFileSync(`${root}/private/frozen-view-bot-actual-operations-first.json`,JSON.stringify(report,null,2)+'\n');save();
try{
 for(const n of [2,3,4])for(let index=0;index<seeds.length;index++){
  const seed=seeds[index];
  let state=init(freeze({players:Array.from({length:n},(_,i)=>({id:`p${i}`,name:`Player ${i+1}`,avatarId:'🙂',connected:true,bot:false})),settings:{mode:seed%2?'draw':'block',deal:seed%3?'traditional':'block-sized',partners:n===4&&seed%5===0,target:String([100,150,250][seed%3]),reserve:seed%2?'2':'0',opening:seed%3?'rotating':'highest-double',blocked:seed%2?'difference':'opponents',teamPoints:seed%2?'opponents':'all'},seed,now:0}));
  for(let step=0;step<3;step++){
   freeze(state);const before=JSON.stringify(state),options=legal(state);assert(options.length);report.counts.frozenStates++;
   for(const viewer of state.seats){
    const original=controllerView(state,viewer),observation=observe(state,viewer);
    const seat=state.seats.indexOf(viewer),pool=[...state.hands.flatMap((hand,i)=>i===seat?[]:hand),...state.stock].reverse();
    let offset=0;const hands=state.hands.map((hand,i)=>{if(i===seat)return [...hand];const changed=pool.slice(offset,offset+hand.length);offset+=hand.length;return changed;});
    const altered=freeze({...state,hands,stock:pool.slice(offset)});
    assert.deepEqual(tvView(state),tvView(altered));assert.deepEqual(original,controllerView(altered,viewer));assert.deepEqual(observation,observe(altered,viewer));
    assert.equal(observation.ends,state.ends);assert(observation.ends===null||Object.isFrozen(observation.ends));
    report.counts.hiddenSubstitutionPairs++;
   }
   for(const spectator of ['unknown','__proto__']){assert.deepEqual(controllerView(state,spectator).hand,[]);assert.deepEqual(controllerView(state,spectator).legal,[]);assert.equal(game.bot.sampleInput(state,spectator,createRng(seed),'sharp'),null);}
   for(const skill of ['easy','normal']){
    const first=game.bot.sampleInput(state,state.seats[state.turn],createRng(seed^0x571),skill),second=game.bot.sampleInput(state,state.seats[state.turn],createRng(seed^0x571),skill);
    assert.deepEqual(first,second);assert(options.some(option=>JSON.stringify(option)===JSON.stringify(first)));report.counts.deterministicEasyNormalCalls+=2;
   }
   if(index<12&&step===1){
    const first=game.bot.sampleInput(state,state.seats[state.turn],createRng(seed^0x571),'sharp'),second=game.bot.sampleInput(state,state.seats[state.turn],createRng(seed^0x571),'sharp');
    assert.deepEqual(first,second);assert(options.some(option=>JSON.stringify(option)===JSON.stringify(first)));report.counts.deterministicSharpCalls+=2;
   }
   assert.equal(JSON.stringify(state),before,'Actual view/bot consumers must not mutate fully frozen input state');
   const next=reduce(state,freeze({type:'input',input:options[0],playerId:state.seats[state.turn],now:step+1}));
   assert.equal(JSON.stringify(state),before);assert.notEqual(next,state);report.counts.pureReducerTransitions++;state=next;
  }
  report.rows.push({players:n,seed,status:'PASS'});if(index%100===0)save();
 }
 assert.equal(report.counts.frozenStates,9027);assert.equal(report.counts.hiddenSubstitutionPairs,27081);assert.equal(report.counts.pureReducerTransitions,9027);
 report.status='PASS';
}catch(error){report.status='FAIL';report.failure={type:error.name,message:error.message,stack:error.stack};save();throw error;}
finally{report.sourcesAfter=record();assert.deepEqual(report.sourcesAfter,report.sourcesBefore);report.closedAt=new Date().toISOString();save();}
console.log(JSON.stringify({status:report.status,counts:report.counts,closedAt:report.closedAt}));
