import {init,legal,reduce} from './large-hand-fixture-first/repo/jobs/G01-dominoes/core.ts';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/tmp/g01-current-838-proof-20261009';
const files=['core.ts','ui.ts','play.html','privacy-veil-check.ts'];
const record=()=>Object.fromEntries(files.map(n=>{const bytes=readFileSync(`${root}/repo/jobs/G01-dominoes/${n}`);return [n,{bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')}];}));
const before=record(),rows=[];
for(let seed=1;seed<=5000;seed++){
 let state=init({players:[0,1,2,3].map(i=>({id:`p${i}`,name:`Player ${i+1}`,avatarId:'🙂',connected:true,bot:false})),settings:{mode:'draw',partners:false,target:'250',opening:'rotating',deal:'block-sized',reserve:'0'},seed,now:0});
 let maximumHand=5,actions=0,draws=0;
 while(state.phase.id==='play'&&actions<100){
  const options=legal(state);assert(options.length);
  const first=options[0];const input=first.type==='play'?(options.find(x=>x.type==='play'&&x.tile===first.tile&&x.side==='right')??first):first;
  if(input.type==='draw')draws++;
  state=reduce(state,{type:'input',input,playerId:state.seats[state.turn],now:actions+1});
  maximumHand=Math.max(maximumHand,...state.hands.map(h=>h.length));actions++;
 }
 assert.equal(state.phase.id,'round-end');rows.push({seed,maximumHand,actions,draws,remainingHands:state.hands.map(h=>h.length)});
}
const ranked=[...rows].sort((a,b)=>b.maximumHand-a.maximumHand||a.seed-b.seed),selected=ranked[0];
const after=record();assert.deepEqual(after,before);
const report={schema:'g01-deterministic-large-hand-functional-fixture-selection/1',status:'PASS',closedAt:new Date().toISOString(),scope:'Untimed pure-core deterministic5000-seed FIRST-round fixture scan; selects highest actual hand size and lowest seed tie for subsequent distinct UI stress case. No browser/performance trial or player-gain claim.',policy:'First DOM hand-order legal tile; right side if legal, otherwise first legal side; legal draw/pass. Same as expanded UI check.',sourcesBefore:before,sourcesAfter:after,rows,selected};
writeFileSync(`${root}/private/large-hand-fixture-scan-first.json`,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,seeds:rows.length,selected}));
