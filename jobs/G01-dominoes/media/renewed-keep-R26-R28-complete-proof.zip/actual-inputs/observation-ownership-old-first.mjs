import {init,legal,reduce,observe} from './large-hand-fixture-first/repo/jobs/G01-dominoes/core.ts';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const base='/tmp/g01-current-838-proof-20261009';
const core=`${base}/private/large-hand-fixture-first/repo/jobs/G01-dominoes/core.ts`;
const identify=()=>{const raw=readFileSync(core);return {bytes:raw.length,sha256:createHash('sha256').update(raw).digest('hex')};};
const report={schema:'g01-exported-observation-owned-array-first-probe/1',status:'STARTED',startedAt:new Date().toISOString(),source:'48cb1b551365f613b65948fb640d3105f679f719',coreBefore:identify(),scope:'FIRST private JavaScript-consumer ownership probe on exact source48 core. Mutates only returned public observation endpoints, asking whether original state/board consistency changes. Tile tuple is readonly at the TypeScript boundary; shipped choose currently reads it. No current player mutation cause or user-visible gain claim.'};
const save=()=>writeFileSync(`${base}/private/observation-ownership-old-first.json`,JSON.stringify(report,null,2)+'\n');save();
try{
 let state=init({players:[0,1].map(i=>({id:`p${i}`,name:`Player ${i+1}`,avatarId:'🙂',connected:true,bot:false})),settings:{mode:'block',opening:'rotating'},seed:23,now:0});
 const input=legal(state)[0];state=reduce(state,{type:'input',input,playerId:state.seats[state.turn],now:1});
 const observation=observe(state,state.seats[state.turn]);assert(observation?.ends&&state.ends);
 report.originalState=structuredClone(state);report.originalEnds=[...state.ends];report.returnedEnds=[...observation.ends];report.sameReference=observation.ends===state.ends;save();
 const before=JSON.stringify(state);observation.ends[0]=(observation.ends[0]+1)%7;
 report.stateAfterReturnedArrayMutation=structuredClone(state);report.changedEnds=[...state.ends];report.boardLeft=state.board[0].a;save();
 assert.equal(JSON.stringify(state),before,'Returned public observation endpoints must not mutate caller game state');
 report.status='PASS';
}catch(error){report.status='FAIL';report.failure={type:error.name,message:error.message,stack:error.stack};save();throw error;}
finally{report.coreAfter=identify();assert.deepEqual(report.coreAfter,report.coreBefore);report.closedAt=new Date().toISOString();save();}
