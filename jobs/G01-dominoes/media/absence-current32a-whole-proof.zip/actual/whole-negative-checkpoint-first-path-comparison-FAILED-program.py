from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,zipfile
ROOT=Path('/tmp/G01-source-queue-audit-20261009');JOB=ROOT/'jobs/G01-dominoes';OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');PARENT='32a10dd94565acbfe7d7f42b5f5ebbef9a57a9ce'
def load(name):return json.loads((OUT/name).read_text())
def identity(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def dump(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==PARENT
accepted=load('official-current32a-first-CLOSED.json');negative=load('postgreen-idle-departure-first-CLOSED.json');local=load('original-node-suite-current32a-first-full-native-readback-CLOSED.json')
assert accepted['status']=='PASS' and accepted['naturalClosure'] and accepted['allFrozenInputsUnchanged'] and accepted['actualIndependentAcceptance']['checks']==1342 and not accepted['remainingOwnedChildren'] and not accepted['remainingOwnedDetached']
assert negative['status']=='CLOSED_FAILURE' and negative['exitCode']==1 and negative['naturalClosure'] and negative['allFrozenInputsUnchanged'] and negative['failureCount']==480 and not negative['remainingOwnedChildren'] and not negative['remainingOwnedDetached']
assert local['status']=='PASS' and local['actualCounts']['tests']==[48,7] and local['totalPassed']==55
official=OUT/'official-current32a-first/whole-original-official.zip';assert identity(official)=={'bytes':accepted['expectedBytes'],'sha256':accepted['expectedSha256']}
members={}
def include(name,path):
 assert name not in members and not Path(name).is_absolute() and '..' not in Path(name).parts and '\\' not in name and not path.is_symlink();members[name]=path.read_bytes()
with zipfile.ZipFile(official) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()));start=json.loads(z.read('ci-start.json'));finish=json.loads(z.read('ci-finish.json'));browser=json.loads(z.read('browser-current.json'));assert finish['status']=='PASS' and PARENT in [start['checkoutHead'],*start['checkoutParents']]
 for name in z.namelist():
  if '/' not in name and not name.endswith('/'):members['official-first-raw/'+name]=z.read(name)
 for name in start['mutableOutputPaths']:
  raw=z.read('after/'+name);assert finish['filesAfter'][name]=={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};members['official-first-after/'+name]=raw
  if not name.endswith('/SHA256SUMS.txt'):(ROOT/name).write_bytes(raw)
 capture=z.read('current-capture.webm');publicClip=JOB/'media/milestone-20-current32a-hosted.webm';publicClip.write_bytes(capture);assert identity(publicClip)==browser['capture']['file'] and len(capture)<10000000
for name in ['official-current32a-first-CLOSED.json','original32a-native-full.log','original-node-suite-current32a-first-CLOSED.json','original-node-suite-current32a-first-native.log','original-node-suite-current32a-first-inputs-before.json','original-node-suite-current32a-first-inputs-after.json','original-node-suite-current32a-first-full-native-readback-CLOSED.json','postgreen-idle-departure-first.json','postgreen-idle-departure-first-CLOSED.json','postgreen-idle-departure-first-native.log','postgreen-idle-departure-first-inputs-before.json','postgreen-idle-departure-first-inputs-after.json','compatibility-milestone-source-publication-CLOSED.json','main-after-material32a-CLOSED.json']:include('actual/'+name,OUT/name)
for name in ['complete-inputs-before.json','complete-inputs-after.json','unchanged-reader-native.log']:include('actual/official-current32a-first/'+name,OUT/'official-current32a-first'/name)
for name in ['G01-current32a-official-whole-first-acceptance-20261009.py','G01-original-node-suite-current32a-first-controller-20261009.py','G01-postgreen-idle-departure-first-20261009.mjs','G01-postgreen-idle-departure-first-controller-20261009.py','G01-current-functional-milestone-first-controller-20261009.py','G01-current32a-whole-and-idle-negative-checkpoint-prepare-20261009.py']:include('programs/'+name,Path('/dev/shm')/name)
include('programs/unchanged-full-reader.py',JOB/'verify-worker-artifact.py')
archive=JOB/'media/absence-current32a-whole-proof.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,raw in sorted(members.items()):
  entry=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,raw)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 for name,raw in members.items():assert z.read(name)==raw
prepared=datetime.datetime.now(datetime.timezone.utc).isoformat();hard=datetime.datetime.fromisoformat('2026-10-09T14:34:47.620789+00:00');delay=(datetime.datetime.fromisoformat(prepared)-hard).total_seconds()
report={'schema':'g01-current32a-whole-and-first-idle-negative/1','preparedUtc':prepared,'sourceParent':PARENT,'originalWholeAcceptance':accepted,'originalNodeFullNativeReadback':local,'actualCurrentProfiles':[{key:p[key] for key in ['name','viewport','throttle','fps','meanMs','p95Ms','p99Ms']} for p in browser['profiles']],'originalMutations':json.loads(members['official-first-after/jobs/G01-dominoes/mutation-report.json']),'currentClip':{'path':str(publicClip.relative_to(JOB)),**identity(publicClip),'scope':'Genuine original32a official36-frame VP9 capture, complete unchanged reader decoder passed. Nominal12fps export is not native refresh.'},'firstPostGreenNegative':negative,'currentInitialAbsenceRepair':'Qualified by genuine original32a full1342-check acceptance; narrow initial active-human absence liveness gain only','unfixedNewIssue':'After a legal whole-table idle cycle, direct active departure and paused departure/resume leave next present-human window1000ms, violating documented30000ms policy;240 cases each/480 actual failures.','renewedFormalReviewsCompleted':0,'consecutiveNoPlayerGain':0,'formalReviewState':'First reread/rank5/measure investigation found real defect; worst still requires narrow fix/measure/log/push. No noGain or completed review credit.','currentNewCheckpointQualification':'PENDING newest-source original whole workflow and actual official full acceptance. Protected Ready11/canonicalDraft1 remain untouched; no Ready20 yet.','fullRawProof':{'path':str(archive.relative_to(JOB)),**identity(archive),'safeUniqueMembers':len(members),'fullCrcAndEveryMemberBytePass':True},'cadence':{'lastActualSourcePush':'2026-10-09T14:04:47.620789+00:00','hardDeadline':'2026-10-09T14:34:47.620789+00:00','actualPreparationSecondsPastHard':max(0,delay),'actualPublication':'Read next native publication receipt; no backdate/prepublication credit'},'scope':'Entire original first official ZIP138424314B/d2bc3d...6e375 preserved in own/dev/shm and fully verified; public archive contains all top-level actual raw evidence, every original mutable after-output, complete controllers/importer aliases/55-test native result and all480 negative observations. Product files/rules/strategies/native clocks/gates unchanged at this checkpoint.'}
dump(JOB/'absence-current32a-whole.json',report)
prefix='''## Current G01 follow-up: genuine full32a green, first review found a real defect

Owner codex-domino-queue-audit-20261009; DraftPR20 remains incomplete.
Branch job/G01-dominoes-queue-audit-20261009; protected Ready11 eadb and
canonical Draft1 8c remain static/unmerged. Below preserves all historical facts.

Initial absence repair is qualified by exact32a original37941524593 /
job113856832232 SUCCESS14:23:09; entire first official11622437616,
138424314B/SHAd2bc3dc9a64d6928aaa59093324fced93b067e753ae3ad74103238576bd6e375
passed unchanged6a33 reader1342 checks. Actual controller closed14:27:04.352304,
all6569 fresh source202/installed/Python/runtime/actual importer/ZIP/native
aliases unchanged; no signals or owned group/detached children. Full native
130021B/SHA03ee4c7d25d569afcfaa8d125e7bd6ad30fd92acaef32dddbb79d75c11f6fb3f.
All25 actual mutant kills/actual file:// privacy/16 real Worker replays/five
variants/600 original native intervals/602 stamps/36 completely decoded VP9
frames pass unchanged gates. Exact observed profile numbers are in the JSON;
no stronger FPS/hardware/gain claim. Earlier original9f FAIL remains preserved.
Complete local original48 +new7 tests pass/no skip, all3331 observed aliases.
Fresh after-only importer observation is not backdated to that earlier suite.

After green, re-read binding job and rank5: old full-idle departure clock;
paused drop/resume clock; fullyconnected adaptive idle parity; historical failed
Worker benefit (no unchanged timing retry); finite phone/upstream scope.
FIRST real240 legal full-idle contexts show active departure leaves next human
1000ms instead of documented30000;240 paused-drop-resume paths fail too.
Child naturally FAIL1 14:33:50.139305; controller CLOSED_FAILURE14:33:56.571522;
all6568 fresh actual importer/source/runtime guards pass/group+detached[].
Full240 states/events/480 genuine failures/helpers/complete guards are public.
This is an incomplete first formal review: NO noGain/completed-round credit.

NEXT: fix only explicit active departure and paused drop/resume from existing
idle cycle; preserve fullyconnected whole states, empty/paused controls and
automatic inactive-budget acceleration. Do NOT reset idle after every absent
automatic turn: that could prevent an inactive remaining human's fast progress.
Measure negative→pass, full connected parity/idle-budget/empty controls; strict
build/new default regression/current functional capture; log/push this separate
review and accept new whole original exact-head official proof. Then reread/
rank5/measure/log/push each further review until3 true player-no-gain rounds.
PR20 stays Draft. No cosmetic source change/old protected source mutation.

absence-current32a-whole.json and safe unique complete media ZIP retain every
original raw/mutable output/source/runtime receipt/current official capture,
all first failures and observed counts. Projection copies genuine current32a
mutable outputs ONLY; the old immutable runner/source attribution stays exact.
Core/page/strategy/native sampler/clock/gate unchanged in this checkpoint.

Last actual source push32a14:04:47.620789; early14:29:47.620789/hard14:34:47.620789.
This preparation happens after the hard deadline during actual whole acceptance
and first post-green negative review; real delay retained, no backdate. Read
actual next push receipt for publication/new conservative cadence. Refresh own
G01 MAIN row only after actual push under exclusive serialized root lease.

## Earlier checkpoint/historical handoffs (exact original scopes remain below)

'''
p=JOB/'NEXT.md';p.write_text(prefix+p.read_text())
for name,heading,body in [
 ('VERIFY.md','Genuine whole32a qualification and first post-green rejection','python /dev/shm/G01-current32a-official-whole-first-acceptance-20261009.py 11622437616 138424314 d2bc3dc9a64d6928aaa59093324fced93b067e753ae3ad74103238576bd6e375: unchanged full6a33 reader PASS1342, controller natural14:27:04.352304/all6569 fresh actual aliases/no child. Original hosted whole pipeline55 default tests/25 real mutant kills/600 intervals602 stamps/36 completeVP9 decode/realfile16Worker5variants pass. Whole native130021B/03ee4c7d25d569afcfaa8d125e7bd6ad30fd92acaef32dddbb79d75c11f6fb3f. Local complete48+7 counts independently read/no skip; after-only importer observation is explicit. python /dev/shm/G01-postgreen-idle-departure-first-controller-20261009.py: actual first old-current policy FAIL1,480 retained assertions in240 legal full-idle contexts, direct andpaused departure human1000ms not30000. Natural14:33:56.571522/all6568 guards/group+detached[]. No source fix/no noGain credit yet; all raw program/state/events/first failures archived. New checkpoint wholeCI mandatory before finalReady.'),
 ('REVIEW.md','First renewed post-green review remains incomplete','Re-read original README/RULES/JOBS after whole32a green. Rank5: full-idle explicit departure; paused departure/resume; unchanged connected adaptive idle plus empty-room budget; unqualified historical Worker benefit; physical-phone/upstream bounds. Real first240 legal contexts reject both currenthuman-clock paths480 times. Worst is real; fix explicit event/resume only, avoid unconditional idle reset which could break remaining inactive-human liveness. No candidate adopted yet; first review is incomplete/no streak credit.'),
 ('LOOP.md','R29 investigation checkpoint, no completed round','After actual whole32a green, reread/rank5; FIRST240 legal full-inactive-cycle controls yield480 true failures: direct active departure and paused-drop-resume give next human1000ms instead30000. Source32a whole1342 proof/genuine55 tests retained; negative natural14:33:56.571522/all6568 inputs. No code change, measured repair gain or completed formal round/noGain credit yet. Worst defect is NEXT; this material evidence/handoff push keeps all old scopes/failures truthful.'),
 ('ASSUMPTIONS.md','First post-green clock issue and truthful cadence','Whole32a qualification certifies tested initial absence liveness and all original gates, not untested full-idle departure. Fresh legal240-context negative discovers480 bad new-human windows. Do not call review noGain or currentDone. Candidate must reset only explicit departure/resume context while preserving inactive acceleration, full connected whole-state equivalence and empty/paused behavior. Prior local3331 source/installed/runtime alias guards remain actual; fresh importer lookup14:21 is after-only, while official whole andnewnegative have fresh before/after actual importer aliases. Source deadline14:34:47.620789 is genuinely exceeded in this preparation; preserve actual publication time/delay without backdate. Whole138MB proof remains own/dev/shm; public bounded archive is every raw/mutable/controller/guard/failure member byte-verified, not a substitute for metadata whole digest/CRC accepted on original first ZIP.')
]:
 p=JOB/name;p.write_text(p.read_text()+'\n## '+heading+'\n'+body+'\n')
p=JOB/'README.md';text=p.read_text().replace('Protected PR11 is Ready on eadb; this isolated absent-turn repair is unqualified.','Protected PR11 stays Ready; initial repair32a passed whole original CI; Draft20 incomplete.').replace('New7-test regressions pass/old6 fail. First full CI failure retained; new full CI/KEEP pending.','All55 tests/25 mutants/whole1342 checks pass; new full-idle departure defect480 FAIL.').replace('1003 full connected matches and24 private handovers pass; NEXT.md records evidence/cadence.','NEXT.md records the first post-green defect, required fix, retained failures and cadence.');assert len(text.splitlines())<60;p.write_text(text)
receipt={'status':'PASS','preparedUtc':prepared,'sourceParent':PARENT,'originalWholeQualifiedSource':PARENT,'firstReviewProductGate':'FAIL preserved480/unfixed/no formal credit','verifiedPublicRawProof':report['fullRawProof'],'currentOriginalClip':report['currentClip'],'preparationSecondsPastHard':max(0,delay),'qualification':'Newest source whole pending; no Ready20'};dump(OUT/'current32a-whole-negative-checkpoint-preparation-CLOSED.json',receipt);print(json.dumps(receipt))
