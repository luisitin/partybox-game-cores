from pathlib import Path
import datetime,json,os,shutil,subprocess,time,signal
ROOT=Path('/tmp/G01-source-queue-audit-20261009');OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');ORIGINAL=Path('/dev/shm/G01-current-functional-milestone-first-controller-20261009.py');HEAD='32a10dd94565acbfe7d7f42b5f5ebbef9a57a9ce';LOG=OUT/'original-node-suite-current32a-first-native.log';RECEIPT=OUT/'original-node-suite-current32a-first-CLOSED.json'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
scope={'__file__':str(ORIGINAL)};program=ORIGINAL.read_text().split("r={'schema':'g01-current-functional-milestone-controller/1'")[0];exec(compile(program,str(ORIGINAL),'exec'),scope);scope['HEAD']=HEAD;scope['__file__']=__file__;scope['HELPER']=ORIGINAL
snapshot=scope['snapshot'];track=scope['track'];group=scope['group'];r={'schema':'g01-original-node-suite-current-first/1','startedUtc':stamp(),'source':HEAD,'wholeBoundSeconds':540,'scope':'First complete unchanged original node:test suite and new absence regressions on exact published32a, without FAST_TEST/test filters/mocks. Whole committed source and complete installed/browser/Python/runtime aliases frozen before and after. No browser/FPS launch.','commands':[],'signalsSent':[]};child=None
try:
 assert not RECEIPT.exists() and not LOG.exists();before=snapshot();(OUT/'original-node-suite-current32a-first-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');deadline=time.monotonic()+540
 with LOG.open('xb') as log:
  for args in [[shutil.which('node'),'--test','test.ts'],[shutil.which('node'),'--test','absence-presence.test.ts']]:
   c={'argv':args,'startedUtc':stamp()};r['commands'].append(c);env=dict(os.environ,TMPDIR=str(OUT));assert not env.get('FAST_TEST') and not env.get('CORE_PATH') and not env.get('ABSENCE_CORE_PATH');child=subprocess.Popen(args,cwd=ROOT/'jobs/G01-dominoes',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);c['childPid']=child.pid
   while child.poll() is None:
    track(child.pid)
    if time.monotonic()>=deadline:raise subprocess.TimeoutExpired(args,540)
    time.sleep(.1)
   c['closedUtc']=stamp();c['exitCode']=child.returncode;assert child.returncode==0,(args,child.returncode);assert not track(child.pid) and not group(child.pid)
 after=snapshot();(OUT/'original-node-suite-current32a-first-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Complete frozen input drift';r['allFrozenInputsUnchanged']=True;r['frozenAliasCount']=len(before['aliases']);r['sourceFiles']=before['sourceFiles'];r['status']='PASS';r['exitCode']=0
except BaseException as e:r.update({'status':'FAIL','exitCode':1,'errorType':type(e).__name__,'error':str(e)})
finally:
 if child is not None:
  live=track(child.pid)
  if child.poll() is None or live:
   try:os.killpg(child.pid,signal.SIGTERM);r['signalsSent'].append('SIGTERM owned group')
   except ProcessLookupError:pass
   for p in live:
    try:os.kill(p['pid'],signal.SIGTERM);r['signalsSent'].append('SIGTERM exact owned detached '+str(p['pid']))
    except ProcessLookupError:pass
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);r['signalsSent'].append('SIGKILL owned group');child.wait(timeout=10)
  r['remainingOwnedChildren']=group(child.pid);r['remainingOwnedDetached']=track(child.pid)
 else:r['remainingOwnedChildren']=[];r['remainingOwnedDetached']=[]
 r['naturalClosure']=child is not None and not r['signalsSent'] and not r['remainingOwnedChildren'] and not r['remainingOwnedDetached']
 if not r['naturalClosure']:r.update({'status':'FAIL','exitCode':1})
 r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(r['exitCode'])
