from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,termios,time,signal
ROOT=Path('/tmp/G01-source-queue-audit-20261009');PRIVATE=Path('/dev/shm/G01-private-remaining-issue-20261009');OUT=PRIVATE/'official-current32a-first';ORIGINAL=Path('/dev/shm/G01-current-functional-milestone-first-controller-20261009.py');SOURCE='32a10dd94565acbfe7d7f42b5f5ebbef9a57a9ce';RUN='37941524593';JOB='113856832232';READER=ROOT/'jobs/G01-dominoes/verify-worker-artifact.py';NATIVE=PRIVATE/'original32a-native-full.log';ARTIFACT=int(sys.argv[1]);EXPECTED_BYTES=int(sys.argv[2]);EXPECTED_SHA=sys.argv[3];ZIP=OUT/'whole-original-official.zip';RECEIPT=PRIVATE/'official-current32a-first-CLOSED.json';LOG=OUT/'unchanged-reader-native.log'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
scope={'__file__':str(ORIGINAL)};program=ORIGINAL.read_text().split("r={'schema':'g01-current-functional-milestone-controller/1'")[0];exec(compile(program,str(ORIGINAL),'exec'),scope);scope['HEAD']=SOURCE;scope['__file__']=__file__;scope['HELPER']=ORIGINAL;snapshot=scope['snapshot'];track=scope['track'];group=scope['group'];alias=scope['alias']
def freeze():
 result=snapshot();additional=[NATIVE,ZIP]
 installed=Path(result['installedRoot'])
 # Guard the actual candidate importer aliases as well as the pinned target
 # tree. These are fresh before/after witnesses for this reader invocation,
 # not retrospective importer guards for the prior local node suite.
 for prefix in [ROOT/'node_modules',ROOT/'jobs/G01-dominoes/node_modules']:
  assert prefix.resolve(strict=True)==installed.resolve(strict=True)
  for path in installed.rglob('*'):
   if path.is_file():additional.append(prefix/path.relative_to(installed))
 result['additionalActualInputs']={str(p):alias(p) for p in additional};return result
r={'schema':'g01-current-original-official-whole-first-acceptance/1','startedUtc':stamp(),'source':SOURCE,'run':RUN,'job':JOB,'artifactId':ARTIFACT,'expectedBytes':EXPECTED_BYTES,'expectedSha256':EXPECTED_SHA,'scope':'First whole official exact32a original artifact, unchanged6a33 whole native/source/privacy/Worker/600interval/602timestamp/36VP9 decoder reader. No local browser/native FPS retry; no historical PASS substitution. Fresh actual candidate importer alias witnesses apply only to this reader invocation.','signalsSent':[],'wholeBoundSeconds':240};child=None;signed=None;deadline=time.monotonic()+240
try:
 assert not OUT.exists() and not RECEIPT.exists();OUT.mkdir();assert READER.read_bytes()==subprocess.check_output(['git','show',SOURCE+':jobs/G01-dominoes/verify-worker-artifact.py'],cwd=ROOT);assert hashlib.sha256(READER.read_bytes()).hexdigest()=='6a33c711fd5d3d17e34c714d0021cf6612783003dc23655c922800cb5fb57106'
 native=NATIVE.read_bytes();assert native and 'SHA256 digest of uploaded artifact zip is '+EXPECTED_SHA in native.decode();r['nativeFullLog']={'bytes':len(native),'sha256':hashlib.sha256(native).hexdigest()}
 attributes=termios.tcgetattr(sys.stdin);private=attributes.copy();private[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,private);print('PRIVATE_STDIN_READY',flush=True);signed=sys.stdin.readline().strip();assert signed.startswith('https://');config='url = "'+signed.replace('\\','\\\\').replace('"','\\"')+'"\n';r['transportStartedUtc']=stamp()
 transport=subprocess.run(['curl','--config','-','--fail','--silent','--show-error','--location','--retry','0','--connect-timeout','15','--max-time','60','--max-filesize',str(EXPECTED_BYTES),'--output',str(ZIP)],input=config.encode(),capture_output=True,timeout=70)
 r['transportExitCode']=transport.returncode;r['transportClosedUtc']=stamp();r['transportStderr']=transport.stderr.decode(errors='replace').replace(signed,'[redacted signed official artifact URL]');assert transport.returncode==0,'Actual official artifact transfer failure';del config;signed=None
 assert ZIP.stat().st_size==EXPECTED_BYTES and hashlib.sha256(ZIP.read_bytes()).hexdigest()==EXPECTED_SHA;r['wholeOfficialMetadataDigestPass']=True
 before=freeze();(OUT/'complete-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');assert time.monotonic()<deadline,'Whole reader controller pre-child deadline exceeded'
 args=[sys.executable,str(READER),str(ZIP),'--sha256',EXPECTED_SHA,'--source',SOURCE,'--run',RUN,'--repo',str(ROOT),'--native-log',str(NATIVE)];r['unchangedReaderArgv']=args
 with LOG.open('xb') as log:
  child=subprocess.Popen(args,cwd=ROOT/'jobs/G01-dominoes',env=dict(os.environ,TMPDIR=str(OUT),PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['childPid']=child.pid;r['childStartedUtc']=stamp()
  while child.poll() is None:
   track(child.pid)
   if time.monotonic()>=deadline:raise subprocess.TimeoutExpired(args,240)
   time.sleep(.1)
  r['childClosedUtc']=stamp();r['childExitCode']=child.returncode
 after=freeze();(OUT/'complete-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Complete original/source/installed/runtime/ZIP/native input drift';r['allFrozenInputsUnchanged']=True;r['frozenAliasCount']=len(before['aliases'])+len(before['additionalActualInputs']);r['sourceFiles']=before['sourceFiles'];assert child.returncode==0,'Unchanged whole original reader genuinely failed'
 result=json.loads(LOG.read_text());assert result['status']=='PASS' and result['source']==SOURCE and result['run']==RUN and result['artifactSha256']==EXPECTED_SHA;assert result['rawIntervals']==600 and result['timestampWitnesses']==602 and result['actualDecodedFrames']==36 and result['realWorkerReplayCases']==16 and result['realWorkerVariants']==5 and result['actualDiskNavigation']=='PASS';r['actualIndependentAcceptance']=result;r['status']='PASS';r['exitCode']=0
except BaseException as e:
 message=str(e)
 if signed:message=message.replace(signed,'[redacted signed official artifact URL]')
 r.update({'status':'FAIL','exitCode':1,'errorType':type(e).__name__,'error':message})
finally:
 if child is not None:
  live=track(child.pid)
  if child.poll() is None or live:
   try:os.killpg(child.pid,signal.SIGTERM);r['signalsSent'].append('SIGTERM owned group')
   except ProcessLookupError:pass
   for p in live:
    try:os.kill(p['pid'],signal.SIGTERM);r['signalsSent'].append('SIGTERM owned detached '+str(p['pid']))
    except ProcessLookupError:pass
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);r['signalsSent'].append('SIGKILL owned group');child.wait(timeout=10)
  r['remainingOwnedChildren']=group(child.pid);r['remainingOwnedDetached']=track(child.pid)
 else:r['remainingOwnedChildren']=[];r['remainingOwnedDetached']=[]
 r['naturalClosure']=child is not None and not r['signalsSent'] and not r['remainingOwnedChildren'] and not r['remainingOwnedDetached']
 if r.get('status')=='PASS' and not r['naturalClosure']:r.update({'status':'FAIL','exitCode':1})
 if LOG.exists():r['completeReaderNativeLog']={'bytes':LOG.stat().st_size,'sha256':hashlib.sha256(LOG.read_bytes()).hexdigest()}
 r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='actualIndependentAcceptance'}|{'actualIndependentAcceptance':({k:v for k,v in r.get('actualIndependentAcceptance',{}).items() if k!='independentDecoderTools'})}),flush=True)
raise SystemExit(r['exitCode'])
