from pathlib import Path
import datetime,json,os,shutil,subprocess,time,signal
ROOT=Path('/tmp/G01-source-queue-audit-20261009');OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');ORIGINAL=Path('/dev/shm/G01-current-functional-milestone-first-controller-20261009.py');HELPER=Path('/dev/shm/G01-postgreen-idle-departure-first-20261009.mjs');HEAD='32a10dd94565acbfe7d7f42b5f5ebbef9a57a9ce';LOG=OUT/'postgreen-idle-departure-first-native.log';RECEIPT=OUT/'postgreen-idle-departure-first-CLOSED.json'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
scope={'__file__':str(ORIGINAL)};program=ORIGINAL.read_text().split("r={'schema':'g01-current-functional-milestone-controller/1'")[0];exec(compile(program,str(ORIGINAL),'exec'),scope);scope.update({'HEAD':HEAD,'__file__':__file__,'HELPER':HELPER});snapshot=scope['snapshot'];track=scope['track'];group=scope['group'];alias=scope['alias']
def freeze():
 r=snapshot();paths=[ORIGINAL];installed=Path(r['installedRoot'])
 for prefix in [ROOT/'node_modules',ROOT/'jobs/G01-dominoes/node_modules']:
  assert prefix.resolve(strict=True)==installed.resolve(strict=True)
  paths.extend(prefix/p.relative_to(installed) for p in installed.rglob('*') if p.is_file())
 r['actualImporterAliases']={str(p):alias(p) for p in paths};return r
r={'schema':'g01-postgreen-idle-departure-first-controller/1','startedUtc':stamp(),'source':HEAD,'scope':'First measured review investigation after whole current original green; native child failure is preserved as a real product-policy rejection, never a PASS/no-gain round.','wholeBoundSeconds':90,'signalsSent':[]};child=None
try:
 assert not RECEIPT.exists() and not LOG.exists();before=freeze();(OUT/'postgreen-idle-departure-first-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
 with LOG.open('xb') as log:child=subprocess.Popen([shutil.which('node'),str(HELPER)],cwd=ROOT/'jobs/G01-dominoes',env=dict(os.environ,TMPDIR=str(OUT)),stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['childPid']=child.pid;r['childStartedUtc']=stamp();deadline=time.monotonic()+90
 while child.poll() is None:
  track(child.pid)
  if time.monotonic()>=deadline:raise subprocess.TimeoutExpired(child.args,90)
  time.sleep(.1)
 r['childClosedUtc']=stamp();r['childExitCode']=child.returncode;after=freeze();(OUT/'postgreen-idle-departure-first-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Frozen input drift';r['allFrozenInputsUnchanged']=True;r['frozenAliasCount']=len(before['aliases'])+len(before['actualImporterAliases']);result=json.loads((OUT/'postgreen-idle-departure-first.json').read_text());r['actualReport']={k:v for k,v in result.items() if k not in ['rows','failures']};r['failureCount']=len(result['failures']);r['firstFailure']=result['failures'][0] if result['failures'] else None;r['status']='CLOSED_FAILURE' if child.returncode else 'PASS';r['exitCode']=child.returncode
except BaseException as e:r.update({'status':'CONTROLLER_FAILURE','exitCode':1,'errorType':type(e).__name__,'error':str(e)})
finally:
 if child is not None:
  live=track(child.pid)
  if child.poll() is None or live:
   try:os.killpg(child.pid,signal.SIGTERM);r['signalsSent'].append('SIGTERM owned group')
   except ProcessLookupError:pass
   for p in live:
    try:os.kill(p['pid'],signal.SIGTERM);r['signalsSent'].append('SIGTERM owned detached '+str(p['pid']))
    except ProcessLookupError:pass
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);r['signalsSent'].append('SIGKILL owned group');child.wait(timeout=10)
  r['remainingOwnedChildren']=group(child.pid);r['remainingOwnedDetached']=track(child.pid)
 else:r['remainingOwnedChildren']=[];r['remainingOwnedDetached']=[]
 r['naturalClosure']=child is not None and not r['signalsSent'] and not r['remainingOwnedChildren'] and not r['remainingOwnedDetached'];r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(r['exitCode'])
