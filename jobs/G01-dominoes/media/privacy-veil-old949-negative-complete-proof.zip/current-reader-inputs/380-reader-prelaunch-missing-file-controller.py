from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

PRIVATE=Path(__file__).resolve().parent
RECEIPT=PRIVATE/'380-official-ram-first-once-controller.json'
LOG=PRIVATE/'380-official-ram-first-once-controller.log'
assert not RECEIPT.exists() and not LOG.exists()
assert not (PRIVATE/'380-official-ram-first').exists()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity(p):
    data=Path(p).read_bytes();return {'path':str(Path(p).resolve()),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def live_group(pgid):
    result=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():continue
        try:
            fields=(path/'stat').read_text().rsplit(')',1)[1].split()
            if int(fields[2])==pgid and fields[0] not in ['Z','X']:result.append(int(path.name))
        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    return result
def kill_group(pgid,value):
    try:os.killpg(pgid,value)
    except ProcessLookupError:pass
scope={}
exec(compile((PRIVATE/'fresh-380-reader-inputs.py').read_bytes(),str(PRIVATE/'fresh-380-reader-inputs.py'),'exec'),scope)
fresh_before=scope['snapshot']()
fresh_path=PRIVATE/'380-official-ram-first-fresh-inputs.json'
assert not fresh_path.exists()
fresh_path.write_text(json.dumps(fresh_before,indent=2)+'\n')
loader=PRIVATE/'accept-380-official-ram-first.py'
before=identity(loader)
receipt={'schema':'g01-official-ram-once-controller/1','status':'STARTED','startedAt':now(),'loaderBefore':before,'scope':'Finite genuine full-hosted-artifact evidence reader; no browser or native timing profile launched. One RAM read, original reader unchanged.'}
with RECEIPT.open('x') as out:out.write(json.dumps(receipt,indent=2)+'\n')
process=None
try:
    with LOG.open('x') as log:
        process=subprocess.Popen([sys.executable,str(loader)],cwd=PRIVATE,env={**os.environ,'TMPDIR':'/tmp'},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        receipt['childPid']=process.pid
        process.wait(timeout=180)
        receipt['naturalClosure']=True
except BaseException as error:
    receipt['failure']={'type':type(error).__name__,'message':str(error)}
    receipt['naturalClosure']=False
finally:
    if process is not None:
        if process.poll() is None or live_group(process.pid):
            receipt['naturalClosure']=False;kill_group(process.pid,signal.SIGTERM)
        try:process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            receipt['naturalClosure']=False;kill_group(process.pid,signal.SIGKILL);process.wait(timeout=10)
        deadline=time.monotonic()+2
        while live_group(process.pid) and time.monotonic()<deadline:time.sleep(.025)
        if live_group(process.pid):
            receipt['naturalClosure']=False;kill_group(process.pid,signal.SIGKILL)
            deadline=time.monotonic()+2
            while live_group(process.pid) and time.monotonic()<deadline:time.sleep(.025)
        receipt['remainingOwnedLiveProcesses']=live_group(process.pid)
        assert receipt['remainingOwnedLiveProcesses']==[]
        receipt['childClosedAt']=now();receipt['exitCode']=process.returncode
    else:
        receipt['remainingOwnedLiveProcesses']=[];receipt['exitCode']=None
try:
    fresh_after=scope['snapshot']()
    assert fresh_after==fresh_before, 'Fresh complete source/installed/runtime/alias input drift'
    receipt['freshCompleteInputs']={'status':'PASS','manifest':identity(fresh_path),'sourceFiles':fresh_before['sourceFiles'],'installedFileAliases':fresh_before['installedFileAliases'],'pythonStandardLibraryFiles':fresh_before['pythonStandardLibraryFiles'],'allAliases':len(fresh_before['aliases'])}
except BaseException as error:
    receipt['freshCompleteInputs']={'status':'FAIL','failure':{'type':type(error).__name__,'message':str(error)}}
receipt['loaderAfter']=identity(loader)
receipt['log']=identity(LOG)
result_path=PRIVATE/'380-official-ram-first/ram-loader-receipt.json'
if result_path.exists():
    receipt['actualLoaderReceipt']=identity(result_path)
    result=json.loads(result_path.read_text());receipt['actualAcceptance']=result.get('independentAcceptance');receipt['loaderStatus']=result['status']
receipt['status']='PASS' if receipt.get('naturalClosure') and receipt['exitCode']==0 and receipt['loaderBefore']==receipt['loaderAfter'] and receipt.get('loaderStatus')=='PASS' and receipt['freshCompleteInputs']['status']=='PASS' else 'FAIL'
receipt['naturallyClosedAt']=now();RECEIPT.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:receipt[key] for key in ['status','naturallyClosedAt','exitCode','remainingOwnedLiveProcesses']}|{'checks':(receipt.get('actualAcceptance') or {}).get('checks')}))
raise SystemExit(0 if receipt['status']=='PASS' else 1)
