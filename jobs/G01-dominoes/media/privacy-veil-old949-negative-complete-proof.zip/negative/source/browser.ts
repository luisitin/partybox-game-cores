import {chromium} from 'playwright';
import {existsSync,readFileSync,mkdirSync,mkdtempSync,writeFileSync,rmSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import assert from 'node:assert/strict';
import {evidence,bindBrowser,saveEvidence,beginEncoding,finishEncoding,verifyCapture,finishEvidence} from './browser-evidence.ts';
const executable=process.env.CHROMIUM_PATH??(existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined);
const browser=await chromium.launch({headless:true,executablePath:executable,args:['--no-sandbox']});
bindBrowser(executable??chromium.executablePath(),browser.version());
mkdirSync('media',{recursive:true});const url='file://'+resolve('play.html');
const errors:string[]=[],requests:string[]=[];
const capturePath=process.env.G01_CAPTURE_PATH??'media/milestone-14-presentation.webm';
async function pageFor(viewport:{width:number;height:number},reducedMotion:'reduce'|'no-preference'='no-preference'){
 const context=await browser.newContext({viewport,reducedMotion});const page=await context.newPage();
 page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))requests.push(r.url());});
 await page.route('**/*',route=>/^https?:/.test(route.request().url())?route.abort():route.continue());
 await page.setContent(readFileSync('play.html','utf8'));return {page,context};
}
try {
 const {page,context}=await pageFor({width:390,height:844});
 await page.click('#houseRules summary');await page.selectOption('#opening','rotating');await page.selectOption('#seat-1','human');await page.click('#start');
 assert.equal(await page.locator('#hand .hand-tile').count(),0,'human hand must start hidden');
 await page.getByRole('button',{name:/reveal hand/}).click();assert.equal(await page.locator('#hand .hand-tile').count(),7);
 assert(await page.locator('#hand .hand-tile.playable').count()>0,'the opener lights playable tiles');
 await page.locator('#hand .hand-tile.playable').first().click();assert.equal(await page.locator('#hand .hand-tile').count(),0,'next player hand must stay hidden');
 assert.equal(await page.locator('#boardLayer .tile').count(),1,'the played tile lands on the table');
 assert.match(await page.locator('#status').innerText(),/Player 2/);await page.getByRole('button',{name:/reveal hand/}).click();assert.equal(await page.locator('#hand .hand-tile').count(),7);
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'phone table must not scroll sideways');
 await page.waitForTimeout(900);await page.screenshot({path:'media/phone.png',fullPage:true});await page.click('#end');assert.equal(await page.locator('#status').innerText(),'Match complete');
 await page.getByRole('button',{name:'Rematch'}).waitFor();await context.close();
 const automated=await pageFor({width:1920,height:1080});await automated.page.clock.install({time:new Date('2026-01-01T00:00:00Z')});
 await automated.page.check('#players-4');await automated.page.check('#partners');await automated.page.check('#mode-block');
 for(let i=0;i<4;i++)await automated.page.selectOption(`#seat-${i}`,'normal');await automated.page.click('#start');
 // Bots move at a watchable pace (0.82s, 1.3s to open, 4.6s between rounds), so the budget is simulated time, stepped.
 const until=async(p:typeof automated.page,limit:number)=>{let ms=0;while(ms<limit&&await p.locator('#status').innerText()!=='Match complete'){await p.clock.runFor(10000);ms+=10000;}return ms;};
 const automatedMs=await until(automated.page,1_200_000);assert.equal(await automated.page.locator('#status').innerText(),'Match complete','full browser bot match must terminate');await automated.context.close();
 const mixed=await pageFor({width:390,height:844});await mixed.page.clock.install({time:new Date('2026-01-01T00:00:00Z')});
 await mixed.page.click('#start');const mixedMs=await until(mixed.page,3_600_000);
 assert.equal(await mixed.page.locator('#status').innerText(),'Match complete','mixed idle-human/computer page must honor automatic round exits');
 assert.equal(await mixed.page.locator('#hand .hand-tile').count(),0,'automatic progression must never reveal an idle human hand');
 await mixed.context.close();
 const performanceReports=[];
 for(const [name,viewport,throttle] of [['tv',{width:1920,height:1080},1],['phone',{width:390,height:844},4]] as const){
  const {page,context}=await pageFor(viewport);const cdp=await context.newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate:throttle});
  await page.selectOption('#seat-0','sharp');await page.selectOption('#seat-1','normal');await page.click('#start');
  const measurement=await page.evaluate(()=>new Promise<{deltas:number[];timestamps:number[]}>(resolve=>{const deltas:number[]=[],timestamps:number[]=[];let previous:number|null=null;function tick(now:number){timestamps.push(now);if(previous!==null)deltas.push(now-previous);previous=now;if(deltas.length>=300)resolve({deltas,timestamps});else requestAnimationFrame(tick);}requestAnimationFrame(tick);}));
  const frames=measurement.deltas;
  const sorted=[...frames].sort((a,b)=>a-b);const mean=frames.reduce((a,b)=>a+b,0)/frames.length;
  const report={name,viewport,throttle,frames:frames.length,meanMs:mean,p95Ms:sorted[Math.floor(sorted.length*.95)],p99Ms:sorted[Math.floor(sorted.length*.99)],fps:1000/mean};performanceReports.push(report);console.log(report);
  (evidence.profiles as unknown[]).push({...report,intervals:frames,timestamps:measurement.timestamps,actualCpuThrottleRate:throttle,clockInstalled:false,passed:report.fps>=58&&report.p95Ms!<=18});saveEvidence();
  assert(report.fps>=58,`${name}: average refresh below 58fps`);assert(report.p95Ms!<=18,`${name}: p95 frame time above one refresh`);
  if(name==='tv'){
   assert(await page.evaluate(()=>document.documentElement.scrollHeight<=innerHeight),'TV match must fit its viewport');
   await page.screenshot({path:'media/tv.png',fullPage:true});const capture=mkdtempSync(join(tmpdir(),'G01-capture-'));
   for(let i=0;i<36;i++){await page.screenshot({path:join(capture,`${String(i).padStart(3,'0')}.png`)});await page.waitForTimeout(66);}
   const encoderArgs=['-y','-loglevel','error','-framerate','12','-i',join(capture,'%03d.png'),'-c:v','libvpx-vp9','-b:v','700k','-an',capturePath],encoder=beginEncoding(encoderArgs,capture);
   const encoded=spawnSync(encoder.path,encoderArgs,{encoding:'utf8'});finishEncoding(encoder,encoded.status);assert.equal(encoded.status,0,encoded.error?.message||encoded.stderr||String(encoded.signal));verifyCapture(capturePath);rmSync(capture,{recursive:true});
  }
  await context.close();
 }
 const reduced=await pageFor({width:390,height:844},'reduce');assert(await reduced.page.evaluate(()=>matchMedia('(prefers-reduced-motion: reduce)').matches));
 await reduced.page.click('#start');await reduced.page.getByRole('button',{name:/reveal hand/}).click();assert.equal(await reduced.page.locator('#hand .hand-tile').count(),7);assert.equal(await reduced.page.evaluate(()=>document.getAnimations().length),0);
 await reduced.context.close();assert.deepEqual(errors,[]);assert.deepEqual(requests,[]);
 writeFileSync('browser-report.json',JSON.stringify({functional:'passed',navigationMode:'setContent; managed Chromium blocks file:// navigation',externalRequests:requests,errors,performance:performanceReports,reducedMotion:'passed',automatedBotMatchMs:automatedMs,mixedUnattended:'passed within 3600000ms with private hands hidden',mixedUnattendedMs:mixedMs,capture:capturePath},null,2)+'\n');
 console.log('Browser functional, hot-seat privacy, offline, frame-time and reduced-motion checks pass');
 evidence.functional='PASS';evidence.externalRequests=requests;evidence.errors=errors;finishEvidence('PASS');
} catch(error){evidence.externalRequests=requests;evidence.errors=errors;finishEvidence('FAIL',error);throw error;} finally {await browser.close();evidence.browserClosedAt=new Date().toISOString();saveEvidence();}
