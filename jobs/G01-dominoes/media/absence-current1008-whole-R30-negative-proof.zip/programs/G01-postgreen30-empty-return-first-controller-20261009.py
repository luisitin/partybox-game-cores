from pathlib import Path
import datetime,json,subprocess,os,sys,time,signal
BASE=Path('/dev/shm/G01-current-functional-milestone-first-controller-20261009.py');ROOT=Path('/tmp/G01-source-queue-audit-20261009');OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');HELPER=Path('/dev/shm/G01-postgreen30-empty-return-first-negative-20261009.mjs');HEAD='1008f1339af49b1d1eaf14d8862e7206df5a3d3f';PREFIX='review30-empty-return-first';LOG=OUT/(PREFIX+'-native.log');RECEIPT=OUT/(PREFIX+'-CLOSED.json')
scope={'__file__':str(BASE)};exec(compile(BASE.read_text().split("r={'schema':'g01-current-functional-milestone-controller/1'")[0],str(BASE),'exec'),scope);scope.update(ROOT=ROOT,OUT=OUT,HELPER=HELPER,HEAD=HEAD,__file__=__file__)
snapshot=scope['snapshot'];alias=scope['alias'];track=scope['track'];group=scope['group']
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def freeze():
 s=snapshot();s['actualCandidateImporterAliases']={str(p):alias(p) for prefix in [ROOT/'node_modules',ROOT/'jobs/G01-dominoes/node_modules'] for p in prefix.rglob('*') if p.is_file()};s['additionalInputs']={str(p):alias(p) for p in [BASE,OUT/'postgreen-idle-departure-first.json',OUT/'official-current1008-first-CLOSED.json',OUT/'original1008-native-full.log',OUT/'official-current1008-first/whole-original-official.zip']};return s
r={'schema':'g01-review30-first-empty-return-negative-controller/1','startedAt':stamp(),'source':HEAD,'scope':'Actual first postgreen formal review30 investigation only, genuine intentional failing controls; no production repair/player-gain/noGain/Ready credit. No local native sampler or browser.','rankedFive':['First live human returns to empty full-idle room before/after expired old timer or while paused','Paused first-human return must preserve board and get a full live clock only on resume','Invalid/duplicate presence and stale timers must retain identity/connected compatibility','Historical Strong responsiveness gain remains unmeasured and unchanged retries prohibited','Physical-phone and finite upstream strength scope remain limited'],'signalsSent':[],'wholeBoundSeconds':120};child=None;deadline=time.monotonic()+120
try:
 assert not RECEIPT.exists() and not LOG.exists();before=freeze();(OUT/(PREFIX+'-inputs-before.json')).write_text(json.dumps(before,indent=2)+'\n')
 with LOG.open('xb') as log:
  child=subprocess.Popen([scope['shutil'].which('node'),str(HELPER)],cwd=ROOT/'jobs/G01-dominoes',env=dict(os.environ,TMPDIR=str(OUT),PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r.update(childPid=child.pid,childStartedAt=stamp())
  while child.poll() is None:
   track(child.pid)
   if time.monotonic()>=deadline:raise subprocess.TimeoutExpired(child.args,120)
   time.sleep(.1)
  r.update(childClosedAt=stamp(),childExitCode=child.returncode)
 after=freeze();(OUT/(PREFIX+'-inputs-after.json')).write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Actual input drift';r.update(allFrozenInputsUnchanged=True,frozenAliases=len(before['aliases'])+len(before['actualCandidateImporterAliases'])+len(before['additionalInputs']))
 report=json.loads((OUT/(PREFIX+'-negative.json')).read_text());r['actualFirstReport']={k:v for k,v in report.items() if k not in ['rows','failures']};r['actualFailureCount']=len(report['failures']);assert report['status']=='FAIL_CURRENT_POLICY' and report['cases']==1440 and child.returncode==1,'Expected actual bounded policy failure not established';r.update(status='FAIL_CURRENT_POLICY',exitCode=1)
except BaseException as e:r.update(status='FAIL_UNEXPECTED',exitCode=1,errorType=type(e).__name__,error=str(e))
finally:
 if child is not None:
  live=track(child.pid)
  if child.poll() is None or live:
   try:os.killpg(child.pid,signal.SIGTERM);r['signalsSent'].append('SIGTERM owned group')
   except ProcessLookupError:pass
   for p in live:
    try:os.kill(p['pid'],signal.SIGTERM);r['signalsSent'].append('SIGTERM owned detached '+str(p['pid']))
    except ProcessLookupError:pass
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);r['signalsSent'].append('SIGKILL owned group');child.wait(timeout=10)
  r['remainingOwnedChildren']=group(child.pid);r['remainingOwnedDetached']=track(child.pid)
 else:r['remainingOwnedChildren']=[];r['remainingOwnedDetached']=[]
 r['naturalClosure']=child is not None and not r['signalsSent'] and not r['remainingOwnedChildren'] and not r['remainingOwnedDetached'];r['closedAt']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(r['exitCode'])
