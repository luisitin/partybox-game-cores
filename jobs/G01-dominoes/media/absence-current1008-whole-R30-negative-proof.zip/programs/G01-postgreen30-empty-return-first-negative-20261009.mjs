import * as C from '/tmp/G01-source-queue-audit-20261009/jobs/G01-dominoes/core.ts';
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
const OUT='/dev/shm/G01-private-remaining-issue-20261009',old=JSON.parse(readFileSync(OUT+'/postgreen-idle-departure-first.json','utf8'));
const r={schema:'g01-review30-first-empty-room-return-negative/1',source:'1008f1339af49b1d1eaf14d8862e7206df5a3d3f',startedAt:new Date().toISOString(),status:'STARTED',cases:0,failures:[],rows:[],fullyConnectedOriginalStateMatches:0,pausedOtherSeatControls:0,physicalMetadataControls:0,requiredFirstHumanWindowMs:30000,scope:'First actual deterministic legal-event test after whole1008 green: first live seat returns to an empty full-idle room, before/after old deadline and while paused. No clock/FPS/performance trial or new production edits.'};
const save=()=>writeFileSync(OUT+'/review30-empty-return-first-negative.json',JSON.stringify(r,null,2)+'\n');save();
const freeze=s=>{if(s&&typeof s==='object'){Object.freeze(s);for(const v of Object.values(s))freeze(v);}return s;};
const physical=s=>{const {idleTurns,phase,...rest}=s;return {...rest,phase:{...phase,startedAt:null,deadline:null,paused:null}};};
try{
 assert.equal(old.rows.length,240);
 for(const row of old.rows){
  let s=C.init(row.context);for(const e of row.events){s=C.reduce(freeze(s),e);r.fullyConnectedOriginalStateMatches++;}assert.deepEqual(s,row.idleState);assert.equal(s.phase.deadline-s.phase.startedAt,1000);assert.equal(s.idleTurns,s.seats.length);const active=s.seats[s.turn],other=s.seats[(s.turn+1)%s.seats.length],base=s.phase.startedAt;
  const out={context:row.context,originalEvents:row.events,idleState:s,scenarios:[]};r.rows.push(out);
  for(const dt of [20,5000])for(const id of [active,other]){
   let empty=s;const events=[];for(const seat of [...s.seats.filter(x=>x!==active),active]){const e={type:'player',playerId:seat,connected:false,now:base+2};events.push(e);empty=C.reduce(freeze(empty),e);}assert(!empty.seats.some(id=>empty.players[id].connected));assert.deepEqual(physical(empty),physical(s));r.physicalMetadataControls++;
   const e={type:'player',playerId:id,connected:true,now:base+dt},got=C.reduce(freeze(empty),e);assert.equal(got.phase.id,'play');assert(got.players[got.seats[got.turn]].connected);assert(!got.phase.paused);const ms=got.phase.deadline-e.now;const scenario={name:(id===active?'active':'other')+'-first-return-'+(dt===20?'before':'after')+'-old-deadline',events:[...events,e],emptyState:empty,returnedState:got,actualRemainingMs:ms,requiredRemainingMs:30000};out.scenarios.push(scenario);r.cases++;if(ms!==30000)r.failures.push({case:r.cases,n:s.seats.length,seed:row.context.seed,name:scenario.name,actualRemainingMs:ms,requiredRemainingMs:30000});
  }
  for(const id of [active,other]){
   const pause={type:'vip',action:'pause',now:base+1};let empty=C.reduce(freeze(s),pause);const events=[pause];for(const seat of s.seats){const e={type:'player',playerId:seat,connected:false,now:base+2};events.push(e);empty=C.reduce(freeze(empty),e);}assert(!empty.seats.some(id=>empty.players[id].connected));assert(empty.phase.paused);
   const join={type:'player',playerId:id,connected:true,now:base+12};const joined=C.reduce(freeze(empty),join);assert(joined.phase.paused);assert.deepEqual(physical(joined),physical(empty));r.physicalMetadataControls++;const resume={type:'vip',action:'resume',now:base+200},got=C.reduce(freeze(joined),resume);assert.equal(got.phase.id,'play');assert(got.players[got.seats[got.turn]].connected);assert(!got.phase.paused);const ms=got.phase.deadline-resume.now;const scenario={name:(id===active?'active':'other')+'-first-return-while-paused',events:[...events,join,resume],emptyState:empty,joinedState:joined,resumedState:got,actualRemainingMs:ms,requiredRemainingMs:30000};out.scenarios.push(scenario);r.cases++;if(ms!==30000)r.failures.push({case:r.cases,n:s.seats.length,seed:row.context.seed,name:scenario.name,actualRemainingMs:ms,requiredRemainingMs:30000});else r.pausedOtherSeatControls++;
  }
 }
 assert.equal(r.cases,1440);r.status=r.failures.length?'FAIL_CURRENT_POLICY':'PASS';r.closedAt=new Date().toISOString();save();console.log(JSON.stringify({...r,rows:undefined,failures:undefined,failureCount:r.failures.length,remainingValueCounts:r.failures.reduce((a,x)=>(a[x.actualRemainingMs]=(a[x.actualRemainingMs]||0)+1,a),{})}));assert.equal(r.failures.length,0,'A first returning live human did not receive the required full30-second decision window');
}catch(e){r.nativeFailure={name:e.name,message:e.message,stack:e.stack};r.closedAt=new Date().toISOString();if(r.status==='STARTED')r.status='FAIL_UNEXPECTED';save();throw e;}
