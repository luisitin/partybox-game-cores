from pathlib import Path
import datetime,hashlib,json,os,re,shutil,signal,subprocess,sys,sysconfig,time
ROOT=Path('/tmp/G01-source-queue-audit-20261009');OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');HELPER=Path('/dev/shm/G01-current-functional-milestone-first-20261009.mjs');HEAD='9facc82d4c88126e6b028e8e8c18ae4637a72d75';INSTALLED=Path('/workspace/game-cores-G01-queue-audit-20261008/jobs/G01-dominoes/node_modules');LOG=OUT/'current-functional-first-native.log';RECEIPT=OUT/'current-functional-first-CLOSED.json'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def stat(p):
 s=p.lstat();return {k:getattr(s,k) for k in ['st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns']}
def alias(p):
 p=Path(os.path.abspath(p));real=p.resolve(strict=True);data=p.read_bytes();chain=[];cursor=Path('/');pending=list(p.parts[1:])
 while pending:
  part=pending.pop(0)
  if part=='.':continue
  if part=='..':cursor=cursor.parent;continue
  cursor=cursor/part
  if cursor.is_symlink():
   target=os.readlink(cursor);chain.append({'path':str(cursor),'target':target,'stat':stat(cursor)});assert len(chain)<=100
   pending=list(Path(target).parts[1:] if os.path.isabs(target) else Path(target).parts)+pending;cursor=Path('/') if os.path.isabs(target) else cursor.parent
 assert cursor==real
 return {'realPath':str(real),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'entryStat':stat(p),'targetStat':stat(real),'symlinkChain':chain}
def snapshot():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
 names=subprocess.check_output(['git','ls-tree','-r','--name-only',HEAD,'--','jobs/G01-dominoes','contract','.github/workflows/G01.yml','README.md','RULES.md','JOBS.md'],cwd=ROOT,text=True).splitlines();paths=set()
 for name in names:
  p=ROOT/name;assert p.is_file() and not p.is_symlink();assert p.read_bytes()==subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT);paths.add(p)
 inventory={};installedAliases=0
 for p in INSTALLED.rglob('*'):
  inventory[str(p.relative_to(INSTALLED))]={'stat':stat(p),'target':os.readlink(p) if p.is_symlink() else None}
  if p.is_file():paths.add(p);installedAliases+=1
 for p in Path('/usr/lib/chromium').rglob('*'):
  if p.is_file():paths.add(p)
 standard=[]
 for p in Path(sysconfig.get_path('stdlib')).rglob('*'):
  if 'site-packages' not in p.parts and p.is_file():paths.add(p);standard.append(p)
 for m in list(sys.modules.values()):
  for key in ['__file__','__cached__']:
   p=getattr(m,key,None)
   if p and Path(p).is_file():paths.add(Path(p))
 for folder in [Path(sysconfig.get_path('purelib')),Path(sysconfig.get_path('platlib'))]:
  if folder.is_dir():paths.update(folder.glob('*.pth'))
 binaries=[Path(sys.executable),Path(shutil.which('node')),Path(shutil.which('git')),Path('/usr/bin/chromium'),Path('/usr/lib/chromium/chromium'),Path('/usr/lib/chromium/chrome_crashpad_handler'),Path(shutil.which('ffmpeg')),Path(shutil.which('ffprobe'))]
 for p in binaries:
  paths.add(p);native=subprocess.run(['ldd',str(p.resolve())],capture_output=True,text=True)
  for n in re.findall(r'(/[A-Za-z0-9_./+\-]+)',native.stdout):
   if Path(n).is_file():paths.add(Path(n))
 paths.update([HELPER,Path(__file__)]);return {'head':HEAD,'sourceFiles':len(names),'installedRoot':str(INSTALLED),'installedInventory':inventory,'installedAliases':installedAliases,'pythonStandardLibraryFiles':len(standard),'aliases':{str(p):alias(p) for p in sorted(paths)}}
def group(pid):
 result=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   f=(p/'stat').read_text().rsplit(')',1)[1].split()
   if int(f[2])==pid and f[0] not in ['Z','X']:result.append(int(p.name))
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return result
def processes():
 result={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   f=(p/'stat').read_text().rsplit(')',1)[1].split();result[int(p.name)]={'ppid':int(f[1]),'pgid':int(f[2]),'startTicks':f[19],'state':f[0]}
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return result
owned={}
def track(pid):
 ps=processes();selected={pid}
 for p,v in owned.items():
  if p in ps and ps[p]['startTicks']==v['startTicks']:selected.add(p)
 changed=True
 while changed:
  changed=False
  for p,v in ps.items():
   if v['ppid'] in selected and p not in selected:selected.add(p);changed=True
 for p in selected:
  if p in ps:owned[p]=ps[p]
 return [{'pid':p,**ps[p]} for p,v in owned.items() if p in ps and ps[p]['startTicks']==v['startTicks'] and ps[p]['state'] not in ['Z','X']]
r={'schema':'g01-current-functional-milestone-controller/1','startedUtc':stamp(),'source':HEAD,'wholeBoundSeconds':180,'scope':'First current-source native functional visual milestone only; no FPS sampler/clock alteration. Whole source/installed/Python/browser/runtime aliases frozen before and after.','signalsSent':[]};child=None
try:
 assert not RECEIPT.exists() and not LOG.exists() and not (OUT/'current-functional-first').exists()
 before=snapshot();(OUT/'current-functional-first-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
 with LOG.open('xb') as log:
  child=subprocess.Popen([shutil.which('node'),str(HELPER)],cwd=ROOT/'jobs/G01-dominoes',env=dict(os.environ,TMPDIR=str(OUT)),stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['childPid']=child.pid;r['childStartedUtc']=stamp()
  deadline=time.monotonic()+180
  while child.poll() is None:
   track(child.pid)
   if time.monotonic()>=deadline:raise subprocess.TimeoutExpired(child.args,180)
   time.sleep(.1)
  r['childClosedUtc']=stamp();r['childExitCode']=child.returncode
 after=snapshot();(OUT/'current-functional-first-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Frozen input drift';r['allFrozenInputsUnchanged']=True;r['frozenAliasCount']=len(before['aliases']);r['sourceFiles']=before['sourceFiles'];r['installedAliases']=before['installedAliases'];r['pythonStandardLibraryFiles']=before['pythonStandardLibraryFiles']
 result=json.loads((OUT/'current-functional-first/report.json').read_text());assert child.returncode==0 and result['status']=='PASS';r['actualReport']={'status':result['status'],'cases':[{k:v for k,v in c.items() if k!='steps'} for c in result['cases']]};r['status']='PASS';r['exitCode']=0
except BaseException as e:r.update({'status':'FAIL','exitCode':1,'errorType':type(e).__name__,'error':str(e)})
finally:
 if child is not None:
  if child.poll() is None or group(child.pid):
   try:os.killpg(child.pid,signal.SIGTERM);r['signalsSent'].append('SIGTERM owned group')
   except ProcessLookupError:pass
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);r['signalsSent'].append('SIGKILL owned group');child.wait(timeout=10)
  detached=track(child.pid)
  if detached:
   for proc in detached:
    try:os.kill(proc['pid'],signal.SIGTERM);r['signalsSent'].append('SIGTERM exact owned detached '+str(proc['pid']))
    except ProcessLookupError:pass
   deadline=time.monotonic()+2
   while track(child.pid) and time.monotonic()<deadline:time.sleep(.05)
  r['remainingOwnedChildren']=group(child.pid);r['remainingOwnedDetached']=track(child.pid);r['ownedProcessWitnesses']=[{'pid':p,**v} for p,v in owned.items()]
 else:r['remainingOwnedChildren']=[]
 r['naturalClosure']=child is not None and not r['signalsSent'] and not r['remainingOwnedChildren'] and not r.get('remainingOwnedDetached')
 if not r['naturalClosure']:r.update({'status':'FAIL','exitCode':1})
 r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(r['exitCode'])
