from pathlib import Path, PurePosixPath
import hashlib,json,datetime,subprocess,zipfile,stat
ROOT=Path('/tmp/G01-source-queue-audit-20261009'); JOB=ROOT/'jobs/G01-dominoes'; OUT=Path('/dev/shm/G01-private-remaining-issue-20261009')
PARENT='1008f1339af49b1d1eaf14d8862e7206df5a3d3f'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def load(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==PARENT
accepted=load(OUT/'official-current1008-first-CLOSED.json'); negative=load(OUT/'review30-empty-return-minimum-window-CLOSED.json'); observations=load(OUT/'review30-empty-return-minimum-window-negative.json')
assert accepted['status']=='PASS' and accepted['naturalClosure'] and accepted['allFrozenInputsUnchanged'] and accepted['actualIndependentAcceptance']['checks']==1360
assert accepted['source']==PARENT and accepted['expectedBytes']==174562700 and accepted['expectedSha256']=='a2f7094b1ae1464d4f2271423ffa9338b220a95dddc259faf764f578cbfb8ffb'
for receipt in [accepted,negative]:assert receipt['naturalClosure'] and not receipt['signalsSent'] and not receipt['remainingOwnedChildren'] and not receipt['remainingOwnedDetached']
assert negative['status']=='FAIL_CURRENT_POLICY' and negative['actualFailureCount']==1200 and negative['allFrozenInputsUnchanged'] and observations['cases']==1440 and len(observations['failures'])==1200
assert observations['fullyConnectedOriginalStateMatches']==780 and observations['physicalMetadataControls']==1440 and observations['pausedOtherSeatControls']==240
assert identity(OUT/'original1008-native-full.log')==accepted['nativeFullLog']
official=OUT/'official-current1008-first/whole-original-official.zip'; assert identity(official)=={'bytes':accepted['expectedBytes'],'sha256':accepted['expectedSha256']}
immutable=['core.ts','ui.ts','play.html','browser.ts','package.json','package-lock.json','total-compatibility.ts','study-total-baseline.ts','study-presence-baseline.ts','verify-worker-artifact.py','worker-browser-check.ts','disk-browser-check.ts','privacy-veil-check.ts','absence-presence.test.ts']
before={name:(JOB/name).read_bytes() for name in immutable}; members={}
def include(name,p):
 assert name not in members and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and '\\' not in name and p.is_file() and not p.is_symlink();members[name]=p.read_bytes()
with zipfile.ZipFile(official) as z:
 assert len(z.namelist())==len(set(z.namelist())) and z.testzip() is None
 for entry in z.infolist():assert not PurePosixPath(entry.filename).is_absolute() and '..' not in PurePosixPath(entry.filename).parts and '\\' not in entry.filename and not stat.S_ISLNK(entry.external_attr>>16)
 start=json.loads(z.read('ci-start.json')); finish=json.loads(z.read('ci-finish.json')); browser=json.loads(z.read('browser-current.json'))
 assert finish['status']=='PASS' and finish['npmTestExitCode']==0 and PARENT in [start['checkoutHead'],*start['checkoutParents']]
 for name in z.namelist():
  if '/' not in name and not name.endswith('/'):members['official-first-raw/'+name]=z.read(name)
 for name in start['mutableOutputPaths']:
  raw=z.read('after/'+name); assert finish['filesAfter'][name]=={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};members['official-first-after/'+name]=raw
  if not name.endswith('/SHA256SUMS.txt'):(ROOT/name).write_bytes(raw)
 capture=z.read('current-capture.webm'); clip=JOB/'media/milestone-22-current1008-hosted.webm';clip.write_bytes(capture)
 assert identity(clip)=={k:browser['capture']['file'][k] for k in ['bytes','sha256']} and len(capture)<10000000
for name,raw in before.items():assert (JOB/name).read_bytes()==raw==subprocess.check_output(['git','show',PARENT+':jobs/G01-dominoes/'+name],cwd=ROOT),name
for name in ['official-current1008-first-CLOSED.json','original1008-native-full.log','idle-handoff-review29-source-publication-CLOSED.json','idle-handoff-review29-source-publication-native.log','main-after-review29-1008-CLOSED.json']:
 include('actual/'+name,OUT/name)
for prefix in ['review30-empty-return-first','review30-empty-return-declared-metadata','review30-empty-return-minimum-window']:
 for suffix in ['inputs-before.json','inputs-after.json','native.log','CLOSED.json','negative.json']:include('actual/'+prefix+'-'+suffix,OUT/(prefix+'-'+suffix))
for name in ['complete-inputs-before.json','complete-inputs-after.json','unchanged-reader-native.log']:include('actual/official-current1008-first/'+name,OUT/'official-current1008-first'/name)
for name in ['G01-current1008-official-whole-first-acceptance-20261009.py','G01-postgreen30-empty-return-first-negative-20261009.mjs','G01-postgreen30-empty-return-first-controller-20261009.py','G01-postgreen30-empty-return-declared-metadata-negative-20261009.mjs','G01-postgreen30-empty-return-declared-metadata-controller-20261009.py','G01-postgreen30-empty-return-minimum-window-negative-20261009.mjs','G01-postgreen30-empty-return-minimum-window-controller-20261009.py','G01-current-functional-milestone-first-controller-20261009.py','G01-current1008-whole-R30-negative-checkpoint-prepare-20261009.py']:include('programs/'+name,Path('/dev/shm')/name)
include('programs/unchanged-full-reader.py',JOB/'verify-worker-artifact.py')
archive=JOB/'media/absence-current1008-whole-R30-negative-proof.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,raw in sorted(members.items()):
  entry=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,raw)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 for name,raw in members.items():assert z.read(name)==raw
prepared=stamp(); past=max(0,(datetime.datetime.fromisoformat(prepared)-datetime.datetime.fromisoformat('2026-10-09T15:42:00.273216+00:00')).total_seconds())
report={'schema':'g01-current1008-whole-and-review30-empty-return-negative/1','preparedUtc':prepared,'sourceParent':PARENT,'originalWholeAcceptance':accepted,'actualCurrentProfiles':[{k:p[k] for k in ['name','viewport','throttle','fps','meanMs','p95Ms','p99Ms']} for p in browser['profiles']],'currentClip':{'path':str(clip.relative_to(JOB)),**identity(clip),'scope':'Genuine first original1008 official36-frame VP9 capture; unchanged full reader decoded every frame. Export frame rate is separate from native refresh.'},'firstPostGreenNegative':negative,'rankedFive':negative['rankedFive'],'firstHelperFailures':[load(OUT/'review30-empty-return-first-CLOSED.json'),load(OUT/'review30-empty-return-declared-metadata-CLOSED.json')],'qualifiedRepair':'R29 explicit departure/resume full30s window qualified by genuine full original1008; noGain0.','review30':'Incomplete: first returning live human in an empty full-idle room has1200 too-short windows in1440 legal cases. Preserve all states/events and genuine failures. Six above30s windows are harmless, not counted as failures; the earlier exact-equality diagnostic remains immutable.','consecutiveNoPlayerGain':0,'newCheckpointWholeQualification':'Pending newest exact-head original full workflow and genuine first official artifact; Draft20 stays incomplete.','fullRawProof':{'path':str(archive.relative_to(JOB)),**identity(archive),'safeUniqueMembers':len(members),'fullCrcAndEveryMemberBytePass':True},'cadence':{'lastActualSourcePush':'2026-10-09T15:12:00.273216+00:00','earlyDeadline':'2026-10-09T15:37:00.273216+00:00','hardDeadline':'2026-10-09T15:42:00.273216+00:00','actualPreparationSecondsPastHard':past,'actualPublication':'Read next actual guarded source publication receipt, never backdate.'},'scope':'Whole174562700B official archive preserved privately; public ZIP retains every top-level raw, every mutable after-output, whole native, original reader, all actual complete guards and three genuine R30 negative natives/states/events. Source/core/page/strategy/native clock/gates unchanged; no repeated local performance trial or new gain credited.'}
dump(JOB/'absence-current1008-whole-R30-negative.json',report)
prefix=f'''## Current genuine1008 whole qualification; R30 empty-room return defect remains open

Source1008 full original37949931679/job113885765277 and first whole artifact
11625469527,174562700B/a2f7094b1ae1464d4f2271423ffa9338b220a95dddc259faf764f578cbfb8ffb
PASS1360 unchanged6a33-reader checks; natural15:32:31.862717/all6575 frozen
actual aliases/source208/no signals/group+detached[]. Full native130880B/
a6f1611e82d715f2651bb4c058cfb4369eea5abfad989f9e260b2d27a880bcc4.
All57 default tests,25 actual mutant kills,600 native intervals/602 stamps,
36 fully decodedVP9 frames,16 realWorker replay/five variants/actualfile privacy
pass original gates. R29's explicit departure/resume +29s repair is qualified.
Protected Ready11 eadb/canonicalDraft1 8c stay static/unmerged; Draft20 incomplete.

After green, actual original job reread/rank5 and R30 investigation found the
next real worst issue: first live return to an empty full-idle room before/after
an old deadline or while paused. Final real1440 legal cases produce1200 windows
below required30000ms;780 connected parity/1440 physical metadata/240 paused
controls pass. Negative natural15:40:33.609564/all6578 guards/no children.
First helper falsely expected declared connected metadata unchanged and failed
before cases; next exact-equality helper also marked six harmless >30s windows.
Both genuine failures stay intact. Corrected minimum30s policy retains all1200
true failures, full states/events/raw observations. No candidate adopted yet.

NEXT: fix only first-empty-room return/full decision-clock semantics including
paused return, with stale-epoch and duplicate/ordinary metadata/fullyconnected
whole-state/physical/RNG/scoring/inactive-budget controls. Measure oldFAIL→newPASS,
add default regressions, strict rebuild and genuine changed functional capture;
log/push this separate R30 review, then full newest original qualification.
NoGain0, no R30 repair/completion/Ready credit. Subsequent reviews must each
reread/rank5/measure/log/push after green until3 true no-player-gain rounds.

This material checkpoint publishes entire1008 qualification and genuine R30
negative evidence, original36-frame capture and current mutable outputs only;
immutable runner attribution stays1008. No sampler/clock/gate/workflow change.
Last actual push15:12:00.273216; early15:37/hard15:42 genuinely missed.
Actual preparation {prepared}, {past:.6f}s past hard; actual publication is
in the next native receipt. B13 peer and restoration interruption occurred;
no retroactive cadence credit. Every prior failure/protected history retained.

## Previous checkpoints below remain historical and verbatim

'''
p=JOB/'NEXT.md';p.write_text(prefix+p.read_text())
for name,heading,body in [
 ('VERIFY.md','Genuine full1008 original qualification and R30 first negatives','Original full37949931679/job113885765277 SUCCESS and first official11625469527/174562700B/a2f7094b1ae1464d4f2271423ffa9338b220a95dddc259faf764f578cbfb8ffb: unchanged6a33 reader1360PASS/natural15:32:31.862717/all6575 fresh guards/source208/no children. All57 default tests/25 real mutants/full600interval602stamp/36VP9/16Worker5variant/actualfile privacy original gates pass. Exact full native130880B/a6f1611e82d715f2651bb4c058cfb4369eea5abfad989f9e260b2d27a880bcc4 retained. python /dev/shm/G01-postgreen30-empty-return-minimum-window-controller-20261009.py: intentional native AssertionError1;1440 real legal cases/1200 below30s failures,780 connected whole-state comparisons/1440 physical metadata/240 paused controls, all6578 before/after guards natural15:40:33.609564. First0-case metadata helper and next six harmless above30s exact-equality false-positive failures retained. Current worst defect uncorrected; no R30 completed/gain/streak credit. New evidence source needs genuine newest whole CI.'),
 ('REVIEW.md','R30 actual postgreen five-weakness rank and negative','After full1008 green re-read binding job; rank first empty-room human return, paused first-human return, stale/duplicate identity preservation, historical failed Worker benefit, physical-phone/upstream limitations. Worst actual1440-case deterministic test finds1200 less-than30s human windows. No production edits/repair/noGain credit. R29 +29s is qualified only by full1008. Narrow next fix must preserve ordinary connected/paused/empty metadata and every original fullyconnected whole state/physical score/RNG/inactive budget.'),
 ('LOOP.md','R30 investigation checkpoint, incomplete','R29 is qualified by full1008 original57tests/whole1360checks. After green, re-read/rank5; first empty-room return negative1440 legal cases produces1200 true below30s windows,780 connected/1440 physical/240 paused controls PASS; natural15:40:33.609564/all6578 inputs. First metadata helper0-case failure and six harmless >30s false positives preserved. No R30 fix/measure-gain/adoption/completed review/noGain credit; worst remains NEXT.'),
 ('ASSUMPTIONS.md','First empty-room human-return policy and actual missed cadence','The first live human returning to an empty play room deserves at least a fresh30s decision window; if paused, no physical move occurs until resume and the fresh window starts then. Ordinary inactive/duplicate reconnects while someone is present do not earn another window. Exact minimum30s policy distinguishes six harmless excess windows from1200 real too-short windows; original exact-equality diagnostic is preserved. First initial helper wrongly ignored deliberately changed connected metadata and failed before any actual case; do not count that as a game failure. 15:42:00.273216 hard source cadence is honestly missed during B13 independent work/restoration interruption; read actual next publication, never backdate. No sampler rerun, performance gate change or inherited current acceptance.')]:
 p=JOB/name;p.write_text(p.read_text()+'\n## '+heading+'\n'+body+'\n')
p=JOB/'README.md';text=p.read_text().replace('Timer repair57 tests/480 oldfail→newpass and full connected parity pass; newest CI pending.','Qualified1008:57 tests/25 mutants/whole1360 checks; R30 first empty-room return1200 FAIL.').replace('NEXT.md records R29 timer repair, required whole qualification, failures and cadence.','NEXT.md records qualified R29, open R30 return defect, failures and actual cadence.');assert len(text.splitlines())<60;p.write_text(text)
receipt={'status':'PASS','preparedUtc':prepared,'sourceParent':PARENT,'originalWholeQualifiedSource':PARENT,'qualifiedR29PlayerGainMs':29000,'firstR30Failures':1200,'R30Repair':'UNEXECUTED/unadopted/no credit','fullRawProof':report['fullRawProof'],'currentOriginalClip':report['currentClip'],'actualPreparationSecondsPastHard':past,'newCheckpointWholeOriginal':'Pending; Draft20 remains incomplete'}
dump(OUT/'current1008-whole-R30-negative-preparation-CLOSED.json',receipt); print(json.dumps(receipt))
