import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.work/queue-audit-20261008'
READY_PATH = WORK / 'worker-native-ready.json'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity(path):
    actual = Path(path).resolve()
    data = actual.read_bytes()
    return {'path': str(actual), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def live_group(group):
    members = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            fields = (entry/'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group and fields[0] not in ['Z', 'X']:
                members.append(int(entry.name))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return members

def signal_group(group, value):
    try:
        os.killpg(group, value)
    except ProcessLookupError:
        pass

ready = json.loads(READY_PATH.read_text())
manifest_before = identity(READY_PATH)
controller_before = identity(__file__)
for group in ['sources', 'binaries']:
    for expected in ready[group].values():
        assert identity(expected['path']) == expected, ('READY drift', expected['path'])
receipt = {'schema': 'g01-native-worker-first-controller/1', 'scope': 'First actual-worker functional trial; no FPS/player-gain claim', 'startedAt': now(), 'ready': manifest_before, 'controllerBefore': controller_before, 'command': [ready['binaries']['node']['path'], 'worker-browser-check.ts'], 'status': 'STARTED'}
receipt_path = WORK / 'worker-native-first-controller.json'
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': 'STARTED', 'startedAt': receipt['startedAt'], 'command': receipt['command']}), flush=True)
environment = dict(os.environ)
environment.update(ready['environment'])
process = None
exit_code = None
receipt['naturalClosure'] = False
try:
    with (WORK / 'worker-native-first.log').open('w') as log:
        process = subprocess.Popen(receipt['command'], cwd=ROOT/'jobs/G01-dominoes', env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        receipt['childPid'] = process.pid
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        exit_code = process.wait(timeout=120)
        receipt['naturalClosure'] = True
except BaseException as error:
    receipt['failure'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    # Every post-spawn operation, including receipt writes, is within this cleanup.
    # Reap the actual child and close any still-live owned group before CLOSED/FAIL.
    if process is not None:
        running = process.poll() is None or bool(live_group(process.pid))
        if running:
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGTERM)
        try:
            exit_code = process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGKILL)
            exit_code = process.wait(timeout=10)
        deadline = time.monotonic() + 2
        while live_group(process.pid) and time.monotonic() < deadline:
            time.sleep(0.025)
        if live_group(process.pid):
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGKILL)
            deadline = time.monotonic() + 2
            while live_group(process.pid) and time.monotonic() < deadline:
                time.sleep(0.025)
        receipt['remainingOwnedLiveProcesses'] = live_group(process.pid)
        assert not receipt['remainingOwnedLiveProcesses'], 'Owned process group still live; no CLOSED/FAIL release'
        receipt['childClosedAt'] = now()
    else:
        receipt['naturalClosure'] = False
        receipt['remainingOwnedLiveProcesses'] = []
        receipt['childClosedAt'] = None
receipt['exitCode'] = exit_code
receipt['log'] = identity(WORK/'worker-native-first.log')
receipt['guardsAfter'] = {group: {name: identity(expected['path']) for name, expected in ready[group].items()} for group in ['sources', 'binaries']}
receipt['sourceAndBinaryGuardsPassed'] = receipt['guardsAfter'] == {group: ready[group] for group in ['sources', 'binaries']}
receipt['readyAfter'] = identity(READY_PATH)
receipt['controllerAfter'] = identity(__file__)
receipt['controllerAndReadyUnchanged'] = receipt['readyAfter'] == manifest_before and receipt['controllerAfter'] == controller_before
proof_path = ROOT/'jobs/G01-dominoes/.tmp/g01-evidence/worker-current.json'
if proof_path.exists():
    receipt['actualProof'] = identity(proof_path)
    receipt['proofStatus'] = json.loads(proof_path.read_text()).get('status')
receipt['status'] = 'PASS' if exit_code == 0 and receipt['naturalClosure'] and not receipt.get('failure') and receipt['sourceAndBinaryGuardsPassed'] and receipt['controllerAndReadyUnchanged'] and receipt.get('proofStatus') == 'PASS' else 'FAIL'
receipt['controllerFinishedAt'] = now()
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ['status', 'childClosedAt', 'controllerFinishedAt', 'exitCode', 'naturalClosure', 'sourceAndBinaryGuardsPassed', 'controllerAndReadyUnchanged']}), flush=True)
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
