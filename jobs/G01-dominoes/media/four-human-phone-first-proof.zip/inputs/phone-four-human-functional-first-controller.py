from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

PRIVATE=Path(__file__).resolve().parent
RECEIPT=PRIVATE/'phone-four-human-functional-first-controller.json'
LOG=PRIVATE/'phone-four-human-functional-first-controller.log'
assert not RECEIPT.exists() and not LOG.exists()
assert not (PRIVATE/'phone-four-human-functional-first').exists()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity(p):
    data=Path(p).read_bytes();return {'path':str(Path(p).resolve()),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def live_group(pgid):
    result=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():continue
        try:
            fields=(path/'stat').read_text().rsplit(')',1)[1].split()
            if int(fields[2])==pgid and fields[0] not in ['Z','X']:result.append(int(path.name))
        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    return result
def kill_group(pgid,value):
    try:os.killpg(pgid,value)
    except ProcessLookupError:pass
def stable_stat(path):
    s=Path(path).lstat()
    return {name:getattr(s,name) for name in ['st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns']}

def actual_link_chain(path):
    path=Path(os.path.abspath(path))
    pending=list(path.parts[1:])
    cursor=Path(path.anchor)
    links=[]
    while pending:
        piece=pending.pop(0)
        if piece=='.': continue
        if piece=='..': cursor=cursor.parent; continue
        cursor=cursor/piece
        if cursor.is_symlink():
            target=os.readlink(cursor)
            links.append({'path':str(cursor),'target':target,'lstat':stable_stat(cursor)})
            assert len(links)<=100, 'Symlink cycle'
            if os.path.isabs(target):
                cursor=Path('/')
                pending=list(Path(target).parts[1:])+pending
            else:
                cursor=cursor.parent
                pending=list(Path(target).parts)+pending
    assert cursor==path.resolve(strict=True)
    return links

def check_complete_installed_inputs():
    expected=json.loads(Path(ready['installedInputManifest']['path']).read_text())
    tree=expected['tree']
    module_root=Path(tree['root'])
    actual_entries=sorted(module_root.rglob('*'))
    assert stable_stat(module_root)==tree['rootLstat'], 'Dependency root stat changed'
    assert {str(p.relative_to(module_root)) for p in actual_entries}==set(tree['entries']), 'Installed dependency inventory changed'
    for p in actual_entries:
        actual={'lstat':stable_stat(p),'symlinkTarget':os.readlink(p) if p.is_symlink() else None}
        assert actual==tree['entries'][str(p.relative_to(module_root))], ('Installed dependency stat/link changed',str(p))
    for path,expected_alias in expected['aliases'].items():
        actual_path=Path(path)
        resolved=actual_path.resolve(strict=True)
        assert str(resolved)==expected_alias['resolvedPath'], ('Input alias target changed',path)
        assert stable_stat(actual_path)==expected_alias['entryLstat'], ('Input entry stat changed',path)
        assert stable_stat(resolved)==expected_alias['targetLstat'], ('Input target stat changed',path)
        assert actual_link_chain(actual_path)==expected_alias['symlinkChain'], ('Input symlink chain changed',path)
        assert identity(actual_path)==expected_alias['content'], ('Resolved input bytes changed',path)
    return {'status':'PASS','installedFiles':expected['completeInstalledFileCount'],'aliases':len(expected['aliases']),'manifest':identity(ready['installedInputManifest']['path'])}

READY_PATH=PRIVATE/'phone-four-human-functional-first-ready.json'
ready=json.loads(READY_PATH.read_text())
ready_before=identity(READY_PATH)
controller_before=identity(__file__)
assert controller_before==ready['controller']
assert identity(ready['installedInputManifest']['path'])==ready['installedInputManifest']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ready['repo'],text=True).strip()==ready['source']
for path,expected in ready['binaries'].items(): assert identity(path)==expected
complete_before=check_complete_installed_inputs()

loader=PRIVATE/'phone-four-human-functional-first.mjs'
before=identity(loader)
receipt={'schema':'g01-current-four-human-phone-functional-once-controller/1','status':'STARTED','startedAt':now(),'loaderBefore':before,'scope':'Finite actual current four-human phone functional check, no FPS/rAF profile or old-pair retry. Every raw DOM step and partial failure retained.'}
with RECEIPT.open('x') as out:out.write(json.dumps(receipt,indent=2)+'\n')
process=None
try:
    with LOG.open('x') as log:
        process=subprocess.Popen(['/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node',str(loader)],cwd=PRIVATE,env={**os.environ,'TMPDIR':'/tmp'},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        receipt['childPid']=process.pid
        process.wait(timeout=75)
        receipt['naturalClosure']=True
except BaseException as error:
    receipt['failure']={'type':type(error).__name__,'message':str(error)}
    receipt['naturalClosure']=False
finally:
    if process is not None:
        if process.poll() is None or live_group(process.pid):
            receipt['naturalClosure']=False;kill_group(process.pid,signal.SIGTERM)
        try:process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            receipt['naturalClosure']=False;kill_group(process.pid,signal.SIGKILL);process.wait(timeout=10)
        deadline=time.monotonic()+2
        while live_group(process.pid) and time.monotonic()<deadline:time.sleep(.025)
        if live_group(process.pid):
            receipt['naturalClosure']=False;kill_group(process.pid,signal.SIGKILL)
            deadline=time.monotonic()+2
            while live_group(process.pid) and time.monotonic()<deadline:time.sleep(.025)
        receipt['remainingOwnedLiveProcesses']=live_group(process.pid)
        assert receipt['remainingOwnedLiveProcesses']==[]
        receipt['childClosedAt']=now();receipt['exitCode']=process.returncode
    else:
        receipt['remainingOwnedLiveProcesses']=[];receipt['exitCode']=None
receipt['completeInputsBefore']=complete_before
try:
    receipt['completeInputsAfter']=check_complete_installed_inputs()
    assert receipt['completeInputsAfter']==complete_before
    assert identity(READY_PATH)==ready_before and identity(__file__)==controller_before
    for path,expected in ready['binaries'].items(): assert identity(path)==expected
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ready['repo'],text=True).strip()==ready['source']
    receipt['completeInputGuardsPassed']=True
except BaseException as error:
    receipt['completeInputGuardsPassed']=False
    receipt['completeInputGuardFailure']={'type':type(error).__name__,'message':str(error)}
receipt['loaderAfter']=identity(loader)
receipt['log']=identity(LOG)
result_path=PRIVATE/'phone-four-human-functional-first/proof.json'
if result_path.exists():
    receipt['actualLoaderReceipt']=identity(result_path)
    result=json.loads(result_path.read_text());receipt['actualAcceptance']={'cases':len(result.get('cases',[])), 'checks':None};receipt['loaderStatus']=result['status']
receipt['status']='PASS' if receipt.get('naturalClosure') and receipt['exitCode']==0 and receipt['loaderBefore']==receipt['loaderAfter'] and receipt.get('loaderStatus')=='PASS' and receipt['completeInputGuardsPassed'] else 'FAIL'
receipt['naturallyClosedAt']=now();RECEIPT.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:receipt[key] for key in ['status','naturallyClosedAt','exitCode','remainingOwnedLiveProcesses']}|{'checks':(receipt.get('actualAcceptance') or {}).get('checks')}))
raise SystemExit(0 if receipt['status']=='PASS' else 1)
