from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile
P=Path(__file__).resolve().parent;R=P.parent/'repo';J=R/'jobs/G01-dominoes'
BASE='949dbcbd3a82882a6d69bb6c50ff8d735ca5d8dc'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def ident(p):
 d=Path(p).read_bytes();return {'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
first=json.loads((P/'phone-callback-candidate-first-controller.json').read_text());reg=json.loads((P/'privacy-veil-regression-candidate-first-controller.json').read_text());proof=json.loads((P/'phone-callback-candidate-first/proof.json').read_text());regraw=P/'phone-stale-reveal-candidate/repo/jobs/G01-dominoes/.tmp/privacy-veil-check.json'
assert first['status']==reg['status']==proof['status']=='PASS' and first['completeInputGuardsPassed'] and reg['completeInputGuardsPassed'] and first['remainingOwnedLiveProcesses']==reg['remainingOwnedLiveProcesses']==[]
assert len(proof['cases'])==4 and all(x['status']=='PASS' for x in proof['cases'])
assert json.loads(regraw.read_text())['status']=='PASS'
adopt=json.loads((P/'phone-callback-source-adoption.json').read_text())
for x in adopt['changedProducts']:assert ident(J/x['path'])=={k:x[k] for k in ['bytes','sha256']}
assert ident(J/'privacy-veil-check.ts')=={k:adopt['newDefaultRegression'][k] for k in ['bytes','sha256']}
payload={'four-cases/'+p.name:p.read_bytes() for p in (P/'phone-callback-candidate-first').iterdir() if p.is_file()}
extras=['phone-callback-candidate-first-controller.json','phone-callback-candidate-first-controller.log','phone-callback-candidate-first-controller.py','phone-callback-candidate-first.mjs','phone-callback-candidate-first-ready.json','phone-callback-candidate-first-complete-inputs.json','privacy-veil-regression-candidate-first-controller.json','privacy-veil-regression-candidate-first-controller.log','privacy-veil-regression-candidate-first-controller.py','privacy-veil-regression-candidate-first-ready.json','privacy-veil-regression-candidate-first-complete-inputs.json','phone-stale-reveal-source-callback-reproduction.mjs','phone-stale-reveal-source-callback-reproduction.json','phone-stale-reveal-candidate-callback-reproduction.mjs','phone-stale-reveal-candidate-callback-reproduction.json','phone-callback-adoption-review.json','phone-callback-source-adoption.json','phone-stale-reveal-candidate-source-preparation.json','phone-stale-reveal-candidate-strict-ts.json','prepare-phone-stale-reveal-candidate.py','phone-stale-reveal-candidate-first-prelaunch-preparation-failure.json','phone-stale-reveal-candidate-second-prelaunch-syntax-failure.json']
for n in extras:payload['inputs/'+n]=(P/n).read_bytes()
payload['real-waapi/actual-regression.json']=regraw.read_bytes()
for n in ['ui.ts','play.html','package.json','privacy-veil-check.ts']:payload['adopted-source/'+n]=(J/n).read_bytes()
archive=J/'media/phone-veil-callback-fix-first-proof.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,v in payload.items():
  info=zipfile.ZipInfo(n,date_time=(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,v)
assert archive.stat().st_size<3_000_000
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(payload)
 for n,v in payload.items():assert z.read(n)==v
summary={'schema':'g01-reviewed-private-veil-callback-fix-first/1','status':'LOCAL_FUNCTIONAL_PASS_FULL_CURRENT_CI_PENDING','baseHead':BASE,'adoptedAt':adopt['naturallyClosedAt'],'sourceAdoption':adopt,'originalFailure':'First old-source phone trial remains FAIL04:03:00.755822, cause unknown, complete raw preserved in four-human-phone-first.json/proof.zip.','deterministicCallbackReproduction':'Exact actual UI functions/minimal mock show old callback can hide new prompt; modified source retains it. Controlled callback-order evidence, not actual historical-browser cause.','firstChangedSourceFourCaseClosedAt':first['naturallyClosedAt'],'firstChangedSourceCompleteInputGuardsPassed':True,'firstChangedSourceCases':[{'mode':x['mode'],'partners':x['partners'],'motion':x['motion'],'status':x['status'],'rawSteps':len(x['steps'])} for x in proof['cases']],'actualHumanTurns':16,'firstRealNativeWaapiRegressionClosedAt':reg['naturallyClosedAt'],'firstRealNativeWaapiCompleteInputGuardsPassed':True,'realNativeWaapiRegression':json.loads(regraw.read_text()),'remainingOwnedLiveProcesses':[],'archive':{'path':'media/'+archive.name,**ident(archive),'members':len(payload)},'originalBrowserSamplerUnchanged':True,'coreRngWorkerPolicyUnchanged':True,'actualAnimationsUnchanged':'260ms reveal,280ms opening,380ms hand animations; existing state/clocks unchanged.','newDefaultTestAddedOnlyPrivacyRegression':True,'originalPr1':'Open/draft/unmerged/unchanged8c','renewedCompletedKeepRounds':0,'provisionalMaterialPrivacyImprovements':1,'scope':'Root read exact full source/diff04:20:53 before adoption. First changed-source four-case PASS and new real-WAAPI regression PASS. Candidate same UI/player adopted audit only; modified full current pipeline/whole official artifact remain required. No original failure cause, FPS, physical phone, old responsiveness-gain or stopping-streak claim.'}
(J/'phone-veil-callback-fix-first.json').write_text(json.dumps(summary,indent=2)+'\n')
section='''## Current private-hand prompt fix adopted in audit

The audit now removes one obsolete reveal-animation finish callback. renderDock
already hides the veil when a hand is revealed; a later old animation callback
must not hide a newly reopened prompt. Same260/280/380ms animations, core/RNG/
Worker policy, UI/game clocks and original300 native sampler/gates remain.
UI45d160bb4ab1d7a8a900369b9e7880f51babfabd28069ce3af599272a2e0aeb5;
player1,032,817B/6740130f01cea0cbf752d4d0a1a66001b9acb4300a5363ac853037b7deded145.
Root actually read full original/candidate UI excerpts/diff04:20:53UTC before
the actual same-hash adoption04:25:40.002423UTC. Canonical PR1 unchanged8c/draft.

FIRST changed-source four-human390x844/4xCPU validation naturally CLOSED
04:16:57.960318UTC/exit0/PASS/group[]. Allfour original cases pass: Draw/Block
partners, Draw individual with reduced motion; Block individual normal motion.
All16 first human turns/private hide-reveal/legal moves/control fit passed with
all1,630 source/helper aliases/whole1,618 installed inputs/1,746inventory and
five runtime guards. Complete raw/native snapshot timestamps saved before
assertions. Exact original seat/visibility/control predicates were preserved.

New legitimate privacy-veil-check.ts runs the actual Reveal/Hide DOM handlers
in one synchronous task, then waits350ms for genuine native WAAPI completion.
The prompt remains visible/private, samePlayer1/empty board/no exposed hand;
a subsequent trusted pointer reveals the samefive tiles. FIRST actual run
naturally CLOSED04:23:57.716040UTC/exit0/PASS/group[], all1,631aliases/whole
installed inputs/runtimes unchanged. No state injection, clock installation,
FPS sample or historical failure-cause claim. This separate functional check
is added to default npm test before byte-unchanged original browser.ts.

phone-veil-callback-fix-first.json and media/phone-veil-callback-fix-first-proof.zip
retain exact full four-case raw/four screenshots, real-WAAPI raw, original
programs/READY/controllers/complete inputs, exact adopted sources, source
review/mocks and both before-native preparation errors. Every member byte/CRC
checked. Original old-source phone FAIL remains intact/causeUNKNOWN; controlled
mock reproduction is not a retrospective browser-cause attribution.

This is a measured bounded privacy usability improvement, pending complete
new-current full original CI and genuine official artifact acceptance. Earlier
ddd1,279-check whole proof remains historical, not green for this modified UI.
PR11 draft, PR1 unchanged8c. Responsiveness native acceptance and both fixed
gain gates remain FAIL; no FPS/physical-phone/player-response gain claim.
Renewed completed KEEP rounds0; provisional material privacy improvements1,
three-consecutive no-gain stopping streak0. After actual full current green,
re-read original instructions/rankfive/fix-measure worst and complete KEEP.

Last actual source push04:05:12.921243UTC, hard04:35:12.921243UTC; this concrete
fix checkpoint is due before that hard time. Read actual new push receipt for
fresh cadence. Own mainCLAIMS refresh follows under exclusive own-row lease.
Authoritative /tmp checkout remains; original workspace/history/unique ZIPs and
all failures remain preserved. No local original FPS or old-pair retry occurred.

'''
q=J/'NEXT.md';text=q.read_text();marker='## Latest exact ddd whole artifact and four-human phone checkpoint\n';assert marker in text;text=text.replace(marker,section+'## Historical accepted ddd artifact and old-source phone failure\n\nThe following describes exact earlier sources, not current modified UI green.\n',1);q.write_text(text)
for name in ['VERIFY.md','HOSTED-WORKER-AUDIT.md','ASSUMPTIONS.md']:
 q=J/name;q.write_text(q.read_text().rstrip()+'\n\n'+section.rstrip()+'\n')
q=J/'README.md';text=q.read_text().replace('Exact Worker/face-down ddd full CI and1,279-check genuine artifact proof passed,','Prior Worker/face-down ddd full CI and1,279-check genuine artifact proof passed,').replace('Current-head CI and renewed KEEP remain; isolated diagnostic/gain gates FAILED.','Privacy prompt fix passes four-case/WAAPI checks; current full CI/KEEP pending.');q.write_text(text);assert len(text.splitlines())<60
review='''

Current review after private-prompt fix (full current CI still pending):
1. Rapid Hide/reveal could lose a private prompt through an obsolete finish
callback. One-callback fix adopted after full source review; original four-case
first3PASS/1FAIL becomes changed-source4PASS and real-WAAPI regression PASS.
Historical failing case cause remains unknown; exact callback-order controlled
mock is separate evidence. No clock/sampler/gate change.
2. Strong-bot responsiveness gain remains unestablished; old native pair and
both fixed gain gates FAIL. Current player performance/strength must be measured.
3. Complete new-current original CI and whole official artifact pending.
4. Four-seat complete-round/large-hand phone interactions and physical hardware
remain limited; current proof covers firstfour turns in four emulated cases.
5. Finite upstream/reference-strength scope still limits best-AI claims.
Renewed completed KEEP0/provisional material privacy improvement1/no-gain streak0.
'''
q=J/'REVIEW.md';q.write_text(q.read_text().rstrip()+review+'\n')
q=J/'LOOP.md';q.write_text(q.read_text().rstrip()+'''

Provisional current privacy improvement P1, 2026-10-09: source reviewed04:20:53,
same-hash UI/player adopted04:25:40. Remove only obsolete veil finish hide
callback; actual animation/game clocks/core/Worker/original sampler unchanged.
First modified-source originalfourphone cases PASS04:16:57.960318, all16 human
turns/guard/raw steps. Default real native-WAAPI regression PASS04:23:57.716040,
genuine finish preserves reopened privateprompt and same hand/seat. Old original
phone firstFAIL/causeUNKNOWN retained. This meaningful privacy fix awaits full
current CI/whole artifact before completing renewed KEEP; completed rounds0,
no-gain streak0. Original response native acceptance and both gain gates FAIL.
'''.rstrip()+'\n')
subprocess.run(['node','checksums.ts'],cwd=J,check=True);subprocess.run(['node','checksums.ts','--check'],cwd=J,check=True);subprocess.run(['git','diff','--check'],cwd=R,check=True)
for x in adopt['changedProducts']:assert ident(J/x['path'])=={k:x[k] for k in ['bytes','sha256']}
status=subprocess.check_output(['git','status','--short'],cwd=R,text=True);assert all(v[3:].startswith('jobs/G01-dominoes/') for v in status.splitlines())
result={'status':'PASS_PREPARED','naturallyClosedAt':now(),'expectedHead':BASE,'archive':summary['archive'],'all7UnchangedProductsVerified':True,'newDefaultRegressionSourceSha256':ident(J/'privacy-veil-check.ts')['sha256'],'gitStatus':status};(P/'phone-callback-fix-public-preparation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
