import {chromium} from '/workspace/game-cores-G01-queue-audit-20261008/jobs/G01-dominoes/node_modules/playwright/index.mjs';
import {readFileSync,writeFileSync,realpathSync,readdirSync,lstatSync,statSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {resolve,join} from 'node:path';
const privateRoot='/tmp/g01-current-838-proof-20261009/private',repo=resolve(privateRoot,'phone-stale-reveal-candidate/repo'),job=join(repo,'jobs/G01-dominoes');
const source='949dbcbd3a82882a6d69bb6c50ff8d735ca5d8dc';
const output=join(privateRoot,'phone-callback-candidate-first');mkdirSync(output);
const proofPath=join(output,'proof.json');
const identity=path=>{const target=realpathSync(path),bytes=readFileSync(target);return {path:target,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};};
const product=['ui.ts','play.html','core.ts','strong-bot.ts','strong-worker.ts','browser.ts','browser-evidence.ts','package.json','build.ts','shell.html'];
assert.equal(execFileSync('git',['-C',repo,'rev-parse','HEAD']).toString().trim(),source);
const candidateProductRecords=[{"path":"ui.ts","bytes":50283,"sha256":"45d160bb4ab1d7a8a900369b9e7880f51babfabd28069ce3af599272a2e0aeb5","differsFromCurrent949":true},{"path":"play.html","bytes":1032817,"sha256":"6740130f01cea0cbf752d4d0a1a66001b9acb4300a5363ac853037b7deded145","differsFromCurrent949":true},{"path":"core.ts","bytes":22697,"sha256":"b8838080d2ac938e9ad3da11966c94895d4fb3991ca99f0bdf2c0a6364644c95","differsFromCurrent949":false},{"path":"strong-bot.ts","bytes":2853,"sha256":"297b8594475cf70ab2a737fdfde243514fdfbe0a1abc49d95aae9df25202ef70","differsFromCurrent949":false},{"path":"strong-worker.ts","bytes":868,"sha256":"5caf9f3cb8250add5e74de640ef7bd113f518b9f36308a1cc43ed280630bd2e6","differsFromCurrent949":false},{"path":"browser.ts","bytes":8026,"sha256":"add398c4924eed6ec1852a22070ae9ff50dc12b299c034de53b0c0769ab4cd94","differsFromCurrent949":false},{"path":"browser-evidence.ts","bytes":5457,"sha256":"61b57e129125f1426bd0c78586faa829b46369791a628cbb111744f3c460bbdb","differsFromCurrent949":false},{"path":"package.json","bytes":1300,"sha256":"f7332248e11dc222dd99cc168de1b345ce7b1cf43f94eea64939572fb278b741","differsFromCurrent949":false},{"path":"build.ts","bytes":1887,"sha256":"b7deea53e66801f219ae1c48374a5af38a01b7f3d6d92377fa63a79f70671601","differsFromCurrent949":false},{"path":"shell.html","bytes":45308,"sha256":"6e4e16feb97c4fbc7de3ada2b7b1dfc0eabd4e0dcb10c9b8cd549e704d1982fb","differsFromCurrent949":false}];
for(const record of candidateProductRecords){const raw=readFileSync(join(job,record.path));assert.equal(raw.length,record.bytes);assert.equal(createHash('sha256').update(raw).digest('hex'),record.sha256);if(!record.differsFromCurrent949)assert(raw.equals(execFileSync('git',['-C',repo,'show',`${source}:jobs/G01-dominoes/${record.path}`])));}

const moduleRoot='/workspace/game-cores-G01-queue-audit-20261008/jobs/G01-dominoes/node_modules';
function installedMap(){const map={};const walk=dir=>{for(const entry of readdirSync(dir,{withFileTypes:true})){const path=join(dir,entry.name);if(entry.isDirectory())walk(path);else if(statSync(path).isFile()){const s=lstatSync(path);map[path]={content:identity(path),lstat:{dev:s.dev,ino:s.ino,mode:s.mode,size:s.size,nlink:s.nlink,mtimeMs:s.mtimeMs,ctimeMs:s.ctimeMs}};}}};walk(moduleRoot);return map;}
const sources=()=>Object.fromEntries([...product.map(n=>join(job,n)),join(repo,'contract/rng.ts'),import.meta.filename].map(path=>[path,identity(path)]));
const binaries=()=>({node:identity(process.execPath),chromium:identity('/usr/lib/chromium/chromium')});
const result={schema:'g01-four-human-phone-functional-proof/1',status:'STARTED',startedAt:new Date().toISOString(),source,candidateProductRecords,scope:'FIRST changed-source prospective callback-fix player interactions on390x844/4xCPU. Same original four scenarios/seat predicates, no FPS/rAF timing, simulated clock, old unchanged retry, file-navigation claim, bot gain or completed KEEP round. Base949 retained; candidate unadopted.',navigation:'Exact source bytes page.setContent; no file:// claim',clockInstalled:false,sourcesBefore:sources(),binariesBefore:binaries(),installedBefore:installedMap(),cases:[],externalRequests:[],errors:[]};
const save=()=>writeFileSync(proofPath,JSON.stringify(result,null,2)+'\n');save();assert.equal(Object.keys(result.installedBefore).length,1618);
let browser=null,activePage=null,activeCase=null;
const snapshot=async(page,label)=>{const raw=await page.evaluate(()=>({observedAt:new Date().toISOString(),wallNow:Date.now(),nativePerformanceNow:performance.now(),veilAnimations:document.querySelector('#veil').getAnimations().map(a=>({playState:a.playState,currentTime:a.currentTime,finishCallbackPresent:typeof a.onfinish==='function'})),view:document.querySelector('#app').dataset.view,status:document.querySelector('#status').textContent,round:document.querySelector('#roundPill').textContent,veilVisible:!document.querySelector('#veil').hidden,privacy:document.querySelector('#privacy').innerText,privateTiles:[...document.querySelectorAll('#hand .hand-tile')].map(e=>({id:Number(e.dataset.tile),playable:e.classList.contains('playable')})),boardTiles:[...document.querySelectorAll('#boardLayer .tile')].map(e=>Number(e.dataset.tile)),seats:[...document.querySelectorAll('#seatsLayer .seat')].map(e=>({seat:Number(e.dataset.seat),name:e.querySelector('.who b span').textContent,count:Number(e.querySelector('.count').textContent),active:e.classList.contains('active'),faceTiles:e.querySelectorAll('[data-tile]').length})),roundEndVisible:!document.querySelector('#roundEnd').hidden,roundRows:document.querySelectorAll('#roundEnd .tally-row').length,roundFaceTiles:document.querySelectorAll('#roundEnd .tally-tiles .tile').length,viewport:{width:innerWidth,height:innerHeight},documentWidth:document.documentElement.scrollWidth,controls:[...document.querySelectorAll('#actions button,#privacy button,#end,#sound')].filter(e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden').map(e=>{const r=e.getBoundingClientRect();return {label:e.getAttribute('aria-label')??e.textContent,x:r.x,y:r.y,width:r.width,height:r.height};})}));activeCase.steps.push({label,raw});save();return raw;};
try{
 browser=await chromium.launch({headless:true,executablePath:'/usr/lib/chromium/chromium',args:['--no-sandbox']});result.chromiumVersion=browser.version();
 for(const scenario of [{mode:'draw',partners:true,motion:'reduce'},{mode:'block',partners:true,motion:'reduce'},{mode:'draw',partners:false,motion:'reduce'},{mode:'block',partners:false,motion:'no-preference'}]){
  activeCase={...scenario,seed:23,viewport:{width:390,height:844},cpuThrottleRate:4,steps:[],status:'STARTED'};result.cases.push(activeCase);save();
  const context=await browser.newContext({viewport:activeCase.viewport,reducedMotion:scenario.motion});const page=await context.newPage();activePage=page;
  page.on('pageerror',e=>{result.errors.push(e.message);save();});page.on('request',r=>{if(/^https?:/.test(r.url())){result.externalRequests.push(r.url());save();}});
  await page.route('**/*',r=>/^https?:/.test(r.request().url())?r.abort():r.continue());
  await page.setContent(readFileSync(join(job,'play.html'),'utf8'));
  const cdp=await context.newCDPSession(page);await cdp.send('Emulation.setCPUThrottlingRate',{rate:4});
  await page.check('#players-4');for(let i=0;i<4;i++)await page.selectOption(`#seat-${i}`,'human');
  await page.setChecked('#partners',scenario.partners);await page.check('#mode-'+scenario.mode);await page.check('#target-250');
  await page.click('#houseRules summary');await page.selectOption('#opening','rotating');await page.fill('#seed','23');await page.click('#start');
  let raw=await snapshot(page,'initial-private-handover');assert.equal(raw.view,'phone');assert.equal(raw.seats.length,4);assert.equal(raw.privateTiles.length,0);assert(raw.veilVisible);
  const firstCount=scenario.partners?7:5;
  for(let turn=0;turn<4;turn++){
   await page.locator('#privacy button').click();raw=await snapshot(page,'seat-'+turn+'-revealed');assert.equal(raw.privateTiles.length,firstCount);assert.equal(raw.veilVisible,false);assert(raw.status.includes('Player '+(turn+1)));
   assert(raw.seats.every(s=>s.faceTiles===0));assert(raw.documentWidth<=390);
   assert(raw.controls.every(c=>c.x>=-1&&c.y>=-1&&c.x+c.width<=391&&c.y+c.height<=845),'visible controls must fit phone viewport');
   await page.getByRole('button',{name:'Hide my tiles',exact:true}).click();raw=await snapshot(page,'seat-'+turn+'-hidden');assert.equal(raw.privateTiles.length,0);assert(raw.veilVisible);
   await page.locator('#privacy button').click();raw=await snapshot(page,'seat-'+turn+'-revealed-again');assert.equal(raw.privateTiles.length,firstCount);
   const playable=page.locator('#hand .hand-tile.playable');
   if(await playable.count()){
    const selected=Number(await playable.first().getAttribute('data-tile'));await playable.first().click();
    if(await page.getByRole('button',{name:'Play on the right end',exact:true}).count())await page.getByRole('button',{name:'Play on the right end',exact:true}).first().click();
    raw=await snapshot(page,'seat-'+turn+'-played');assert(raw.boardTiles.includes(selected),'chosen legal tile must reach public board');
   }else if(await page.getByRole('button',{name:'Pass',exact:true}).count()){
    await page.getByRole('button',{name:'Pass',exact:true}).click();raw=await snapshot(page,'seat-'+turn+'-passed');
   }else{
    throw new Error('First-four-turn scenario reached a draw-only hand; preserve before expanding the predeclared cases');
   }
   await page.waitForFunction(()=>!document.querySelector('#veil').hidden,undefined,{timeout:3000});raw=await snapshot(page,'next-seat-private');assert.equal(raw.privateTiles.length,0);assert(raw.veilVisible);
  }
  await page.screenshot({path:join(output,`${scenario.mode}-${scenario.partners?'partners':'individual'}-${scenario.motion}.png`)});
  activeCase.status='PASS';save();await context.close();activePage=null;activeCase=null;
 }
 assert.deepEqual(result.externalRequests,[]);assert.deepEqual(result.errors,[]);result.status='PASS';result.finishedAt=new Date().toISOString();
}catch(error){result.status='FAIL';result.failure={type:error?.name??'Error',message:String(error?.message??error),stack:String(error?.stack??'')};if(activePage&&activeCase){try{await snapshot(activePage,'actual-partial-failure');}catch(e){result.partialSnapshotFailure=String(e);}}save();throw error;
}finally{
 try{if(browser){await browser.close();result.browserClosedAt=new Date().toISOString();}result.sourcesAfter=sources();result.binariesAfter=binaries();result.installedAfter=installedMap();save();assert.deepEqual(result.sourcesAfter,result.sourcesBefore);assert.deepEqual(result.binariesAfter,result.binariesBefore);assert.deepEqual(result.installedAfter,result.installedBefore);}catch(error){result.status='FAIL';result.guardOrClosureFailure=String(error);throw error;}finally{save();}
}
console.log(JSON.stringify({status:result.status,cases:result.cases.length,browserClosedAt:result.browserClosedAt,scope:result.scope}));
