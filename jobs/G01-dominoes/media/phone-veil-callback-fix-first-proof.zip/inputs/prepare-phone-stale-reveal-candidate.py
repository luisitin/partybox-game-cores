from pathlib import Path
import subprocess,json,datetime,hashlib
p=Path(__file__).resolve().parent
repo=p/'phone-stale-reveal-candidate/repo';job=repo/'jobs/G01-dominoes'
head='949dbcbd3a82882a6d69bb6c50ff8d735ca5d8dc'
cm=Path('/workspace/game-cores-G01-queue-audit-20261008/contract/node_modules')
assert cm.is_dir() and not (repo/'contract/node_modules').exists()
(repo/'contract/node_modules').symlink_to(cm,target_is_directory=True)
ui=job/'ui.ts';old=ui.read_text()
pattern="const a=veil.animate([{opacity:1,transform:'none'},{opacity:0,transform:'translateY(-30px)'}],{duration:260,easing:EASE});a.onfinish=()=>{veil.hidden=true;};"
replacement="veil.animate([{opacity:1,transform:'none'},{opacity:0,transform:'translateY(-30px)'}],{duration:260,easing:EASE});"
assert old.count(pattern)==1
ui.write_text(old.replace(pattern,replacement))
assert ui.read_text().replace(replacement,pattern)==old
subprocess.run(['node','build.ts'],cwd=job,check=True)
subprocess.run(['node','build.ts','--check'],cwd=job,check=True)
subprocess.run(['git','diff','--check'],cwd=repo,check=True)
records=[]
for n in ['ui.ts','play.html','core.ts','strong-bot.ts','strong-worker.ts','browser.ts','browser-evidence.ts','package.json','build.ts','shell.html']:
 d=(job/n).read_bytes();original=subprocess.check_output(['git','show',head+':jobs/G01-dominoes/'+n],cwd=repo)
 changed=d!=original;assert changed==(n in ['ui.ts','play.html'])
 records.append({'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest(),'differsFromCurrent949':changed})
result={'status':'PREPARED_UNADOPTED','naturallyClosedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseHead':head,'repo':str(repo),'productRecords':records,'scope':'One obsolete reveal animation callback removed; same animate/keyframes/260ms/easing, all core/RNG/Worker/sampler/build clocks unchanged. Original949 untouched. First changed-source functional validation not executed.'}
(p/'phone-stale-reveal-candidate-source-preparation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
