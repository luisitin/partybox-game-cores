from pathlib import Path
import datetime,json,os,shutil,subprocess,time,signal,re,hashlib
ROOT=Path('/tmp/G01-source-queue-audit-20261009');CANDIDATE=Path('/dev/shm/G01-idle-handoff-private-candidate-20261009');JOB=CANDIDATE/'jobs/G01-dominoes';OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');ORIGINAL=Path('/dev/shm/G01-current-functional-milestone-first-controller-20261009.py');HELPER=Path('/dev/shm/G01-idle-handoff-private-first-visual-20261009.mjs');HEAD='a81713c23ab6e2a605e2cd34e1b2f11b6cff3fe1';RECEIPT=OUT/'idle-handoff-private-first-visual-CLOSED.json';BOUND=180
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
scope={'__file__':str(ORIGINAL)};program=ORIGINAL.read_text().split("r={'schema':'g01-current-functional-milestone-controller/1'")[0];exec(compile(program,str(ORIGINAL),'exec'),scope);scope.update({'HEAD':HEAD,'__file__':__file__,'HELPER':HELPER});base=scope['snapshot'];track=scope['track'];group=scope['group'];alias=scope['alias']
def snapshot():
 r=base();paths=[ORIGINAL,Path('/dev/shm/G01-idle-handoff-private-candidate-prepare-20261009.py'),OUT/'postgreen-idle-departure-first.json'];installed=Path(r['installedRoot']);inventory=[]
 for p in CANDIDATE.rglob('*'):
  if p.is_file() and 'node_modules' not in p.relative_to(CANDIDATE).parts:paths.append(p);inventory.append(str(p.relative_to(CANDIDATE)))
 for prefix in [ROOT/'node_modules',ROOT/'jobs/G01-dominoes/node_modules',CANDIDATE/'node_modules',JOB/'node_modules']:
  assert prefix.resolve(strict=True)==installed.resolve(strict=True)
  paths.extend(prefix/p.relative_to(installed) for p in installed.rglob('*') if p.is_file())
 r['candidateInventory']=sorted(inventory);r['freshActualImporterAndCandidateAliases']={str(p):alias(p) for p in paths};return r

r={'schema':'g01-idle-handoff-private-first-visual-controller/1','startedUtc':stamp(),'publishedParent':HEAD,'candidateRoot':str(CANDIDATE),'wholeBoundSeconds':BOUND,'scope':'Actual changed private candidate page, native trusted functional hot-seat visuals only. No FPS/native clock alteration/file-navigation/absence UI-event/hardware claim.','signalsSent':[]};child=None
try:
 assert not RECEIPT.exists() and not (OUT/'idle-handoff-private-first-visual').exists();before=snapshot();(OUT/'idle-handoff-private-first-visual-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');deadline=time.monotonic()+BOUND
 with (OUT/'idle-handoff-private-first-visual-native.log').open('xb') as log:
  child=subprocess.Popen([shutil.which('node'),str(HELPER)],cwd=JOB,env=dict(os.environ,TMPDIR=str(OUT)),stdout=log,stderr=subprocess.STDOUT,start_new_session=True);r['childPid']=child.pid;r['childStartedUtc']=stamp()
  while child.poll() is None:
   track(child.pid)
   if time.monotonic()>=deadline:raise subprocess.TimeoutExpired(child.args,BOUND)
   time.sleep(.1)
 r['childClosedUtc']=stamp();r['childExitCode']=child.returncode;assert child.returncode==0;actual=json.loads((OUT/'idle-handoff-private-first-visual/report.json').read_text());assert actual['status']=='PASS' and len(actual['cases'])==3 and sum(c['actions'] for c in actual['cases'])==24 and not actual['errors'] and not actual['externalRequests']
 after=snapshot();(OUT/'idle-handoff-private-first-visual-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Frozen current/candidate/importer/runtime drift';r.update({'allFrozenInputsUnchanged':True,'frozenAliasCount':len(before['aliases'])+len(before['freshActualImporterAndCandidateAliases']),'actualReport':{k:v for k,v in actual.items() if k!='cases'},'caseSummaries':[{k:v for k,v in c.items() if k!='steps'} for c in actual['cases']],'status':'PASS','exitCode':0})
except BaseException as e:r.update({'status':'FAIL','exitCode':1,'errorType':type(e).__name__,'error':str(e)})
finally:
 if child is not None:
  live=track(child.pid)
  if child.poll() is None or live:
   try:os.killpg(child.pid,signal.SIGTERM);r['signalsSent'].append('SIGTERM owned group')
   except ProcessLookupError:pass
   for proc in live:
    try:os.kill(proc['pid'],signal.SIGTERM);r['signalsSent'].append('SIGTERM exact owned detached '+str(proc['pid']))
    except ProcessLookupError:pass
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);r['signalsSent'].append('SIGKILL owned group');child.wait(timeout=10)
  r['remainingOwnedChildren']=group(child.pid);r['remainingOwnedDetached']=track(child.pid)
 else:r['remainingOwnedChildren']=[];r['remainingOwnedDetached']=[]
 r['naturalClosure']=child is not None and not r['signalsSent'] and not r['remainingOwnedChildren'] and not r['remainingOwnedDetached']
 if not r['naturalClosure']:r.update({'status':'FAIL','exitCode':1})
 r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(r['exitCode'])
