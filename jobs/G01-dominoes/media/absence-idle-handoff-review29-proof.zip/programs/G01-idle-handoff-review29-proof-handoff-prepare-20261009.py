from pathlib import Path
import hashlib,json,datetime,subprocess,zipfile,shutil
ROOT=Path('/tmp/G01-source-queue-audit-20261009');JOB=ROOT/'jobs/G01-dominoes';CANDIDATE=Path('/dev/shm/G01-idle-handoff-private-candidate-20261009');OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');HEAD='a81713c23ab6e2a605e2cd34e1b2f11b6cff3fe1'
def load(name):return json.loads((OUT/name).read_text())
def identity(path):return {'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def dump(path,r):path.write_text(json.dumps(r,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
adoption=load('idle-handoff-review29-adoption-CLOSED.json');control=load('idle-handoff-private-first-CLOSED.json');visual=load('idle-handoff-private-first-visual-CLOSED.json');decoder=load('idle-handoff-private-first-video-decode-CLOSED.json');mutants=load('idle-handoff-private-mutants-first-CLOSED.json');actual=load('idle-handoff-private-first-control.json')
for r in [control,visual,decoder,mutants]:assert r['status']=='PASS' and r['naturalClosure'] and not r['remainingOwnedChildren'] and not r['remainingOwnedDetached'] and not r['signalsSent']
assert adoption['status']=='PASS' and adoption['allAdoptedProductBytesMatchGuardedPrivateCandidate'] and control['bothOriginalCompleteReportsByteIdentical'] and control['allFrozenInputsUnchanged'] and len(mutants['actualStrictlyCompiledMutationKills'])==3
assert actual['oldFailures']==actual['newFullHumanWindows']==480 and actual['wholeInactiveMatches']==240 and actual['wholePhysicalTransitions']==88055 and decoder['frames']==665
for name in ['core.ts','absence-presence.test.ts','play.html']:assert (JOB/name).read_bytes()==(CANDIDATE/'jobs/G01-dominoes'/name).read_bytes() and identity(JOB/name)==adoption['adoptedFiles'][name]
for name in ['total-compatibility.ts','total-compatibility-report.json','study-total-baseline.ts','study-presence-baseline.ts','test.ts','package.json','package-lock.json','browser.ts','verify-worker-artifact.py','worker-browser-check.ts','disk-browser-check.ts','privacy-veil-check.ts','ui.ts','shell.html']:assert (JOB/name).read_bytes()==subprocess.check_output(['git','show',HEAD+':jobs/G01-dominoes/'+name],cwd=ROOT),name
clip=Path(decoder['clip']['path']);publicClip=JOB/'media/milestone-21-idle-departure-clock-functional.webm';shutil.copyfile(clip,publicClip);assert identity(publicClip)=={key:decoder['clip'][key] for key in ['bytes','sha256']} and publicClip.stat().st_size<10000000
members={}
def include(name,path):
 assert name not in members and not Path(name).is_absolute() and '..' not in Path(name).parts and '\\' not in name and path.is_file() and not path.is_symlink();members[name]=path.read_bytes()
for name in ['idle-handoff-candidate-preparation-CLOSED.json','idle-handoff-private-first-control.json','idle-handoff-private-first-CLOSED.json','idle-handoff-private-first-inputs-before.json','idle-handoff-private-first-inputs-after.json','idle-handoff-private-first-new-control-native.log','idle-handoff-private-first-new-default9-native.log','idle-handoff-private-first-old-default9-native.log','idle-handoff-private-first-compatibility1-native.log','idle-handoff-private-first-compatibility2-native.log','idle-handoff-private-first-original-default48-native.log','idle-handoff-private-first-visual-CLOSED.json','idle-handoff-private-first-visual-inputs-before.json','idle-handoff-private-first-visual-inputs-after.json','idle-handoff-private-first-visual-native.log','idle-handoff-private-first-video-decode-CLOSED.json','idle-handoff-private-first-video-decode-inputs-before.json','idle-handoff-private-first-video-decode-inputs-after.json','idle-handoff-private-first-whole-ffprobe-native.log','idle-handoff-private-first-whole-ffmpeg-native.log','idle-handoff-private-first-complete-framehash.txt','idle-handoff-private-mutants-preparation-CLOSED.json','idle-handoff-private-mutants-first-CLOSED.json','idle-handoff-private-mutants-first-inputs-before.json','idle-handoff-private-mutants-first-inputs-after.json','idle-handoff-private-mutant-strict-all3-native.log','idle-handoff-review29-adoption-CLOSED.json','idle-handoff-review29-adoption-native.log','own-ram-git-write-location-CLOSED.json','a817-immutable-first-official-source-CLOSED.json','a817-immutable-first-official-source-native.log','current32a-whole-negative-source-publication-CLOSED.json','postgreen-idle-departure-first.json','postgreen-idle-departure-first-CLOSED.json','postgreen-idle-departure-first-native.log']:
 include('actual/'+name,OUT/name)
include('actual/main-after-material-a817-CLOSED.json',Path('/workspace/main-after-material-a817-CLOSED.json'));include('actual/main-after-material-a817-native.log',Path('/workspace/main-after-material-a817-native.log'))
for p in (OUT/'idle-handoff-private-first-visual').rglob('*'):
 if p.is_file():include('actual/visual/'+str(p.relative_to(OUT/'idle-handoff-private-first-visual')),p)
for mutant in mutants['actualStrictlyCompiledMutationKills']:
 name=mutant['name'];include('actual/mutant-'+name+'-native.log',OUT/('idle-handoff-private-mutant-'+name+'-native.log'));include('actual/mutant-'+name+'-complete-rejected-control.json',Path(mutant['mutant']['reportDirectory'])/'idle-handoff-private-first-control.json');include('actual/strictly-compiled-mutants/'+Path(mutant['mutant']['corePath']).name,Path(mutant['mutant']['corePath']))
include('programs/actual-mutant-control.mjs',Path('/dev/shm/G01-idle-handoff-private-mutants-20261009/actual-control.mjs'))
for name in ['G01-idle-handoff-private-candidate-prepare-20261009.py','G01-idle-handoff-private-candidate-control-20261009.mjs','G01-idle-handoff-private-first-controller-20261009.py','G01-idle-handoff-private-visual-prepare-20261009.py','G01-idle-handoff-private-first-visual-20261009.mjs','G01-idle-handoff-private-first-visual-controller-20261009.py','G01-idle-handoff-private-first-video-decoder-20261009.py','G01-idle-handoff-private-mutants-prepare-20261009.py','G01-idle-handoff-private-mutants-first-controller-20261009.py','G01-idle-handoff-review29-adopt-20261009.py','G01-idle-handoff-review29-proof-handoff-prepare-20261009.py','G01-own-ram-git-object-write-location-20261009.py','G01-a817-immutable-first-official-source-prepare-20261009.py','G01-current-functional-milestone-first-controller-20261009.py']:include('programs/'+name,Path('/dev/shm')/name)
# All newly changed candidate product/source bytes plus full original code,
# contract, rules and reports are retained. Historical media/archives remain
# byte-identical in immutable public a817 and are guarded in complete manifests.
for p in CANDIDATE.rglob('*'):
 if p.is_file() and not p.is_symlink() and 'node_modules' not in p.relative_to(CANDIDATE).parts and p.suffix not in ['.zip','.webm','.png']:include('guarded-private-candidate/'+str(p.relative_to(CANDIDATE)),p)
archive=JOB/'media/absence-idle-handoff-review29-proof.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,raw in sorted(members.items()):
  entry=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,raw)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 for name,raw in members.items():assert z.read(name)==raw
prepared=datetime.datetime.now(datetime.timezone.utc).isoformat();report={'schema':'g01-postgreen-review29-explicit-idle-handoff/1','preparedUtc':prepared,'publishedParent':HEAD,'reviewNumber':29,'fiveWeaknessesRanked':['Explicit active departure after full inactive cycle can leave next human only1000ms','Paused active departure/resume must reset only the new present turn','Connected adaptive idle/empty/remaining-inactive budgets must remain unchanged','Prior Worker response/gain diagnostics remain failed and unqualified; no unchanged timing retry','Finite functional/physical-phone/upstream scope must stay explicit'],'adoptedNarrowPolicy':'Reset idleTurns only on actual connected active-seat departure, or actual resume into declared absent active seat, while unpaused play and at least one present seat remain; then run the unchanged legal absent-seat drain. Ordinary automatic timers, inactive/duplicate metadata, paused/empty behavior and connected whole states are preserved.','adoptedProduct':adoption['adoptedFiles'],'measuredPlayerGain':{'oldHumanWindowMs':1000,'newHumanWindowMs':30000,'additionalHumanWindowMs':29000,'actualOldFailures':480,'actualCorrectedWindows':480,'legalContexts':240,'scope':'Deterministic legal core-event observations; not native browser elapsed time/absence UI-event/performance/hardware measurement. Whole new hosted qualification pending.'},'actualFullPrivateController':control,'actualPrivateFunctionalVisual':visual,'actualWholeCaptureDecode':decoder,'actualIndependentStrictMutationControls':mutants,'fullRawProof':{'path':str(archive.relative_to(JOB)),**identity(archive),'safeUniqueMembers':len(members),'fullCrcAndEveryMemberBytePass':True},'currentFunctionalCapture':{'path':str(publicClip.relative_to(JOB)),**identity(publicClip),'frames':665,'durationSeconds':26.6,'codec':'VP8','scope':'Exact changed candidate page24 trusted actions/private handovers at desktop/phone4x/reduced motion; full665-frame decode. setContent only/no UI absence declaration/file/FPS/physical-phone claim.'},'originalWorkflowStateAtPreparation':'a817 original37946697815/job113874697807 still observed in_progress15:07:27; original32a whole1342 acceptance remains genuine historical initial-repair qualification, never substituted for new timer repair or newest source.','formalReviewCredit':'R29 fix/measure/log completed in this preparation; formal source publication pending actual next guarded normalFF receipt. New repair qualification pending whole current original workflow/native first official artifact. No noGain/Ready credit; next review must wait current whole green.','consecutiveNoPlayerGain':0,'protectedHistory':'Protected Ready11 eadb and canonical Draft1 8c stay unchanged/unmerged; first43 invalid ZIP/stale NEXT, concurrent-build guard failure, actual original9f failed oracle, full-idle480 negatives and first packaging path comparison error remain preserved.','cadence':{'lastActualSourcePush':'2026-10-09T14:46:24.715050+00:00','earlyDeadline':'2026-10-09T15:11:24.715050+00:00','hardDeadline':'2026-10-09T15:16:24.715050+00:00','priorActualHardMissSeconds':697.094261,'nextActualPublication':'Read next source receipt, never backdate'},'storage':'Original objects/files/proofs retained. Only own new reconstructible Git writes use dedicated RAM store/default verified alternates; no original object relocation/deletion or external file change.'};dump(JOB/'absence-idle-handoff-review29.json',report)
prefix='''## Current R29 timer repair: measured and adopted, full new hosted qualification pending

DraftPR20, job/G01-dominoes-queue-audit-20261009. Protected Ready11 eadb and
canonical Draft1 8c stay static/unmerged; full old histories remain below.
Initial32a repair has genuine whole1342 acceptance14:27:04.352304. The first
post-green review found480 real full-idle departure/resume human1000ms failures.
R29 now narrowly resets idle only on explicit active departure or actual resume
into an absent active seat when a present seat remains; automatic idle speed-up,
paused/empty rooms, inactive/duplicate declarations and all connected behavior
are preserved. Core c36e2d6e7ed5877bcbe74726da55faf2b3527351b012defd6841e3052dfd7869.

FIRST private full control closed15:01:46.232632/all10015 fresh source/candidate/
actual importer/runtime aliases unchanged/no signals/group+detached[].
240 real contexts reproduce480 old failures→480 full30000ms windows (+29000ms).
240 whole unattended remainders/88055 strict non-clock physical/RNG/score
comparisons match; max1244311 simulatedms stays inside unchanged3600000 budget.
780 connected-idle full-state/480 paused/480 inactive metadata/240 duplicate/
1020 empty/960 invalid-identity controls pass. All48 original +9 default tests
PASS/no skip; actual old7PASS2FAIL retained. Entire original1003 games/372510
transitions/827 old-engine absence replays and separate1003 fullyconnected
games/377896 WHOLESTATE transitions run twice byte-identically (944B native);
every original oracle/seed/event/physical/scoring/RNG/field/gate remains unchanged.
Three real separately injected ordinary-absence/paused/empty reset bugs strictly
compile then each genuinely fails AssertionError/native1. Mutant controller
closed15:03:57.623477/all13268 fresh aliases/no child; original25 gate unchanged.

Changed page1033446B/92f2e7b91b81db799f04eea233c80fe70a9564f47f7eb34a8042a3cd0481a7a1
passes24 trusted private handovers desktop/phone4x/reduced motion, no HTTP/errors;
visual closed14:56:01.462469/all10015 guards. Actual2969822B/8e6bdcff93610908597b616686d2dd042286e9b835741126c3eb69cf5288c07e
26.6s665VP8 frame clip fully independently decoded14:57:13.518962/all1201 fresh
inputs. These are functional setContent observations, no nativeFPS/file/absence
UI-event/physical-phone claims. Strict adopted rebuild exactly matches this page.

NEXT: finish actual guarded source push/readback and refresh ONLY ownG01 MAIN
row under root serialized lease. Keep Draft20. Accept EVERY original newest
workflow/default test/25 mutants/source/native first WHOLE official artifact/
raw privacy/Worker/browser intervals/full decoder with unchanged6a33 reader.
a817 original37946697815/job113874697807 was still in_progress15:07:27; its exact
206-file RAM partial detached worktree preserves first whole evidence scope if
it closes after publication. Never infer old32a success for new source or hide
actual cancellation/failure. No sampler retry/gate change/extra workflow.
R29 measured +29s gain remains unqualified until newest whole original passes;
no noGain/Ready credit. Then reread/rank5/measure/log/push EACH subsequent review
separately until3 actual player-no-gain rounds; no bundled/private review credit.

Full genuine first controls/default natives/old failures/aliases/actual mutants/
complete framehash/all new candidate code are in absence-idle-handoff-review29
JSON +safe complete media ZIP. Prior media remain exact public a817 bytes; all
are listed and guarded in complete manifests. Historical raw/errors retained.
Last actualsourcea81714:46:24.715050: early15:11:24.715050/hard15:16:24.715050.
Prior source697.094261s hardmiss remains real. Read next actual receipt for new
cadence, never backdate. New Git object writes go to owned RAM via verified
alternates; every original object/source/proof remains untouched.

## Earlier checkpoints and original historical scopes remain below verbatim

''';p=JOB/'NEXT.md';p.write_text(prefix+p.read_text())
append=[('VERIFY.md','R29 narrow explicit-idle handoff repair','python /dev/shm/G01-idle-handoff-private-first-controller-20261009.py: actual480 old1000ms failures→480 new30000ms windows in240 legal contexts;240 entire unattended matches/88055 strict physical/RNG/scoring transitions/max1244311ms<3600000 unchanged budget. All48 original +9 added default regressions PASS/no skip; pre-fix actual7PASS2FAIL retained. Both complete unchanged original1003seed lanes (372510 transitions/827 old absence actions;377896 exact connected whole states) run twice byte-identical944B native. Controller natural15:01:46.232632/all10015 inputs/no child. python /dev/shm/G01-idle-handoff-private-mutants-first-controller-20261009.py:3 real separately injected timer bugs strictly compile then nativeAssertionError1, all13268 fresh guards/no signals/child, natural15:03:57.623477; no original25 mutation change. Actual changed page24 trusted private handovers/3 profiles/all10015 frozen aliases and complete665VP8 decode/all1201 fresh inputs PASS; functional only, no clock installation/FPS/file/absence UI-event/hardware claim. Adopted exact guarded core/page/tests then npm run check; node build.ts --check; node checksums.ts; node checksums.ts --check; git diff --check PASS, full native saved. New current whole original official qualification remains mandatory/pending.'),('REVIEW.md','R29 fix of the first measured worst defect','After original32a green and reread/rank5, worst was explicit active departure after full inactivity. Narrow predicate resets idle only on actual active departure or actual resume into absent active seat with someone present; never ordinary automatic absent turns/paused/empty rooms.240 real contexts+480oldfail/newpass prove29s additional human time, with whole240 games/88055 physical transitions and both exact original1003-seed compatibility lanes;3 actual mutants catch overbroad reset. No native performance inference; currentwhole stillpending/no next formal review until green.'),('ASSUMPTIONS.md','R29 event-context policy and unchanged source/gates','The 30s fresh-human window applies to an explicit active-seat departure/resume into declared active absence, not every timer/automatic absent action. Otherwise repeated idle resets would defeat unattended acceleration. Actual480 legal negatives and overbroad reset mutants justify this narrow policy; all connected/paused/empty/state/scoring/RNG/originalseed/oracle checks remain exact. No browser-native clocks/sampler gates changed. Functional capture exercises genuine rebuilt page trusted actions, not a UI absence-event path. Protected originals and every earlier failure stay exact. Newsource qualification pending; sourcepublication cadence derives only from actual receipts. Small206-file immutable RAM a817 partial worktree comes from existing objects with no remote clone; own RAM write-store alternates smoke passed/default Git reads exact bytes, no existing pack/object/source/proof deleted or moved.')]
for name,heading,body in append:
 p=JOB/name;p.write_text(p.read_text()+'\n## '+heading+'\n'+body+'\n')
p=JOB/'LOOP.md';p.write_text(p.read_text()+'\nR29 | After genuine32a green, reread/rank5 and fix worst full-idle explicit departure/resume:480 real1000ms failures→480 full30000ms windows in240 legal contexts (+29000ms);240 whole unattended matches/88055 physical transitions,57 unfiltered tests, two identical entire1003+1003 compatibility lanes and3 actual strict mutant kills PASS. Exact changed page24 private handovers/full665VP8 decode pass. Adopted/logged source push pending next real receipt; new repair whole hosted qualification pending, no noGain/Ready credit/streak0. Original seeds/oracle/strategy/gates/paused/empty/automatic idle remain unchanged.\n')
p=JOB/'README.md';text=p.read_text().replace('All55 tests/25 mutants/whole1342 checks pass; new full-idle departure defect480 FAIL.','Timer repair57 tests/480 oldfail→newpass and full connected parity pass; newest CI pending.').replace('NEXT.md records the first post-green defect, required fix, retained failures and cadence.','NEXT.md records R29 timer repair, required whole qualification, failures and cadence.');assert len(text.splitlines())<60;p.write_text(text)
receipt={'status':'PASS','preparedUtc':prepared,'sourceParent':HEAD,'adoptedCore':adoption['adoptedFiles']['core.ts'],'wholePrivateControllerNaturalClosure':control['closedUtc'],'measuredGainMs':29000,'realOldFailures':480,'realCorrectedWindows':480,'completeDefaultTests':57,'actualStrictlyCompiledMutantKills':3,'fullRawProof':report['fullRawProof'],'currentFunctionalCapture':report['currentFunctionalCapture'],'formalPublication':'PENDING next actual guarded normalFF source receipt','wholeNewestHostedQualification':'PENDING/no Ready20/no noGain credit'};dump(OUT/'idle-handoff-review29-proof-handoff-preparation-CLOSED.json',receipt);print(json.dumps(receipt))
