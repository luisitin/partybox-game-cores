from pathlib import Path
import subprocess,hashlib,json,datetime
ROOT=Path('/tmp/G01-source-queue-audit-20261009');DEST=Path('/dev/shm/G01-idle-handoff-private-candidate-20261009');HEAD='a81713c23ab6e2a605e2cd34e1b2f11b6cff3fe1';OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');INSTALLED=Path('/workspace/game-cores-G01-queue-audit-20261008/jobs/G01-dominoes/node_modules')
assert not DEST.exists() and subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip()
names=subprocess.check_output(['git','ls-tree','-r','--name-only',HEAD,'--','jobs/G01-dominoes','contract','.github/workflows/G01.yml','README.md','RULES.md','JOBS.md','RUN-ALL.md'],cwd=ROOT,text=True).splitlines()
for name in names:
 src=ROOT/name;raw=src.read_bytes();assert raw==subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT);dest=DEST/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
for prefix in [DEST/'node_modules',DEST/'jobs/G01-dominoes/node_modules']:prefix.symlink_to(INSTALLED,target_is_directory=True)
core=DEST/'jobs/G01-dominoes/core.ts';old=core.read_text();needle=" const next=reduceEvent(s,e);\n return next===s?s:drainAbsent(next,e.now);"
replacement=""" const next=reduceEvent(s,e);
 if(next===s)return s;
 // An explicit active departure, or resuming onto a declared absent active
 // seat, starts a fresh present-human turn. Preserve ordinary automatic idle
 // acceleration: resetting after every absent action would stall empty play.
 const departed=e.type==='player'&&e.connected===false&&e.playerId===s.seats[s.turn]&&s.players[e.playerId]!.connected;
 const resumed=e.type==='vip'&&e.action==='resume'&&!!s.phase.paused;
 const fresh=(departed||resumed)&&next.phase.id==='play'&&!next.phase.paused&&!next.players[next.seats[next.turn]!]!.connected&&next.seats.some(id=>next.players[id]!.connected);
 return drainAbsent(fresh?{...next,idleTurns:0}:next,e.now);"""
assert old.count(needle)==1;core.write_text(old.replace(needle,replacement))
test=DEST/'jobs/G01-dominoes/absence-presence.test.ts';text=test.read_text();text+='''
function fullyIdle(n:number,seed:number):ReturnType<typeof C.init> {
 let s=C.init(context(n,seed,(1<<n)-1,{mode:seed%2?'draw':'block',target:'250',opening:'rotating'}));
 for(let i=0;i<100&&s.phase.id==='play'&&s.idleTurns<n;i++)s=C.reduce(freeze(s),{type:'timer',now:s.phase.deadline!,phaseId:s.phase.id,startedAt:s.phase.startedAt});
 assert.equal(s.phase.id,'play');assert.equal(s.idleTurns,n);assert.equal(s.phase.deadline!-s.phase.startedAt,1000);return s;
}
test('explicit active departure after a legal inactive cycle restores a full human turn',()=>{
 for(const n of [2,3,4])for(const seed of [1,2,3,146,700064]){
  const s=fullyIdle(n,seed),next=C.reduce(freeze(s),{type:'player',now:s.phase.startedAt+1,playerId:s.seats[s.turn]!,connected:false,gone:'left'});
  assert.equal(next.phase.id,'play');assert(next.players[next.seats[next.turn]!]!.connected);assert.equal(next.phase.deadline!-next.phase.startedAt,30000);assert.equal(next.idleTurns,0);assert.deepEqual(next.rng,s.rng);assert.deepEqual([...next.hands.flat(),...next.stock,...next.board.map(t=>t.tile)].sort((a,b)=>a-b),C.allTiles());
 }
});
test('paused active departure after an inactive cycle restores full time only on resume',()=>{
 for(const n of [2,3,4])for(const seed of [1,2,3,146,700064]){
  const s=fullyIdle(n,seed),paused=C.reduce(freeze(s),{type:'vip',now:s.phase.startedAt+1,action:'pause'}),dropped=C.reduce(freeze(paused),{type:'player',now:s.phase.startedAt+2,playerId:s.seats[s.turn]!,connected:false});
  assert.deepEqual(dropped.phase,paused.phase);assert.deepEqual(dropped.board,paused.board);assert.equal(dropped.idleTurns,n);
  const resumed=C.reduce(freeze(dropped),{type:'vip',now:s.phase.startedAt+101,action:'resume'});assert.equal(resumed.phase.id,'play');assert(resumed.players[resumed.seats[resumed.turn]!]!.connected);assert.equal(resumed.phase.deadline!-resumed.phase.startedAt,30000);assert.equal(resumed.idleTurns,0);assert.deepEqual(resumed.rng,s.rng);
 }
});
''';test.write_text(text)
receipt={'status':'PREPARED_NOT_TESTED','preparedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'publishedParent':HEAD,'candidateRoot':str(DEST),'copiedSourceFiles':len(names),'modifiedFiles':['core.ts','absence-presence.test.ts'],'scope':'Private unadopted candidate, no qualified gain/formal review credit. Explicit active departure/resume only; no unconditional automatic absence reset.','core':{'bytes':core.stat().st_size,'sha256':hashlib.sha256(core.read_bytes()).hexdigest()}}
(OUT/'idle-handoff-candidate-preparation-CLOSED.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
