from pathlib import Path
import datetime,json,os,shutil,subprocess,time,signal,re,hashlib
ROOT=Path('/tmp/G01-source-queue-audit-20261009');CANDIDATE=Path('/dev/shm/G01-idle-handoff-private-candidate-20261009');JOB=CANDIDATE/'jobs/G01-dominoes';OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');ORIGINAL=Path('/dev/shm/G01-current-functional-milestone-first-controller-20261009.py');HELPER=Path('/dev/shm/G01-idle-handoff-private-candidate-control-20261009.mjs');HEAD='a81713c23ab6e2a605e2cd34e1b2f11b6cff3fe1';RECEIPT=OUT/'idle-handoff-private-first-CLOSED.json';BOUND=840
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
scope={'__file__':str(ORIGINAL)};program=ORIGINAL.read_text().split("r={'schema':'g01-current-functional-milestone-controller/1'")[0];exec(compile(program,str(ORIGINAL),'exec'),scope);scope.update({'HEAD':HEAD,'__file__':__file__,'HELPER':HELPER});base=scope['snapshot'];track=scope['track'];group=scope['group'];alias=scope['alias']
def snapshot():
 r=base();paths=[ORIGINAL,Path('/dev/shm/G01-idle-handoff-private-candidate-prepare-20261009.py'),OUT/'postgreen-idle-departure-first.json'];installed=Path(r['installedRoot']);inventory=[]
 for p in CANDIDATE.rglob('*'):
  if p.is_file() and 'node_modules' not in p.relative_to(CANDIDATE).parts:paths.append(p);inventory.append(str(p.relative_to(CANDIDATE)))
 for prefix in [ROOT/'node_modules',ROOT/'jobs/G01-dominoes/node_modules',CANDIDATE/'node_modules',JOB/'node_modules']:
  assert prefix.resolve(strict=True)==installed.resolve(strict=True)
  paths.extend(prefix/p.relative_to(installed) for p in installed.rglob('*') if p.is_file())
 r['candidateInventory']=sorted(inventory);r['freshActualImporterAndCandidateAliases']={str(p):alias(p) for p in paths};return r
r={'schema':'g01-idle-handoff-private-first-controller/1','startedUtc':stamp(),'publishedParent':HEAD,'candidateRoot':str(CANDIDATE),'wholeBoundSeconds':BOUND,'scope':'First unadopted narrow timer repair. Full480 oldfail/newpass real contexts, physical/idle-budget controls; new9 default regressions against candidate and actual pre-fix source (old7PASS2FAIL expected); both entire original1003-seed compatibility lanes twice; original48 default node tests. No FAST_TEST, skips or native/browser clock/sample. Fresh all current/candidate/importer/dependency/runtime aliases protected before and after.','commands':[],'signalsSent':[]};child=None
try:
 assert not RECEIPT.exists();before=snapshot();(OUT/'idle-handoff-private-first-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');deadline=time.monotonic()+BOUND
 specs=[('new-control',[shutil.which('node'),str(HELPER)],{},0),('new-default9',[shutil.which('node'),'--test','absence-presence.test.ts'],{},0),('old-default9',[shutil.which('node'),'--test','absence-presence.test.ts'],{'ABSENCE_CORE_PATH':str(ROOT/'jobs/G01-dominoes/core.ts')},1),('compatibility1',[shutil.which('node'),'total-compatibility.ts'],{},0),('compatibility2',[shutil.which('node'),'total-compatibility.ts'],{},0),('original-default48',[shutil.which('node'),'--test','test.ts'],{},0)]
 for name,argv,extra,expected in specs:
  logpath=OUT/('idle-handoff-private-first-'+name+'-native.log');assert not logpath.exists();command={'name':name,'argv':argv,'envOverrides':extra,'expectedNativeExit':expected,'startedUtc':stamp(),'nativePath':str(logpath)};r['commands'].append(command);env=dict(os.environ,TMPDIR=str(OUT));assert not env.get('FAST_TEST') and not env.get('CORE_PATH') and not env.get('ABSENCE_CORE_PATH');env.update(extra)
  with logpath.open('xb') as log:
   child=subprocess.Popen(argv,cwd=JOB,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);command['childPid']=child.pid
   while child.poll() is None:
    track(child.pid)
    if time.monotonic()>=deadline:raise subprocess.TimeoutExpired(argv,BOUND)
    time.sleep(.1)
  command['exitCode']=child.returncode;command['closedUtc']=stamp();raw=logpath.read_bytes();command.update({'nativeBytes':len(raw),'nativeSha256':hashlib.sha256(raw).hexdigest()});assert child.returncode==expected,(name,child.returncode,raw[-1800:].decode(errors='replace'));assert not group(child.pid) and not track(child.pid)
  text=raw.decode()
  if name in ['new-default9','old-default9','original-default48']:
   counts={key:[int(v) for v in re.findall(r'^ℹ '+key+r' (\d+)\s*$',text,re.M)] for key in ['tests','pass','fail','cancelled','skipped','todo']};expectedCounts={'new-default9':(9,9,0),'old-default9':(9,7,2),'original-default48':(48,48,0)}[name]
   assert counts['tests']==[expectedCounts[0]] and counts['pass']==[expectedCounts[1]] and counts['fail']==[expectedCounts[2]] and all(counts[key]==[0] for key in ['cancelled','skipped','todo']),counts;command['wholeNativeCounts']=counts;command['scope']='Actual expected pre-fix product rejection, not a passed game gate' if expected else 'Actual complete unfiltered default Node suite PASS'
  elif name.startswith('compatibility'):
   command['entireOriginalReport']=json.loads(text);assert command['entireOriginalReport']['games']==1003 and command['entireOriginalReport']['connectedGames']==1003 and command['entireOriginalReport']['connectedWholeStateMismatches']==0
   if name=='compatibility2':assert raw==(OUT/'idle-handoff-private-first-compatibility1-native.log').read_bytes();r['bothOriginalCompleteReportsByteIdentical']=True
 actual=json.loads((OUT/'idle-handoff-private-first-control.json').read_text());assert actual['status']=='PASS' and actual['oldFailures']==actual['newFullHumanWindows']==480 and actual['wholeInactiveMatches']==240
 after=snapshot();(OUT/'idle-handoff-private-first-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Frozen current/candidate/actual-importer input drift';r.update({'allFrozenInputsUnchanged':True,'frozenAliasCount':len(before['aliases'])+len(before['freshActualImporterAndCandidateAliases']),'candidateFiles':len(before['candidateInventory']),'actualControl':{k:v for k,v in actual.items() if k!='rows'},'status':'PASS','exitCode':0})
except BaseException as e:r.update({'status':'FAIL','exitCode':1,'errorType':type(e).__name__,'error':str(e)})
finally:
 if child is not None:
  live=track(child.pid)
  if child.poll() is None or live:
   try:os.killpg(child.pid,signal.SIGTERM);r['signalsSent'].append('SIGTERM owned group')
   except ProcessLookupError:pass
   for proc in live:
    try:os.kill(proc['pid'],signal.SIGTERM);r['signalsSent'].append('SIGTERM exact owned detached '+str(proc['pid']))
    except ProcessLookupError:pass
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);r['signalsSent'].append('SIGKILL owned group');child.wait(timeout=10)
  r['remainingOwnedChildren']=group(child.pid);r['remainingOwnedDetached']=track(child.pid)
 else:r['remainingOwnedChildren']=[];r['remainingOwnedDetached']=[]
 r['naturalClosure']=child is not None and not r['signalsSent'] and not r['remainingOwnedChildren'] and not r['remainingOwnedDetached']
 if not r['naturalClosure']:r.update({'status':'FAIL','exitCode':1})
 r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(r['exitCode'])
