from pathlib import Path
import subprocess,hashlib,json,datetime,os
ROOT=Path('/tmp/G01-source-queue-audit-20261009');JOB=ROOT/'jobs/G01-dominoes';CANDIDATE=Path('/dev/shm/G01-idle-handoff-private-candidate-20261009/jobs/G01-dominoes');OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');HEAD='a81713c23ab6e2a605e2cd34e1b2f11b6cff3fe1';NATIVE=[];RECEIPT=OUT/'idle-handoff-review29-adoption-CLOSED.json'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(argv):
 r=subprocess.run(argv,cwd=JOB,capture_output=True,text=True,env=dict(os.environ,TMPDIR=str(OUT)));NATIVE.append({'argv':argv,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'closedUtc':stamp()});assert r.returncode==0,(argv,r.stderr);return r.stdout
r={'startedUtc':stamp(),'publishedParent':HEAD,'scope':'Adopt only byte-identical actual guarded private candidate core, two default regressions and freshly built page after all own candidate/control/capture/decoder/mutant children naturally closed. Existing strategy/oracle/default pipeline/workflow/native clocks and gates unchanged; hosted current whole qualification pending.'}
try:
 assert not RECEIPT.exists() and subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==HEAD and not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT,text=True).strip()
 for name in ['idle-handoff-private-first-CLOSED.json','idle-handoff-private-first-visual-CLOSED.json','idle-handoff-private-first-video-decode-CLOSED.json','idle-handoff-private-mutants-first-CLOSED.json']:
  proof=json.loads((OUT/name).read_text());assert proof['status']=='PASS' and proof['naturalClosure'] and not proof['remainingOwnedChildren'] and not proof['remainingOwnedDetached'] and not proof['signalsSent']
 immutable=json.loads((OUT/'a817-immutable-first-official-source-CLOSED.json').read_text());assert immutable['status']=='PASS' and immutable['allGitAndCurrentBytesIdentical']
 for name in ['core.ts','absence-presence.test.ts','play.html']:(JOB/name).write_bytes((CANDIDATE/name).read_bytes())
 assert hashlib.sha256((JOB/'core.ts').read_bytes()).hexdigest()=='c36e2d6e7ed5877bcbe74726da55faf2b3527351b012defd6841e3052dfd7869';run(['npm','run','check']);run(['node','build.ts','--check']);run(['node','checksums.ts']);run(['node','checksums.ts','--check']);run(['git','diff','--check'])
 changed=subprocess.check_output(['git','diff','--name-only',HEAD],cwd=ROOT,text=True).splitlines();assert set(changed)=={'jobs/G01-dominoes/core.ts','jobs/G01-dominoes/absence-presence.test.ts','jobs/G01-dominoes/play.html','jobs/G01-dominoes/SHA256SUMS.txt'},changed
 r.update({'status':'PASS','exitCode':0,'adoptedFiles':{name:{'bytes':(JOB/name).stat().st_size,'sha256':hashlib.sha256((JOB/name).read_bytes()).hexdigest()} for name in ['core.ts','absence-presence.test.ts','play.html']},'allAdoptedProductBytesMatchGuardedPrivateCandidate':True,'changedFiles':changed})
except BaseException as e:r.update({'status':'FAIL','exitCode':1,'errorType':type(e).__name__,'error':str(e)})
r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');(OUT/'idle-handoff-review29-adoption-native.log').write_text(json.dumps(NATIVE,indent=2)+'\n');print(json.dumps(r));raise SystemExit(r['exitCode'])
