import * as C from '/dev/shm/G01-idle-handoff-private-candidate-20261009/jobs/G01-dominoes/core.ts';
import * as O from '/tmp/G01-source-queue-audit-20261009/jobs/G01-dominoes/core.ts';
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
const OUT='/dev/shm/G01-private-remaining-issue-20261009',negative=JSON.parse(readFileSync(OUT+'/postgreen-idle-departure-first.json','utf8'));
const report={schema:'g01-idle-handoff-private-first-control/1',status:'STARTED',startedUtc:new Date().toISOString(),publishedBefore:'a81713c23ab6e2a605e2cd34e1b2f11b6cff3fe1',candidateRoot:'/dev/shm/G01-idle-handoff-private-candidate-20261009',scope:'New private deterministic event control, no native/browser timing. Compare genuine pre-fix480 failures against narrow explicit departure/resume repair. All normal connected timers/counters remain exact; full physical/RNG/scoring states and inactive budgets checked.',cases:0,oldFailures:0,newFullHumanWindows:0,fullConnectedWholeStateControls:0,pausedUnchangedControls:0,inactiveMetadataExactControls:0,duplicateAbsenceExactControls:0,emptyExactControls:0,invalidIdentityControls:0,wholeInactiveMatches:0,wholePhysicalTransitions:0,budgetMs:C.manifest.estimatedMinutes*3*60000,maximumCandidateInactiveMs:0,rows:[]};
const save=()=>writeFileSync(OUT+'/idle-handoff-private-first-control.json',JSON.stringify(report,null,2)+'\n');save();
const frozen=x=>{if(x&&typeof x==='object'){Object.freeze(x);for(const v of Object.values(x))frozen(v);}return x;};
const physical=s=>{const {idleTurns,phase,...rest}=s;return {...rest,phase:{...phase,startedAt:null,deadline:null}};};
const sameNow=s=>{const {idleTurns,phase,...rest}=s;return {...rest,phase:{...phase,deadline:null}};};
const inventory=s=>assert.deepEqual([...s.hands.flat(),...s.stock,...s.board.map(t=>t.tile)].sort((a,b)=>a-b),C.allTiles());
try{
 assert.equal(negative.status,'FAIL_CURRENT_POLICY');assert.equal(negative.failures.length,480);assert.equal(negative.rows.length,240);
 for(const original of negative.rows){
  report.cases++;let s=C.init(original.context),o=O.init(original.context);assert.deepEqual(s,o);
  for(const event of original.events){s=C.reduce(frozen(s),event);o=O.reduce(frozen(o),event);assert.deepEqual(s,o);report.fullConnectedWholeStateControls++;}
  assert.deepEqual(s,original.idleState);assert.equal(s.idleTurns,s.seats.length);assert.equal(s.phase.deadline-s.phase.startedAt,1000);
  const row={case:report.cases,n:s.seats.length,seed:original.context.seed,settings:original.context.settings};report.rows.push(row);
  const departed=C.reduce(frozen(s),original.departure.event);const oldDeparted=O.reduce(frozen(o),original.departure.event);assert.deepEqual(oldDeparted,original.departure.state);assert.equal(oldDeparted.phase.deadline-oldDeparted.phase.startedAt,1000);report.oldFailures++;
  assert.equal(departed.phase.id,'play');assert(departed.players[departed.seats[departed.turn]].connected);assert.equal(departed.phase.deadline-departed.phase.startedAt,30000);assert.equal(departed.idleTurns,0);assert.deepEqual(sameNow(departed),sameNow(oldDeparted));inventory(departed);report.newFullHumanWindows++;row.direct={oldMs:1000,newMs:30000,phaseStartedAt:departed.phase.startedAt};
  let p=s,oldP=o;for(const event of original.paused.events.slice(0,2)){p=C.reduce(frozen(p),event);oldP=O.reduce(frozen(oldP),event);assert.deepEqual(p,oldP);report.pausedUnchangedControls++;}
  assert.deepEqual(p,original.paused.dropped);const resumed=C.reduce(frozen(p),original.paused.events[2]),oldResumed=O.reduce(frozen(oldP),original.paused.events[2]);assert.deepEqual(oldResumed,original.paused.resumed);assert.equal(oldResumed.phase.deadline-oldResumed.phase.startedAt,1000);report.oldFailures++;
  assert.equal(resumed.phase.id,'play');assert(resumed.players[resumed.seats[resumed.turn]].connected);assert.equal(resumed.phase.deadline-resumed.phase.startedAt,30000);assert.equal(resumed.idleTurns,0);assert.deepEqual(sameNow(resumed),sameNow(oldResumed));inventory(resumed);report.newFullHumanWindows++;row.pausedResume={oldMs:1000,newMs:30000,phaseStartedAt:resumed.phase.startedAt};
  for(const event of [{type:'player',playerId:s.seats[s.turn],connected:true,now:s.phase.startedAt+1},{type:'player',playerId:s.seats[(s.turn+1)%s.seats.length],connected:false,now:s.phase.startedAt+1}]){assert.deepEqual(C.reduce(s,event),O.reduce(o,event));report.inactiveMetadataExactControls++;}
  const duplicate={...original.departure.event,now:departed.phase.startedAt+1};assert.deepEqual(C.reduce(departed,duplicate),O.reduce(departed,duplicate));report.duplicateAbsenceExactControls++;
  for(const event of [{type:'timer',now:s.phase.deadline-1,phaseId:s.phase.id,startedAt:s.phase.startedAt},{type:'timer',now:s.phase.deadline,phaseId:s.phase.id,startedAt:s.phase.startedAt-1},{type:'player',playerId:'missing',connected:false,now:s.phase.startedAt+1},{type:'player',playerId:s.seats[s.turn],connected:false,now:NaN}]){assert.equal(C.reduce(s,event),s);assert.equal(O.reduce(o,event),o);report.invalidIdentityControls++;}
  // Build a legal empty room while paused, then resume. No human gets a new
  // turn and no fresh counter reset is allowed; compare every field exactly.
  let empty=C.reduce(s,{type:'vip',action:'pause',now:s.phase.startedAt+1}),oldEmpty=O.reduce(o,{type:'vip',action:'pause',now:s.phase.startedAt+1});
  for(const id of s.seats){const event={type:'player',playerId:id,connected:false,now:s.phase.startedAt+2};empty=C.reduce(empty,event);oldEmpty=O.reduce(oldEmpty,event);assert.deepEqual(empty,oldEmpty);report.emptyExactControls++;}
  const emptyResume={type:'vip',action:'resume',now:s.phase.startedAt+102};assert.deepEqual(C.reduce(empty,emptyResume),O.reduce(oldEmpty,emptyResume));report.emptyExactControls++;
  // A whole unattended remainder after the single explicit departure must
  // still accelerate by real Timer events. Each engine uses its own genuine
  // deadline: compare every non-clock physical/state field and final result.
  let current=departed,prior=oldDeparted,steps=0;const firstTimer={type:'timer',now:current.phase.deadline,phaseId:current.phase.id,startedAt:current.phase.startedAt},oldFirst={type:'timer',now:prior.phase.deadline,phaseId:prior.phase.id,startedAt:prior.phase.startedAt};
  current=C.reduce(frozen(current),firstTimer);prior=O.reduce(frozen(prior),oldFirst);assert.equal(current.idleTurns,1);assert.deepEqual(physical(current),physical(prior));report.wholePhysicalTransitions++;
  while(current.phase.id!=='done'&&steps++<20000){assert.equal(current.phase.id,prior.phase.id);const event={type:'timer',now:current.phase.deadline,phaseId:current.phase.id,startedAt:current.phase.startedAt},oldEvent={type:'timer',now:prior.phase.deadline,phaseId:prior.phase.id,startedAt:prior.phase.startedAt};current=C.reduce(frozen(current),event);prior=O.reduce(frozen(prior),oldEvent);assert.deepEqual(physical(current),physical(prior));inventory(current);report.wholePhysicalTransitions++;}
  assert.equal(current.phase.id,'done');assert.equal(prior.phase.id,'done');assert.deepEqual(C.results(current),O.results(prior));assert(current.phase.startedAt<=report.budgetMs);assert(prior.phase.startedAt<=report.budgetMs);report.wholeInactiveMatches++;report.maximumCandidateInactiveMs=Math.max(report.maximumCandidateInactiveMs,current.phase.startedAt);row.inactiveRemainder={steps:steps+1,oldMs:prior.phase.startedAt,newMs:current.phase.startedAt,results:C.results(current)};
 }
 assert.equal(report.oldFailures,480);assert.equal(report.newFullHumanWindows,480);assert.equal(report.wholeInactiveMatches,240);report.status='PASS';report.finishedUtc=new Date().toISOString();save();console.log(JSON.stringify({...report,rows:undefined}));
}catch(error){report.status='FAIL';report.failure={name:error.name,message:error.message,stack:error.stack};report.finishedUtc=new Date().toISOString();save();throw error;}
