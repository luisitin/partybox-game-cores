from pathlib import Path
import datetime,json,os,shutil,subprocess,time,signal,hashlib
ORIGINAL=Path('/dev/shm/G01-idle-handoff-private-first-controller-20261009.py');scope={'__file__':str(ORIGINAL)};program=ORIGINAL.read_text().split("r={'schema':'g01-idle-handoff-private-first-controller/1'")[0];exec(compile(program,str(ORIGINAL),'exec'),scope)
OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');ROOT=Path('/dev/shm/G01-idle-handoff-private-mutants-20261009');JOB=ROOT/'jobs/G01-dominoes';PREP=OUT/'idle-handoff-private-mutants-preparation-CLOSED.json';RECEIPT=OUT/'idle-handoff-private-mutants-first-CLOSED.json';base=scope['snapshot'];alias=scope['alias'];group=scope['group'];track=scope['track'];BOUND=180
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snapshot():
 r=base();installed=Path(r['installedRoot']);paths=[Path(__file__),ORIGINAL,PREP,Path('/dev/shm/G01-idle-handoff-private-mutants-prepare-20261009.py')];paths.extend(p for p in ROOT.rglob('*') if p.is_file() and 'node_modules' not in p.relative_to(ROOT).parts)
 for p in (Path('/dev/shm/G01-idle-handoff-private-candidate-20261009')/'contract').rglob('*'):
  if p.is_file():paths.append(ROOT/'contract'/p.relative_to(Path('/dev/shm/G01-idle-handoff-private-candidate-20261009')/'contract'))
 for prefix in [ROOT/'node_modules',JOB/'node_modules']:
  assert prefix.resolve(strict=True)==installed.resolve(strict=True);paths.extend(prefix/p.relative_to(installed) for p in installed.rglob('*') if p.is_file())
 r['freshMutantAliases']={str(p):alias(p) for p in paths};return r
r={'schema':'g01-idle-handoff-private-first-actual-mutants/1','startedUtc':stamp(),'scope':'Three real separately injected, strictly compiled timer policy bugs must be rejected by the complete actual first control. Expected native failures are mutant kills, not passing game gates. Original25 mutation gate remains unchanged. No source mutation or browser/native timing.','wholeBoundSeconds':BOUND,'signalsSent':[],'commands':[]};child=None
try:
 assert not RECEIPT.exists();private=json.loads((OUT/'idle-handoff-private-first-CLOSED.json').read_text());assert private['status']=='PASS' and private['naturalClosure'] and private['allFrozenInputsUnchanged'];prep=json.loads(PREP.read_text());assert prep['status']=='PREPARED_UNEXECUTED';before=snapshot();(OUT/'idle-handoff-private-mutants-first-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');deadline=time.monotonic()+BOUND
 compiler=Path(before['installedRoot'])/'typescript/bin/tsc';compileArgs=[shutil.which('node'),str(compiler),'--noEmit','--strict','--target','ES2022','--module','ES2022','--moduleResolution','bundler','--allowImportingTsExtensions','--skipLibCheck','--lib','ES2022,DOM,DOM.Iterable',*[m['corePath'] for m in prep['mutants']]];specs=[('strict-all3',compileArgs,{},0,None)]
 for mutant in prep['mutants']:specs.append((mutant['name'],[shutil.which('node'),prep['helper']],{'G01_MUTANT_CORE':mutant['corePath'],'G01_MUTANT_OUTPUT':mutant['reportDirectory']},1,mutant))
 kills=[]
 for name,argv,extra,expected,mutant in specs:
  logpath=OUT/('idle-handoff-private-mutant-'+name+'-native.log');assert not logpath.exists();command={'name':name,'argv':argv,'envOverrides':extra,'expectedNativeExit':expected,'startedUtc':stamp()};r['commands'].append(command)
  with logpath.open('xb') as log:
   child=subprocess.Popen(argv,cwd=JOB,env=dict(os.environ,TMPDIR=str(OUT),**extra),stdout=log,stderr=subprocess.STDOUT,start_new_session=True);command['childPid']=child.pid
   while child.poll() is None:
    track(child.pid)
    if time.monotonic()>=deadline:raise subprocess.TimeoutExpired(argv,BOUND)
    time.sleep(.1)
  command['closedUtc']=stamp();command['exitCode']=child.returncode;native=logpath.read_bytes();command['fullNativeIdentity']={'bytes':len(native),'sha256':hashlib.sha256(native).hexdigest()};assert child.returncode==expected,(name,child.returncode,native[-1200:].decode(errors='replace'));assert not group(child.pid) and not track(child.pid)
  if mutant:
   actual=json.loads((Path(mutant['reportDirectory'])/'idle-handoff-private-first-control.json').read_text());assert actual['status']=='FAIL' and actual['failure']['name']=='AssertionError';assert actual['actualMutantCore']==mutant['corePath'];kills.append({'name':name,'mutant':mutant,'actualRejectedProductControl':{k:v for k,v in actual.items() if k!='rows'},'native':command['fullNativeIdentity'],'nativeExitCode':child.returncode})
 after=snapshot();(OUT/'idle-handoff-private-mutants-first-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Frozen current/candidate/mutant/actual importer/runtime drift';assert len(kills)==3;r.update({'status':'PASS','exitCode':0,'actualStrictlyCompiledMutationKills':kills,'allFrozenInputsUnchanged':True,'frozenAliasCount':len(before['aliases'])+len(before['freshActualImporterAndCandidateAliases'])+len(before['freshMutantAliases'])})
except BaseException as e:r.update({'status':'FAIL','exitCode':1,'errorType':type(e).__name__,'error':str(e)})
finally:
 if child is not None:
  live=track(child.pid)
  if child.poll() is None or live:
   try:os.killpg(child.pid,signal.SIGTERM);r['signalsSent'].append('SIGTERM owned group')
   except ProcessLookupError:pass
   for proc in live:
    try:os.kill(proc['pid'],signal.SIGTERM);r['signalsSent'].append('SIGTERM exact owned detached '+str(proc['pid']))
    except ProcessLookupError:pass
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);r['signalsSent'].append('SIGKILL owned group');child.wait(timeout=10)
  r['remainingOwnedChildren']=group(child.pid);r['remainingOwnedDetached']=track(child.pid)
 else:r['remainingOwnedChildren']=[];r['remainingOwnedDetached']=[]
 r['naturalClosure']=child is not None and not r['signalsSent'] and not r['remainingOwnedChildren'] and not r['remainingOwnedDetached']
 if not r['naturalClosure']:r.update({'status':'FAIL','exitCode':1})
 r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k!='actualStrictlyCompiledMutationKills'}|{'actualStrictlyCompiledMutationKills':[{k:v for k,v in kill.items() if k!='actualRejectedProductControl'} for kill in r.get('actualStrictlyCompiledMutationKills',[])]}))
raise SystemExit(r['exitCode'])
