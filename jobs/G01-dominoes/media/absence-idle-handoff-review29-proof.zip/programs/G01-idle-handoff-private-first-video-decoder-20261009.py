from pathlib import Path
import datetime,json,os,shutil,subprocess,time,signal,re,hashlib,sys,sysconfig
OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');ORIGINAL=Path('/dev/shm/G01-current-functional-milestone-first-controller-20261009.py');VISUAL=OUT/'idle-handoff-private-first-visual-CLOSED.json';REPORT=OUT/'idle-handoff-private-first-visual/report.json';RECEIPT=OUT/'idle-handoff-private-first-video-decode-CLOSED.json';FRAMEHASH=OUT/'idle-handoff-private-first-complete-framehash.txt';BOUND=90
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
scope={'__file__':str(ORIGINAL)};program=ORIGINAL.read_text().split("r={'schema':'g01-current-functional-milestone-controller/1'")[0];exec(compile(program,str(ORIGINAL),'exec'),scope);alias=scope['alias'];track=scope['track'];group=scope['group']
r={'schema':'g01-idle-handoff-private-first-whole-video-decode/1','startedUtc':stamp(),'scope':'Whole new private candidate source-bound native functional capture independent full decode. Export25fps is not a native performance measurement; no timing/FPS/gain claim.','wholeBoundSeconds':BOUND,'signalsSent':[],'commands':[]};child=None
try:
 assert not RECEIPT.exists() and not FRAMEHASH.exists();visual=json.loads(VISUAL.read_text());assert visual['status']=='PASS' and visual['naturalClosure'] and visual['allFrozenInputsUnchanged'] and not visual['remainingOwnedChildren'] and not visual['remainingOwnedDetached'];report=json.loads(REPORT.read_text());video=report['cases'][0]['video'];CLIP=Path(video['path']);raw=CLIP.read_bytes();assert len(raw)==video['bytes'] and hashlib.sha256(raw).hexdigest()==video['sha256'] and len(raw)<10000000
 paths={CLIP,REPORT,VISUAL,Path(__file__),ORIGINAL,Path(sys.executable),Path(shutil.which('ffmpeg')),Path(shutil.which('ffprobe'))}
 for binary in [Path(sys.executable),Path(shutil.which('ffmpeg')),Path(shutil.which('ffprobe'))]:
  native=subprocess.run(['ldd',str(binary.resolve())],capture_output=True,text=True)
  for name in re.findall(r'(/[A-Za-z0-9_./+\-]+)',native.stdout):
   if Path(name).is_file():paths.add(Path(name))
 for p in Path(sysconfig.get_path('stdlib')).rglob('*'):
  if 'site-packages' not in p.parts and p.is_file():paths.add(p)
 for m in list(sys.modules.values()):
  for key in ['__file__','__cached__']:
   p=getattr(m,key,None)
   if p and Path(p).is_file():paths.add(Path(p))
 for folder in [Path(sysconfig.get_path('purelib')),Path(sysconfig.get_path('platlib'))]:
  if folder.is_dir():paths.update(folder.glob('*.pth'))
 freeze=lambda:{str(p):alias(p) for p in sorted(paths)};before=freeze();(OUT/'idle-handoff-private-first-video-decode-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');deadline=time.monotonic()+BOUND
 specs=[('ffprobe',[shutil.which('ffprobe'),'-v','error','-select_streams','v:0','-count_frames','-show_entries','stream=codec_name,width,height,r_frame_rate,nb_read_frames:format=duration,size','-of','json',str(CLIP)]),('ffmpeg',[shutil.which('ffmpeg'),'-v','error','-i',str(CLIP),'-map','0:v:0','-f','framehash','-hash','sha256',str(FRAMEHASH)])]
 for name,argv in specs:
  logpath=OUT/('idle-handoff-private-first-whole-'+name+'-native.log');assert not logpath.exists();command={'argv':argv,'startedUtc':stamp(),'nativePath':str(logpath)};r['commands'].append(command)
  with logpath.open('xb') as log:
   child=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=dict(os.environ,TMPDIR=str(OUT)));command['childPid']=child.pid
   while child.poll() is None:
    track(child.pid)
    if time.monotonic()>=deadline:raise subprocess.TimeoutExpired(argv,BOUND)
    time.sleep(.1)
  command['closedUtc']=stamp();command['exitCode']=child.returncode;assert child.returncode==0;assert not group(child.pid) and not track(child.pid)
 metadata=json.loads((OUT/'idle-handoff-private-first-whole-ffprobe-native.log').read_text());stream=metadata['streams'][0];frames=[line for line in FRAMEHASH.read_text().splitlines() if line and not line.startswith('#')];assert stream['codec_name']=='vp8' and stream['width']==390 and stream['height']==844 and len(frames)==int(stream['nb_read_frames'])>0;assert int(metadata['format']['size'])==len(raw)
 after=freeze();(OUT/'idle-handoff-private-first-video-decode-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Immutable clip/report/decoder/runtime alias drift';r.update({'status':'PASS','exitCode':0,'metadata':metadata,'frames':len(frames),'clip':video,'completeFramehash':{'bytes':FRAMEHASH.stat().st_size,'sha256':hashlib.sha256(FRAMEHASH.read_bytes()).hexdigest()},'allFreshInputAliasesUnchanged':True,'frozenAliasCount':len(before)})
except BaseException as e:r.update({'status':'FAIL','exitCode':1,'errorType':type(e).__name__,'error':str(e)})
finally:
 if child is not None:
  live=track(child.pid)
  if child.poll() is None or live:
   try:os.killpg(child.pid,signal.SIGTERM);r['signalsSent'].append('SIGTERM owned group')
   except ProcessLookupError:pass
   for proc in live:
    try:os.kill(proc['pid'],signal.SIGTERM);r['signalsSent'].append('SIGTERM exact owned detached '+str(proc['pid']))
    except ProcessLookupError:pass
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);r['signalsSent'].append('SIGKILL owned group');child.wait(timeout=10)
  r['remainingOwnedChildren']=group(child.pid);r['remainingOwnedDetached']=track(child.pid)
 else:r['remainingOwnedChildren']=[];r['remainingOwnedDetached']=[]
 r['naturalClosure']=child is not None and not r['signalsSent'] and not r['remainingOwnedChildren'] and not r['remainingOwnedDetached']
 if not r['naturalClosure']:r.update({'status':'FAIL','exitCode':1})
 r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(r['exitCode'])
