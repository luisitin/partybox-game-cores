import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
const oldRoot=process.argv[2],newRoot=process.argv[4];
const O=await import(path.join(oldRoot,'jobs/G01-dominoes/core.ts')),N=await import(path.join(newRoot,'jobs/G01-dominoes/core.ts')),{createRng}=await import(path.join(oldRoot,'contract/rng.ts'));
const freeze=x=>{if(x&&typeof x==='object'){Object.freeze(x);for(const v of Object.values(x))freeze(v);}return x;};
const physical=s=>({rng:s.rng,seats:s.seats,settings:s.settings,hands:s.hands,stock:s.stock,board:s.board,ends:s.ends,turn:s.turn,starter:s.starter,forced:s.forced,round:s.round,passes:s.passes,scores:s.scores,missed:s.missed,history:s.history,last:s.last,phaseId:s.phase.id});
const rows=[];let assertions=0,checkpoints=0,oldAutomaticEvents=0,active=null;
const eq=(a,b,m)=>{assertions++;assert.deepEqual(a,b,m);},ok=(x,m)=>{assertions++;assert(x,m);};
process.on('uncaughtException',e=>{fs.writeFileSync(process.argv[3],JSON.stringify({status:'FAIL',message:e.message,stack:e.stack,assertions,checkpoints,oldAutomaticEvents,rows,active},null,2)+'\n');console.error(e.stack);process.exitCode=1;});
for(const n of [2,3,4])for(const partners of n===4?[false,true]:[false])for(const mode of ['draw','block'])for(const target of ['100','150','250'])for(const seed of [1,2,3,700064,146,991])for(let present=0;present<n;present++){
 const settings={mode,target,partners,deal:seed%2?'block-sized':'traditional',reserve:seed%3?'0':'2',opening:seed%2?'rotating':'highest-double',blocked:seed%2?'difference':'opponents',teamPoints:seed%2?'opponents':'all'};
 const players=Array.from({length:n},(_,i)=>({id:`p${i}`,name:`Player ${i+1}`,avatarId:'plain',connected:i===present,bot:false}));
 const context={players,settings,seed,now:0};let old=O.init(context),next=N.init(context),turns=0;
 active={context,old,next,oldEvents:[],newEvents:[]};
 const settle=()=>{let actions=0;while(old.phase.id==='play'&&!old.players[old.seats[old.turn]].connected){const e={type:'timer',now:old.phase.deadline,phaseId:old.phase.id,startedAt:old.phase.startedAt};active.oldEvents.push(e);old=O.reduce(freeze(old),e);oldAutomaticEvents++;ok(++actions<=28+n,'independent original missing-seat bound');}active.old=old;};
 while(next.phase.id!=='done'&&turns<12000){
  settle();eq(physical(next),physical(old),'same physical checkpoint and scoring');checkpoints++;
  if(next.phase.id==='play'){
   eq(next.turn,present,'present seat can act');eq(next.phase.deadline-next.phase.startedAt,30000,'present seat retains full turn');
   const actor=next.seats[present],input=N.game.bot.sampleInput(next,actor,createRng(seed+turns),'normal');ok(N.inputSchema.safeParse(input).success,'schema valid present input');
   const oldEvent={type:'input',now:old.phase.startedAt+1,playerId:actor,input},newEvent={type:'input',now:next.phase.startedAt+1,playerId:actor,input};active.oldEvents.push(oldEvent);active.newEvents.push(newEvent);old=O.reduce(freeze(old),oldEvent);next=N.reduce(freeze(next),newEvent);
  }else{
   eq(next.phase.id,'round-end');const oldEvent={type:'timer',now:old.phase.deadline,phaseId:old.phase.id,startedAt:old.phase.startedAt},newEvent={type:'timer',now:next.phase.deadline,phaseId:next.phase.id,startedAt:next.phase.startedAt};active.oldEvents.push(oldEvent);active.newEvents.push(newEvent);old=O.reduce(freeze(old),oldEvent);next=N.reduce(freeze(next),newEvent);
  }
  active.old=old;active.next=next;turns++;
 }
 settle();eq(next.phase.id,'done');eq(physical(next),physical(old),'whole ordinary game physical equivalence');ok(next.phase.startedAt<=3600000,'corrected one-present match budget');eq(N.results(next),O.results(old),'same results');
 rows.push({n,present,settings,seed,presentInputsAndRoundEnds:turns,round:next.round,scores:next.scores,oldElapsedMs:old.phase.startedAt,newElapsedMs:next.phase.startedAt,allPhysicalCheckpointsEqual:true,presentAlwaysFullTurn:true});
}
let connectedContexts=0,connectedEveryEvent=0,emptyContexts=0,pauseCases=0;
for(const n of [2,3,4])for(const mode of ['draw','block'])for(let seed=1;seed<=60;seed++){
 const players=Array.from({length:n},(_,i)=>({id:`p${i}`,name:'Player',avatarId:'plain',connected:true,bot:i===seed%n})),settings={mode,target:'100',partners:n===4&&seed%2===0};const context={players,settings,seed,now:seed%2?0:600000};let old=O.init(context),next=N.init(context);eq(next,old,'connected exact init');
 for(let step=0;next.phase.id!=='done'&&step<12000;step++){eq(next,old,'connected exact full state');let event;if(next.phase.id==='round-end'||step%17===0)event={type:'timer',now:next.phase.deadline,phaseId:next.phase.id,startedAt:next.phase.startedAt};else event={type:'input',now:next.phase.startedAt+1,playerId:next.seats[next.turn],input:N.game.bot.sampleInput(next,next.seats[next.turn],createRng(seed+step),'normal')};old=O.reduce(freeze(old),event);next=N.reduce(freeze(next),event);connectedEveryEvent++;}eq(next,old,'connected exact completion');eq(next.phase.id,'done');connectedContexts++;
 const absent={...context,players:players.map(p=>({...p,connected:false}))};eq(N.init(absent),O.init(absent),'all-empty init unchanged');emptyContexts++;
 const paused=N.reduce(N.init(context),{type:'vip',action:'pause',now:context.now+1});const actor=paused.seats[paused.turn],dropped=N.reduce(freeze(paused),{type:'player',now:context.now+2,playerId:actor,connected:false});eq(dropped.board,paused.board,'paused departure never takes action');eq(dropped.phase,paused.phase,'paused clock unchanged');
 const resumed=N.reduce(freeze(dropped),{type:'vip',action:'resume',now:context.now+101});ok(!resumed.phase.paused,'resume unpauses');ok(resumed.phase.id!=='play'||resumed.players[resumed.seats[resumed.turn]].connected,'resume settles absent active seat');pauseCases++;
}
const result={status:'PASS',scope:'Controlled private candidate proof; unqualified until original full new-source workflow',pairedCompleteGames:rows.length,assertions,checkpoints,oldAutomaticEvents,connectedContexts,connectedEveryEvent,emptyContexts,pauseCases,oldBudgetFailures:rows.filter(r=>r.oldElapsedMs>3600000).length,newBudgetFailures:rows.filter(r=>r.newElapsedMs>3600000).length,noBrowserOrTimingSampler:true,firstMeasured:rows[0],rows};
fs.writeFileSync(process.argv[3],JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,rows:undefined}));
