import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const root=process.argv[2];
const C=await import(path.join(root,'jobs/G01-dominoes/core.ts'));
const {createRng}=await import(path.join(root,'contract/rng.ts'));
const req=createRequire(path.join(root,'jobs/G01-dominoes/core.ts'));
assert.equal(req('zod/package.json').version,'4.6.5');
const freeze=x=>{if(x&&typeof x==='object'){Object.freeze(x);for(const v of Object.values(x))freeze(v);}return x;};
let assertions=0,games=0,steps=0,pauseCycles=0,rosterEvents=0,timerMoves=0,rounds=0,hiddenPairs=0,botBoundaryCalls=0;
const rows=[];
let activeContext=null,activeState=null,activeEvents=[];
process.on('uncaughtException',error=>{fs.writeFileSync(process.argv[3],JSON.stringify({status:'FAIL',scope:'Private untimed remaining-issue investigation; no formal KEEP credit',message:error.message,stack:error.stack,games,assertions,steps,pauseCycles,rosterEvents,timerMoves,rounds,hiddenPairs,botBoundaryCalls,rows,activeContext,activeState,activeEvents},null,2)+'\n');console.error(error.stack);process.exitCode=1;});
const ok=(x,msg)=>{assertions++;assert(x,msg);};
const equal=(a,b,msg)=>{assertions++;assert.deepEqual(a,b,msg);};
const pip=t=>{let id=0;for(let a=0;a<=6;a++)for(let b=a;b<=6;b++,id++)if(id===t)return a+b;throw new Error('invalid tile');};
function validate(s){
 equal([...s.hands.flat(),...s.stock,...s.board.map(t=>t.tile)].sort((a,b)=>a-b),Array.from({length:28},(_,i)=>i),'all tiles conserved');
 ok(Buffer.byteLength(JSON.stringify(s))<=262144,'bounded JSON state');
 for(const t of s.board){ok(t.a>=0&&t.a<=6&&t.b>=0&&t.b<=6,'pip range');equal(t.a+t.b,pip(t.tile),'placed tile identity');}
 for(let i=1;i<s.board.length;i++)equal(s.board[i-1].b,s.board[i].a,'touching chain');
 equal(s.ends,s.board.length?[s.board[0].a,s.board.at(-1).b]:null,'public ends');
 for(let i=0;i<s.seats.length;i++)ok(Number.isFinite(s.scores[i]),'finite score');
 if(s.settings.partners){equal(s.scores[0],s.scores[2]);equal(s.scores[1],s.scores[3]);}
 equal(JSON.parse(JSON.stringify(C.tvView(s))),C.tvView(s),'TV JSON round-trip');
 for(const id of [...s.seats,'unknown','__proto__','constructor']){const v=C.controllerView(s,id);equal(JSON.parse(JSON.stringify(v)),v,'controller JSON round-trip');if(!s.seats.includes(id))equal(v.hand,[],'spectator hidden hand');}
}
function independentRound(before,after){
 const sums=after.hands.map(h=>h.reduce((n,t)=>n+pip(t),0));
 const group=i=>after.settings.partners?i%2:i;
 let win=after.hands.findIndex(h=>h.length===0),blocked=win<0;
 if(blocked){const gs=[...new Set(after.seats.map((_,i)=>group(i)))];const totals=gs.map(g=>sums.reduce((n,v,i)=>n+(group(i)===g?v:0),0));const min=Math.min(...totals),w=gs.filter((_,i)=>totals[i]===min);win=w.length===1?after.seats.findIndex((_,i)=>group(i)===w[0]):null;}
 let points=0;
 if(win!==null){const g=group(win),mine=sums.reduce((n,v,i)=>n+(group(i)===g?v:0),0),other=sums.reduce((n,v,i)=>n+(group(i)!==g?v:0),0);points=after.settings.partners?(after.settings.teamPoints==='all'?mine+other:other):Math.max(0,other-(blocked&&after.settings.blocked==='difference'?mine:0));}
 equal(after.last,{winner:win,points,blocked},'independent full-round scoring');
 equal(after.scores,before.scores.map((v,i)=>v+(win!==null&&group(i)===group(win)?points:0)),'independent match-score increment');rounds++;
}
for(const n of [2,3,4])for(const partners of n===4?[false,true]:[false])for(const mode of ['draw','block'])for(const target of ['100','150','250'])for(const deal of ['block-sized','traditional'])for(const reserve of ['0','2'])for(const opening of ['highest-double','rotating'])for(const blocked of ['difference','opponents'])for(const teamPoints of ['opponents','all']){
 const index=games,seed=index<3?index+1:700000+index,mask=1+(index%((1<<n)-1)),settings={mode,target,deal,reserve,opening,blocked,teamPoints,partners};
 const context={players:Array.from({length:n},(_,i)=>({id:`p${i}`,name:`Player ${i+1}`,avatarId:'plain',connected:!!(mask&(1<<i)),bot:i===index%n})),settings,seed,now:index%2?0:600000};
 activeContext=context;activeEvents=[];
 let s=C.init(context),replay=JSON.parse(JSON.stringify(s)),turns=0,now=context.now;
 activeState=s;
 const reduce=e=>{activeEvents.push(e);const old=s,a=C.reduce(freeze(s),freeze(e)),b=C.reduce(freeze(replay),JSON.parse(JSON.stringify(e)));equal(a,b,'source versus JSON-save replay');s=a;activeState=s;replay=JSON.parse(JSON.stringify(b));steps++;if(old.phase.id==='play'&&a.phase.id!=='play')independentRound(old,a);validate(s);};
 validate(s);
 while(s.phase.id!=='done'&&turns<12000){
  now=Math.max(now,s.phase.startedAt)+1;
  if(turns%19===3){
   const id=s.seats[(turns+index)%n],oldDeadline=s.phase.deadline,oldStart=s.phase.startedAt;
   reduce({type:'vip',action:'pause',now});
   const held=s,move=C.legal(s)[0];
   equal(C.reduce(freeze(s),{type:'timer',now:s.phase.deadline+1000,phaseId:s.phase.id,startedAt:s.phase.startedAt}),held,'paused timer ignored');
   if(move)equal(C.reduce(freeze(s),{type:'input',now,playerId:s.seats[s.turn],input:move}),held,'paused legal input ignored');
   equal(C.reduce(freeze(s),{type:'vip',action:'skip',now}),held,'paused skip ignored');
   for(const p of s.seats)equal(C.game.bot.sampleInput(s,p,createRng(13),'normal'),null,'paused bot null');
   reduce({type:'player',now:now+1,playerId:id,connected:false,...(turns%2?{gone:'left'}:{})});rosterEvents++;
   reduce({type:'vip',action:'resume',now:now+23});now+=23;
   equal(s.phase.startedAt,oldStart,'resume phase instance');equal(s.phase.deadline,oldDeadline+23,'exact resume clock shift');pauseCycles++;
  }
  if(turns%23===5){const id=s.seats[(turns+index+1)%n];reduce({type:'player',now,playerId:id,connected:true});rosterEvents++;}
  const current=s;
  equal(C.reduce(freeze(s),{type:'timer',now:s.phase.deadline-1,phaseId:s.phase.id,startedAt:s.phase.startedAt}),current,'early timer unchanged');
  equal(C.reduce(freeze(s),{type:'timer',now:s.phase.deadline+100000,phaseId:s.phase.id,startedAt:s.phase.startedAt-1}),current,'stale timer unchanged');
  equal(C.reduce(freeze(s),{type:'input',now,playerId:'unknown',input:C.legal(s)[0]}),current,'unknown input unchanged');
  if(s.phase.id==='play'){
   const actor=s.seats[s.turn],o=C.observe(s,actor),other=JSON.parse(JSON.stringify(s));
   const pool=[...other.stock,...other.hands.flatMap((h,i)=>i===s.turn?[]:h)].reverse();let at=0;
   other.hands=other.hands.map((h,i)=>i===s.turn?h:pool.slice(at,at+=h.length));other.stock=pool.slice(at);
   equal(C.controllerView(s,actor),C.controllerView(other,actor),'same-view hidden substitution');equal(o,C.observe(other,actor),'same bot observation');hiddenPairs++;
   if(turns%37===0){for(const skill of ['easy','normal']){const a=C.game.bot.sampleInput(s,actor,createRng(99),skill),b=C.game.bot.sampleInput(freeze(other),actor,createRng(99),skill);equal(a,b,'hidden-independent decision');ok(C.inputSchema.safeParse(a).success,'schema-valid bot');ok(C.legal(s).some(x=>C.sameInput(x,a)),'legal bot');botBoundaryCalls+=2;}}
  }
  if(s.phase.id==='round-end'||!s.players[s.seats[s.turn]].connected||turns%29===0){now=s.phase.deadline;reduce({type:'timer',now,phaseId:s.phase.id,startedAt:s.phase.startedAt});timerMoves++;}
  else{const actor=s.seats[s.turn],input=C.game.bot.sampleInput(s,actor,createRng(seed+turns),'normal');ok(input!==null&&C.inputSchema.safeParse(input).success,'normal legal input');reduce({type:'input',now,playerId:actor,input});}
  turns++;
 }
 equal(s.phase.id,'done','ordinary match finishes without VIP end/skip');
 ok(s.phase.startedAt-context.now<=C.manifest.estimatedMinutes*3*60000,'contract simulated-time bound');
 const results=C.results(s);equal(Object.keys(results.scores).sort(),s.seats.slice().sort(),'every original seat in results');ok(Object.values(results.scores).every(Number.isFinite),'finite result scores');
 rows.push({index,seed,n,settings,initialConnectedMask:mask,turns,round:s.round,scores:s.scores,phaseStartedAt:s.phase.startedAt,winners:results.winnerIds});games++;
}
const result={status:'PASS',scope:'Private untimed remaining-issue investigation of exact protected Ready11, no source change or new formal KEEP credit',actualResolvedZod:req.resolve('zod'),pinnedZodVersion:req('zod/package.json').version,games,assertions,steps,pauseCycles,rosterEvents,timerMoves,rounds,hiddenPairs,botBoundaryCalls,noVipEndOrSkip:true,noBrowserOrTimingSampler:true,rows};
fs.writeFileSync(process.argv[3],JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({...result,rows:undefined}));
