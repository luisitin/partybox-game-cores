from pathlib import Path
import json,hashlib,zipfile,datetime,subprocess,io

root=Path('/tmp/G01-source-queue-audit-20261009');job=root/'jobs/G01-dominoes';work=root/'.work';stable=Path('/dev/shm/G01-private-remaining-issue-20261009')
proof=job/'media/absence-takeover-first-proof.zip';first=proof.read_bytes()
first_path=stable/'first-publication-43f28f5-invalid-duplicate-proof.zip'
if first_path.exists():assert first_path.read_bytes()==first
else:first_path.write_bytes(first)
with zipfile.ZipFile(io.BytesIO(first)) as z:
 names=z.namelist();duplicates=sorted({n for n in names if names.count(n)>1});assert duplicates
failure={'status':'FAIL','actualFirstSource':'43f28f5ac55d5b308a75ba9998b99bfae32c8196','firstSourceCommitUtc':'2026-10-09T13:26:35Z','firstSourceRemoteObservedUtc':'2026-10-09T13:27:18Z','exactPublicationTimeNotInstrumented':True,'firstSourceHardUtc':'2026-10-09T13:26:24.419231Z','hardMissMinimumSeconds':10.580769,'firstArchiveBytes':len(first),'firstArchiveSha256':hashlib.sha256(first).hexdigest(),'duplicateMemberNames':duplicates,'firstArchivePreparationRejected':True,'dependentShellCommandsIncorrectlyContinuedBeforeFailureInspection':True,'oldCopiedNEXTStillStaleAtFirstPublication':True,'newSourceQualification':'PENDING','originalReady11Unchanged':True,'newNativePerformanceOrFormalKeepCredit':False,'emptyStableHelperAfterENOSPC':'UNEXECUTED; exit0 from an empty Python file is not a test pass','HeartsCacheArchivePreparation':'Wrong src/core.ts path caused preflight FileNotFoundError; no cache file was removed; separate shared-memory output mount now available'}
(stable/'first-publication-43f28f5-failure-receipt.json').write_text(json.dumps(failure,indent=2)+'\n')
data=json.loads((stable/'candidate-absence-stable-build-v2.json').read_text());closed=json.loads((stable/'candidate-absence-stable-build-v2-CLOSED.json').read_text());assert data['status']=='PASS' and closed['status']=='PASS' and closed['allFrozenInputsUnchanged'] and closed['naturalClosure']
payload={}
def add(p,name):
 b=p.read_bytes()
 if name in payload:assert payload[name]==b,'unequal archive path collision'
 else:payload[name]=b
for prefix in ['remaining-issue-first','fixed-all-human-absence-first','candidate-absence-first']:
 for p in work.glob(prefix+'*'):
  if p.is_file():add(p,'private-first/'+p.name)
for p in stable.iterdir():
 if p.is_file():add(p,'stable-build/'+p.name)
for p in ['/tmp/G01-private-remaining-issue-probe-20261009.mjs','/tmp/G01-private-remaining-issue-controller-20261009.py','/tmp/G01-private-remaining-issue-controller-v2-20261009.py','/tmp/G01-private-remaining-issue-controller-v3-20261009.py','/tmp/G01-private-fixed-absence-control-20261009.mjs','/tmp/G01-private-fixed-absence-controller-20261009.py','/tmp/G01-private-candidate-absence-check-20261009.mjs','/tmp/G01-private-candidate-absence-controller-20261009.py']:
 p=Path(p);add(p,'helpers/'+p.name)
for name in ['core.ts','play.html','absence-presence.test.ts','package.json']:add(job/name,'candidate/'+name)
add(Path(__file__),'helpers/'+Path(__file__).name)
out=io.BytesIO()
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,b in payload.items():z.writestr(name,b)
archive_bytes=out.getvalue()
with zipfile.ZipFile(io.BytesIO(archive_bytes)) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(payload) and not z.testzip()
 for name,b in payload.items():assert z.read(name)==b
proof.write_bytes(archive_bytes)
summary={'schema':'g01-absent-turn-candidate/2','recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'protectedReady11':'eadb642bc1f9f4f2c839c7a6754932e7a5b640ec','currentCoreSha256':hashlib.sha256((job/'core.ts').read_bytes()).hexdigest(),'currentPageSha256':hashlib.sha256((job/'play.html').read_bytes()).hexdigest(),'firstActualFixedHumanControl':{'pairedCases':468,'oldBudgetFailures':427,'allPhysicalCheckpointsEqual':True,'closedUtc':'2026-10-09T13:09:27.529285+00:00'},'stableCandidateProof':{k:v for k,v in data.items() if k!='rows'},'controller':closed,'newDefaultRegressionSmoke':{'command':'node --test absence-presence.test.ts','pass':7,'fail':0,'firstProtectedOldSourceCommand':'ABSENCE_CORE_PATH=<exact copied eadb core> node --test absence-presence.test.ts','firstOldPass':1,'firstOldFail':6,'scope':'Separate targeted smoke runs; these do not independently certify entire new source/hosted qualification'},'proofArchive':{'path':'media/'+proof.name,'bytes':len(archive_bytes),'sha256':hashlib.sha256(archive_bytes).hexdigest(),'members':len(payload),'allMemberBytesCRCAndUniqueNamesVerified':True},'firstPublicationFailure':failure,'qualification':'PENDING original whole new-source CI and visual milestone capture','formalKeepRoundsCredited':0,'nativePerformanceClaim':False}
(job/'absence-takeover-first.json').write_text(json.dumps(summary,indent=2)+'\n')
current='''## Current isolated follow-up: absent-turn repair remains unqualified

Owner: codex-domino-queue-audit-20261009. Branch:
job/G01-dominoes-queue-audit-20261009 from claimed MAIN ba14179.
Protected Ready11 eadb and Draft1 canonical8c are untouched and unmerged.
Original final eadb full1318-check acceptance and R25–28 stop stay historical.

Fixed all-human one-present control completed468 pairs/936 ordinary games:
427 old matches exceed the contract60-minute simulated budget. Bounded greedy
takeover of explicitly absent active seats removes repeated extra turn waits.
Empty and paused rooms wait; every next present human keeps the full30s turn.
Rules, RNG, scoring, original bot strategies, native clocks/gates stay exact.
Stable controlled proof CLOSED13:22:00.314634/pass/no child/all1230 inputs:
468 full pairs/527041 assertions/74211 physical checkpoints match, old427 to
new0 budget failures. Seed1 Draw100:7303305 to90587 simulated ms, same19 rounds
and scores94/133.360 connected games/101238 every-event states byte-identical;
360 empty starts/360 pause-drop-resume cases pass. No FPS/hardware gain claim.
Seven new default regressions pass; six genuinely fail the exact old eadb core.
Those separate smoke runs are not whole-source or hosted acceptance.

First actual source43f28f5 was normally pushed, commit13:26:35Z/readback13:27:18Z.
Its exact publication clock was not instrumented. Hard13:26:24.419231 was missed
by at least10.580769s; the earlier25-minute target was missed too. No backdate.
Its first ZIP preparation rejected duplicate member names, but dependent shell
commands wrongly continued; the source contained that invalid ZIP and stale
copied handoff. The exact bad ZIP/first source/failure receipt remain retained.
This correction deduplicates identical input paths and fully verifies every
member byte, full CRC and unique names before publication. ENOSPC/empty helper
was UNEXECUTED; the first concurrent-build controller truly FAIL remains.

Current code/page proofs, all raw rows/events/programs/guards/native outputs and
failures are in absence-takeover-first.json and its corrected complete media ZIP.
Read actual next normal push receipt for new source and conservative cadence;
until then use earliest next hard13:56:35Z, never infer exact prior push time.

NEXT: current visual milestone capture; complete every original check plus new
default regressions, open/keep supplemental PR Draft, accept exact new original
workflow and whole genuine official artifact. No qualified new gain/formal KEEP
round credited. After actual full current green, reread/rank5, measure/log/push
each separate round until3 no-player-gain. Preserve original Ready11 static.

'''
p=job/'NEXT.md';p.write_text(current+p.read_text())
p=job/'README.md';old=p.read_text();old=old[:old.index('## Status')]+'''## Status

Protected PR11 is Ready on eadb; this isolated absent-turn repair is unqualified.
Controlled468 pairs pass;360 connected games keep every state byte-identical.
New7-test regressions pass/old6 fail. Original full CI/video/KEEP remain pending.
NEXT.md records the retained failed first package and truthful source cadence.
''';assert len(old.splitlines())<60;p.write_text(old)
texts={
'ASSUMPTIONS.md':'\n## Lawful G01 follow-up,2026-10-09\nFull latest MAIN instructions/CLAIMS/all29 matching committer tips made G01 lowest stale. Own-row claim published12:56:24.419231, all foreign rows/tree/G10 BLOCKED intact. Isolated branch created from claimed MAIN. Declared disconnect already passed shell grace per contract/GAME_CONTRACT.md; deterministic legal takeover avoids extra absent-turn waits. Those actions are not missed present-human turns. Empty/paused rooms retain control. Original Ready11 whole1318 proof and R25–28 stop remain protected. Simulated schedule gain is not native FPS/hardware evidence. First source43 was genuinely late and its invalid duplicate ZIP/stale handoff remain in history; no backdate/force/retrocredit. Separate output mount resolved ENOSPC without reclaiming any Hearts cache/source.\n',
'REVIEW.md':'\n## Isolated remaining-issue preparation\nRe-read original job/instructions/NEXT/LOOP and genuine final Ready11 receipt. Ranked5:1 explicitly absent seat repeatedly receives30s windows,427/468 controlled human budget failures;2 pause/drop/resume must retain full present-human time;3 saved/connected exact-state compatibility;4 failed Worker-response improvement evidence, do not rerun unchanged timing;5 finite physical-phone/upstream strength scope. Narrow repair1 with360 pause/empty controls and360 full connected-state comparisons. Stable468 pairs pass. This private preparation is not a completed post-green round; all broad current CI/video checks still required.\n',
'LOOP.md':'\nProvisional isolated absence repair,2026-10-09:468 fixed-human whole pairs old427/new0 simulated-budget failures with exact physical RNG/scoring;360 connected games101238 whole-state comparisons byte-identical;360 empty and360 pause cases pass. New7 regressions pass/old6 fail in smoke runs. Original full current CI/video pending; no qualified gain or formal KEEP credit. Original R25–28 stop protected. First43 invalid archive/late publication and correction retained truthfully.\n',
'VERIFY.md':'\n## Isolated absent-turn candidate/checkpoint correction\nCurrent npm run check and node build.ts pass; node build.ts --check also passes after adding the new7-test default suite. Fixed all-human controller: python /tmp/G01-private-fixed-absence-controller-20261009.py, CLOSED13:09:27.529285/pass/all1047 guards/468 full pairs,427 original60-minute simulated-budget failures. Stable controller: python /dev/shm/G01-private-remaining-issue-20261009/stable-build-controller-v2.py, CLOSED13:22:00.314634/pass/all1230 guards/527041 assertions/468 pairs/360 connected games101238 whole-state comparisons/360 empty/360 pause cases. These guard receipts certify that stable product invocation, not later docs/package/whole workflow. Separate smoke: node --test absence-presence.test.ts pass7/fail0; ABSENCE_CORE_PATH=<exact copied eadb> node --test absence-presence.test.ts pass1/fail6. All first raw programs/outputs/failures/complete guards are archived byte-for-byte. First candidate controller FAIL because play.html changed during concurrent build; empty helper after ENOSPC UNEXECUTED. First published43 ZIP had duplicate member names and failed its unique-name assertion before dependent commands wrongly continued; exact failed ZIP retained. Corrected package independently verifies all unique names/full CRC/all input member bytes before writing. Full original broad tests/current visual capture/exact-current hosted qualification still pending. No FPS or new formal KEEP claim.\n'}
for name,text in texts.items():
 p=job/name;p.write_text(p.read_text()+text)
p=job/'RULES.md';s=p.read_text();old='    has a timer. After a full cycle of automatic turns';new='    has a timer. Explicitly absent active seats take deterministic legal actions\n    while another seat is connected; empty/paused rooms wait. These absent actions\n    do not shorten a present human\'s next turn. After a full cycle of automatic turns';assert old in s;p.write_text(s.replace(old,new))
print(json.dumps({'correctedArchiveBytes':len(archive_bytes),'members':len(payload),'sha256':summary['proofArchive']['sha256'],'allMemberBytesCRCAndUniqueNamesVerified':True,'retainedFirstBadSource':'43f28f5ac55d5b308a75ba9998b99bfae32c8196','retainedBadZIP':str(first_path),'handoffCurrent':True,'qualification':'PENDING'}))
