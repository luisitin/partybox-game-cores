import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
const root=process.argv[2],C=await import(path.join(root,'jobs/G01-dominoes/core.ts')),{createRng}=await import(path.join(root,'contract/rng.ts'));
const freeze=x=>{if(x&&typeof x==='object'){Object.freeze(x);for(const v of Object.values(x))freeze(v);}return x;};
const rows=[];let comparisons=0,actualInputs=0,actualTimers=0;
const physical=s=>({rng:s.rng,seats:s.seats,settings:s.settings,hands:s.hands,stock:s.stock,board:s.board,ends:s.ends,turn:s.turn,starter:s.starter,forced:s.forced,round:s.round,passes:s.passes,scores:s.scores,missed:s.missed,history:s.history,last:s.last,phaseId:s.phase.id});
let active=null;
process.on('uncaughtException',e=>{fs.writeFileSync(process.argv[3],JSON.stringify({status:'FAIL',message:e.message,stack:e.stack,comparisons,actualInputs,actualTimers,rows,active},null,2)+'\n');console.error(e.stack);process.exitCode=1;});
for(const n of [2,3,4])for(const partners of n===4?[false,true]:[false])for(const mode of ['draw','block'])for(const target of ['100','150','250'])for(const seed of [1,2,3,700064,146,991])for(let present=0;present<n;present++){
 const settings={mode,target,partners,deal:seed%2?'block-sized':'traditional',reserve:seed%3?'0':'2',opening:seed%2?'rotating':'highest-double',blocked:seed%2?'difference':'opponents',teamPoints:seed%2?'opponents':'all'};
 const players=Array.from({length:n},(_,i)=>({id:`p${i}`,name:`Player ${i+1}`,avatarId:'plain',connected:i===present,bot:false}));
 let absent=C.init({players,settings,seed,now:0}),connected=C.init({players:players.map(p=>({...p,connected:true})),settings,seed,now:0});let steps=0;
 active={n,present,settings,seed,players,events:[],absent,connected};
 while(absent.phase.id!=='done'&&steps<12000){
  assert.deepEqual(physical(absent),physical(connected));comparisons++;
  let ea,ec;
  if(absent.phase.id==='round-end'){
   ea={type:'timer',now:absent.phase.deadline,phaseId:absent.phase.id,startedAt:absent.phase.startedAt};
   ec={type:'input',now:connected.phase.startedAt+1,playerId:connected.seats[present],input:{type:'next'}};actualTimers++;actualInputs++;
  }else{
   const actor=absent.seats[absent.turn],input=C.game.bot.sampleInput(absent,actor,createRng(seed+steps),'normal');assert(C.inputSchema.safeParse(input).success);
   ec={type:'input',now:connected.phase.startedAt+1,playerId:actor,input};actualInputs++;
   if(absent.turn===present){ea={type:'input',now:absent.phase.startedAt+1,playerId:actor,input};actualInputs++;}
   else{ea={type:'timer',now:absent.phase.deadline,phaseId:absent.phase.id,startedAt:absent.phase.startedAt};actualTimers++;}
  }
  active.events.push(ea);absent=C.reduce(freeze(absent),ea);connected=C.reduce(freeze(connected),ec);active.absent=absent;active.connected=connected;steps++;
 }
 assert.equal(absent.phase.id,'done');assert.deepEqual(physical(absent),physical(connected));comparisons++;
 const bound=C.manifest.estimatedMinutes*3*60000;
 assert(connected.phase.startedAt<=bound);
 rows.push({n,present,settings,seed,allPlayersHuman:true,initialPresentPlayers:1,rosterChanges:0,pauseEvents:0,noVipEndOrSkip:true,steps,round:absent.round,scores:absent.scores,absentElapsedMs:absent.phase.startedAt,allConnectedElapsedMs:connected.phase.startedAt,boundMs:bound,absenceExceedsBound:absent.phase.startedAt>bound,allPhysicalStatesEqual:true});
}
const failures=rows.filter(r=>r.absenceExceedsBound),result={status:'PASS',scope:'Independent fixed all-human absence/time-budget control; no source adoption or formal KEEP credit',games:rows.length*2,pairedCases:rows.length,comparisons,actualInputs,actualTimers,absentExceedsBudget:failures.length,firstBudgetFailure:failures[0]??null,worstCase:rows.reduce((a,b)=>a.absentElapsedMs>b.absentElapsedMs?a:b),allPhysicalStatesEqual:true,rows};
fs.writeFileSync(process.argv[3],JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({...result,rows:undefined}));
