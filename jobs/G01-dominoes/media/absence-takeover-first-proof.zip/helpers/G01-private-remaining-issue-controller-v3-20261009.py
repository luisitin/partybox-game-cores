import datetime,hashlib,json,os,subprocess,sys,time,shutil
from pathlib import Path
work=Path('/tmp/G01-source-queue-audit-20261009/.work'); source=Path('/tmp/g01-current-838-proof-20261009/repo'); baseline=work/'private-baseline'; helper=Path('/tmp/G01-private-remaining-issue-probe-20261009.mjs'); out=work/'remaining-issue-first-v3.json'; log=work/'remaining-issue-first-v3-native.log'; receipt=work/'remaining-issue-first-v3-CLOSED.json'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def file(p):
 s=p.stat();return {'realPath':str(p.resolve()),'bytes':s.st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'dev':s.st_dev,'inode':s.st_ino,'nlink':s.st_nlink,'mtimeNs':s.st_mtime_ns}
def freeze():
 tracked=subprocess.run(['git','ls-files'],cwd=source,capture_output=True,text=True,check=True).stdout.splitlines()
 paths=[source/line for line in tracked if line.startswith(('jobs/G01-dominoes/','contract/')) or line=='.github/workflows/G01.yml']
 paths.extend(work.parent/name for name in ['README.md','RULES.md','JOBS.md','RUN-ALL.md','CLAIMS.md'])
 paths.extend(p for p in baseline.rglob('*') if p.is_file() and 'node_modules' not in p.parts)
 zod=Path('/workspace/game-cores-G01-queue-audit-20261008/jobs/G01-dominoes/node_modules/zod');paths.extend(p for p in zod.rglob('*') if p.is_file())
 paths.extend([helper,Path(__file__),Path(sys.executable),Path(shutil.which('node'))])
 return {str(p):file(p) for p in paths}
r={'startedUtc':stamp(),'scope':'First bounded private untimed investigation of exact protected Ready11; no source adoption, browser, timing retry or formal KEEP credit','protectedSource':'eadb642bc1f9f4f2c839c7a6754932e7a5b640ec','wholeBoundSeconds':330,'signalsSent':[],'remainingOwnedChildren':[]}
child=None
try:
 assert subprocess.run(['git','rev-parse','HEAD'],cwd=source,capture_output=True,text=True,check=True).stdout.strip()==r['protectedSource']
 before=freeze();(work/'remaining-issue-first-v3-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
 with log.open('wb') as stream:
  child=subprocess.Popen([shutil.which('node'),str(helper),str(baseline),str(out)],cwd=baseline,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
  r['childPid']=child.pid;r['childStartedUtc']=stamp()
  try:exitcode=child.wait(timeout=330)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,15);r['signalsSent'].append('SIGTERM owned group');exitcode=child.wait(timeout=15);r['deadlineExceeded']=True
  r['childClosedUtc']=stamp();r['childExitCode']=exitcode
 after=freeze();(work/'remaining-issue-first-v3-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'frozen input changed'
 r['allFrozenInputsUnchanged']=True;r['frozenInputCount']=len(before);r['naturalClosure']=not r['signalsSent'];r['status']='PASS' if exitcode==0 else 'FAIL';r['exitCode']=exitcode
 if out.exists():
  result=json.loads(out.read_text());r['actualResult']={k:v for k,v in result.items() if k not in ['rows','activeEvents','activeState','stack','activeContext']};r['resultFile']=file(out)
 r['nativeLog']=file(log)
except BaseException as error:r.update({'status':'FAIL','exitCode':1,'controllerErrorType':type(error).__name__,'controllerError':str(error)})
finally:
 r['closedUtc']=stamp();receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(0 if r.get('status')=='PASS' else 1)
