from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time,signal
ROOT=Path('/tmp/G01-source-queue-audit-20261009');OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');JOB=ROOT/'jobs/G01-dominoes';ORIGINAL=Path('/dev/shm/G01-current-functional-milestone-first-controller-20261009.py');HEAD='9facc82d4c88126e6b028e8e8c18ae4637a72d75';LOG=OUT/'compatibility-oracle-first-native.log';RECEIPT=OUT/'compatibility-oracle-first-CLOSED.json';OUTPUT='jobs/G01-dominoes/total-compatibility-report.json';CHANGED='jobs/G01-dominoes/total-compatibility.ts';ADDED='jobs/G01-dominoes/study-presence-baseline.ts'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
scope={'__file__':str(ORIGINAL)};program=ORIGINAL.read_text().split("r={'schema':'g01-current-functional-milestone-controller/1'")[0];exec(compile(program,str(ORIGINAL),'exec'),scope)
alias=scope['alias'];stat=scope['stat'];group=scope['group'];track=scope['track'];snapshotOriginal=scope['snapshot']
# Use the same full independently resolved dependency/runtime/alias inventory.
# Only the deliberate oracle source replacement and declared generated report
# differ from Git9f; every other original source remains exactly committed.
snapshotProgram=program[program.index('def snapshot():'):program.index('def group(pid):')]
snapshotProgram=snapshotProgram.replace("for name in names:","names=[name for name in names if name!=OUTPUT]\n for name in names:").replace("assert p.read_bytes()==subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT);paths.add(p)","assert name==CHANGED or p.read_bytes()==subprocess.check_output(['git','show',HEAD+':'+name],cwd=ROOT);paths.add(p)").replace("paths.update([HELPER,Path(__file__)])", "paths.update([HELPER,Path(__file__),ORIGINAL,ROOT/ADDED]);assert (ROOT/ADDED).read_bytes()==subprocess.check_output(['git','show','eadb642bc1f9f4f2c839c7a6754932e7a5b640ec:jobs/G01-dominoes/core.ts'],cwd=ROOT)")
scope.update({'__file__':__file__,'OUTPUT':OUTPUT,'CHANGED':CHANGED,'ADDED':ADDED,'ORIGINAL':ORIGINAL});exec(compile(snapshotProgram,__file__,'exec'),scope);snapshot=scope['snapshot']
r={'schema':'g01-first-explicit-absence-compatibility-oracle/1','startedUtc':stamp(),'sourceParent':HEAD,'wholeBoundSeconds':420,'declaredMutableOutput':OUTPUT,'intentionalOracleSourceChange':CHANGED,'addedFrozenProtectedCore':ADDED,'scope':'Every original1003 seed/event/physical/RNG/result comparison retained, frozen old-engine legal-action absence replay with tighter progress bound; independent1003 full connected games require exact whole-state agreement with protected eadb. Strict compiler and two complete byte-identical regenerated reports. No browser/native timing trial.','signalsSent':[],'commands':[]};child=None
try:
 assert not RECEIPT.exists() and not LOG.exists();before=snapshot();(OUT/'compatibility-oracle-first-inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');deadline=time.monotonic()+420
 with LOG.open('xb') as log:
  for index,args in enumerate([['npm','run','check'],[shutil.which('node'),'total-compatibility.ts','--write'],[shutil.which('node'),'total-compatibility.ts','--write']]):
   command={'argv':args,'startedUtc':stamp()};r['commands'].append(command);child=subprocess.Popen(args,cwd=JOB,env=dict(os.environ,TMPDIR=str(OUT)),stdout=log,stderr=subprocess.STDOUT,start_new_session=True);command['childPid']=child.pid
   while child.poll() is None:
    track(child.pid)
    if time.monotonic()>=deadline:raise subprocess.TimeoutExpired(args,420)
    time.sleep(.1)
   command['exitCode']=child.returncode;command['closedUtc']=stamp();assert child.returncode==0,(args,child.returncode)
   assert not track(child.pid) and not group(child.pid),'Owned child did not close'
   if index>0:
    raw=(ROOT/OUTPUT).read_bytes();(OUT/('compatibility-report-regeneration-'+str(index)+'.json')).write_bytes(raw);command['reportBytes']=len(raw);command['reportSha256']=hashlib.sha256(raw).hexdigest()
    if index==2:assert raw==(OUT/'compatibility-report-regeneration-1.json').read_bytes(),'Regeneration differs'
 after=snapshot();(OUT/'compatibility-oracle-first-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after,'Complete frozen input drift';r['allFrozenInputsUnchanged']=True;r['frozenAliasCount']=len(before['aliases']);r['actualReport']=json.loads((ROOT/OUTPUT).read_text());r['bothFullRegenerationsByteIdentical']=True;r['status']='PASS';r['exitCode']=0
except BaseException as e:r.update({'status':'FAIL','exitCode':1,'errorType':type(e).__name__,'error':str(e)})
finally:
 if child is not None:
  live=track(child.pid)
  if child.poll() is None or live:
   try:os.killpg(child.pid,signal.SIGTERM);r['signalsSent'].append('SIGTERM owned group')
   except ProcessLookupError:pass
   for p in live:
    try:os.kill(p['pid'],signal.SIGTERM);r['signalsSent'].append('SIGTERM owned detached '+str(p['pid']))
    except ProcessLookupError:pass
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);r['signalsSent'].append('SIGKILL owned group');child.wait(timeout=10)
  r['remainingOwnedChildren']=group(child.pid);r['remainingOwnedDetached']=track(child.pid)
 else:r['remainingOwnedChildren']=[];r['remainingOwnedDetached']=[]
 r['naturalClosure']=child is not None and not r['signalsSent'] and not r['remainingOwnedChildren'] and not r['remainingOwnedDetached']
 if not r['naturalClosure']:r.update({'status':'FAIL','exitCode':1})
 r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(r['exitCode'])
