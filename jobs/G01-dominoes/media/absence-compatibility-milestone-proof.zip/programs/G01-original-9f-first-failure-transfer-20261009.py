from pathlib import Path
import datetime,hashlib,json,os,re,stat,subprocess,sys,termios,zipfile
OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');ROOT=Path('/tmp/G01-source-queue-audit-20261009');ZIP=OUT/'original-9f-first-failure-whole.zip';EXPECTED_SHA='77dd5ac989493bc3a74598a7310b305d6e03f19795e3470ae056631c2de99ad7';EXPECTED_BYTES=128399627;SOURCE='9facc82d4c88126e6b028e8e8c18ae4637a72d75';RECEIPT=OUT/'original-9f-first-failure-whole-CLOSED.json'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
r={'schema':'g01-first-original-failed-artifact-inspection/1','startedUtc':stamp(),'source':SOURCE,'run':37939034123,'job':113848358588,'artifactId':11620331652,'expectedBytes':EXPECTED_BYTES,'expectedSha256':EXPECTED_SHA,'scope':'Entire original first failed official ZIP/source maps/full actual native failure; no success or native sampling claimed.'}
try:
 assert not ZIP.exists() and not RECEIPT.exists();original=termios.tcgetattr(sys.stdin);private=original.copy();private[3]&=~termios.ECHO;termios.tcsetattr(sys.stdin,termios.TCSANOW,private);print('PRIVATE_STDIN_READY',flush=True)
 signed=sys.stdin.readline().strip();assert signed.startswith('https://');config='url = "'+signed.replace('\\','\\\\').replace('"','\\"')+'"\n';r['transportStartedUtc']=stamp()
 result=subprocess.run(['curl','--config','-','--fail','--silent','--show-error','--location','--retry','0','--connect-timeout','15','--max-time','60','--max-filesize',str(EXPECTED_BYTES),'--output',str(ZIP)],input=config.encode(),capture_output=True,timeout=70)
 r['transportExitCode']=result.returncode;r['transportClosedUtc']=stamp();r['transportStderr']=result.stderr.decode(errors='replace').replace(signed,'[redacted signed official artifact URL]');assert result.returncode==0,'Official artifact transfer failed'
 del signed,config
 raw=ZIP.read_bytes();assert len(raw)==EXPECTED_BYTES and hashlib.sha256(raw).hexdigest()==EXPECTED_SHA;r['wholeOfficialDigestPass']=True
 with zipfile.ZipFile(ZIP) as z:
  infos=z.infolist();names=z.namelist();assert len(names)==len(set(names));assert z.testzip() is None
  for i in infos:
   p=Path(i.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and not stat.S_ISLNK(i.external_attr>>16)
  start=json.loads(z.read('ci-start.json'));end=json.loads(z.read('ci-finish.json'));r['actualStart']=start;r['actualFinish']=end
  assert start['github']['GITHUB_RUN_ID']==str(r['run']) and SOURCE in [start['checkoutHead'],*start['checkoutParents']]
  assert end['status']=='FAIL' and end['npmTestExitCode']==1 and not end['immutableDrift'] and end['nodeUnchanged']
  expected=subprocess.check_output(['git','ls-tree','-r','--name-only',SOURCE,'--','jobs/G01-dominoes','contract','.github/workflows/G01.yml','README.md','RULES.md','JOBS.md'],cwd=ROOT,text=True).splitlines();assert set(expected)==set(start['filesBefore'])==set(end['filesAfter']);count=0
  for name in expected:
   before=z.read('before/'+name);after=z.read('after/'+name);assert before==subprocess.check_output(['git','show',SOURCE+':'+name],cwd=ROOT)
   for value,data in [(start['filesBefore'][name],before),(end['filesAfter'][name],after)]:assert value=={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};count+=1
   if name not in start['mutableOutputPaths']:assert before==after;count+=1
  log=z.read('full-npm-test.log');assert end['fullLog']=={'bytes':len(log),'sha256':hashlib.sha256(log).hexdigest()}
  native=(OUT/'original-9f-first-failure-native-full.log').read_bytes();text=native.decode();stripped=re.sub(r'^\d{4}-\d\d-\d\dT[0-9:.]+Z ','',text,flags=re.MULTILINE);assert log.decode() in stripped
  assert 'SHA256 digest of uploaded artifact zip is '+EXPECTED_SHA in text and 'seed 1, player, transition 0' in log.decode()
  assert 'node total-compatibility.ts && node total-envelopes.ts' in log.decode()
  (OUT/'original-9f-first-failure-npm.log').write_bytes(log)
  retained={n:z.read(n) for n in names if '/' not in n and not n.endswith('/')};retained['native-full.log']=native;retained['official-sanitized-metadata.json']=(json.dumps({k:v for k,v in r.items() if k not in ['actualStart','actualFinish']},indent=2)+'\n').encode()
  proof=OUT/'original-9f-first-failure-bounded.zip'
  with zipfile.ZipFile(proof,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as p:
   for name,data in retained.items():p.writestr(name,data)
  with zipfile.ZipFile(proof) as p:
   assert len(p.namelist())==len(set(p.namelist()))==len(retained) and p.testzip() is None
   for name,data in retained.items():assert p.read(name)==data
  r.update({'safeUniqueEntries':len(names),'fullCrcPass':True,'sourceMapFileCount':len(expected),'sourceAssertions':count,'wholeSourceMapsAgainstImmutableGitPass':True,'originalPipelineResult':'FAIL preserved','firstFailure':'total-compatibility.ts seed1 player transition0 deliberate absence policy differs from frozen historical behavior','originalNativeFullBytes':len(native),'originalNativeFullSha256':hashlib.sha256(native).hexdigest(),'originalNpmFullBytes':len(log),'originalNpmFullSha256':hashlib.sha256(log).hexdigest(),'browserSamplerAndDecode':'NOT EXECUTED: pipeline failed before original browser checks; no old browser PASS substituted','boundedProof':{'path':str(proof),'bytes':proof.stat().st_size,'sha256':hashlib.sha256(proof.read_bytes()).hexdigest(),'entries':len(retained)},'inspectionStatus':'PASS','exitCode':0})
except BaseException as e:r.update({'inspectionStatus':'FAIL','exitCode':1,'errorType':type(e).__name__,'error':str(e)})
finally:r['closedUtc']=stamp();RECEIPT.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['actualStart','actualFinish']}),flush=True)
raise SystemExit(r['exitCode'])
