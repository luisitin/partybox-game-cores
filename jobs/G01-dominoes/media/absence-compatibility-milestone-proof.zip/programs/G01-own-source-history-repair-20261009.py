from pathlib import Path
import subprocess,json,datetime,os
root=Path('/tmp/G01-source-queue-audit-20261009');out=Path('/dev/shm/G01-private-remaining-issue-20261009');branch='job/G01-dominoes-queue-audit-20261009';parent='ce2b5d0ccceb6b3d048ac44c7dbee0e8ec332c1f';protected='eadb642bc1f9f4f2c839c7a6754932e7a5b640ec';canonical='8c57376d817d1b34c165425cd8bf8d9ee219f7f6';native=[]
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(args):
 r=subprocess.run(args,cwd=root,capture_output=True,text=True,env=dict(os.environ,GIT_TERMINAL_PROMPT='0'));native.append({'argv':args,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'closedUtc':stamp()});assert r.returncode==0,(args,r.stderr);return r.stdout
def remote(b):return run(['git','-c','credential.helper=','ls-remote','--heads','origin','refs/heads/'+b]).split()[0]
r={'startedUtc':stamp(),'branch':branch,'expectedParent':parent,'protectedSecondParent':protected,'scope':'Local source history merge resolves add/add PR conflict while preserving exact tested tree; neither protected source nor public PR is merged.','qualification':'PENDING full original current workflow/visual capture'}
try:
 assert run(['git','branch','--show-current']).strip()==branch
 assert run(['git','rev-parse','HEAD']).strip()==parent
 assert not run(['git','status','--porcelain','--untracked-files=no']).strip()
 assert remote(branch)==parent
 assert remote('job/G01-dominoes-queue-audit-20261008')==protected
 assert remote('job/G01-dominoes')==canonical
 tree=run(['git','rev-parse','HEAD^{tree}']).strip()
 changed=run(['git','diff','--name-only',protected,parent]).splitlines();assert len(changed)==14 and all(p.startswith('jobs/G01-dominoes/') for p in changed),changed
 run(['git','merge','--strategy=ours','--no-ff',protected,'-m','G01 preserve completed source ancestry for isolated follow-up'])
 head=run(['git','rev-parse','HEAD']).strip()
 assert run(['git','rev-parse','HEAD^{tree}']).strip()==tree
 assert run(['git','show','-s','--format=%P','HEAD']).strip().split()==[parent,protected]
 assert run(['git','merge-base',protected,head]).strip()==protected
 assert run(['git','diff','--name-only',protected,head]).splitlines()==changed
 r.update({'source':head,'sourceTree':tree,'unchangedTreeComparedWithCe2':True,'parents':[parent,protected],'allForeignPathsIdenticalToProtectedReady11':True,'changedFiles':changed,'sourceCommitUtc':run(['git','show','-s','--format=%cI',head]).strip(),'pushStartedUtc':stamp()})
 run(['git','push','origin',branch]);r['publishedUtc']=stamp()
 assert remote(branch)==head
 assert remote('job/G01-dominoes-queue-audit-20261008')==protected
 assert remote('job/G01-dominoes')==canonical
 assert not run(['git','status','--porcelain','--untracked-files=no']).strip()
 r.update({'normalFastForwardPush':True,'exactRemoteReadback':True,'protectedRefsUnchanged':True,'sourceClean':True,'exitCode':0})
except BaseException as e:r.update({'exitCode':1,'errorType':type(e).__name__,'error':str(e)})
finally:
 r['closedUtc']=stamp();(out/'source-history-repair-native.log').write_text(json.dumps(native,indent=2)+'\n');(out/'source-history-repair-CLOSED.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(r['exitCode'])
