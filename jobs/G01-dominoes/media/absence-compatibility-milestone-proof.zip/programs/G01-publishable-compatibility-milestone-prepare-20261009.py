from pathlib import Path
import datetime,hashlib,json,subprocess,zipfile,shutil,stat
ROOT=Path('/tmp/G01-source-queue-audit-20261009');JOB=ROOT/'jobs/G01-dominoes';OUT=Path('/dev/shm/G01-private-remaining-issue-20261009');PARENT='9facc82d4c88126e6b028e8e8c18ae4637a72d75';PROTECTED='eadb642bc1f9f4f2c839c7a6754932e7a5b640ec'
def sha(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def load(name):return json.loads((OUT/name).read_text())
def dump(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==PARENT
oracle=load('compatibility-oracle-first-CLOSED.json');functional=load('current-functional-first-CLOSED.json');decode=load('current-functional-first-decode-CLOSED.json');failed=load('original-9f-first-failure-whole-CLOSED.json');history=load('source-history-repair-CLOSED.json')
assert oracle['status']=='PASS' and oracle['allFrozenInputsUnchanged'] and oracle['bothFullRegenerationsByteIdentical'] and oracle['naturalClosure'] and not oracle['remainingOwnedChildren'] and not oracle['remainingOwnedDetached']
assert oracle['actualReport']['games']==oracle['actualReport']['connectedGames']==1003 and oracle['actualReport']['connectedWholeStateMismatches']==0 and oracle['actualReport']['stateMismatches']==0
assert functional['status']=='PASS' and functional['allFrozenInputsUnchanged'] and functional['naturalClosure'] and not functional['remainingOwnedChildren'] and not functional['remainingOwnedDetached']
assert decode['status']=='PASS' and decode['frames']==333 and decode['allClipAndDecoderLibraryIdentitiesUnchanged']
assert failed['inspectionStatus']=='PASS' and failed['originalPipelineResult']=='FAIL preserved' and failed['wholeOfficialDigestPass'] and failed['fullCrcPass']
assert history['unchangedTreeComparedWithCe2'] and history['protectedRefsUnchanged']
assert (JOB/'study-presence-baseline.ts').read_bytes()==subprocess.check_output(['git','show',PROTECTED+':jobs/G01-dominoes/core.ts'],cwd=ROOT)
for name in ['core.ts','play.html','ui.ts','browser.ts','browser-evidence.ts','privacy-veil-check.ts','mutations.ts']:
 assert (JOB/name).read_bytes()==subprocess.check_output(['git','show',PARENT+':jobs/G01-dominoes/'+name],cwd=ROOT),name
assert (ROOT/'.github/workflows/G01.yml').read_bytes()==subprocess.check_output(['git','show',PROTECTED+':.github/workflows/G01.yml'],cwd=ROOT)
package=json.loads((JOB/'package.json').read_text());oldPackage=json.loads(subprocess.check_output(['git','show',PROTECTED+':jobs/G01-dominoes/package.json'],cwd=ROOT));assert package['scripts']['test'].replace(' && node --test absence-presence.test.ts','')==oldPackage['scripts']['test']
clip=Path(functional['actualReport']['cases'][0]['video']['path']);assert sha(clip)=={k:functional['actualReport']['cases'][0]['video'][k] for k in ['bytes','sha256']};assert clip.stat().st_size<10000000
publicClip=JOB/'media/milestone-19-absent-presence-functional.webm';shutil.copyfile(clip,publicClip);assert publicClip.read_bytes()==clip.read_bytes()
publicFailure=JOB/'media/absence-first-ci-failure-proof.zip';privateFailure=OUT/'original-9f-first-failure-bounded.zip';shutil.copyfile(privateFailure,publicFailure);assert publicFailure.read_bytes()==privateFailure.read_bytes()
members={}
def include(name,path):
 assert name not in members and not Path(name).is_absolute() and '..' not in Path(name).parts and '\\' not in name
 assert path.is_file() and not path.is_symlink();members[name]=path.read_bytes()
names=['compatibility-oracle-first-CLOSED.json','compatibility-oracle-first-native.log','compatibility-oracle-first-inputs-before.json','compatibility-oracle-first-inputs-after.json','compatibility-report-regeneration-1.json','compatibility-report-regeneration-2.json','current-functional-first-CLOSED.json','current-functional-first-native.log','current-functional-first-inputs-before.json','current-functional-first-inputs-after.json','current-functional-first-decode-CLOSED.json','current-functional-first-complete-framehash.txt','original-9f-first-failure-whole-CLOSED.json','original-9f-first-failure-native-full.log','original-9f-first-failure-npm.log','original-9f-first-failure-bounded.zip','source-history-repair-CLOSED.json','source-history-repair-native.log','main-after-source-history9f-CLOSED.json','main-after-source-history9f-native.log','corrected-first-source-publication-CLOSED.json','first-publication-43f28f5-invalid-duplicate-proof.zip','first-publication-43f28f5-failure-receipt.json']
for name in names:include('actual/'+name,OUT/name)
for name in ['report.json','phone-normal.png','tv-normal.png','phone-reduced.png']:include('actual/current-functional-first/'+name,OUT/'current-functional-first'/name)
for name in ['G01-current-functional-milestone-first-20261009.mjs','G01-current-functional-milestone-first-controller-20261009.py','G01-compatibility-oracle-first-controller-20261009.py','G01-original-9f-first-failure-transfer-20261009.py','G01-own-source-history-repair-20261009.py','G01-publishable-compatibility-milestone-prepare-20261009.py']:include('programs/'+name,Path('/dev/shm')/name)
for name in ['total-compatibility.ts','total-compatibility-report.json','study-presence-baseline.ts','absence-presence.test.ts']:include('current-oracle/'+name,JOB/name)
zipPath=JOB/'media/absence-compatibility-milestone-proof.zip'
with zipfile.ZipFile(zipPath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,data in sorted(members.items()):
  entry=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));entry.compress_type=zipfile.ZIP_DEFLATED;z.writestr(entry,data)
with zipfile.ZipFile(zipPath) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(members) and z.testzip() is None
 for name,data in members.items():assert z.read(name)==data
report={'schema':'g01-absent-presence-compatibility-milestone/1','preparedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceParent':PARENT,'protectedReady11':PROTECTED,'protectedCanonicalDraft1':'8c57376d817d1b34c165425cd8bf8d9ee219f7f6','currentProductUnchangedFromStableCandidate':{name:sha(JOB/name) for name in ['core.ts','play.html','ui.ts','browser.ts','browser-evidence.ts','privacy-veil-check.ts','mutations.ts']},'originalWorkflowByteUnchanged':True,'originalDefaultCommandRetainedWithAddedAbsenceRegressionSuite':True,'compatibility':oracle,'functionalMilestone':functional,'fullDecode':decode,'firstActualOriginalWorkflow':{'run':failed['run'],'job':failed['job'],'artifactId':failed['artifactId'],'status':'FAIL preserved','wholeArchiveBytes':failed['expectedBytes'],'wholeArchiveSha256':failed['expectedSha256'],'fullCrcPass':failed['fullCrcPass'],'safeUniqueEntries':failed['safeUniqueEntries'],'sourceMapFileCount':failed['sourceMapFileCount'],'sourceAssertions':failed['sourceAssertions'],'nativeFullBytes':failed['originalNativeFullBytes'],'nativeFullSha256':failed['originalNativeFullSha256'],'firstFailure':failed['firstFailure'],'browserSamplerAndDecode':failed['browserSamplerAndDecode']},'localSourceHistoryRepair':history,'currentCapture':{'path':str(publicClip.relative_to(JOB)),**sha(publicClip),'nativeExportFrames':333,'nativeExportDurationSeconds':13.32,'scope':'Functional visual milestone; encoded25fps is not measured native refresh/performance'},'fullRawProof':{'path':str(zipPath.relative_to(JOB)),**sha(zipPath),'exactSafeUniqueMembers':len(members),'fullCrcAndEveryMemberBytePass':True},'retainedFirstFailureProof':{'path':str(publicFailure.relative_to(JOB)),**sha(publicFailure)},'qualification':'PENDING original whole current exact-head CI/native official artifact, then separately measured/logged/pushed post-green KEEP rounds. No qualified new gain/formal round yet.','limitations':['No native FPS improvement, physical-phone or UI absence-control claim.','First43 genuinely late invalid duplicate ZIP/stale handoff retained; controlled concurrent-build drift FAIL and empty helper UNEXECUTED retained.','Current oracle changes expected intentional absent-seat scheduling explicitly, retaining every original seed/event and strict physical/RNG/result fields; adds a separate full connected-state lane with zero normalization.','Original Ready11 eadb and Draft1 canonical8c remain unchanged and unmerged; all old failures and R25–28 stop stay historical.']}
dump(JOB/'absence-compatibility-milestone.json',report)
prefix='''## Current isolated absence follow-up: Draft PR20, full qualification pending

Owner: codex-domino-queue-audit-20261009. Branch:
job/G01-dominoes-queue-audit-20261009 from claimed MAIN ba14179.
PR20 targets protected Ready11 eadb; canonical Draft1 8c stays untouched.
Original Ready11 whole1318 acceptance and R25–28 stopping rounds remain historical.

Actual source9f history repair published13:44:37.278902/closed13:44:39.036081.
It preserves exact ce2 tree029dc9f and adds eadb as second parent, making the
14-file G01-only PR mergeable. No public PR merge, force or protected-ref change.
Original run37939034123/job113848358588 actually FAILED13:45:35 before browser:
historical total-compatibility expected departed active seat to remain idle.
Entire first official11620331652,128399627B/SHA77dd5ac989493bc3a74598a7310b305
d6e03f19795e3470ae056631c2de99ad7 has397 safe unique entries/full CRC/all197
source maps/572 immutable assertions/native failure retained, inspection closed
13:52:16.097435. Native105111B/SHA14aedac882627c2395bbdbb79b4668310eca6b3a050
633145951756af299264f. No historical browser success substituted.

The corrected oracle keeps every original1003 seed/event and the exact frozen
949 engine, two historical idleTurns/deadline normalisations only. Explicit
absence is independently replayed through unchanged old legal/apply/greedy,
strict stock+N-1 bound, all28 conservation and RNG.372510 full transitions/
827 absence actions/1003 results agree. Separate exact eadb module1003 fully
connected matches/377896 transitions compare EVERY WHOLESTATE byte with no
normalisation. Strict compiler/two whole byte-identical943B regenerated reports
PASS; controller closed13:59:36.736578/all3327 input aliases/groups/detached[].
No production core/page/strategy/native sampler/clock/gate changed here.

First source-bound actual functional milestone: TV, phone4x normal and phone
reduced motion;24 legal actions/24 private handovers/full30s next-human clocks,
zero HTTP/errors. Closed13:48:56.856901/all3326 aliases/natural/group/detached[].
Actual phone capture1576893B,13.32s,333VP8 frames completely independently
decoded13:56:43.574302/all214 decoder/library guards. Nativeexport25fps is NOT
a performance measurement, file-navigation proof or physical phone result.
Full source/raw/helper/controller/alias/failure evidence and clip identities:
absence-compatibility-milestone.json and its safe unique complete media ZIP.

Prior stable repair control remains468 all-human complete pairs/527041
assertions/74211 exact physical checkpoints:427 old budget failures to0new.
Seed1 Draw100 7303305→90587 simulatedms, same19 rounds/scores94,133.
360 earlier connected games/101238 exact transitions and360 empty/360 paused
drop/resume controls pass. Seven new default regressions pass/six old fail;
those targeted smoke runs are not whole current hosted qualification.

First43 late invalid ZIP/stale copied NEXT, concurrent-build guard failure and
ENOSPC/empty-helper UNEXECUTED remain preserved; no retroactive cadence credit.
Last actual source push9f13:44:37.278902: early14:09:37.278902/hard14:14:37.278902.
Read the next actual normal push receipt for this checkpoint's head/timing.
Refresh only own G01 MAIN row after each push under exclusive root lease.

NEXT: keep PR20 Draft; accept every original full check plus new regression,
complete actual native log/first whole official ZIP/current Git bytes/current
both native browser profiles/36-frame official capture with unchanged reader.
If golden expectations differ, preserve first failure and reason independently;
no skipped checks, weaker gates or repeat unchanged timing. No qualified new
gain/formal KEEP credit yet. After complete current green, reread/rank5,
measure/log/push each review separately until3 player-no-gain rounds. Preserve
all original sources and never merge public PRs without explicit authorization.

## Protected historical handoff below (verbatim; prior Draft statements historical)

'''
nextFile=JOB/'NEXT.md';text=nextFile.read_text();marker='# G01 delivery review — incomplete';assert marker in text;nextFile.write_text(prefix+text[text.index(marker):])
for name,heading,body in [
 ('VERIFY.md','Current absence compatibility/visual milestone','Commands: python /dev/shm/G01-compatibility-oracle-first-controller-20261009.py invokes unchanged strict compiler and node total-compatibility.ts --write twice. Both943B reports SHAcb9f3d4ea129bf7e0c9310f8080807ab85669f410ace2ff7140d8aacfeb0442b byte-identical; all3327 frozen aliases unchanged; natural close13:59:36.736578. All original1003 seeds/events/physical fields/results preserved; independent old-engine827 legal absence actions pass tighter stock+N-1 and28-tile/RNG checks. New separate1003 fullyconnected games377896 whole-state transitions exactly match byte-frozen protected eadb with no normalized field. Original949 baseline is unchanged. Current functional helper/controller: actual3 cases TV/phone4x/reduced motion24 legal actions/24 private handovers, full human clocks/offline/error/privacy pass13:48:56.856901/all3326 aliases/no signals/owned groups or detached children. Complete333-frame VP8 decoder ffprobe/count_frames + ffmpeg -xerror framehash pass13:56:43.574302/all214 library guards; export25fps is not performance. Full first original9f run37939034123 actually FAIL remains; entire official128399627B/77dd5ac989493bc3a74598a7310b305d6e03f19795e3470ae056631c2de99ad7 CRC/397unique/source197/native105111B verified. No browser test ran there. All raw inputs/outputs/helpers/first failure archived; new whole current original pipeline still pending.'),
 ('ASSUMPTIONS.md','Explicit absence oracle and source ancestry','The frozen pre-guard compatibility reference had deliberately required old absent-turn waiting. That expectation conflicts with this documented, measured new presence policy. Preserve every old seed/event/state assertion; explicitly replay old legal/raw apply/greedy at declaration time, with a tighter stock+N-1 physical-progress/conservation/RNG bound. Only prior idle/deadline normalizations stay; separate exact protected eadb engine checks every whole connected state. This is an expectation correction for intentional behavior, not a skipped mismatch or weaker game/native gate. study-presence-baseline.ts is exact immutable eadb core22697B/SHAb8838080d2ac938e9ad3da11966c94895d4fb3991ca99f0bdf2c0a6364644c95, verified from public Git. Original failed workflow/all397-entry whole ZIP/full native remain retained. User requires new branch from claimed MAIN; local ours ancestry merge preserves identical tested ce2 tree and both real parents to resolve add/add conflicts against Ready11. It neither merges a public PR nor mutates protected old refs. Functional page capture uses exact setContent bytes/native animations/no clock installation; it does not expose a UI absence event or prove FPS/file-navigation/hardware. Own/dev/shm outputs avoid shared TMP capacity. Later docs/evidence/source commits need their own full original CI; controlled earlier scopes do not grant whole current acceptance.'),
 ('REVIEW.md','Current prequalification audit, no post-green round','Current ranked5:1 full original new-head qualification/intentional-absence reference integration;2 declared absence paused/empty/reconnect and next-human timing;3 whole connected-state/privacy/RNG parity;4 failed historical Worker-response benefit, no unchanged native retry;5 physical-phone/finite upstream-strength scope. First whole9f fails old absence expectation. Corrected strict independent old-engine replay and exact1003 connected-match lane plus full native functional three-case milestone now pass bounded guards. Product bytes stay the stable absence repair. New exact-head whole original CI and genuine official full acceptance still required. No qualified new gain or completed formal review; protected R25–28 stop remains historical.'),
 ('LOOP.md','Evidence checkpoint, not a KEEP round','2026-10-09: exact-tree source-history repair makes Draft20 mergeable; preserve genuine original9f whole failure. Corrected explicit-absence old-engine oracle retains1003 seeds/372510 original physical transitions/827 independently bounded moves; extra1003 connected games377896 WHOLESTATE transitions byte-exact eadb; two full reports identical/all3327 guards natural13:59:36.736578. Actual new-page TV/phone4x/reduced24 private handovers/all3326 guards and333 fully decoded functional capture frames pass. No production/native gate edit, qualified new gain or formal post-green credit; complete current original pipeline pending.')
]:
 p=JOB/name;p.write_text(p.read_text()+'\n## '+heading+'\n'+body+'\n')
readme=JOB/'README.md';text=readme.read_text().replace('New7-test regressions pass/old6 fail. Original full CI/video/KEEP remain pending.','New7-test regressions pass/old6 fail. First full CI failure retained; new full CI/KEEP pending.').replace('NEXT.md records the retained failed first package and truthful source cadence.','1003 full connected matches and24 private handovers pass; NEXT.md records evidence/cadence.');assert len(text.splitlines())<60;readme.write_text(text)
receipt={'status':'PASS','preparedUtc':report['preparedUtc'],'sourceParent':PARENT,'verifiedProof':report['fullRawProof'],'actualCapture':report['currentCapture'],'scope':'Prepared source evidence/handoff, no publication or full qualification claimed','allOriginalProductBytesUnchanged':True};dump(OUT/'compatibility-milestone-preparation-CLOSED.json',receipt);print(json.dumps(receipt))
