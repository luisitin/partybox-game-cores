import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.work/queue-audit-20261008'
READY_PATH = WORK / 'worker-profile-ready.json'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity(path):
    actual = Path(path).resolve()
    data = actual.read_bytes()
    return {'path': str(actual), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def live_group(group):
    members = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            fields = (entry/'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group and fields[0] not in ['Z', 'X']:
                members.append(int(entry.name))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return members

def signal_group(group, value):
    try:
        os.killpg(group, value)
    except ProcessLookupError:
        pass

ready = json.loads(READY_PATH.read_text())
manifest_before = identity(READY_PATH)
controller_before = identity(__file__)
for group in ['sources', 'binaries']:
    for expected in ready[group].values():
        assert identity(expected['path']) == expected, ('READY drift', expected['path'])
receipt = {'schema': 'g01-original-native-profile-first-controller/1', 'scope': 'Once-only unchanged original browser functional and300-native-profile gates with genuine milestone15 capture; no paired player-gain claim', 'startedAt': now(), 'ready': manifest_before, 'controllerBefore': controller_before, 'command': [ready['binaries']['node']['path'], 'browser.ts'], 'status': 'STARTED'}
receipt_path = WORK / 'worker-profile-first-controller.json'
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': 'STARTED', 'startedAt': receipt['startedAt'], 'command': receipt['command']}), flush=True)
environment = dict(os.environ)
environment.update(ready['environment'])
process = None
exit_code = None
receipt['naturalClosure'] = False
try:
    with (WORK / 'worker-profile-first.log').open('w') as log:
        process = subprocess.Popen(receipt['command'], cwd=ROOT/'jobs/G01-dominoes', env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        receipt['childPid'] = process.pid
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        exit_code = process.wait(timeout=180)
        receipt['naturalClosure'] = True
except BaseException as error:
    receipt['failure'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    # Every post-spawn operation, including receipt writes, is within this cleanup.
    # Reap the actual child and close any still-live owned group before CLOSED/FAIL.
    if process is not None:
        running = process.poll() is None or bool(live_group(process.pid))
        if running:
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGTERM)
        try:
            exit_code = process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGKILL)
            exit_code = process.wait(timeout=10)
        deadline = time.monotonic() + 2
        while live_group(process.pid) and time.monotonic() < deadline:
            time.sleep(0.025)
        if live_group(process.pid):
            receipt['exceptionalCleanup'] = True
            receipt['naturalClosure'] = False
            signal_group(process.pid, signal.SIGKILL)
            deadline = time.monotonic() + 2
            while live_group(process.pid) and time.monotonic() < deadline:
                time.sleep(0.025)
        receipt['remainingOwnedLiveProcesses'] = live_group(process.pid)
        assert not receipt['remainingOwnedLiveProcesses'], 'Owned process group still live; no CLOSED/FAIL release'
        receipt['childClosedAt'] = now()
    else:
        receipt['naturalClosure'] = False
        receipt['remainingOwnedLiveProcesses'] = []
        receipt['childClosedAt'] = None
receipt['exitCode'] = exit_code
receipt['log'] = identity(WORK/'worker-profile-first.log')
receipt['guardsAfter'] = {group: {name: identity(expected['path']) for name, expected in ready[group].items()} for group in ['sources', 'binaries']}
receipt['sourceAndBinaryGuardsPassed'] = receipt['guardsAfter'] == {group: ready[group] for group in ['sources', 'binaries']}
receipt['readyAfter'] = identity(READY_PATH)
receipt['controllerAfter'] = identity(__file__)
receipt['controllerAndReadyUnchanged'] = receipt['readyAfter'] == manifest_before and receipt['controllerAfter'] == controller_before
proof_path = ROOT/'jobs/G01-dominoes/.tmp/g01-evidence/browser-current.json'
if proof_path.exists():
    receipt['actualProof'] = identity(proof_path)
    proof = json.loads(proof_path.read_text())
    receipt['proofStatus'] = proof.get('status')
    try:
        import math
        from datetime import datetime as DateTime
        assert DateTime.fromisoformat(proof['startedAt'].replace('Z', '+00:00')) >= DateTime.fromisoformat(receipt['startedAt'])
        assert proof['schema'] == 'g01-browser-evidence/1' and proof['status'] == 'PASS' and proof['functional'] == 'PASS'
        assert proof['sampler'] == {'intervals': 300, 'warmup': 0, 'filtered': 0, 'timestamp': 'native requestAnimationFrame callback', 'gate': {'minimumFps': 58, 'maximumP95Ms': 18}}
        assert proof['browserClosedAt'] and proof['errors'] == [] and proof['externalRequests'] == []
        assert proof['sourcesBefore'] == proof['sourcesAfter']
        for binary in ['node', 'chromium']:
            assert proof[binary+'Before'] == proof[binary+'After'] == ready['binaries'][binary]
        assert len(proof['profiles']) == 2
        native = []
        for profile, name, rate, viewport in zip(proof['profiles'], ['tv', 'phone'], [1, 4], [{'width': 1920, 'height': 1080}, {'width': 390, 'height': 844}]):
            assert profile['name'] == name and profile['viewport'] == viewport
            assert profile['throttle'] == rate and profile['actualCpuThrottleRate'] == rate and profile['clockInstalled'] is False
            values, times = profile['intervals'], profile['timestamps']
            assert len(values) == 300 and len(times) == 301 and all(math.isfinite(v) and v > 0 for v in values)
            assert all(abs(values[i] - (times[i+1]-times[i])) < 1e-8 for i in range(300))
            mean = sum(values)/300
            assert abs(mean - profile['meanMs']) < 1e-8 and abs(1000/mean - profile['fps']) < 1e-8
            assert profile['p95Ms'] == sorted(values)[285] and profile['p99Ms'] == sorted(values)[297]
            assert profile['fps'] >= 58 and profile['p95Ms'] <= 18 and profile['passed'] is True
            native.append({k: profile[k] for k in ['name', 'frames', 'fps', 'meanMs', 'p95Ms', 'p99Ms']})
        capture = proof['capture']
        assert capture['file'] == identity(ROOT/'jobs/G01-dominoes'/ready['capturePath'])
        assert capture['file']['sha256'] == identity(ROOT/'jobs/G01-dominoes/.tmp/g01-evidence/current-capture.webm')['sha256']
        assert capture['file']['bytes'] < 10_000_000 and capture['decode']['frames'] == 36
        metadata = capture['probe']['metadata'];video = metadata['streams'][0]
        assert video['codec_name'] == 'vp9' and video['width'] == 1920 and video['height'] == 1080 and int(video['nb_read_frames']) == 36 and video['r_frame_rate'] == '12/1'
        assert float(metadata['format']['duration']) == 3
        for component, binary in [('decode', 'ffmpeg'), ('probe', 'ffprobe')]:
            actual = capture[component]['tool'];assert {k: actual[k] for k in ['path', 'bytes', 'sha256']} == ready['binaries'][binary]
        encoder = proof['encoding'];assert encoder['status'] == 0 and len(encoder['sourceFrames']) == 36
        assert {k: encoder['tool'][k] for k in ['path', 'bytes', 'sha256']} == ready['binaries']['ffmpeg']
        framehash = ROOT/'jobs/G01-dominoes/.tmp/g01-evidence/capture-framehash.txt'
        assert identity(framehash)['sha256'] == capture['decode']['completeFramehashSha256']
        receipt['nativeAcceptance'] = {'status': 'PASS', 'profiles': native, 'capture': capture['file'], 'scope': 'Original gates passed once; player gain not measured'}
    except BaseException as error:
        receipt['nativeAcceptance'] = {'status': 'FAIL', 'type': type(error).__name__, 'message': str(error)}
        receipt['proofStatus'] = 'UNACCEPTED'
receipt['status'] = 'PASS' if exit_code == 0 and receipt['naturalClosure'] and not receipt.get('failure') and receipt['sourceAndBinaryGuardsPassed'] and receipt['controllerAndReadyUnchanged'] and receipt.get('proofStatus') == 'PASS' else 'FAIL'
receipt['controllerFinishedAt'] = now()
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ['status', 'childClosedAt', 'controllerFinishedAt', 'exitCode', 'naturalClosure', 'sourceAndBinaryGuardsPassed', 'controllerAndReadyUnchanged']}), flush=True)
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
