import assert from 'node:assert/strict';import{writeFileSync,readFileSync}from'node:fs';import{createHash}from'node:crypto';
import {game,start,eventFor,finish}from'../../jobs/G05-hearts/tests/helpers.mjs';
import {makeSave,parseSave}from'../../jobs/G05-hearts/.build/jobs/G05-hearts/src/save.js';
const root=new URL('./',import.meta.url),save=(name,v)=>writeFileSync(new URL(name,root),JSON.stringify(v,null,2)+'\n');
const configs=[];for(const n of[3,4,5,6])for(const moon of['add','subtract'])for(const jack of[false,true])for(const noPass of[false,true])for(const clock of[0,10])configs.push({n,settings:{target:25,moon,jack,noPass,turnSeconds:clock,queenBreaks:jack,threeDeck:noPass?'clubs':'diamonds'}});
const prefs=n=>Array.from({length:n},(_,i)=>({name:'Player '+(i+1),mode:'normal'}));
const code=new URL('../../jobs/G05-hearts/src/save.ts',import.meta.url),sourceHash=createHash('sha256').update(readFileSync(code)).digest('hex'),receipt={startedAt:new Date().toISOString(),sourceHash,configs:configs.length,purpose:'post-green substantive recovery audits; no browser or timing claim',rounds:[]};
let all=0;const phases=new Set(),seats=new Set(),samples=[];
for(let i=0;i<configs.length;i++){const c=configs[i];let s=start(4000+i,c.n,c.settings),steps=0;const snapshots=new Map();
 while(true){if(!snapshots.has(s.phase.id))snapshots.set(s.phase.id,structuredClone(s));const before=JSON.stringify(s);assert.ok(parseSave(makeSave(s,prefs(c.n),s.phase.startedAt+1)),JSON.stringify({c,phase:s.phase.id,hand:s.handNumber,trick:s.trickNumber}));assert.equal(JSON.stringify(s),before);all++;phases.add(s.phase.id);seats.add(c.n);
 if(s.phase.id==='done')break;assert.ok(steps++<10000,'every full match terminates');const e=eventFor(s,'normal',steps),next=game.reduce(s,e);assert.notEqual(next,s);s=next;
 }for(const state of snapshots.values())samples.push({config:c,state});
}
receipt.rounds.push({round:15,weaknesses:['partial-trick-only new save coverage','alternate three-player cut not in new regression','Jack and subtract-moon recovery interactions','timed hold/no-pass combinations','physical-phone coverage remains CPU4x approximation'],selected:'Full-match save validation across all native phases and house-rule combinations',measured:{completeMatches:configs.length,validSnapshots:all,counts:[...seats],phases:[...phases]},productChange:false,playerGain:false,noGainStreak:1});save('round15.json',receipt.rounds.at(-1));console.log(JSON.stringify(receipt.rounds.at(-1)));
let restored=0;
for(const sample of samples){const s=sample.state,n=sample.config.n,good=makeSave(s,prefs(n),s.phase.startedAt+1),parsed=parseSave(JSON.parse(JSON.stringify(good)));assert.ok(parsed);const r=s.phase.id==='done'?parsed.state:game.reduce(parsed.state,{type:'vip',action:'resume',now:s.phase.startedAt+10000});
 const original=finish(s).state,recovered=finish(r).state;assert.deepEqual(recovered.scores,original.scores);assert.deepEqual(recovered.history,original.history);assert.deepEqual(game.results(recovered),game.results(original));restored++;
}
receipt.rounds.push({round:16,weaknesses:['whole-game results after recovery need direct comparison','paused timed saves shift deadlines','scored-hand recovery must not score twice','completed-match recovery must retain results','real device coverage unavailable'],selected:'Actual resumed reducer matches final score/history/results for each phase and rule combination',measured:{restoredGames:restored,phasesPerConfiguration:game.phases.length,counts:[3,4,5,6]},productChange:false,playerGain:false,noGainStreak:2});save('round16.json',receipt.rounds.at(-1));console.log(JSON.stringify(receipt.rounds.at(-1)));
let secretComparisons=0,aliases=0;
for(const sample of samples){const s=sample.state,n=sample.config.n,parsed=parseSave(makeSave(s,prefs(n),s.phase.startedAt+1));assert.ok(parsed);const state=parsed.state,before=JSON.stringify(state),tv=game.tvView(state);assert.ok(!Object.hasOwn(tv,'hands'));
 for(const id of state.order){const ctrl=game.controllerView(state,id),alt=structuredClone(state);
 for(const other of state.order.filter(x=>x!==id))alt.hands[other].reverse();
 assert.deepEqual(game.tvView(alt),tv);assert.deepEqual(game.controllerView(alt,id),ctrl);secretComparisons+=2;
 if(ctrl.hand)ctrl.hand.fill(99);if(ctrl.legal)ctrl.legal.fill(99);if(ctrl.ownPass)ctrl.ownPass.fill(99);if(ctrl.sentCards)ctrl.sentCards.fill(99);if(ctrl.receivedCards)ctrl.receivedCards.fill(99);
 assert.equal(JSON.stringify(state),before);aliases++;
 }
}
assert.equal(createHash('sha256').update(readFileSync(code)).digest('hex'),sourceHash);
receipt.rounds.push({round:17,weaknesses:['recovered views could accidentally reveal opponents','returned controller data could alias recovered state','passing memories after restore need privacy checks','completed-table private card residues','historical sampler lacks native per-frame witnesses'],selected:'Recovered TV/controller hidden-hand ordering and mutable-result isolation in every phase/configuration',measured:{hiddenHandComparisons:secretComparisons,controllerMutationIsolationChecks:aliases,restoredStates:samples.length},productChange:false,playerGain:false,noGainStreak:3});save('round17.json',receipt.rounds.at(-1));console.log(JSON.stringify(receipt.rounds.at(-1)));
receipt.closedAt=new Date().toISOString();receipt.passed=true;save('combined.json',receipt);
