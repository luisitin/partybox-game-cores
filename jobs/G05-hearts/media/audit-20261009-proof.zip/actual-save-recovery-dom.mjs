import {chromium} from '/workspace/game-cores-G04-reverify-2019/jobs/G04-reality-check/node_modules/playwright/index.mjs';
import {readFileSync,writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const base='/tmp/game-cores-G05-audit-20261009/.work/audit-20261009';
const valid=JSON.parse(readFileSync(base+'/genuine-human-valid-save.json','utf8'));
const corrupt=JSON.parse(readFileSync(base+'/genuine-human-erased-trick-save.json','utf8'));
let browser;const cases=[];let error=null;
try {
 browser=await chromium.launch({executablePath:'/home/agent/.cache/ms-playwright/chromium_headless_shell-1194/chrome-linux/headless_shell',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 for(const viewport of[{width:1920,height:1080},{width:390,height:844}])for(const edition of['canonical85d','currentCorrected']){
  const context=await browser.newContext({viewport});
  try{
   await context.addInitScript(value=>localStorage.setItem('partybox-hearts-save-v1',JSON.stringify(value)),corrupt);
   const page=await context.newPage(),requests=[],errors=[];
   page.on('request',request=>{if(!request.url().startsWith('file:'))requests.push(request.url());});page.on('pageerror',err=>errors.push(String(err)));
   const path=edition==='canonical85d'?base+'/canonical-85d-play.html':'/tmp/game-cores-G05-audit-20261009/jobs/G05-hearts/play.html';
   await page.goto(pathToFileURL(path).href,{waitUntil:'domcontentloaded',timeout:10000});
   const witness=await page.evaluate(()=>({resumeVisible:!document.getElementById('resume-box').hidden,resumeDisabled:document.getElementById('resume-saved').disabled,description:document.getElementById('resume-description').textContent,privateCards:document.querySelectorAll('.hand-card').length,storageRetained:localStorage.getItem('partybox-hearts-save-v1')!==null}));
   assert.equal(witness.resumeVisible,true);assert.equal(witness.resumeDisabled,edition==='currentCorrected');assert.equal(witness.privateCards,0);assert.equal(witness.storageRetained,true);
   if(edition==='currentCorrected')assert.equal(witness.description,'The saved table could not be opened.');
   assert.deepEqual(requests,[]);assert.deepEqual(errors,[]);
   const screenshot=`${edition}-${viewport.width}-corrupt-save.png`;await page.screenshot({path:base+'/'+screenshot});
   cases.push({edition,viewport,case:'deliberately erased genuine human partial second trick',actualDiskPage:path,...witness,requests,errors,screenshot});
  }finally{await context.close();}
 }
 const context=await browser.newContext({viewport:{width:390,height:844}});
 try{
  await context.addInitScript(value=>localStorage.setItem('partybox-hearts-save-v1',JSON.stringify(value)),valid);
  const page=await context.newPage(),requests=[],errors=[];page.on('request',r=>{if(!r.url().startsWith('file:'))requests.push(r.url());});page.on('pageerror',e=>errors.push(String(e)));
  await page.goto(pathToFileURL('/tmp/game-cores-G05-audit-20261009/jobs/G05-hearts/play.html').href,{waitUntil:'domcontentloaded',timeout:10000});assert.equal(await page.locator('#resume-saved').isDisabled(),false);
  const witness=await page.evaluate(()=>{document.getElementById('resume-saved').click();return window.__hearts.snapshot();});
  assert.equal(witness.view.phaseId,'play');assert.equal(witness.view.actor,valid.state.actor);assert.equal(witness.view.trickNumber,1);assert.deepEqual(witness.view.trick,valid.state.trick);assert.equal(witness.privateCards,0);assert.equal(witness.revealed,null);
  await page.locator('#start-turn').click();assert.equal(await page.locator('.hand-card').count(),valid.state.hands[valid.state.actor].length);assert.deepEqual(requests,[]);assert.deepEqual(errors,[]);
  cases.push({edition:'currentCorrected',viewport:{width:390,height:844},case:'genuine human valid save resumes exact current trick concealed, then owner reveals',accepted:true,actualResumeWitness:witness,ownHandRevealedAfterExplicitClick:true,requests,errors});
 }finally{await context.close();}
}catch(e){error={name:e.name,message:e.message,stack:e.stack};}
finally{
 if(browser)await browser.close();
 const receipt={closedAt:new Date().toISOString(),scope:'actual unmodified file pages/native DOM; corruption injected only into localStorage data before load; no native clock,RAF,Date,timer override; no frame sampling/performance/FPS/settling trial',cases,passed:error===null,error};
 writeFileSync(base+'/actual-save-recovery-dom.json',JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
}
process.exitCode=error?1:0;
