from pathlib import Path
import ctypes,os,signal,subprocess,datetime,json,hashlib,traceback
repo=Path('/tmp/game-cores-G05-audit-20261009');b=repo/'.work/audit-20261009';driver=b/'actual-save-recovery-dom.mjs';node=Path(subprocess.check_output(['which','node'],text=True).strip()).resolve();chrome=Path('/home/agent/.cache/ms-playwright/chromium_headless_shell-1194/chrome-linux/headless_shell');child=None;status=None;error=None;cleanup=[]
names=subprocess.check_output(['git','ls-tree','-r','--name-only','85d373c5c7eaa946acc84ed316098d63fa4eac8b','--','jobs/G05-hearts','contract','.github/workflows/G05.yml'],cwd=repo,text=True).splitlines()
paths=[repo/n for n in names]+[Path(__file__),driver,b/'genuine-human-valid-save.json',b/'genuine-human-erased-trick-save.json',b/'canonical-85d-play.html',node,chrome]
for runtime in [Path('/workspace/game-cores-G04-reverify-2019/jobs/G04-reality-check/node_modules/playwright'),Path('/workspace/game-cores-G04-reverify-2019/jobs/G04-reality-check/node_modules/playwright-core')]:paths+=list(p for p in runtime.rglob('*') if p.is_file() and p.suffix in ['.js','.mjs','.json'])
def guards():return{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
def owned():
 records=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   try:
    s=(p/'stat').read_text();t=s[s.rfind(')')+2:].split();records.append({'pid':int(p.name),'ppid':int(t[1]),'pgid':int(t[2]),'state':t[0]})
   except(OSError,ValueError,IndexError):pass
 selected={os.getpid()};result=[]
 for _ in range(len(records)+1):
  new=[r for r in records if r['ppid']in selected and r['pid']not in selected]
  if not new:break
  result+=new;selected.update(r['pid']for r in new)
 return result
before=guards();r={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'bounded untimed actual file recovery before/after; no elapsed experiment','frozenInputCount':len(before)};(b/'dom-frozen-before.json').write_text(json.dumps(before,indent=2)+'\n')
try:
 ctypes.CDLL(None).prctl(36,1,0,0,0)
 with(b/'dom.stdout.log').open('wb')as out,(b/'dom.stderr.log').open('wb')as err:
  child=subprocess.Popen([str(node),str(driver)],cwd=repo,stdout=out,stderr=err,start_new_session=True);status=child.wait(timeout=45)
 assert status==0,'actual native functional driver failed '+str(status)
 try:
  while True:
   p,c=os.waitpid(-1,os.WNOHANG)
   if p==0:break
 except ChildProcessError:pass
 assert not owned(),'owned detached browser descendants survive natural driver close'
 result=json.loads((b/'actual-save-recovery-dom.json').read_text());assert result['passed'] and len(result['cases'])==5
 after=guards();assert before==after,'frozen sources/runtime inputs changed';(b/'dom-frozen-after.json').write_text(json.dumps(after,indent=2)+'\n')
except BaseException as exc:error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
finally:
 if child and child.poll()is None:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
 if child:status=child.wait()
 remaining=owned()
 if remaining:
  for g in sorted({p['pgid']for p in remaining if p['pgid']!=os.getpgrp()}):
   try:os.killpg(g,signal.SIGKILL);cleanup.append({'actualOwnedGroupKilled':g})
   except ProcessLookupError:pass
  for p in remaining:
   try:os.kill(p['pid'],signal.SIGKILL)
   except ProcessLookupError:pass
  try:
   while True:os.waitpid(-1,0)
  except ChildProcessError:pass
 survivors=owned();r.update(closedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),actualChildExit=status,directChildReaped=child is None or child.returncode is not None,actualOwnedDescendants=survivors,cleanup=cleanup,allFrozenInputsUnchanged=before==guards(),exception=error,passed=error is None and status==0 and not cleanup and not survivors);(b/'dom-CLOSED.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
raise SystemExit(0 if r['passed'] else 1)
