from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,sys,traceback
root=Path('/tmp/G05-source-queue-audit-20261009');job=root/'jobs/G05-hearts';out=root/'.work/G05-review20-20261009'
started=datetime.datetime.now(datetime.timezone.utc).isoformat();child=None;exception=None
bindings=['README.md','RULES.md','JOBS.md','RUN-ALL.md','contract/GAME_CONTRACT.md','jobs/G05-hearts/README.md','jobs/G05-hearts/RULES.md','jobs/G05-hearts/NEXT.md','jobs/G05-hearts/LOOP.md','jobs/G05-hearts/ASSUMPTIONS.md','jobs/G05-hearts/BOTS.md','jobs/G05-hearts/VERIFY.md']
rank={'rereadUtc':started,'previousFormalReviewPublishedAt':'2026-10-09T12:14:10.267628+00:00','sourceHead':'8674f5e5c0b1257bdef8c8a261c71b8061b09d3b','afterActualOriginalPrSuccess':37926638979,'afterWholeOriginalAcceptance':'2026-10-09T12:06:17.513237+00:00','bindingFilesSha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in bindings},'rankedFive':['missing-seat partial ledgers after full reconnect across standalone save/recovery boundaries','whole-game score/history and next-hand passing after roster events','private views and mutable snapshots after missing-seat takeover','fully connected old/current byte equivalence outside the repaired presence domain','truthful delivery, source proof and original sampler limitations'],'selectedWorst':'actual full reconnect, partial-trick ledger save/resume, next-input coherence and repeated scored-hand end'}
(out/'ranked-five-before.json').write_text(json.dumps(rank,indent=2)+'\n')
names=subprocess.check_output(['git','ls-tree','-r','--name-only',rank['sourceHead'],'--','jobs/G05-hearts','contract','.github/workflows/G05.yml'],cwd=root,text=True).splitlines()
paths=[root/n for n in names]+[p for p in (job/'.build').rglob('*') if p.is_file()]+[out/'probe.mjs',Path(__file__),out/'ranked-five-before.json']
freeze=lambda:{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=freeze();(out/'frozen-before.json').write_text(json.dumps(before,indent=2)+'\n')
try:
 command=['node',str(out/'probe.mjs')]
 with (out/'native.stdout').open('wb') as stdout,(out/'native.stderr').open('wb') as stderr:
  child=subprocess.Popen(command,cwd=job,stdout=stdout,stderr=stderr,start_new_session=True);code=child.wait(timeout=330)
 assert code==0,'actual selected review probe failed'
 rows=[json.loads(line) for line in (out/'native.stdout').read_text().splitlines() if line.startswith('{')]
 assert len(rows)==1 and rows[0]['passed'] is True and rows[0]['cases']==5568
 after=freeze();assert after==before
except BaseException as e:exception={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
finally:
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGKILL);child.wait()
 after=freeze();(out/'frozen-after.json').write_text(json.dumps(after,indent=2)+'\n')
 receipt={'startedAt':started,'closedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':rank['sourceHead'],'argv':['node',str(out/'probe.mjs')],'nativeExit':child.returncode if child is not None else None,'directChildReaped':child is None or child.returncode is not None,'frozenInputs':len(before),'allFrozenInputsUnchanged':before==after,'nativeStdoutSha256':hashlib.sha256((out/'native.stdout').read_bytes()).hexdigest(),'exception':exception,'passed':exception is None and before==after}
 if receipt['passed']:receipt['measured']=rows[0]
 (out/'CLOSED.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
sys.exit(0 if receipt['passed'] else 1)
