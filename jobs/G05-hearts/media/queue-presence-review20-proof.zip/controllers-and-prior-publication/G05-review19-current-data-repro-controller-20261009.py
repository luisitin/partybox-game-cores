from pathlib import Path
import ctypes,os,signal,subprocess,datetime,json,hashlib
repo=Path('/tmp/G05-source-queue-audit-20261009')
job=repo/'jobs/G05-hearts'
out=repo/'.work/G05-review19-current-data-repro-20261009'
out.mkdir()
ctypes.CDLL(None).prctl(36,1,0,0,0)
names=subprocess.check_output(['git','ls-files','jobs/G05-hearts','contract','.github/workflows/G05.yml'],cwd=repo,text=True).splitlines()
paths=list(dict.fromkeys([repo/n for n in names]+[p for p in (job/'.build').rglob('*') if p.is_file()]+[p for p in (job/'media').iterdir() if p.is_file()]+[Path(__file__)]))
freeze=lambda:{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=freeze()
(out/'frozen-before.json').write_text(json.dumps(before,indent=2)+'\n')
steps=[]
rec={'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':'8b21cfcd53a19cf54db6e548cbdd6c1208b14d33','newBrowserOrTimingRun':False}
def owned():
 records=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   try:
    text=(p/'stat').read_text();v=text[text.rfind(')')+2:].split();records.append({'pid':int(p.name),'ppid':int(v[1]),'pgid':int(v[2])})
   except (OSError,ValueError,IndexError):pass
 found={os.getpid()};result=[]
 for _ in range(len(records)+1):
  children=[r for r in records if r['ppid'] in found and r['pid'] not in found]
  if not children:break
  result+=children;found.update(r['pid'] for r in children)
 return result
cleanup=[]
try:
 for name,argv in [('two-regenerations',['node','scripts/check-repro.mjs']),('data',['node','scripts/check-data.mjs'])]:
  start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
   child=subprocess.Popen(argv,cwd=job,stdout=stdout,stderr=stderr,start_new_session=True)
   try:code=child.wait(timeout=330)
   except BaseException:
    os.killpg(child.pid,signal.SIGKILL);code=child.wait();raise
  steps.append({'name':name,'argv':argv,'startedUtc':start,'closedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code})
  assert code==0,(name,code)
 try:
  while True:
   p,c=os.waitpid(-1,os.WNOHANG)
   if p==0:break
 except ChildProcessError:pass
 assert not owned()
 after=freeze()
 (out/'frozen-after.json').write_text(json.dumps(after,indent=2)+'\n')
 assert before==after
 rec.update({'exitCode':0,'passed':True,'twoOriginalRegenerationsPassed':True,'current114DataOriginalPassed':True,'allFrozenInputsUnchanged':True,'frozenInputCount':len(paths)})
except BaseException as e:rec.update({'exitCode':1,'passed':False,'errorType':type(e).__name__,'error':str(e)})
finally:
 for r in owned():
  try:os.kill(r['pid'],signal.SIGKILL);cleanup.append(r)
  except ProcessLookupError:pass
 if cleanup:
  try:
   while True:os.waitpid(-1,0)
  except ChildProcessError:pass
 rec.update({'closedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'native':steps,'ownedSurvivors':owned(),'cleanup':cleanup})
 (out/'CLOSED.json').write_text(json.dumps(rec,indent=2)+'\n')
 print(json.dumps(rec))
raise SystemExit(rec['exitCode'])
