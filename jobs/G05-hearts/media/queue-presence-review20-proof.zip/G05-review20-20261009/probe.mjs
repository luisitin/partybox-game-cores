import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {game,players,stateSchema,createRng} from '/tmp/G05-source-queue-audit-20261009/jobs/G05-hearts/tests/helpers.mjs';
const {makeSave,parseSave}=await import(pathToFileURL(resolve('.build/jobs/G05-hearts/src/save.js')).href);
let assertions=0,cases=0,snapshots=0,reconnectedSeats=0,resumedNextInputs=0,partialTrickSnapshots=0,unsupportedAbsentSaveChecks=0;
const phases={pass:0,play:0,trick:0,hand:0,done:0},transcript=createHash('sha256');
const equal=(a,b,message)=>{assertions++;assert.deepEqual(a,b,message);};
const ok=(a,message)=>{assertions++;assert.ok(a,message);};
const clone=s=>JSON.parse(JSON.stringify(s));
function nextEvent(s,salt){
  if(s.phase.id==='done')return null;
  const playerId=s.phase.id==='trick'||s.phase.id==='hand'?'p0':s.actor;
  const input=s.phase.id==='trick'||s.phase.id==='hand'?{type:'next'}:game.bot.sampleInput(s,playerId,createRng(salt),'normal');
  ok(input&&game.inputSchema.safeParse(input).success,'genuine next player input exists');
  return {type:'input',playerId,input,now:s.phase.startedAt+1};
}
function snapshot(s,seats){
  const live=JSON.stringify(s),at=Math.max(0,s.phase.startedAt+10),exported=makeSave(s,seats,at);
  equal(JSON.stringify(s),live,'export never changes the live state');
  const exportedBefore=JSON.stringify(exported),parsed=parseSave(exported);
  ok(parsed,'fully reconnected genuine state is accepted by the standalone save parser');
  equal(JSON.stringify(exported),exportedBefore,'parse never changes its input');
  ok(stateSchema.safeParse(parsed.state).success,'recovered core is schema-valid');
  const expected=clone(s);
  if(expected.phase.id!=='done'&&!expected.phase.paused)expected.phase={...expected.phase,paused:{at}};
  equal(parsed.state,expected,'the entire emitted card/turn/pass/score ledger recovers exactly');
  equal(parsed.seats,seats,'seat modes and names recover exactly');
  let recovered=parsed.state,oracle=s;
  if(s.phase.id!=='done'){
    recovered=game.reduce(recovered,{type:'vip',action:'resume',now:at+5000});
    oracle=game.reduce(game.reduce(s,{type:'vip',action:'pause',now:at}),{type:'vip',action:'resume',now:at+5000});
    equal(recovered,oracle,'save recovery agrees with independent ordinary core pause/resume events');
    const event=nextEvent(recovered,100000+snapshots);
    event.now=recovered.phase.deadline===null?at+5001:recovered.phase.deadline-1;
    const actual=game.reduce(recovered,event),control=game.reduce(oracle,clone(event));
    ok(actual!==recovered,'actual resumed human input advances');
    equal(actual,control,'resumed next real input preserves exact state and scores');
    resumedNextInputs++;
  }else equal(game.results(recovered),game.results(s),'all final score/ranking/tie results restore exactly');
  exported.state.hands.p0.push(99);
  exported.seats[0].name='mutated local export';
  equal(JSON.stringify(s),live,'mutating exported data cannot affect live state');
  equal(parsed.state,expected,'mutating exported data cannot affect parsed state');
  transcript.update(JSON.stringify({state:s,parsed:expected,recovered})+'\n');
  if(s.phase.id==='play'&&s.trick.length)partialTrickSnapshots++;
  phases[s.phase.id]++;snapshots++;
}
for(const count of [3,4,5,6])for(let mask=1;mask<2**count;mask++)
for(const noPass of [false,true])for(const moon of ['add','subtract'])for(const jack of [false,true])
for(const turnSeconds of [0,1,60])for(const target of [25,200]){
  const ctx={players:players(count).map((p,i)=>({...p,bot:false,connected:Boolean(mask&(1<<i))})),settings:{target,noPass,moon,jack,turnSeconds},seed:90000+cases,now:1000};
  let state=game.init(ctx);
  const seats=state.order.map(id=>({name:state.players[id].name,mode:'human'}));
  if(mask!==2**count-1){
    equal(parseSave(makeSave(state,seats,state.phase.startedAt+10)),null,'unsupported disconnected standalone roster remains deliberately rejected');
    unsupportedAbsentSaveChecks++;
  }
  for(const id of state.order.filter(id=>!state.players[id].connected)){
    const beforeCards=clone({hands:state.hands,played:state.played,passes:state.passes});
    state=game.reduce(state,{type:'player',playerId:id,connected:true,now:state.phase.startedAt+1});
    equal({hands:state.hands,played:state.played,passes:state.passes},beforeCards,'ordinary reconnect preserves the already-valid takeover ledger');
    reconnectedSeats++;
  }
  const seen=new Set();let steps=0;
  while(state.phase.id!=='hand'&&steps++<500){
    const key=state.phase.id==='play'?'play-partial-'+state.trick.length:state.phase.id==='pass'?'pass-submitted-'+Object.keys(state.passes).length:state.phase.id;
    if(!seen.has(key)){snapshot(state,seats);seen.add(key);}
    const event=nextEvent(state,200000+steps+cases),next=game.reduce(state,event);
    ok(next!==state,'actual first-hand player progression advances');state=next;
  }
  equal(state.phase.id,'hand','the complete first hand terminates without administrative skips');
  snapshot(state,seats);
  const points=clone(state.scores),history=clone(state.history);
  const done=game.reduce(state,{type:'vip',action:'end',now:state.phase.startedAt+10});
  equal(done.scores,points,'ending an already-scored hand cannot double-count');
  equal(done.history,history,'ending an already-scored hand preserves its ledger');
  snapshot(done,seats);
  equal(game.reduce(done,{type:'vip',action:'end',now:done.phase.startedAt+100}),done,'repeated end is harmless');
  cases++;
}
equal(cases,5568,'all declared masks and settings at both target endpoints ran');
ok(Object.values(phases).every(n=>n>0),'all five actual phases are witnessed');
console.log(JSON.stringify({cases,assertions,snapshots,phases,reconnectedSeats,partialTrickSnapshots,resumedNextInputs,unsupportedAbsentSaveChecks,transcriptSha256:transcript.digest('hex'),domain:'all nonempty 3–6-seat masks × noPass × moon × Jack × turnSeconds[0,1,60] × target[25,200]; one seeded first hand per context; deliberate VIP end after scored hand',newBrowserOrPerformanceRun:false,newPlayerGain:false,passed:true}));
