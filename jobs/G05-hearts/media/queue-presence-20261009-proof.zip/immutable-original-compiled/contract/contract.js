// The game contract (docs/GAME_CONTRACT.md). Games implement `GameDefinition`; the engine drives it.
// Changing anything here changes every game — write an ADR first (docs/DECISIONS.md).
import { z } from 'zod';
import { minigameSpecSchema } from './minigame-schema';
import { playerCountsSchema, validPlayerCounts } from './player-count-schema';
import { CONTENT_LANGS } from './constants';
// ─── Manifest + settings ────────────────────────────────────────────────────────────────────────
export const GAME_ID_PATTERN = /^[a-z][a-z0-9-]{1,31}$/;
const SEMVER = /^\d+\.\d+\.\d+$/;
/** A sibling setting's `key` and `value`, with a `note` for the player (`disabledBy`, `impliedBy`). */
const settingRef = z.object({
    key: z.string(),
    value: z.union([z.boolean(), z.string(), z.number()]),
    note: z.string().max(80),
});
const settingBase = {
    key: z.string().regex(/^[a-zA-Z][a-zA-Z0-9]*$/),
    label: z.string().min(1).max(40),
    description: z.string().max(200).optional(),
    /** ADR-073: the selected edition cannot use this field; retain its stored preference. */
    disabledBy: settingRef.extend({ note: z.string().min(1).max(80) }).optional(),
    /** I-112 A: while the sibling setting `key` equals `value`, this one is implied — greyed out
     *  with `note` (e.g. "the board already shows it"). */
    impliedBy: settingRef.optional(),
};
export const settingSpecSchema = z.discriminatedUnion('type', [
    z.object({
        ...settingBase,
        type: z.literal('number'),
        default: z.number(),
        min: z.number(),
        max: z.number(),
        step: z.number().positive().optional(),
        /**
         * The ceiling follows the roster: effective max = min(max, players + maxFromPlayers), and a
         * stored value above it displays and starts as that ceiling ("players per book" = −1: everyone
         * else). The game's own start logic keeps the same cap (games/broken-pencil/server/index.ts).
         */
        maxFromPlayers: z.number().int().optional(),
    }),
    z.object({ ...settingBase, type: z.literal('boolean'), default: z.boolean() }),
    z.object({
        ...settingBase,
        type: z.literal('select'),
        default: z.string(),
        /** `lang` (ADR-054): offered only when the room's content language is that one (a reader's
         *  voice); an option without it is offered in every language. */
        options: z
            .array(z.object({ value: z.string(), label: z.string(), lang: z.enum(CONTENT_LANGS).optional() }))
            .min(2),
    }),
    /**
     * Several picks from a list (ADR-034): the value is the picked option values joined by commas
     * (`''` = nothing picked, which a game reads as "no filter"). With `groupBy`, the options carry a
     * `group` and only those whose group equals the sibling `select` setting's current value are
     * offered — and kept: the engine drops picks from another group.
     */
    z.object({
        ...settingBase,
        type: z.literal('multiselect'),
        default: z.string(),
        options: z
            .array(z.object({ value: z.string(), label: z.string(), group: z.string().optional() }))
            .min(1),
        groupBy: z.string().optional(),
    }),
]);
export const DEFAULT_MAX_INPUT_BYTES = 16 * 1024;
export const HARD_MAX_INPUT_BYTES = 256 * 1024;
/**
 * The picker's filter chips (game pack Part 00 §1.2, the owner's ruling 4): 1–3 per game. `quick`
 * is not on the list — the catalog derives it from `estimatedMinutes ≤ QUICK_MINUTES`.
 */
export const GAME_TAGS = [
    'words',
    'drawing',
    'trivia',
    'bluff',
    'hidden-roles',
    'teams',
    'co-op',
    'comedy',
    'strategy',
    'classic',
];
export const QUICK_MINUTES = 8;
/** Where the players must be (Part 00 §3.5): the picker's badge and the notice on choosing. */
export const PRESENCE_NEEDS = ['anywhere', 'voice-if-remote', 'same-room'];
/** A file in the game's `art/<style>/` folder (ADR-056), named after what it is: `icon.webp`,
 *  `tile.svg`… A WebP icon is a set (ADR-058): `icon.webp` at 512 and its ICON_RENDITIONS beside it. */
const artFile = (kind) => z.enum([`${kind}.png`, `${kind}.svg`, `${kind}.webp`]);
/** One style's art (ADR-056/057). */
const artSet = z
    .object({
    /** 512×512, transparent: the picker, the chosen game, the start stage (phones and TV). */
    icon: artFile('icon').optional(),
    /** 1920×1080 key art behind the TV's start stage; its left 45 % stays calm for the text. */
    tile: artFile('tile').optional(),
    /** 1920×1080, low contrast, behind the game's TV stage while it plays. */
    backdrop: artFile('backdrop').optional(),
})
    .strict();
/** One user-perceived character: `icon` is a single emoji (flags and ZWJ sequences included). */
function oneGrapheme(s) {
    return [...new Intl.Segmenter('en', { granularity: 'grapheme' }).segment(s)].length === 1;
}
export const gameManifestSchema = z
    .object({
    id: z.string().regex(GAME_ID_PATTERN),
    name: z.string().min(1).max(40),
    /** One emoji: the picker's icon tile and the TV card. */
    icon: z.string().min(1).max(16).refine(oneGrapheme, { message: 'icon must be one emoji' }),
    tagline: z.string().min(1).max(60),
    /** Served only through `about` (never in the catalog). */
    description: z.string().min(1).max(300),
    /** The About sheet's 1-2-3 (and the TV mirror's), each step one short sentence. */
    howToPlay: z.tuple([
        z.string().min(1).max(90),
        z.string().min(1).max(90),
        z.string().min(1).max(90),
    ]),
    version: z.string().regex(SEMVER),
    minPlayers: z.number().int().min(1).max(16),
    maxPlayers: z.number().int().min(1).max(16),
    /** ADR-072: a select setting narrows the global roster bounds for an edition or variant. */
    playerCounts: playerCountsSchema.optional(),
    estimatedMinutes: z.number().int().min(1).max(60),
    /** Long board games persist until their rules or the VIP end them, including an empty room. */
    unlimitedDuration: z.boolean().optional(),
    /**
     * I-189: the game's measured pace, so the picker can say how long THIS game will take:
     * fixedSeconds + rounds × (perRoundSeconds + players × perPlayerPerRoundSeconds), where
     * `rounds` is the named setting's value (or the player count, for "players"). Without it the
     * picker shows estimatedMinutes.
     */
    estimate: z
        .object({
        fixedSeconds: z.number().min(0).max(600),
        perRoundSeconds: z.number().min(0).max(600),
        perPlayerPerRoundSeconds: z.number().min(0).max(120),
        roundsSetting: z.string().min(1).max(40),
    })
        .optional(),
    tags: z.array(z.enum(GAME_TAGS)).min(1).max(3),
    presence: z.object({
        needs: z.enum(PRESENCE_NEEDS),
        /** One sentence for the lobby notice when this game is chosen in a room that conflicts. */
        note: z.string().min(1).max(140).optional(),
    }),
    /** ISO date the game joined PartyBox: the catalog's NEW badge for 30 days. */
    addedOn: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
    /** The game ships a `PhoneSettings` panel for the lobby's 🎨 sheet (loaded on expand). */
    phoneSettings: z.boolean().optional(),
    settings: z.array(settingSpecSchema).max(12),
    /** ADR-002: raise for stroke-list inputs (drawing games). */
    maxInputBytes: z.number().int().min(1024).max(HARD_MAX_INPUT_BYTES).optional(),
    /**
     * "Available for bots": the author certifies `bot.sampleInput` is a reasonable opponent in every
     * input phase. Players may add bots in the lobby; a game without this flag cannot be started
     * while bots are in the room (ADR-028).
     */
    supportsBots: z.boolean().optional(),
    /**
     * T-0296: the VIP may save a running game to the host PC and resume it later. Only a game whose
     * whole state is JSON and needs no clock but `event.now` (the contract) can honestly say yes.
     */
    saveable: z.boolean().optional(),
    /** ADR-087: the game can run as a 20-90 s minigame inside a board game; absent = it cannot. */
    minigame: minigameSpecSchema.optional(),
    /** ADR-054: the content languages the game ships (its deck, bot lines, reader); absent = ['en'].
     *  A room in a language the game lacks plays it in the first one listed (herd-mind 07b839). */
    contentLangs: z.array(z.enum(CONTENT_LANGS)).min(1).max(CONTENT_LANGS.length).optional(),
    /** T-0535: the game has no cards, prompts or words in a language (a board or dice game), so the picker
     *  shows no "Cards in English" chip for it. Absent = the game has content. */
    noCards: z.literal(true).optional(),
    /**
     * ADR-056/057: the game's drawn art per style, files in `games/<id>/art/<style>/` named after
     * their kind (PNG or SVG), served by the host at `/art/<id>/<style>/<file>` and never bundled.
     * Each one is optional: a style without a piece shows the other style's, and with neither the
     * shell shows the emoji `icon` (and no tile or backdrop). `pnpm check-art` checks them.
     */
    art: z.object({ pop: artSet.optional(), gouache: artSet.optional() }).strict().optional(),
})
    .refine((m) => m.minPlayers <= m.maxPlayers, { message: 'minPlayers must be <= maxPlayers' })
    .refine(validPlayerCounts, {
    message: 'playerCounts must name select options and ranges within the manifest bounds',
});
export const settingsSchema = z.record(z.string(), z.union([z.number(), z.boolean(), z.string()]));
/** What a speech key may be: lowercase letters, digits and hyphens — room for `<gameId>-<hash>`
 *  (`speechKey` in `@partybox/game-sdk/speech`) and never a path (game-pack audit #18). */
export const SPEECH_KEY_PATTERN = /^[a-z0-9][a-z0-9-]{5,63}$/;
/* eslint-enable @typescript-eslint/no-explicit-any */
export const STATE_SIZE_LIMIT_BYTES = 256 * 1024;
