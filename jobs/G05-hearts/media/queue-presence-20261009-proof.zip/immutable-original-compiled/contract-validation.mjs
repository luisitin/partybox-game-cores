// ../../contract/contract.ts
import { z as z3 } from "zod";

// ../../contract/minigame-schema.ts
import { z } from "zod";
var MINIGAME_MODES = ["ffa", "2v2", "1v3", "duel"];
var minigameSpecSchema = z.object({
  /** The modes the game plays; `ffa` needs 2+ players, `duel` 2, `2v2` and `1v3` 4. */
  modes: z.array(z.enum(MINIGAME_MODES)).min(1).max(MINIGAME_MODES.length),
  /** What the play takes with `settings` below, in seconds (the contract test checks it, with slack). */
  seconds: z.number().int().min(20).max(90),
  /** Settings in minigame mode: the game's defaults, then these. The room's own settings never apply. */
  settings: z.record(z.string(), z.union([z.number(), z.boolean(), z.string()])).optional(),
  /** The instruction screen's Controls list: 1-4 short lines, "Tap · Lock an answer". */
  controls: z.array(z.string().min(1).max(60)).min(1).max(4),
  /** Toad's two lines on the instruction screen. */
  howTo: z.tuple([z.string().min(1).max(90), z.string().min(1).max(90)]),
  /** The instruction screen runs a live demo ("Practice Time!"): the game must be fine with
   *  players tapping before the real start. Absent = a still how-to. */
  practice: z.boolean().optional(),
  /** `sum`: in `2v2` / `1v3` the game plays free-for-all (it knows no sides) and a side's score is
   *  its members' `results().scores` added (`1v3`: the lone player's against the other three's
   *  average); more points wins, equal is a draw. Absent: the game plays its own teams. */
  teamScore: z.literal("sum").optional(),
  /** `boss`: a Jamboree boss fight (T-0597). It stays out of the ordinary round and VS pools; a host asks
   *  for it by category (`minigameGames(…, 'boss')`). Absent: an ordinary minigame. */
  category: z.literal("boss").optional()
}).strict();

// ../../contract/player-count-schema.ts
import { z as z2 } from "zod";
var range = z2.tuple([z2.number().int().min(1).max(16), z2.number().int().min(1).max(16)]);
var playerCountsSchema = z2.object({
  setting: z2.string(),
  default: range,
  overrides: z2.record(z2.string(), range)
});
function validPlayerCounts(m) {
  const counts = m.playerCounts;
  if (!counts) return true;
  const spec = m.settings.find((s) => s.key === counts.setting);
  return spec?.type === "select" && typeof spec.default === "string" && (!Object.hasOwn(counts.overrides, spec.default) || counts.overrides[spec.default]?.every((n, i) => n === counts.default[i]) === true) && Object.keys(counts.overrides).every((v) => spec.options?.some((o) => o.value === v) === true) && [counts.default, ...Object.values(counts.overrides)].every(
    ([min, max]) => min <= max && min >= m.minPlayers && max <= m.maxPlayers
  );
}

// ../../contract/constants.ts
var LIMITS = {
  roomCapacity: 16,
  maxPayloadBytes: 16 * 1024,
  inputsPerSecond: 20,
  disconnectGraceMs: 12e4,
  vipHandoverMs: 3e4,
  /** ADR-065: how long a running game does not hear that a phone dropped (a reload, a Wi-Fi blip). */
  dropGraceMs: 8e3,
  pingIntervalMs: 1e4,
  pingTimeoutMs: 2e4
};
var PHOTO_MAX_BYTES = 24 * 1024;
var CONTENT_LANGS = ["en", "es"];

// ../../contract/contract.ts
var GAME_ID_PATTERN = /^[a-z][a-z0-9-]{1,31}$/;
var SEMVER = /^\d+\.\d+\.\d+$/;
var settingRef = z3.object({
  key: z3.string(),
  value: z3.union([z3.boolean(), z3.string(), z3.number()]),
  note: z3.string().max(80)
});
var settingBase = {
  key: z3.string().regex(/^[a-zA-Z][a-zA-Z0-9]*$/),
  label: z3.string().min(1).max(40),
  description: z3.string().max(200).optional(),
  /** ADR-073: the selected edition cannot use this field; retain its stored preference. */
  disabledBy: settingRef.extend({ note: z3.string().min(1).max(80) }).optional(),
  /** I-112 A: while the sibling setting `key` equals `value`, this one is implied — greyed out
   *  with `note` (e.g. "the board already shows it"). */
  impliedBy: settingRef.optional()
};
var settingSpecSchema = z3.discriminatedUnion("type", [
  z3.object({
    ...settingBase,
    type: z3.literal("number"),
    default: z3.number(),
    min: z3.number(),
    max: z3.number(),
    step: z3.number().positive().optional(),
    /**
     * The ceiling follows the roster: effective max = min(max, players + maxFromPlayers), and a
     * stored value above it displays and starts as that ceiling ("players per book" = −1: everyone
     * else). The game's own start logic keeps the same cap (games/broken-pencil/server/index.ts).
     */
    maxFromPlayers: z3.number().int().optional()
  }),
  z3.object({ ...settingBase, type: z3.literal("boolean"), default: z3.boolean() }),
  z3.object({
    ...settingBase,
    type: z3.literal("select"),
    default: z3.string(),
    /** `lang` (ADR-054): offered only when the room's content language is that one (a reader's
     *  voice); an option without it is offered in every language. */
    options: z3.array(
      z3.object({ value: z3.string(), label: z3.string(), lang: z3.enum(CONTENT_LANGS).optional() })
    ).min(2)
  }),
  /**
   * Several picks from a list (ADR-034): the value is the picked option values joined by commas
   * (`''` = nothing picked, which a game reads as "no filter"). With `groupBy`, the options carry a
   * `group` and only those whose group equals the sibling `select` setting's current value are
   * offered — and kept: the engine drops picks from another group.
   */
  z3.object({
    ...settingBase,
    type: z3.literal("multiselect"),
    default: z3.string(),
    options: z3.array(z3.object({ value: z3.string(), label: z3.string(), group: z3.string().optional() })).min(1),
    groupBy: z3.string().optional()
  })
]);
var DEFAULT_MAX_INPUT_BYTES = 16 * 1024;
var HARD_MAX_INPUT_BYTES = 256 * 1024;
var GAME_TAGS = [
  "words",
  "drawing",
  "trivia",
  "bluff",
  "hidden-roles",
  "teams",
  "co-op",
  "comedy",
  "strategy",
  "classic"
];
var QUICK_MINUTES = 8;
var PRESENCE_NEEDS = ["anywhere", "voice-if-remote", "same-room"];
var artFile = (kind) => z3.enum([`${kind}.png`, `${kind}.svg`, `${kind}.webp`]);
var artSet = z3.object({
  /** 512×512, transparent: the picker, the chosen game, the start stage (phones and TV). */
  icon: artFile("icon").optional(),
  /** 1920×1080 key art behind the TV's start stage; its left 45 % stays calm for the text. */
  tile: artFile("tile").optional(),
  /** 1920×1080, low contrast, behind the game's TV stage while it plays. */
  backdrop: artFile("backdrop").optional()
}).strict();
function oneGrapheme(s) {
  return [...new Intl.Segmenter("en", { granularity: "grapheme" }).segment(s)].length === 1;
}
var gameManifestSchema = z3.object({
  id: z3.string().regex(GAME_ID_PATTERN),
  name: z3.string().min(1).max(40),
  /** One emoji: the picker's icon tile and the TV card. */
  icon: z3.string().min(1).max(16).refine(oneGrapheme, { message: "icon must be one emoji" }),
  tagline: z3.string().min(1).max(60),
  /** Served only through `about` (never in the catalog). */
  description: z3.string().min(1).max(300),
  /** The About sheet's 1-2-3 (and the TV mirror's), each step one short sentence. */
  howToPlay: z3.tuple([
    z3.string().min(1).max(90),
    z3.string().min(1).max(90),
    z3.string().min(1).max(90)
  ]),
  version: z3.string().regex(SEMVER),
  minPlayers: z3.number().int().min(1).max(16),
  maxPlayers: z3.number().int().min(1).max(16),
  /** ADR-072: a select setting narrows the global roster bounds for an edition or variant. */
  playerCounts: playerCountsSchema.optional(),
  estimatedMinutes: z3.number().int().min(1).max(60),
  /** Long board games persist until their rules or the VIP end them, including an empty room. */
  unlimitedDuration: z3.boolean().optional(),
  /**
   * I-189: the game's measured pace, so the picker can say how long THIS game will take:
   * fixedSeconds + rounds × (perRoundSeconds + players × perPlayerPerRoundSeconds), where
   * `rounds` is the named setting's value (or the player count, for "players"). Without it the
   * picker shows estimatedMinutes.
   */
  estimate: z3.object({
    fixedSeconds: z3.number().min(0).max(600),
    perRoundSeconds: z3.number().min(0).max(600),
    perPlayerPerRoundSeconds: z3.number().min(0).max(120),
    roundsSetting: z3.string().min(1).max(40)
  }).optional(),
  tags: z3.array(z3.enum(GAME_TAGS)).min(1).max(3),
  presence: z3.object({
    needs: z3.enum(PRESENCE_NEEDS),
    /** One sentence for the lobby notice when this game is chosen in a room that conflicts. */
    note: z3.string().min(1).max(140).optional()
  }),
  /** ISO date the game joined PartyBox: the catalog's NEW badge for 30 days. */
  addedOn: z3.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  /** The game ships a `PhoneSettings` panel for the lobby's 🎨 sheet (loaded on expand). */
  phoneSettings: z3.boolean().optional(),
  settings: z3.array(settingSpecSchema).max(12),
  /** ADR-002: raise for stroke-list inputs (drawing games). */
  maxInputBytes: z3.number().int().min(1024).max(HARD_MAX_INPUT_BYTES).optional(),
  /**
   * "Available for bots": the author certifies `bot.sampleInput` is a reasonable opponent in every
   * input phase. Players may add bots in the lobby; a game without this flag cannot be started
   * while bots are in the room (ADR-028).
   */
  supportsBots: z3.boolean().optional(),
  /**
   * T-0296: the VIP may save a running game to the host PC and resume it later. Only a game whose
   * whole state is JSON and needs no clock but `event.now` (the contract) can honestly say yes.
   */
  saveable: z3.boolean().optional(),
  /** ADR-087: the game can run as a 20-90 s minigame inside a board game; absent = it cannot. */
  minigame: minigameSpecSchema.optional(),
  /** ADR-054: the content languages the game ships (its deck, bot lines, reader); absent = ['en'].
   *  A room in a language the game lacks plays it in the first one listed (herd-mind 07b839). */
  contentLangs: z3.array(z3.enum(CONTENT_LANGS)).min(1).max(CONTENT_LANGS.length).optional(),
  /** T-0535: the game has no cards, prompts or words in a language (a board or dice game), so the picker
   *  shows no "Cards in English" chip for it. Absent = the game has content. */
  noCards: z3.literal(true).optional(),
  /**
   * ADR-056/057: the game's drawn art per style, files in `games/<id>/art/<style>/` named after
   * their kind (PNG or SVG), served by the host at `/art/<id>/<style>/<file>` and never bundled.
   * Each one is optional: a style without a piece shows the other style's, and with neither the
   * shell shows the emoji `icon` (and no tile or backdrop). `pnpm check-art` checks them.
   */
  art: z3.object({ pop: artSet.optional(), gouache: artSet.optional() }).strict().optional()
}).refine((m) => m.minPlayers <= m.maxPlayers, { message: "minPlayers must be <= maxPlayers" }).refine(validPlayerCounts, {
  message: "playerCounts must name select options and ranges within the manifest bounds"
});
var settingsSchema = z3.record(z3.string(), z3.union([z3.number(), z3.boolean(), z3.string()]));
var SPEECH_KEY_PATTERN = /^[a-z0-9][a-z0-9-]{5,63}$/;
var STATE_SIZE_LIMIT_BYTES = 256 * 1024;
export {
  DEFAULT_MAX_INPUT_BYTES,
  GAME_ID_PATTERN,
  GAME_TAGS,
  HARD_MAX_INPUT_BYTES,
  PRESENCE_NEEDS,
  QUICK_MINUTES,
  SPEECH_KEY_PATTERN,
  STATE_SIZE_LIMIT_BYTES,
  gameManifestSchema,
  settingSpecSchema,
  settingsSchema
};
