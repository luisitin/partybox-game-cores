import { object, number, array, string, literal, enum as enumeration } from 'zod';
import { stateSchema } from './schema.js';
import { deckFor, legalCards, passingOffset, trickWinner } from './rules.js';
export const saveSchema = object({ version: literal(1), savedAt: number().int().min(0).max(Number.MAX_SAFE_INTEGER), state: stateSchema, seats: array(object({ name: string().max(24), mode: enumeration(['human', 'easy', 'normal', 'sharp']) }).strict()).min(3).max(6) }).strict();
const same = (a, b) => { const x = [...a].sort((i, j) => i - j), y = [...b].sort((i, j) => i - j); return x.length === y.length && x.every((c, i) => c === y[i]); };
const samePlays = (a, b) => a.length === b.length && a.every((p, i) => p.playerId === b[i].playerId && p.card === b[i].card);
/** Snapshot data only: holding a saved clock never mutates the live game. */
export function makeSave(s, seats, at) {
    const copy = JSON.parse(JSON.stringify(s));
    if (copy.phase.id !== 'done' && !copy.phase.paused)
        copy.phase = { ...copy.phase, paused: { at } };
    return { version: 1, savedAt: at, state: copy, seats: seats.map(p => ({ ...p })) };
}
/** Validate only snapshots this standalone table can emit; reject corrupt data. */
export function parseSave(value) {
    const checked = saveSchema.safeParse(value);
    if (!checked.success)
        return null;
    // Canonical JSON eliminates optional undefined and negative-zero values.
    const record = JSON.parse(JSON.stringify(checked.data));
    const s = record.state, n = s.order.length, ids = new Set(s.order), deck = deckFor(n, s.settings.threeDeck);
    if (record.seats.length !== n || s.left.length || s.dealer >= n || s.order.some((id, i) => id !== `p${i}`) || !ids.has(s.actor))
        return null;
    for (const map of [s.players, s.hands, s.captured, s.scores])
        if (Object.keys(map).length !== n || s.order.some(id => !Object.hasOwn(map, id)))
            return null;
    for (const map of [s.passes, s.sent, s.received])
        if (Object.keys(map).some(id => !ids.has(id)))
            return null;
    if (s.order.some((id, i) => s.players[id].id !== id || !s.players[id].connected || Boolean(s.players[id].bot) !== (record.seats[i].mode !== 'human')))
        return null;
    if (s.settings.target % 25 || s.passOffset !== passingOffset(s.handNumber, n, s.settings.noPass) || s.phase.deadline !== null && s.phase.deadline < s.phase.startedAt)
        return null;
    const remaining = Object.values(s.hands).flat(), played = s.played.map(p => p.card);
    if (!same([...remaining, ...played], deck) || new Set([...remaining, ...played]).size !== deck.length)
        return null;
    if (s.played.some(p => !ids.has(p.playerId)) || s.trick.some(p => !ids.has(p.playerId)) || s.lastTrick.some(p => !ids.has(p.playerId)))
        return null;
    const expected = Object.fromEntries(s.order.map(id => [id, []]));
    for (let i = 0; i < s.played.length; i += n) {
        const trick = s.played.slice(i, i + n);
        if (new Set(trick.map(p => p.playerId)).size !== trick.length)
            return null;
        if (trick.length === n)
            expected[trickWinner(trick)].push(...trick.map(p => p.card));
    }
    if (s.order.some(id => !same(s.captured[id], expected[id]) || s.hands[id].length !== deck.length / n - s.played.filter(p => p.playerId === id).length))
        return null;
    // A schema-valid snapshot can still erase a live card or restore the wrong turn.
    // Keep the current/public trick metadata tied to the actual played-card ledger.
    const partial = s.played.length % n, currentLength = s.trick.length;
    if (partial ? currentLength !== partial : currentLength !== 0 && currentLength !== n)
        return null;
    if (currentLength && !samePlays(s.trick, s.played.slice(-currentLength)))
        return null;
    if (s.trickNumber !== (s.played.length - currentLength) / n)
        return null;
    const completeEnd = s.played.length - partial, last = completeEnd ? s.played.slice(completeEnd - n, completeEnd) : [];
    if (!samePlays(s.lastTrick, last) || s.lastWinner !== trickWinner(last))
        return null;
    if (s.phase.id === 'pass' && s.actor !== s.order.find(id => !Object.hasOwn(s.passes, id)))
        return null;
    if (s.phase.id === 'play') {
        const actor = currentLength ? s.order[(s.order.indexOf(s.trick.at(-1).playerId) + 1) % n] : s.played.length ? s.lastWinner : s.order.find(id => s.hands[id].includes(s.opening));
        if (s.actor !== actor)
            return null;
    }
    if ((s.phase.id === 'trick' || s.phase.id === 'hand') && s.actor !== s.lastWinner)
        return null;
    if (s.lastWinner !== null && !ids.has(s.lastWinner) || s.phase.id === 'trick' && (s.lastWinner === null || s.trick.length !== n))
        return null;
    if (s.phase.id === 'hand' && (!s.handScored || remaining.length) || s.phase.id === 'done' && !s.handScored)
        return null;
    if (s.phase.id === 'play' && (!s.hands[s.actor].length || !legalCards(s.hands[s.actor], s.trick, s.trickNumber === 0, s.heartsBroken, s.opening).length))
        return null;
    if (s.phase.id === 'pass' && (s.passOffset === 0 || s.played.length || s.order.some(id => Object.hasOwn(s.passes, id) && (s.passes[id].length !== 3 || new Set(s.passes[id]).size !== 3 || s.passes[id].some(c => !s.hands[id].includes(c))))))
        return null;
    if (Object.keys(s.sent).length) {
        if (Object.keys(s.sent).length !== n || Object.keys(s.received).length !== n || Object.keys(s.passes).length !== n)
            return null;
        for (let i = 0; i < n; i++) {
            const id = s.order[i], from = s.order[(i - s.passOffset + n) % n];
            if (s.sent[id].length !== 3 || new Set(s.sent[id]).size !== 3 || !same(s.sent[id], s.passes[id]) || !same(s.received[id], s.passes[from]))
                return null;
        }
    }
    else if (Object.keys(s.received).length)
        return null;
    if (s.phase.id === 'play' && s.trick.length >= n)
        return null;
    if (s.history.some(h => h.moon !== null && !ids.has(h.moon) || Object.keys(h.points).length !== n || s.order.some(id => !Object.hasOwn(h.points, id))))
        return null;
    return record;
}
