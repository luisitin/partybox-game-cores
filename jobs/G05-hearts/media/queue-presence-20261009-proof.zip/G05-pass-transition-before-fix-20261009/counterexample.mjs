import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
const repo='/tmp/G05-source-queue-audit-20261009';
const old=await import(pathToFileURL(repo+'/.work/G05-immutable-original-build-20261009/compiled/jobs/G05-hearts/src/core.js'));
const candidate=await import(pathToFileURL(repo+'/jobs/G05-hearts/.build/jobs/G05-hearts/src/core.js'));
const {createRng}=await import(pathToFileURL(repo+'/jobs/G05-hearts/.build/contract/rng.js'));
const ctx={players:Array.from({length:3},(_,i)=>({id:'p'+i,name:'Seat '+(i+1),avatarId:'face-1',connected:i===0,bot:false})),settings:{target:25,noPass:false,moon:'add',jack:false,turnSeconds:0},seed:50000,now:1000};
for(const [label,mod] of [['protected-original',old],['initial-only-candidate',candidate]]) {
 const initial=mod.init(ctx),input=mod.game.bot.sampleInput(initial,'p0',createRng(1),'normal');
 assert.ok(input&&mod.game.inputSchema.safeParse(input).success);
 const after=mod.reduce(initial,{type:'input',playerId:'p0',input,now:initial.phase.startedAt+1});
 console.log(JSON.stringify({label,ctx,initialPhase:initial.phase,initialActor:initial.actor,actualPlayerInput:input,afterPhase:after.phase,afterActor:after.actor,afterActorConnected:after.players[after.actor].connected,passedSeats:Object.keys(after.passes),played:after.played,remainingHumanLegal:mod.game.controllerView(after,'p0').legal,remainingHumanInput:mod.game.bot.sampleInput(after,'p0',createRng(2),'sharp')}));
 assert.equal(after.players[after.actor].connected,false);
}
