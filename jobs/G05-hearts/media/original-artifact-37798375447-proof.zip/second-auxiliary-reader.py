from pathlib import Path,PurePosixPath
import json,zipfile,hashlib,subprocess,stat,math,datetime,re
repo=Path.cwd();job=repo/'jobs/G05-hearts';root=repo/'.work/g04-independent-artifact';head='3c28358a576fdd65226f1bbd0ef47abd574add6b';checks=0

def check(value,message):
 global checks
 assert value,message
 checks+=1

def sha(b):return hashlib.sha256(b).hexdigest()

def load(p):return json.loads(p.read_text())
meta=load(root/'artifact-metadata.json');check(meta['id']==11560101856 and meta['workflow_run']['id']==37798375447 and meta['workflow_run']['head_sha']==head,'native official historical artifact binding');zbytes=(root/'actual.zip').read_bytes();check(len(zbytes)==929011 and sha(zbytes)=='62d97e418d5e304b6c077f8113e2c22407cf5c1e93ae938e72505299806cdf14','actual official ZIP bytes/SHA')
with zipfile.ZipFile(root/'actual.zip') as z:
 check(z.testzip() is None,'actual CRCs');seen=set()
 for e in z.infolist():
  p=PurePosixPath(e.filename);check(not p.is_absolute() and '..' not in p.parts and '\\' not in e.filename and e.filename not in seen and not stat.S_ISLNK(e.external_attr>>16),'safe ZIP entry');seen.add(e.filename)
check(len(seen)==13,'all actual immutable entries')
base=root/'extracted/visual';r=load(base/'current-report.json');run=load(base/'current-run.json');expected={}
old_checker=subprocess.check_output(['git','show',head+':jobs/G05-hearts/scripts/check-visual.mjs'],cwd=repo).decode()
guarded=re.search(r'export const guardedFiles=(\[[^;]+\]);',old_checker)
check(guarded is not None,'actual immutable original guarded-file declaration')
guarded_files=json.loads(guarded.group(1).replace("'",'"'))
check(set(r['sourceStart'])==set(guarded_files) and len(guarded_files)==26,'exact original26 guard names, independently read from immutable source')
old_sampler=subprocess.check_output(['git','show',head+':jobs/G05-hearts/scripts/visual.mjs'],cwd=repo).decode()
check("'-c:v','libvpx-vp9'" in old_sampler and "'-framerate','10'" in old_sampler and 'frame<36' in old_sampler,'actual immutable originalVP9/10FPS/36frame capture instructions')
lock=json.loads(subprocess.check_output(['git','show',head+':jobs/G05-hearts/package-lock.json'],cwd=repo));check(lock['packages']['node_modules/zod']['version']=='4.6.5','immutable pinned public Zod version')
# Independent public package bytes were already captured and hash-checked in
# G04's original source archive. This is the same pinned package's MIT notice.
with zipfile.ZipFile('/workspace/game-cores-G04-reverify-2019/jobs/G04-reality-check/results/reverify-2019/local-be30189/source-bytes.zip') as sources:
 license_bytes=sources.read('source-tree/job/node_modules/zod/LICENSE')
for name in r['sourceStart']:
 if name=='node_modules/zod/LICENSE':b=license_bytes
 else:
  rel=(job/name).resolve().relative_to(repo).as_posix();b=subprocess.check_output(['git','show',head+':'+rel],cwd=repo)
 expected[name]=sha(b)
 check(expected[name]==r['sourceStart'][name],'actual immutable guarded byte identity '+name)
check(len(expected)==26 and r['sourceEnd']==expected,'all original26 end identities');check(run['sourceStart']==expected and run['runId']==r['runId'],'current original attempt binding')
check(r['kind']=='full' and r['passed'] is True and r['schemaVersion']==1 and r['fileOpened'] is True and r['serving']=='disk','actual historical complete offline report');check(r['externalRequests']==0 and r['runtimeExceptions']==0,'actual historical zero runtime traffic/errors');check(r['completedPlayerCounts']==[3,4,5,6],'all original rosters');check(datetime.datetime.fromisoformat(r['completedAt'].replace('Z','+00:00'))>=datetime.datetime.fromisoformat(r['startedAt'].replace('Z','+00:00')),'actual chronological run');check(r['chrome']=='Chrome/154.0.8037.97','actual historical browser identity')
flags=['outcomeFocus','winnerAnnounced','mobileWinnerVisible','accessibleControls','manageClock','selectionAnnouncements','handoffAnnouncements','receivedMarked','mobileResultPriority','freshDeals','resumedSavedGame','corruptSaveRejected','reducedMotion','privateHandoff','passing','mouseCard','touchCard','keyboardCard','keyboardFocus','longNamesFit']
for flag in flags:check(r[flag] is True,'actual original functional flag '+flag)
check(r['minimumTapHeight']>=44 and r['controlBoundaryContrast']>=3 and r['footerContrast']>=4.5,'actual original accessibility thresholds')
runfolder=base/'runs'/expected['play.html']/r['runId'];attempt=load(runfolder/'attempt.json');check(attempt['sourceStart']==expected and attempt['runId']==r['runId'],'actual immutable attempt source identity');check(load(runfolder/'report.json')==r and load(base/'visual-measurements-01.json')==r,'same actual full report copies');check((runfolder/'visual.mjs').read_bytes()==subprocess.check_output(['git','show',head+':jobs/G05-hearts/scripts/visual.mjs'],cwd=repo),'actual archived sampler bytes')
profiles=[]
for name,width,height,cpu in [('desktop',1920,1080,1),('phone',390,844,4)]:
 p=r[name];raw=load(runfolder/f'{name}-frames.json');check(raw['sourceStart']==expected and raw['runId']==r['runId'],'original separate raw identity');check({k:v for k,v in raw.items() if k not in ['sourceStart','runId']}==p,'all separately retained raw values');check(p['width']==width and p['height']==height and p['cpu']==cpu and p['warmupFrames']==60 and p['frames']==600 and p['overflow'] is False,'actual original steady-state profile');check(p['interaction']=='17-card private pass selection at10Hz; retained card controls','actual original defined interaction')
 iv=p['rawIntervals'];check(len(iv)==600 and all(isinstance(v,(int,float)) and math.isfinite(v) and v>0 for v in iv),'all600 retained finite unfiltered intervals');sorted_=sorted(iv);mean=sum(iv)/600;stats={'meanMs':mean,'fps':1000/mean,'p95Ms':sorted_[570],'p99Ms':sorted_[594],'maxMs':sorted_[-1]}
 for k,v in stats.items():check(math.isclose(p[k],v,rel_tol=1e-12,abs_tol=1e-9),'independent original '+k)
 check(stats['fps']>=59 and stats['p95Ms']<=18,'unchanged original mean/p95 gates');profiles.append({'profile':name,'viewport':[width,height],'cpu':cpu,'retainedIntervals':600,'warmupFrames':60,'scope':'steady-state after original explicit60-frame warmup; not first-frame/startup evidence',**stats})
clip=base/'milestone-01.webm';cb=clip.read_bytes();check(len(cb)==r['videoBytes']==138541 and sha(cb)==r['videoSha256']=='81723241729f22294bbf604d70292501a0eba2c6db2faf25431617c80ecac398','actual current historical full clip bytes/SHA');check((runfolder/'capture.webm').read_bytes()==cb,'actual capture copy identical');check(0<len(cb)<10000000,'original under10MB')
probe=subprocess.run(['/usr/bin/ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=codec_name,width,height,nb_read_frames,r_frame_rate,duration','-show_entries','format=duration','-of','json',str(clip)],capture_output=True,text=True,check=True);pd=json.loads(probe.stdout);stream=pd['streams'][0];check(stream['codec_name']=='vp9' and stream['width']==1920 and stream['height']==1080 and int(stream['nb_read_frames'])==36 and stream['r_frame_rate']=='10/1','actual original-source VP9 dimensions/36decoded frames/10encodedFPS')
def decoder_identity():
 binary=Path('/usr/bin/ffmpeg').resolve()
 version=subprocess.run(['/usr/bin/ffmpeg','-version'],capture_output=True,text=True,check=True).stdout.splitlines()[0]
 return {'path':'/usr/bin/ffmpeg','realPath':str(binary),'sha256':sha(binary.read_bytes()),'version':version}
decoder_before=decoder_identity()
decode_command=['/usr/bin/ffmpeg','-nostdin','-v','error','-xerror','-err_detect','explode','-i',str(clip),'-map','0:v:0','-progress','pipe:1','-nostats','-f','null','-']
decoded=subprocess.run(decode_command,capture_output=True,text=True)
(root/'actual-full-decode.stdout').write_text(decoded.stdout);(root/'actual-full-decode.stderr').write_text(decoded.stderr)
check(decoded.returncode==0 and decoded.stderr=='','actual strict all-frame decode exits0 without reported errors')
decoded_frames=re.findall(r'^frame=(\d+)$',decoded.stdout,re.M)
check(bool(decoded_frames) and int(decoded_frames[-1])==36 and decoded.stdout.rstrip().endswith('progress=end'),'actual decoder naturally reaches all36frames and END')
decoder_after=decoder_identity();check(decoder_before==decoder_after,'actual supported decoder identity stable throughout full decode')
for name,w,h in [('hearts-desktop-01.png',1920,1080),('hearts-phone-01.png',390,844)]:
 b=(base/name).read_bytes();check(b[:8]==b'\x89PNG\r\n\x1a\n' and int.from_bytes(b[16:20],'big')==w and int.from_bytes(b[20:24],'big')==h,'actual historical screenshot dimensions')
summary={'observedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'historicalSourceCommit':head,'runId':37798375447,'jobId':113383711919,'actualFullNativeLogCharacters':94817,'artifactId':11560101856,'artifactBytes':len(zbytes),'artifactSha256':sha(zbytes),'safeEntries':13,'originalGuardedSourceInputs':26,'independentAssertions':checks,'originalFunctionalFlags':20,'rawIntervals':1200,'warmupScope':'two original native600-interval profiles AFTER explicit60-frame warmup; no first-frame timing claim','nativeApiAndPhaseScope':'original archived sampler uses requestAnimationFrame and untimed clock0 private pass workload; no per-frame native-API/phase witness is claimed','profiles':profiles,'actualCapture':{'bytes':len(cb),'sha256':sha(cb),'fullyDecoded':True,'fullDecodeExit':decoded.returncode,'actualFullDecodeCommand':decode_command,'decodedFrames':int(decoded_frames[-1]),'decoderIdentity':decoder_before,'decoderIdentityAfter':decoder_after,'probe':pd,'performanceMeasurement':False},'newBrowserWorkloadRun':False,'sourceOrGitMutation':False,'verificationReaderSha256':sha(Path(__file__).read_bytes()),'auxiliaryReaderCorrection':{'firstReaderSha256':sha(first.read_bytes()),'preservedFailureLog':'first-auxiliary-reader-failure.log','reason':'private auxiliary reader initially assumed VP8; immutable original sampler explicitly encodes VP9. Reader corrected to the actual source; genuine artifact bytes, original gates, browser sampler and Git unchanged by this auditor.'},'passed':True}
(root/'independent-original-receipt.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
