from pathlib import Path
import ctypes,datetime,hashlib,json,os,signal,subprocess,sys,traceback
r=Path('/tmp/G05-source-queue-audit-20261009');j=r/'jobs/G05-hearts';round_id=int(sys.argv[1]);head=sys.argv[2];o=r/f'.work/G05-review{round_id}-current-data-repro-20261009';o.mkdir()
ctypes.CDLL(None).prctl(36,1,0,0,0);child=None;error=None;steps=[];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','jobs/G05-hearts','contract','.github/workflows/G05.yml'],cwd=r,text=True).splitlines()
paths=list(dict.fromkeys([r/n for n in names]+[p for p in (j/'.build').rglob('*') if p.is_file()]+[p for p in (j/'media').iterdir() if p.is_file()]+[Path(__file__)]))
program_paths=[p for p in paths if not any(t in p.parts for t in ['data','fixtures','schemas']) and p.name!='SHA256SUMS.txt']
freeze=lambda ps:{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in ps}
original_programs=freeze(program_paths);(o/'programs-before-first-generation.json').write_text(json.dumps(original_programs,indent=2)+'\n');before=None
def children():
 all=[]
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   try:s=(p/'stat').read_text();v=s[s.rfind(')')+2:].split();all.append({'pid':int(p.name),'ppid':int(v[1])})
   except (OSError,ValueError,IndexError):pass
 found={os.getpid()};result=[]
 for _ in range(len(all)+1):
  c=[x for x in all if x['ppid'] in found and x['pid'] not in found]
  if not c:break
  result+=c;found.update(x['pid'] for x in c)
 return result
def run(name,argv):
 global child
 at=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (o/(name+'.stdout')).open('wb') as stdout,(o/(name+'.stderr')).open('wb') as stderr:
  child=subprocess.Popen(argv,cwd=j,stdout=stdout,stderr=stderr,start_new_session=True);code=child.wait(timeout=330)
 steps.append({'name':name,'argv':argv,'startedAt':at,'closedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':code})
 assert code==0,'actual original data command failed: '+name
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==head
 run('first-current-generation',['node','scripts/generate.mjs'])
 assert freeze(program_paths)==original_programs,'executed source/proof programs changed during intended first data generation'
 before=freeze(paths);(o/'frozen-before-two-regenerations.json').write_text(json.dumps(before,indent=2)+'\n')
 run('two-original-regenerations',['node','scripts/check-repro.mjs'])
 run('original-data-check',['node','scripts/check-data.mjs'])
 assert freeze(paths)==before,'current full data did not remain byte-identical'
 for _ in range(10):
  try:
   p,s=os.waitpid(-1,os.WNOHANG)
   if p==0:break
  except ChildProcessError:break
 assert not children(),'owned descendant remains'
except BaseException as e:error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
finally:
 cleanup=[]
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGKILL);child.wait();cleanup.append({'ownedGroup':child.pid})
 for c in children():
  try:os.kill(c['pid'],signal.SIGKILL);cleanup.append(c)
  except ProcessLookupError:pass
 if cleanup:
  try:
   while True:os.waitpid(-1,0)
  except ChildProcessError:pass
 after=freeze(paths);(o/'frozen-after.json').write_text(json.dumps(after,indent=2)+'\n')
 receipt={'startedAt':started,'closedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHeadBeforeEvidencePublication':head,'review':round_id,'native':steps,'firstGenerationHasDeclaredOutputChanges':True,'allProgramsAndProofMediaUnchanged':freeze(program_paths)==original_programs,'frozenInputsAfterFirstGeneration':len(before) if before else None,'allFrozenInputsUnchanged':before is not None and before==after,'ownedSurvivors':children(),'cleanup':cleanup,'newBrowserOrTimingRun':False,'exception':error,'passed':error is None and before==after}
 if receipt['passed']:
  for n in ['first-current-generation','two-original-regenerations','original-data-check']:
   receipt[n]=[json.loads(line) for line in (o/(n+'.stdout')).read_text().splitlines() if line.startswith('{')]
 (o/'CLOSED.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['first-current-generation','two-original-regenerations']}),flush=True)
sys.exit(0 if receipt['passed'] else 1)
