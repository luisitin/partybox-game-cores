import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const {game,players,stateSchema,createRng,rules,reference}=await import(pathToFileURL(resolve('tests/helpers.mjs')).href);
let cases=0,assertions=0,realInputs=0,rosterEvents=0,pausedDrops=0,permanentLeaves=0,scoredHands=0,replayedEvents=0,privateViewChecks=0,botBoundaryChecks=0,mutableCopyChecks=0;
const phases={pass:0,play:0,trick:0,hand:0,done:0},transcript=createHash('sha256'),passingOffsets=new Set();
const equal=(a,b,message)=>{assertions++;assert.deepEqual(a,b,message);};
const ok=(a,message)=>{assertions++;assert.ok(a,message);};
const clone=x=>JSON.parse(JSON.stringify(x));
const cycle={3:[1,2,0],4:[1,3,2,0],5:[1,4,2,3,0],6:[1,5,2,4,3,0]};
for(const count of [3,4,5,6])for(let seat=0;seat<count;seat++)
for(const noPass of [false,true])for(const moon of ['add','subtract'])for(const jack of [false,true])
for(const turnSeconds of [0,1,60])for(const presencePolicy of ['temporary','left','kicked'])for(const target of [25,100]){
 const anchor='p'+seat,victim='p'+((seat+1)%count);
 const ctx={players:players(count).map((p,i)=>({...p,bot:false,connected:i===seat})),settings:{target,noPass,moon,jack,turnSeconds,threeDeck:moon==='add'?'diamonds':'clubs',queenBreaks:Boolean(seat%2)},seed:330000+cases,now:1000};
 let s=game.init(ctx),events=[],steps=0,lastObservedHand=0,pausedHand=0,leaveApplied=false;
 const expectedScores=Object.fromEntries(s.order.map(id=>[id,0])),order=[...s.order];
 function apply(event){
  const immutable=JSON.stringify(s),prior=s;
  const next=game.reduce(s,event);
  equal(JSON.stringify(s),immutable,'ordinary core event cannot mutate the prior state');
  ok(next!==s,'each deliberate legal event progresses');
  s=next;events.push(event);
  ok(stateSchema.safeParse(s).success,'every emitted whole-match state stays valid');
  equal(s.order,order,'departures never delete a retained score seat');
  const cards=[...Object.values(s.hands).flat(),...s.played.map(p=>p.card)].sort((a,b)=>a-b);
  equal(cards,rules.deckFor(count,s.settings.threeDeck),'every physical card remains exactly conserved');
  ok(Buffer.byteLength(JSON.stringify(s))<256*1024,'state stays within JSON contract bound');
  ok(s.players[anchor].connected&&!s.left.includes(anchor),'the actual human anchor always remains in the table');
  if(s.phase.id==='pass'||s.phase.id==='play'){
   const view=game.controllerView(s,s.actor);
   if(s.phase.paused){
    equal(view.legal,[],'paused core correctly disables card inputs');
    equal(view.canPass,false,'paused core correctly disables pass submission');
    equal(game.bot.sampleInput(s,s.actor,createRng(7),'normal'),null,'paused core correctly disables bot action');
   }else{
    ok(s.players[s.actor].connected&&!s.left.includes(s.actor),'finite missing-seat drain never strands an unpaused match');
    ok(s.phase.id==='pass'?view.canPass:view.legal.length>0,'an unpaused connected actor has a genuine player input');
   }
  }
  if(s.phase.startedAt!==prior.phase.startedAt||s.phase.id!==prior.phase.id)
   equal(game.reduce(s,{type:'timer',phaseId:prior.phase.id,startedAt:prior.phase.startedAt,now:s.phase.startedAt+1e9}),s,'stale previous phase timers cannot change an advanced match');
  phases[s.phase.id]++;
 }
 function views(){
  if(s.phase.id!=='pass'&&s.phase.id!=='play')return;
  const viewer=s.actor,other=s.order.filter(id=>id!==viewer&&s.hands[id].length);
  if(other.length>=2){
   const [a,b]=other,altered={...s,hands:{...s.hands,[a]:[...s.hands[a]],[b]:[...s.hands[b]]}};
   [altered.hands[a][0],altered.hands[b][0]]=[altered.hands[b][0],altered.hands[a][0]];
   equal(game.tvView(altered),game.tvView(s),'different actual hidden cards cannot change the TV');privateViewChecks++;
   for(const id of [viewer,'spectator','__proto__']){
    equal(game.controllerView(altered,id),game.controllerView(s,id),'different opponent hands cannot change an uninformed controller');privateViewChecks++;
    for(const skill of ['easy','normal','sharp']){
     equal(game.bot.sampleInput(altered,id,createRng(31337),skill),game.bot.sampleInput(s,id,createRng(31337),skill),'every bot decision uses the same permitted information');botBoundaryChecks++;
    }
   }
  }
  const live=JSON.stringify(s),tv=game.tvView(s),controller=game.controllerView(s,viewer);
  tv.scores[anchor]=999999;tv.handCounts[anchor]=999999;controller.hand.push(99);controller.legal.push(99);
  equal(JSON.stringify(s),live,'mutable TV/controller copies cannot corrupt live cards or scores');mutableCopyChecks++;
 }
 views();
 while(s.phase.id!=='done'&&steps++<30000){
  const expectedOffset=noPass?0:cycle[count][(s.handNumber-1)%count];
  equal(s.passOffset,expectedOffset,'passing rotation follows the independent official table');passingOffsets.add(count+':'+s.passOffset);
  if(s.phase.id==='hand'&&lastObservedHand!==s.handNumber){
   const independent=reference.referenceScore(s.order,s.captured,s.settings.moon,s.settings.jack);
   const hand=s.history.at(-1);
   equal(hand.points,independent.points,'completed takeover hand scores match the independent scoring implementation');
   equal(hand.moon,independent.moon,'actual moon qualification stays independent');
   for(const id of s.order)expectedScores[id]+=independent.points[id];
   equal(s.scores,expectedScores,'the full cumulative score includes every retained seat exactly once');
   scoredHands++;lastObservedHand=s.handNumber;
   if(!Object.values(s.scores).some(score=>score>=target)){
    if(presencePolicy!=='temporary'&&!leaveApplied){
     apply({type:'player',playerId:victim,connected:false,gone:presencePolicy,now:s.phase.startedAt+1});rosterEvents++;permanentLeaves++;leaveApplied=true;
     apply({type:'player',playerId:victim,connected:true,now:s.phase.startedAt+1});rosterEvents++;
     ok(s.left.includes(victim),'a permanent departure remains unavailable after an ordinary reconnect');
     const view=game.controllerView(s,victim);
     equal(view.me.role,'spectator','permanent leaver has spectator controls');equal(view.hand,[],'permanent leaver cannot recover a private hand');
    }
    for(let i=0;i<count;i++){
     const id='p'+i;
     if(id===anchor||s.left.includes(id))continue;
     const connected=(s.handNumber+i)%3!==0;
     if(s.players[id].connected!==connected){apply({type:'player',playerId:id,connected,now:s.phase.startedAt+1});rosterEvents++;}
    }
   }
  }
  if((s.phase.id==='pass'||s.phase.id==='play')&&pausedHand!==s.handNumber){
   if(!s.left.includes(victim)&&!s.players[victim].connected){apply({type:'player',playerId:victim,connected:true,now:s.phase.startedAt+1});rosterEvents++;}
   if(!s.left.includes(victim)){
    const at=s.phase.startedAt+10;
    apply({type:'vip',action:'pause',now:at});
    const held=clone(s.phase),cards=clone(s.hands);
    apply({type:'player',playerId:victim,connected:false,now:at+20});rosterEvents++;pausedDrops++;
    equal(s.phase,held,'paused ordinary departure cannot advance the phase');equal(s.hands,cards,'paused departure cannot play a card');
    apply({type:'vip',action:'resume',now:at+50});
    apply({type:'player',playerId:victim,connected:true,now:s.phase.startedAt+1});rosterEvents++;
   }
   pausedHand=s.handNumber;views();
  }
  const playerId=s.phase.id==='trick'||s.phase.id==='hand'?anchor:s.actor;
  const input=s.phase.id==='trick'||s.phase.id==='hand'?{type:'next'}:game.bot.sampleInput(s,playerId,createRng(steps),steps%2?'easy':'normal');
  ok(input&&game.inputSchema.safeParse(input).success,'whole match advances only with schema-valid real player inputs');
  apply({type:'input',playerId,input,now:s.phase.startedAt+1});realInputs++;
 }
 equal(s.phase.id,'done','ordinary complete match terminates without VIP skip or end');
 equal(s.scores,expectedScores,'final score exactly equals the independently scored completed hands');
 const result=game.results(s),minimum=Math.min(...Object.values(expectedScores));
 equal(result.scores,expectedScores,'result retains all original players and scores');
 equal(result.winnerIds,order.filter(id=>expectedScores[id]===minimum),'all actual tied winners agree independently');
 let replay=game.init(clone(ctx));for(const event of events){replay=game.reduce(replay,clone(event));replayedEvents++;}
 equal(replay,s,'entire recorded match replays byte-equivalently');
 equal(game.results(replay),result,'replayed final results remain exact');
 transcript.update(JSON.stringify({ctx,events,state:s,result})+'\n');cases++;
 if(cases%64===0)console.log('completed ordinary matches: '+cases);
}
equal(cases,2592,'all declared roster/seat/rule/clock/departure/target cases ran');
for(const count of [3,4,5,6])for(const offset of cycle[count])ok(passingOffsets.has(count+':'+offset),'every selected passing offset was actually witnessed');
console.log(JSON.stringify({cases,assertions,realInputs,rosterEvents,pausedDrops,permanentLeaves,scoredHands,replayedEvents,privateViewChecks,botBoundaryChecks,mutableCopyChecks,phases,passingOffsets:[...passingOffsets].sort(),transcriptSha256:transcript.digest('hex'),domain:'3–6 seats × every anchor seat × noPass × moon × Jack × turnSeconds[0,1,60] × temporary/left/kicked roster policy × target[25,100]; correlated threeDeck and queenBreaks are explicit',administrativeSkips:0,administrativeEnds:0,newBrowserOrPerformanceRun:false,newPlayerGain:false,passed:true}));
