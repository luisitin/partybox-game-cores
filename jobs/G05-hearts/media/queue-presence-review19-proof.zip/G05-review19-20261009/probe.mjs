import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {game, players, stateSchema, createRng, rules} from '/tmp/G05-source-queue-audit-20261009/jobs/G05-hearts/tests/helpers.mjs';

let assertions=0,cases=0,pausedDepartures=0,staleTimers=0,legalInputs=0,replayComparisons=0;
const transcript=createHash('sha256');
const equal=(a,b,message)=>{assertions++;assert.deepEqual(a,b,message);};
const ok=(a,message)=>{assertions++;assert.ok(a,message);};
const json=s=>JSON.parse(JSON.stringify(s));
function valid(s){
  ok(stateSchema.safeParse(s).success,'every actual emitted state remains schema-valid');
  const all=[...Object.values(s.hands).flat(),...s.played.map(p=>p.card)].sort((a,b)=>a-b);
  equal(all,rules.deckFor(s.order.length,s.settings.threeDeck),'all physical cards conserved');
  equal(new Set(all).size,all.length,'no duplicated physical card');
  ok(Buffer.byteLength(JSON.stringify(s))<256*1024,'state fits contract');
}
for(const count of [3,4,5,6])for(let mask=1;mask<2**count;mask++)
for(const noPass of [false,true])for(const moon of ['add','subtract'])for(const jack of [false,true])
for(const turnSeconds of [0,1,60])for(const now of [0,1000,1e12]){
  const ctx={players:players(count).map((p,i)=>({...p,bot:false,connected:Boolean(mask&(1<<i))})),settings:{target:25,noPass,moon,jack,turnSeconds},seed:70000+cases,now};
  const ctxBefore=JSON.stringify(ctx);
  let s=game.init(ctx);valid(s);
  const initial=json(s),events=[];
  const apply=e=>{const prior=JSON.stringify(s);const again=game.reduce(json(s),json(e));const next=game.reduce(s,e);equal(JSON.stringify(s),prior,'reduce cannot mutate its argument');equal(next,again,'JSON-reconstructed state accepts the identical host event');s=next;events.push(e);valid(s);replayComparisons++;};
  const id=s.actor,pauseAt=s.phase.startedAt+5;
  ok(s.players[id].connected,'init reaches a live seat');
  apply({type:'vip',action:'pause',now:pauseAt});
  const held=json(s);
  for(const player of s.order.filter(p=>s.players[p].connected)){
    apply({type:'player',playerId:player,connected:false,now:pauseAt+100});
    equal(s.phase,held.phase,'a paused departure preserves the phase instance and held clock');
    equal(s.hands,held.hands,'a paused departure cannot play another private card');
    equal(s.passes,held.passes,'a paused departure cannot submit another private pass');
    pausedDepartures++;
  }
  ok(!s.order.some(p=>s.players[p].connected),'all previously present seats have disconnected');
  const empty=json(s);
  apply({type:'player',playerId:id,connected:true,now:pauseAt+1500});
  equal(s.phase,held.phase,'paused reconnect does not advance');
  equal(s.hands,empty.hands,'reconnect does not mutate cards');
  const resumeAt=pauseAt+5000;
  apply({type:'vip',action:'resume',now:resumeAt});
  equal(s.phase.startedAt,held.phase.startedAt,'resume keeps a live actor phase instance');
  equal(s.phase.deadline,held.phase.deadline===null?null:held.phase.deadline+5000,'resume adds only the actual paused duration');
  equal(s.phase.paused,undefined,'resume clears pause');
  equal(s.actor,id,'the only connected actor remains active');
  const resumed=json(s);
  const oldTimer={type:'timer',phaseId:held.phase.id,startedAt:held.phase.startedAt,now:held.phase.deadline??resumeAt};
  equal(game.reduce(s,oldTimer),s,'the old unshifted deadline cannot steal a resumed turn');staleTimers++;
  const input=game.bot.sampleInput(s,id,createRng(cases+1),'normal');
  ok(input&&game.inputSchema.safeParse(input).success,'the sole remaining human can act legally');
  const acceptedAt=s.phase.deadline===null?resumeAt+1:s.phase.deadline-1;
  const before=s;
  apply({type:'input',playerId:id,input,now:acceptedAt});
  ok(s!==before,'actual human input changes state');legalInputs++;
  if(s.phase.id==='pass'||s.phase.id==='play'){
    ok(s.players[s.actor].connected,'the repaired finite drain returns to a connected seat');
    const v=game.controllerView(s,id);
    ok(s.phase.id==='pass'?v.canPass:v.legal.length>0,'the next actual input is available');
  }
  equal(game.reduce(s,{...oldTimer,now:acceptedAt+1e6}),s,'a stale pre-input timer cannot advance the new phase instance');staleTimers++;
  let replay=json(initial);
  for(const e of events)replay=game.reduce(replay,json(e));
  equal(s,replay,'the entire pause/drop/rejoin/input transcript deterministically replays');
  equal(JSON.stringify(ctx),ctxBefore,'init never mutates the supplied presence context');
  transcript.update(JSON.stringify({ctx,initial,held,resumed,events,state:s})+'\n');
  cases++;
}
equal(cases,8352,'all declared presence × clock × passing × moon × Jack × time cases ran');
console.log(JSON.stringify({cases,assertions,pausedDepartures,staleTimers,legalInputs,replayComparisons,transcriptSha256:transcript.digest('hex'),domain:'all nonempty 3–6-seat masks; noPass×moon×Jack×turnSeconds[0,1,60]×now[0,1000,1e12]; one seeded deal per context',newBrowserOrPerformanceRun:false,newPlayerGain:false,passed:true}));
