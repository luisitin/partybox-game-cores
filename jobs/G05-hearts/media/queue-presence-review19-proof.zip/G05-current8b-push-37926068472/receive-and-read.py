from pathlib import Path
import datetime,hashlib,json,subprocess,os,sys,termios,signal,traceback
root=Path('/tmp/G05-source-queue-audit-20261009')
out=root/'.work/G05-current8b-push-37926068472'
meta=json.loads((out/'artifact-metadata.json').read_text())
assert meta['id']==11613433924 and meta['size_in_bytes']==936644 and meta['digest']=='sha256:ce42f58e27cdbf0a3454e4fe449c774e824450506ac7db9d4435a40168e22f71'
child=None;exc=None;steps=[];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
names=subprocess.check_output(['git','ls-tree','-r','--name-only','8b21cfcd53a19cf54db6e548cbdd6c1208b14d33','--','jobs/G05-hearts','contract','.github/workflows/G05.yml'],cwd=root,text=True).splitlines()
paths=[root/n for n in names]+[Path(__file__),out/'workflow-run.json',out/'artifact-metadata.json',out/'complete-native-job.log',root/'jobs/G05-hearts/node_modules/zod/LICENSE']
def guards():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=guards();(out/'reader-frozen-before.json').write_text(json.dumps(before,indent=2)+'\n')
try:
 t=termios.tcgetattr(0);t[3]&=~termios.ECHO;termios.tcsetattr(0,termios.TCSANOW,t)
 print('PRIVATE_STDIN_READY',flush=True)
 u=json.loads(sys.stdin.readline())['download_url'];assert u.startswith('https://') and '\n' not in u and '\r' not in u
 args=['curl','--config','-']
 config='url = '+json.dumps(u)+'\nlocation\nfail\nsilent\nshow-error\nconnect-timeout = 15\nmax-time = 60\nretry = 0\nmax-filesize = 936644\noutput = '+json.dumps(str(out/'actual.zip'))+'\n'
 with (out/'curl.stdout.log').open('wb') as sout,(out/'curl.stderr.log').open('wb') as serr:
  child=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=sout,stderr=serr,start_new_session=True)
  child.communicate(config.encode(),timeout=65);steps.append({'purpose':'actual official ZIP through private stdin','argv':args,'exit':child.returncode})
 assert child.returncode==0,'native official download failed'
 z=(out/'actual.zip').read_bytes();assert len(z)==meta['size_in_bytes'] and hashlib.sha256(z).hexdigest()==meta['digest'].removeprefix('sha256:')
 (out/'actual-zip-receipt.json').write_text(json.dumps({'artifactId':meta['id'],'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest(),'observedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True},indent=2)+'\n')
 command=[sys.executable,str(root/'jobs/G05-hearts/scripts/verify-ci-artifact.py'),'--head','8b21cfcd53a19cf54db6e548cbdd6c1208b14d33','--run-id','37926068472','--evidence-dir',str(out)]
 with (out/'original-reader.stdout.log').open('wb') as sout,(out/'original-reader.stderr.log').open('wb') as serr:
  child=subprocess.Popen(command,cwd=root,stdout=sout,stderr=serr,start_new_session=True);rc=child.wait(timeout=120);steps.append({'purpose':'unchanged original complete artifact reader','argv':command,'exit':rc})
 assert rc==0,'original full artifact reader failed'
 assert guards()==before,'original frozen source/metadata changed'
except BaseException as e:exc={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
finally:
 if child is not None and child.poll() is None:
  try:os.killpg(child.pid,signal.SIGKILL)
  except ProcessLookupError:pass
  child.wait()
 try:after=guards();(out/'reader-frozen-after.json').write_text(json.dumps(after,indent=2)+'\n')
 except BaseException as e:after=None;exc=exc or {'type':type(e).__name__,'message':str(e)}
 receipt={'startedAt':started,'closedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':steps,'directChildReaped':child is None or child.returncode is not None,'frozenInputCount':len(before),'allFrozenInputsUnchanged':before==after,'exception':exc,'passed':exc is None and before==after}
 (out/'CLOSED.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
sys.exit(0 if receipt['passed'] else 1)
