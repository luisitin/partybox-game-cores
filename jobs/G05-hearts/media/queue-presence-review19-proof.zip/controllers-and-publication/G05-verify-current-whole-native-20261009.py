from pathlib import Path
import datetime, hashlib, json, re, subprocess

ROOT = Path('/tmp/G05-source-queue-audit-20261009')
HEAD = '8b21cfcd53a19cf54db6e548cbdd6c1208b14d33'
BASE = '033090e340add8664dba4f5e2be8a9c8ff6c8eb6'
checks = 0

def require(value, message):
    global checks
    checks += 1
    if not value:
        raise AssertionError(message)

def rows_from(log):
    rows = []
    for line in log.splitlines():
        body = re.sub(r'^\d{4}-\d{2}-\d{2}T\S+\s+', '', line)
        if body.startswith('{'):
            try:
                rows.append(json.loads(body))
            except json.JSONDecodeError:
                pass
    return rows

old_log = (ROOT / '.work/G05-queue-original-baseline-20261009/complete-native-job.log').read_text()
baseline_leagues = {r['league']: r for r in rows_from(old_log) if 'league' in r}
for event, run_id, job_id, artifact_id in [
    ('push', 37926068472, 113805195247, 11613433924),
    ('pull_request', 37926638979, 113807060149, 11614487431),
]:
    checks = 0
    out = ROOT / f'.work/G05-current8b-{"push" if event == "push" else "pr"}-{run_id}'
    inputs = [out / n for n in ['workflow-run.json', 'artifact-metadata.json', 'actual-full-jobs.json', 'complete-native-job.log', 'actual.zip', 'independent-current-receipt.json', 'CLOSED.json']]
    guard_paths = [Path(p) for p in json.loads((out / 'reader-frozen-before.json').read_text())] + inputs + [Path(__file__)]
    guards = lambda: {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in guard_paths}
    before = guards()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    run = json.loads((out / 'workflow-run.json').read_text())
    jobs = json.loads((out / 'actual-full-jobs.json').read_text())['jobs']
    artifact = json.loads((out / 'artifact-metadata.json').read_text())
    whole = json.loads((out / 'independent-current-receipt.json').read_text())
    closed = json.loads((out / 'CLOSED.json').read_text())
    raw = (out / 'complete-native-job.log').read_bytes()
    log = raw.decode('utf-8')
    rows = rows_from(log)
    require(run['id'] == run_id and run['head_sha'] == HEAD and run['event'] == event, 'actual original run identity')
    require(run['path'] == '.github/workflows/G05.yml' and run['run_attempt'] == 1, 'original sole workflow and first attempt')
    require(run['status'] == 'completed' and run['conclusion'] == 'success', 'actual complete success')
    require(len(jobs) == 1 and jobs[0]['id'] == job_id and jobs[0]['run_id'] == run_id, 'complete native job identity')
    require(jobs[0]['status'] == 'completed' and jobs[0]['conclusion'] == 'success', 'native job success')
    for step in jobs[0]['steps']:
        require(step['status'] == 'completed' and step['conclusion'] == 'success', 'each native step closed successfully: ' + step['name'])
    require(any(step['name'] == 'Run npm test' for step in jobs[0]['steps']), 'full original npm test step')
    require(any(step['name'] == 'Run actions/upload-artifact@v4' for step in jobs[0]['steps']), 'genuine official upload step')
    require('Cleaning up orphan processes' in log, 'complete native final log retained')
    require('tsc -p tsconfig.json && node scripts/build.mjs' in log, 'actual strict source compilation')
    require('node scripts/html.mjs --check' in log and 'node --test --test-concurrency=1 tests/*.test.mjs' in log, 'actual standalone check and complete discovered suite')
    stats = {name: int(value) for name, value in re.findall(r'ℹ (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)', log)}
    require(stats == {'tests': 46, 'suites': 0, 'pass': 46, 'fail': 0, 'cancelled': 0, 'skipped': 0, 'todo': 0}, 'all 46 actual tests pass without skip')
    names = ['disconnected opening seat starts an untimed no-pass table', 'every 3–6-seat presence mask', 'fully connected starts retain every supported target', '1003 seeded missing-seat starts', 'one connected human completes whole matches', 'finishing missing-seat passes also drains', 'empty-room persistence, stale events and paused reconnects']
    for name in names:
        require(any('✔ ' + name in line for line in log.splitlines()), 'actual new regression executed: ' + name)
    require([int(n) for n in re.findall(r'Z M(\d\d): caught — ', log)] == list(range(1, 26)), 'all 25 real individually logged mutant kills')
    require({'planted': 25, 'caught': 25} in rows, 'original mutation summary')
    find = lambda key: [r for r in rows if key in r]
    require(find('propertySeeds')[0]['propertySeeds'] == 1003 and find('replayedEvents')[0]['replayedEvents'] == 204184, 'original 1003 seeded replay corpus')
    games = [r for r in rows if 'players' in r and r.get('games') == 1000]
    require(len(games) == 4 and sorted(r['players'] for r in games) == [3, 4, 5, 6], '1000 complete games at every valid roster')
    require(find('independentCases') == [{'independentCases': 10000, 'forcedAndNaturalMoons': 500}], 'full independent 10000-case scoring oracle')
    require(find('initialPresenceCases') == [{'initialPresenceCases': 34560, 'configurationsPerMask': 96, 'nowProfiles': 3, 'emptyRoomCases': 1152, 'appliedTakeovers': 16141, 'transcriptSha256': '613b88a49418805fc8c48c15afb138e0a270a50ceabe7799ee87ac678f7b5c7b'}], 'entire declared initial-presence domain and exact transcript')
    require(find('fullyConnectedTargetControls') == [{'fullyConnectedTargetControls': 9216}], '9216 fully connected target controls')
    require(find('seededMissingSeatStarts') == [{'seededMissingSeatStarts': 1003, 'privateViewChecks': 25880, 'allSkillHiddenHandChecks': 77640}], 'full seeded view and bot boundaries')
    require(find('completeOneConnectedHumanMatches') == [{'completeOneConnectedHumanMatches': 144, 'realPlayerInputs': 10046, 'administrativeSkips': 0}], '144 whole human games without skips')
    require(find('emptyRoomAndPauseControls') == [{'emptyRoomAndPauseControls': 24}], '24 empty and paused controls')
    require(find('validIntermediateAndEarlyEndSaves') == [{'validIntermediateAndEarlyEndSaves': 600}], '600 actual valid save states')
    leagues = find('league')
    require(len(leagues) == 6, 'two complete leagues plus both regenerations')
    for league in leagues:
        require(league == baseline_leagues[league['league']], 'fully connected original league remains byte-equivalent')
        require(league['games'] == 2000 and league['wilson95'][0] > 0.5, 'actual clearly separated original bot strengths')
    require(find('generated') == [{'generated': 111, 'phases': ['pass', 'play', 'trick', 'hand', 'done'], 'fixtureSeed': 103, 'propertySeeds': 1003}] * 2, 'both complete current 111-file generations')
    require(find('regenerations') == [{'regenerations': 2, 'byteIdentical': True, 'files': 111}], 'actual twice byte-identical current data and media')
    require(find('sourceReceipts') == [{'sourceReceipts': 29, 'schemaValid': True, 'referenceSealValid': True, 'hashesValid': True, 'researchOnly': True}], '29 pinned research receipts')
    require(find('schemaValidatedJson') == [{'schemaValidatedJson': 38, 'checksums': 111, 'allJsonCovered': True}], 'all 38 JSON schemas and 111 hashes')
    browser = find('kind')
    require(len(browser) == 1 and browser[0]['kind'] == 'full' and browser[0]['passed'] is True, 'actual full current browser run')
    require(browser[0]['sourceStart'] == browser[0]['sourceEnd'] == whole['sourceIdentity'], 'all actual current browser source guards match independent reader')
    require(browser[0]['externalRequests'] == browser[0]['runtimeExceptions'] == 0 and browser[0]['serving'] == 'disk', 'actual offline direct-disk browser')
    require(find('accepted') == [{'accepted': True, 'currentSource': True, 'rawFrames': 1200, 'functionals': 20, 'sourceGuards': 30, 'captureBytes': browser[0]['videoBytes'], 'currentCaptureReceipt': '.tmp/visual/current-capture-decoding.json'}], 'original current visual gate actual complete acceptance')
    require(artifact['id'] == artifact_id and artifact['workflow_run']['head_sha'] == HEAD, 'first genuine whole artifact source identity')
    require(whole['passed'] and whole['sourceCommit'] == HEAD and whole['runId'] == run_id and whole['event'] == event, 'fresh independent whole reader actual current acceptance')
    require(whole['artifactId'] == artifact_id and whole['artifactBytes'] == artifact['size_in_bytes'] and 'sha256:' + whole['artifactSha256'] == artifact['digest'], 'whole ZIP size and official digest equality')
    require(whole['independentAssertions'] == 137 and whole['safeEntries'] == 15 and whole['currentGuardedSources'] == 30 and whole['rawIntervals'] == 1200 and whole['originalFunctionalFlags'] == 20, 'full immutable original reader scope')
    require(closed['passed'] and closed['directChildReaped'] and closed['allFrozenInputsUnchanged'] and closed['exception'] is None, 'actual reader naturally closed and source unchanged')
    for name in ['build.mjs', 'html.mjs', 'mutations.mjs', 'check-repro.mjs', 'check-research.mjs', 'check-data.mjs', 'generate.mjs', 'visual.mjs', 'check-visual.mjs', 'verify-ci-artifact.py']:
        path = 'jobs/G05-hearts/scripts/' + name
        original = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
        require((ROOT / path).read_bytes() == original, 'original executed checker unchanged: ' + name)
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD, 'actual current local source head')
    after = guards()
    require(after == before, 'all immutable source, log, metadata, ZIP and independent results unchanged during native read')
    receipt = {'startedAt': started, 'closedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sourceCommit': HEAD, 'runId': run_id, 'event': event, 'jobId': job_id, 'artifactId': artifact_id, 'artifactBytes': whole['artifactBytes'], 'artifactSha256': whole['artifactSha256'], 'fullNativeLogBytes': len(raw), 'fullNativeLogSha256': hashlib.sha256(raw).hexdigest(), 'fullNativeLines': len(log.splitlines()), 'nativeAssertions': checks, 'nativeStatistics': stats, 'propertySeeds': 1003, 'completeBotGamesByRoster': {str(r['players']): r['games'] for r in games}, 'independentCases': 10000, 'originalMutantsCaught': 25, 'regeneratedFiles': 111, 'regenerations': 2, 'currentBrowserReaderAssertions': 137, 'guardedInputs': len(before), 'allFrozenInputsUnchanged': before == after, 'newBrowserOrPerformanceRun': False, 'passed': True}
    (out / 'full-native-readback-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))
