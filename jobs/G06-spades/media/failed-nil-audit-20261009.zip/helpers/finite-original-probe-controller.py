import subprocess,hashlib,json,os,sysconfig,shutil
from pathlib import Path
from datetime import datetime,timezone

root=Path('/tmp/core-root-queue-claims-remote-20261009');job=root/'jobs/G06-spades';out=Path('/tmp/G06-root-audit-20261009')
driver=job/'.work/failed-nil-baseline-probe.ts';controller=Path(__file__).resolve()
git=lambda *a:subprocess.check_output(['git','-C',str(root),*a])
head=git('rev-parse','HEAD').decode().strip();assert head=='0ed388a70d13b59fb3f69a412b77d5c606e5b9a7'
paths=[root/p for p in git('ls-tree','-r','--name-only',head).decode().splitlines()]
for p in paths:assert p.read_bytes()==git('show',head+':'+str(p.relative_to(root)))
paths+=list((job/'node_modules').resolve().rglob('*'))+list((root/'contract/node_modules').resolve().rglob('*'))
stdlib=Path(sysconfig.get_paths()['stdlib'])
paths += [p for p in stdlib.rglob('*.py') if 'site-packages' not in p.parts]
paths += [p for p in stdlib.rglob('*.so') if 'site-packages' not in p.parts]
paths += [Path(m.__file__) for m in list(__import__('sys').modules.values()) if getattr(m,'__file__',None) and Path(m.__file__).is_file()]
paths += [driver,controller,Path(shutil.which('node')).resolve(),Path(__import__('sys').executable).resolve()]
paths=sorted(set(p for p in paths if p.is_file()))
def freeze():
 return {str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size,'dev':p.stat().st_dev,'ino':p.stat().st_ino,'mode':p.stat().st_mode} for p in paths}
before=freeze();(out/'failed-nil-probe-source-before.json').write_text(json.dumps(before,indent=2)+'\n')
start=datetime.now(timezone.utc).isoformat();child=None
try:
 child=subprocess.Popen(['node',str(driver)],cwd=job,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 stdout,stderr=child.communicate(timeout=80)
 (out/'failed-nil-probe.stdout').write_bytes(stdout);(out/'failed-nil-probe.stderr').write_bytes(stderr)
finally:
 if child and child.poll() is None:
  os.killpg(child.pid,15);child.wait(timeout=5)
 after=freeze();(out/'failed-nil-probe-source-after.json').write_text(json.dumps(after,indent=2)+'\n')
 assert before==after,'source/runtime/driver/controller/installed guards changed'
receipt={'status':'ACTUAL_FINITE_PROBE_CLOSED','sourceHead':head,'startedAt':start,'naturallyClosedAt':datetime.now(timezone.utc).isoformat(),'exitCode':child.returncode,'fullGuardCount':len(before),'allGuardsUnchanged':True,'controllerSha256':before[str(controller)]['sha256'],'driverSha256':before[str(driver)]['sha256'],'scope':'untimed legal-game diagnostic; no native FPS or policy adoption'}
(out/'failed-nil-probe-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(stdout.decode());assert child.returncode==0
