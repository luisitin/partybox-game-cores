import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {init,reduce,controllerView,sideOf,type State,type Input} from '../core.ts';
import {fromView} from '../bots.ts';
import {context,conservation} from '../runner.ts';
import {winningPlay,suit,rank} from '../cards.ts';
import {stateSchema} from '../data-schema.ts';
import {createRng} from '../../../contract/rng.ts';

const output='/tmp/G06-root-audit-20261009/failed-nil-baseline-probe.json';
let hands=0,events=0,eligible=0;
function checked(s:State,event:any):State{
 const before=JSON.stringify(s),after=reduce(s,event);
 assert.equal(JSON.stringify(s),before);assert.notEqual(after,s);
 assert.deepEqual(after,reduce(JSON.parse(before),event));
 stateSchema.parse(after);conservation(after);events++;return after;
}
function action(s:State):{playerId:string;input:Input}{
 const id=s.seats[s.turn]!,v=controllerView(s,id),rng=createRng(731),sample=fromView(v,rng,'normal');
 assert.equal(rng.state().step,0,'normal strategy in this diagnostic draws no entropy');
 assert(sample);return {playerId:id,input:sample};
}
function roll(start:State,first:Input){
 let s=checked(start,{type:'input',playerId:'p0',input:first,now:start.phase.startedAt+1});
 const trace:any[]=[{type:'input',playerId:'p0',input:first,now:start.phase.startedAt+1}];
 for(let step=0;s.phase.id!=='hand'&&step<200;step++){
  const event=s.phase.id==='trick'?{type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!}:{type:'input',...action(s),now:s.phase.startedAt+1};
  trace.push(event);s=checked(s,event);
 }
 assert.equal(s.phase.id,'hand');assert(s.report);return {report:s.report,trace};
}
outer:for(let seed=1;seed<=1000;seed++)for(let partnerBid=1;partnerBid<=8;partnerBid++){
 let s=init(context(4,seed,{blind:false,exchange:false,failedNilCounts:true}));
 stateSchema.parse(s);conservation(s);const prefix:any[]=[];hands++;
 for(let step=0;s.phase.id!=='hand'&&step<150;step++){
  if(s.phase.id==='play'&&s.seats[s.turn]==='p0'&&s.won.p0!>0&&s.trick.length===3&&s.hands.p0!.length<=2){
   const v=controllerView(s,'p0'),original=action(s).input;
   assert.equal(original.type,'play');if(original.type!=='play')throw Error('play expected');
   const contract=v.sides.find(x=>x.ids.includes('p0'))!.ids.reduce((n,id)=>n+(v.bids[id]?.kind==='number'?v.bids[id]!.value:0),0);
   const taken=v.sides.find(x=>x.ids.includes('p0'))!.ids.reduce((n,id)=>n+v.won[id]!,0);
   const winners=v.legal.filter(card=>winningPlay([...v.trick,{playerId:'p0',card}])?.playerId==='p0');
   const originalWins=winningPlay([...v.trick,{playerId:'p0',card:original.card}])?.playerId==='p0';
   if(taken<contract&&winners.length&&!originalWins){
    eligible++;
    const cheapest=[...winners].sort((a,b)=>(suit(a)===3?30:0)+rank(a)-((suit(b)===3?30:0)+rank(b)))[0]!;
    const old=roll(s,original),counterfactual=roll(s,{type:'play',card:cheapest}),side=sideOf(s,'p0');
    if(counterfactual.report.sides[side]!.score>old.report.sides[side]!.score){
     writeFileSync(output,JSON.stringify({status:'VALID_LEGAL_COUNTERFACTUAL_SCORE_GAIN',scope:'one untimed seeded hand, original source unchanged, no adopted policy or universal league gain',seed,partnerBid,hands,events,eligible,initialContext:context(4,seed,{blind:false,exchange:false,failedNilCounts:true}),prefix,state:s,publicOwnView:v,originalChoice:original,legalCounterfactualChoice:{type:'play',card:cheapest},original:old,counterfactual,side,gain:counterfactual.report.sides[side]!.score-old.report.sides[side]!.score},null,2)+'\n');
     console.log(JSON.stringify({status:'VALID_LEGAL_COUNTERFACTUAL_SCORE_GAIN',seed,partnerBid,hands,events,eligible,originalCard:original.card,counterfactualCard:cheapest,oldScore:old.report.sides[side]!.score,newScore:counterfactual.report.sides[side]!.score,gain:counterfactual.report.sides[side]!.score-old.report.sides[side]!.score}));break outer;
    }
   }
  }
  let event:any;
  if(s.phase.id==='trick')event={type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!};
  else{
   const a=action(s);
   if(s.phase.id==='bid'&&a.playerId==='p0')a.input={type:'nil'};
   else if(s.phase.id==='bid'&&a.playerId==='p2')a.input={type:'bid',value:partnerBid};
   event={type:'input',...a,now:s.phase.startedAt+1};
  }
  prefix.push(event);s=checked(s,event);
 }
 assert.equal(s.phase.id,'hand');
}
if(!process.getBuiltinModule('fs').existsSync(output)){
 writeFileSync(output,JSON.stringify({status:'NO_SCORE_GAIN_FOUND_IN_FINITE_PROBE',hands,events,eligible,seeds:[1,1000],partnerBids:[1,8],scope:'no proof of universal correctness or absence of all nil-strategy gaps'})+'\n');
 console.log(JSON.stringify({status:'NO_SCORE_GAIN_FOUND_IN_FINITE_PROBE',hands,events,eligible}));
}
