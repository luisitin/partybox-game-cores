import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {init,reduce,controllerView,sideOf,type State,type Input} from '../core.ts';
import {fromView as baseline} from '../bots-before-opponent-nil.ts';
import {fromView as current} from '../bots.ts';
import {context,conservation} from '../runner.ts';
import {stateSchema} from '../data-schema.ts';
import {scoreSide} from '../scoring.ts';
import {ledger} from '../reference.ts';
import {createRng} from '../../../contract/rng.ts';
const proof=JSON.parse(readFileSync('failed-opponent-nil-replay.json','utf8'));
const output='/tmp/G06-root-audit-20261009/genuine-numeric-bid-lattice-review.json';assert(!existsSync(output));
let events=0,boundaries=0,unchanged=0,changed=0,minChangedGain=Infinity;
function checked(s:State,e:any){const b=JSON.stringify(s),n=reduce(s,e);assert.notEqual(n,s);assert.equal(JSON.stringify(s),b);assert.deepEqual(n,reduce(JSON.parse(b),e));stateSchema.parse(n);conservation(n);events++;return n;}
function finish(s:State,first:Input){const trace:any[]=[];for(let k=0;s.phase.id!=='hand'&&k<30;k++){const id=s.seats[s.turn]!,e=s.phase.id==='trick'?{type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!}:{type:'input',playerId:id,input:k===0?first:baseline(controllerView(s,id),createRng(731),'normal')!,now:s.phase.startedAt+1};trace.push(e);s=checked(s,e);}assert.equal(s.phase.id,'hand');assert(s.report);for(let side=0;side<2;side++)assert.deepEqual(s.report.sides[side],ledger(s.seats.filter(id=>sideOf(s,id)===side).map(id=>({bid:s.bids[id]!,won:s.won[id]!})),0,0,s.settings.nilValue,s.settings.failedNilCounts));return {report:s.report,trace};}
const records:any[]=[];
for(const failedNilCounts of [false,true])for(const nilValue of [50,100])for(let ownBid=1;ownBid<=13;ownBid++)for(let opponentBid=1;opponentBid<=13;opponentBid++){
 const ctx=context(4,577,{blind:false,exchange:false,failedNilCounts,nilValue});let s=init(ctx);const prefix=proof.prefix.map((e:any)=>e.type==='input'&&e.input.type==='bid'&&['p0','p1'].includes(e.playerId)?{...e,input:{type:'bid',value:e.playerId==='p0'?ownBid:opponentBid}}:structuredClone(e));for(const e of prefix)s=checked(s,e);assert.deepEqual(s.hands,proof.state.hands);assert.deepEqual(s.won,proof.state.won);assert.equal(s.bids.p0!.value,ownBid);assert.equal(s.bids.p1!.value,opponentBid);const v=controllerView(s,'p0'),decisions:any[]=[];
 for(const skill of ['easy','normal','sharp'] as const){const a=createRng(731),b=createRng(731),old=baseline(v,a,skill),next=current(v,b,skill);assert(old&&next);assert.deepEqual(a.state(),b.state());const equal=JSON.stringify(old)===JSON.stringify(next);if(skill==='easy'||!failedNilCounts)assert(equal);if(equal)unchanged++;else changed++;
  const x=finish(s,old),y=finish(s,next),scores:number[][]=[];let minGain=Infinity,maxGain=-Infinity;
  for(let ownBag=0;ownBag<10;ownBag++)for(let opponentBag=0;opponentBag<10;opponentBag++){const scored=[x.report,y.report].map(r=>[0,1].map(side=>{const seats=s.seats.filter(id=>sideOf(s,id)===side).map(id=>({bid:r.bids[id],won:r.won[id]})),bags=side===0?ownBag:opponentBag,p=scoreSide(seats,0,bags,nilValue,failedNilCounts);assert.deepEqual(p,ledger(seats,0,bags,nilValue,failedNilCounts));return p;}));const ownGain=scored[1]![0]!.score-scored[0]![0]!.score,opponentGain=scored[1]![1]!.score-scored[0]![1]!.score,marginGain=ownGain-opponentGain;assert(marginGain>=0);assert(ownGain>=0);if(equal)assert.equal(marginGain,0);if(!equal)minChangedGain=Math.min(minChangedGain,marginGain);minGain=Math.min(minGain,marginGain);maxGain=Math.max(maxGain,marginGain);scores.push([ownBag,opponentBag,scored[0]![0]!.score,scored[0]![1]!.score,scored[1]![0]!.score,scored[1]![1]!.score,marginGain]);boundaries++;}
  decisions.push({skill,oldChoice:old,currentChoice:next,unchanged:equal,original:x,current:y,minMarginGain:minGain,maxMarginGain:maxGain,scoreColumns:['ownBag','opponentBag','oldOwn','oldOpponent','currentOwn','currentOpponent','marginGain'],scores});
 }records.push({ownBid,opponentBid,failedNilCounts,nilValue,initialContext:ctx,prefix,preDecision:s,decisions});
}
assert.equal(records.length,676);assert.equal(unchanged+changed,2028);assert.equal(boundaries,202800);assert(changed>0);assert(minChangedGain>=0);
const report={status:'ACTUAL_GENUINE_NUMERIC_BID_LATTICE_REVIEW_PASS',scope:'676 legitimate full seeded577 histories with legal bid-only changes covering all169 numeric pairs, both nil bonuses and failedNilCounts settings; all three skill actions/RNG and both terminal continuations,202800 independent carried-bag scores. Finite one-deal lattice; not169 random deals, universal strength or a new production gain. No timing repeated.',cases:records.length,numericPairs:169,events,unchanged,changed,boundaries,minChangedMarginGain:minChangedGain,newProductionGain:0,records};
writeFileSync(output,JSON.stringify(report)+'\n');console.log(JSON.stringify({...report,records:undefined}));
