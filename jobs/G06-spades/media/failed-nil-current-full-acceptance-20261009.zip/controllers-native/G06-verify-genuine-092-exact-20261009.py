import json,zipfile,hashlib,subprocess,re,os,shutil
from pathlib import Path
from datetime import datetime,timezone

root=Path('/tmp/core-root-queue-claims-remote-20261009');job=root/'jobs/G06-spades';base=Path('/tmp/G06-current-official-092-exact-20261009');out=Path('/tmp/G06-root-audit-20261009')
git=lambda *a:subprocess.check_output(['git','-C',str(root),*a])
head=git('rev-parse','HEAD').decode().strip();assert head=='092dbf8fdc65da3a7e6b58afa013612617613fed'
tracked=[root/p for p in git('ls-tree','-r','--name-only',head).decode().splitlines()]
for p in tracked:assert p.read_bytes()==git('show',head+':'+str(p.relative_to(root)))
frozen=[*tracked,Path(__file__).resolve(),job/'.work/verify-genuine-092-exact.ts',base/'actual.zip',out/'current-092-exact-full-native.log',Path(shutil.which('node')).resolve(),Path('/usr/bin/ffmpeg'),Path('/usr/bin/ffprobe')]
freeze=lambda:{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in frozen}
before=freeze();(base/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
raw=(base/'actual.zip').read_bytes();assert len(raw)==98094 and hashlib.sha256(raw).hexdigest()=='79f7f837c67d033f2c5afbc60d951b35edc0cf6fdd0538d8cf9eede966399499'
target=base/'files';assert not target.exists();target.mkdir()
expected={'browser-raw-1-TV.json','browser-raw-1-phone-4x.json','browser-report.json','capture-milestone-15-report.json','media/milestone-15-pinned-encoder.webm'}
with zipfile.ZipFile(base/'actual.zip') as z:
 assert len(z.namelist())==5 and set(z.namelist())==expected and z.testzip() is None
 for n in z.namelist():
  p=target/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
native=(out/'current-092-exact-full-native.log').read_text();clean=re.sub(r'^\d{4}-[^ ]+ ', '',native,flags=re.M)
assert 'ℹ tests 36' in clean and 'ℹ pass 36' in clean and 'ℹ tests 21' in clean and 'ℹ pass 21' in clean
assert clean.count('ℹ fail 0')==2 and '25/25 genuine assertion kills; baseline 28/28; no startup failures/timeouts counted' in clean
assert len(re.findall(r'^\d+/25 killed:',clean,re.M))==25
assert '1000 complete bot matches at 3 players' in clean and '1000 complete bot matches at 4 players' in clean
assert 'seeds 1/2/3 plus 1000 unique random seeds replay every full match byte-identically' in clean
assert '"seeds": 1003' in clean and clean.count('8000 full 500-point/mercy matches complete')==2
assert clean.count('games: 2000,')==8 and 'all four 95% lower bounds exceed 50%' in clean
controls=[json.loads(x.split('G06_VERIFICATION_CONTROLS ',1)[1]) for x in clean.splitlines() if x.startswith('G06_VERIFICATION_CONTROLS ')]
assert len(controls)==1 and controls[0]['negativeControls']==58 and len(controls[0]['controls'])==58
capture=[json.loads(x.split('G06_CAPTURE_PREFLIGHT_CONTROLS ',1)[1]) for x in clean.splitlines() if x.startswith('G06_CAPTURE_PREFLIGHT_CONTROLS ')]
assert len(capture)==1 and capture[0]['negativeControls']==12 and capture[0]['unchanged'] is True
start=datetime.now(timezone.utc).isoformat();steps=[]
try:
 for name,args in [('full-original-reader',['node',str(job/'.work/verify-genuine-092-exact.ts')]),('full-video-decode',['ffmpeg','-v','error','-i',str(target/'media/milestone-15-pinned-encoder.webm'),'-f','null','-']),('all-video-frame-inventory',['ffprobe','-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=codec_name,nb_read_frames,width,height,duration','-show_entries','format=duration','-of','json',str(target/'media/milestone-15-pinned-encoder.webm')])]:
  r=subprocess.run(args,cwd=job,capture_output=True,timeout=45)
  (base/(name+'.stdout')).write_bytes(r.stdout);(base/(name+'.stderr')).write_bytes(r.stderr)
  steps.append({'name':name,'exitCode':r.returncode});assert r.returncode==0,(name,r.stderr.decode())
 meta=json.loads((base/'all-video-frame-inventory.stdout').read_text());assert meta['streams'][0]['codec_name']=='vp8';assert int(meta['streams'][0]['nb_read_frames'])==18
finally:
 after=freeze();(base/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
receipt={'status':'ACTUAL_FULL_ORIGINAL_CURRENT_092_ACCEPTED','sourceHead':'092dbf8fdc65da3a7e6b58afa013612617613fed','currentRuntimeBridgeHead':head,'scope':'current exact092 original full CI, actual official whole artifact and original unchanged verification reader','artifactId':11598961283,'runId':37891792425,'jobId':113694132749,'officialZipBytes':len(raw),'officialZipSha256':hashlib.sha256(raw).hexdigest(),'fullNativeCharacters':len(native),'trackedGitFilesCompared':len(tracked),'outerGuardCount':len(before),'allGuardsUnchanged':True,'startedAt':start,'naturallyClosedAt':datetime.now(timezone.utc).isoformat(),'steps':steps,'video':meta,'rawIntervals':1800,'coreTests':36,'focusedGroups':21,'actualMutationKills':25,'presenceSeeds':1003,'skillGames':16000,'negativeEvidenceControls':58,'captureCliControls':12}
(base/'full-acceptance-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
