import assert from 'node:assert/strict';
import {writeFileSync,existsSync} from 'node:fs';
import {init,reduce,controllerView,tvView,sideOf,blindEligible,type State,type Input} from '../core.ts';
import {fromView as baseline} from '../bots-before-opponent-nil.ts';
import {fromView as current} from '../bots.ts';
import {context,conservation} from '../runner.ts';
import {stateSchema} from '../data-schema.ts';
import {scoreSide} from '../scoring.ts';
import {ledger} from '../reference.ts';
import {createRng} from '../../../contract/rng.ts';
const output='/tmp/G06-root-audit-20261009/genuine-blind-cutthroat-matrix-review.json';assert(!existsSync(output));
let events=0,privacy=0,blindDeclarations=0,gap100LaterDeclarations=0,exchanges=0,rejectedBlind=0,skillComparisons=0,changed=0,boundaries=0,hands=0;
function checked(s:State,e:any){const b=JSON.stringify(s),n=reduce(s,e);assert.notEqual(n,s);assert.equal(JSON.stringify(s),b);assert.deepEqual(n,reduce(JSON.parse(b),e));stateSchema.parse(n);conservation(n);events++;return n;}
function finish(start:State,first:Input){let s=start;const trace:any[]=[];for(let k=0;s.phase.id!=='hand'&&k<30;k++){const id=tvView(s).turn!,e=s.phase.id==='trick'?{type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!}:{type:'input',playerId:id,input:k===0?first:baseline(controllerView(s,id),createRng(731),'normal')!,now:s.phase.startedAt+1};trace.push(e);s=checked(s,e);}assert.equal(s.phase.id,'hand');assert(s.report);for(let side=0;side<start.scores.length;side++)assert.deepEqual(s.report.sides[side],ledger(s.seats.filter(id=>sideOf(s,id)===side).map(id=>({bid:s.bids[id]!,won:s.won[id]!})),start.scores[side]!,start.bags[side]!,s.settings.nilValue,s.settings.failedNilCounts));return {report:s.report,trace};}
const records:any[]=[];
for(const n of [3,4])for(const seed of [1,2,3,577])for(const blindGap of [0,100])for(const exchange of [false,true])for(const nilValue of [50,100])for(const failedNilCounts of [false,true])for(const cutDeck of n===3?['low-club','stock']:['low-club'])for(const cutLead of n===3?['dealer','club']:['dealer']){
 const ctx=context(n,seed,{blind:true,blindGap,exchange,nilValue,failedNilCounts,mercy:false,cutDeck,cutLead});let s=init(ctx),beforeScores=[...s.scores],beforeBags=[...s.bags];stateSchema.parse(s);conservation(s);const trace:any[]=[],completed:any[]=[],changes:any[]=[];
 for(let step=0;completed.length<3&&s.phase.id!=='done'&&step<700;step++){
  if(s.phase.id==='hand'){assert(s.report);for(let side=0;side<s.scores.length;side++)assert.deepEqual(s.report.sides[side],ledger(s.seats.filter(id=>sideOf(s,id)===side).map(id=>({bid:s.bids[id]!,won:s.won[id]!})),beforeScores[side]!,beforeBags[side]!,nilValue,failedNilCounts));completed.push(s.report);hands++;if(completed.length===3)break;const e={type:'input',playerId:'p0',input:{type:'next'},now:s.phase.startedAt+1};trace.push(e);s=checked(s,e);beforeScores=[...s.scores];beforeBags=[...s.bags];continue;}
  if(s.phase.id==='trick'){const e={type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!};trace.push(e);s=checked(s,e);continue;}
  const id=tvView(s).turn!,v=controllerView(s,id);assert(id);const nilSeat=n===4?['p2','p3'].includes(id):id==='p0';
  for(const skill of ['easy','normal','sharp'] as const){const a=createRng(731),b=createRng(731),old=baseline(v,a,skill),next=current(v,b,skill);assert(old&&next);assert.deepEqual(a.state(),b.state());skillComparisons++;
   if(JSON.stringify(old)!==JSON.stringify(next)){changed++;assert.equal(n,4);assert(failedNilCounts);assert.notEqual(skill,'easy');assert.equal(s.phase.id,'play');const x=finish(s,old),y=finish(s,next),scores:any[]=[];
    for(let ownBag=0;ownBag<10;ownBag++)for(let opponentBag=0;opponentBag<10;opponentBag++){const own=sideOf(s,id),other=1-own,scored=[x.report,y.report].map(r=>[own,other].map((side,i)=>{const seats=s.seats.filter(p=>sideOf(s,p)===side).map(p=>({bid:r.bids[p],won:r.won[p]})),bags=i===0?ownBag:opponentBag,p=scoreSide(seats,s.scores[side]!,bags,nilValue,failedNilCounts);assert.deepEqual(p,ledger(seats,s.scores[side]!,bags,nilValue,failedNilCounts));return p;}));const ownGain=scored[1]![0]!.score-scored[0]![0]!.score,opponentGain=scored[1]![1]!.score-scored[0]![1]!.score,marginGain=ownGain-opponentGain;assert(ownGain>=0);assert(marginGain>=0);scores.push({ownBag,opponentBag,original:scored[0],current:scored[1],ownGain,opponentGain,marginGain});boundaries++;}
    changes.push({hand:s.handNumber,id,skill,state:s,old,current:next,original:x,counterfactual:y,scores});
   }
  }
  let input=baseline(v,createRng(731),'normal')!;
  if(s.phase.id==='blind'){assert(blindEligible(s,id));assert(v.blindEligible);assert(!s.looked.includes(id));assert.deepEqual(v.hand,[]);assert.deepEqual(v.legal,[]);privacy++;if(nilSeat){input={type:'blind-nil'};blindDeclarations++;if(blindGap===100&&s.handNumber>1)gap100LaterDeclarations++;}else input={type:'look'};}
  else if(s.phase.id==='bid'){const saved=JSON.stringify(s);assert.equal(reduce(s,{type:'input',playerId:id,input:{type:'blind-nil'},now:s.phase.startedAt+1}),s);assert.equal(JSON.stringify(s),saved);rejectedBlind++;input=nilSeat?{type:'nil'}:{type:'bid',value:n===4?(id==='p0'?6:9):8};}
  else if(s.phase.id==='exchange'){assert.equal(n,4);assert(exchange);assert.equal(input.type,'exchange');assert.equal(new Set((input as any).cards).size,2);exchanges++;}
  const e={type:'input',playerId:id,input,now:s.phase.startedAt+1};trace.push(e);s=checked(s,e);
 }
 assert(completed.length===3||s.phase.id==='done');records.push({initialContext:ctx,trace,completed,changes,phase:s.phase.id,finalScores:s.scores,finalBags:s.bags});
}
assert.equal(records.length,320);assert(privacy>0);assert(blindDeclarations>0);assert(gap100LaterDeclarations>0);assert(exchanges>0);assert(rejectedBlind>0);assert(changed>0);
const report={status:'ACTUAL_GENUINE_BLIND_CUTTHROAT_MATRIX_REVIEW_PASS',scope:'320 genuine consecutive-hand games with seeds1/2/3/577 across3/4 seats, both blind gaps, exchanges, bonuses, failed-nil toggles and four Cutthroat deck/lead variants. Scores and eligibility come only from actual prior completed hands; no synthetic score assignments. Original baseline progress, all3 current skill/RNG comparisons, actual pre-look privacy/illegal blind rejection/legal exchanges/persisted independent bag ledger; changed choices get both legal final continuations/independent bag outcomes. Finite suite; no universal safety or new production change/native timing.',games:records.length,hands,events,privacy,blindDeclarations,gap100LaterDeclarations,exchanges,rejectedBlind,skillComparisons,changed,boundaries,newProductionGain:0,records};
writeFileSync(output,JSON.stringify(report)+'\n');console.log(JSON.stringify({...report,records:undefined}));
