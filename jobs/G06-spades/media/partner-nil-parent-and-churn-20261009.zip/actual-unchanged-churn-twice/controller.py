import subprocess,hashlib,json,os,sysconfig,shutil,sys,datetime,signal
from pathlib import Path
root=Path('/tmp/core-root-queue-claims-remote-20261009');job=root/'jobs/G06-spades';out=Path('/tmp/G06-root-audit-20261009')
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
git=lambda *a:subprocess.check_output(['git','-C',str(root),*a])
head=git('rev-parse','HEAD').decode().strip();assert head=='f92ddec60e4f7f4f48a855951574dd798f6b8f5b'
tracked=[root/p for p in git('ls-tree','-r','--name-only',head).decode().splitlines()]
allowed={'jobs/G06-spades/bots.ts', 'jobs/G06-spades/ASSUMPTIONS.md', 'jobs/G06-spades/package.json', 'jobs/G06-spades/BOTS.md', '.github/workflows/G06.yml', 'jobs/G06-spades/SHA256SUMS.txt', 'jobs/G06-spades/AUDIT.md', 'jobs/G06-spades/play.html', 'jobs/G06-spades/VERIFY.md', 'jobs/G06-spades/NEXT.md', 'jobs/G06-spades/LOOP.md'}
for p in tracked:
 if str(p.relative_to(root)) not in allowed:assert p.read_bytes()==git('show',head+':'+str(p.relative_to(root)))
paths=[p for p in tracked if p!=job/'churn-results.json']
for directory in [job/'node_modules',root/'contract/node_modules']:paths.extend(p for p in directory.rglob('*') if p.is_file())
stdlib=Path(sysconfig.get_paths()['stdlib'])
paths.extend(p for p in stdlib.rglob('*.py') if 'site-packages' not in p.parts);paths.extend(p for p in stdlib.rglob('*.so') if 'site-packages' not in p.parts)
paths.extend(Path(m.__file__) for m in list(sys.modules.values()) if getattr(m,'__file__',None) and Path(m.__file__).is_file())
paths.extend([Path(__file__).resolve(),Path(shutil.which('node')).resolve(),Path(sys.executable).resolve(),job/'bots-before-partner-nil.ts',job/'failed-partner-nil-test.ts',job/'failed-partner-nil-replay.json',job/'failed-partner-nil-rejected-bag-proposal.json',job/'failed-partner-nil-audit-summary.json',job/'media/failed-partner-nil-audit-20261009.zip',job/'capture-milestone-16-report.json',job/'media/milestone-16-pinned-encoder.webm'])
paths=sorted(set(paths))
def frozen():
 return {str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'resolved':str(p.resolve()),'bytes':p.stat().st_size,'dev':p.stat().st_dev,'ino':p.stat().st_ino} for p in paths}
before=frozen();(out/'partner-nil-churn-before.json').write_text(json.dumps(before,indent=2)+'\n');baseline=(job/'churn-results.json').read_bytes();(out/'partner-nil-old-churn.json').write_bytes(baseline);steps=[];first=None
try:
 for i in [1,2]:
  begin=utc();child=subprocess.Popen(['node','churn.ts','--write'],cwd=job,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);natural=False
  try:stdout,stderr=child.communicate(timeout=100);natural=True
  finally:
   if child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=8)
  (out/f'partner-nil-churn-{i}.stdout').write_bytes(stdout);(out/f'partner-nil-churn-{i}.stderr').write_bytes(stderr)
  try:os.killpg(child.pid,0);empty=False
  except ProcessLookupError:empty=True
  r={'i':i,'startedAt':begin,'naturallyClosedAt':utc(),'exitCode':child.returncode,'natural':natural,'actualOwnedGroupEmpty':empty};steps.append(r);print(json.dumps(r),flush=True);assert child.returncode==0 and natural and empty and not stderr
  data=(job/'churn-results.json').read_bytes();(out/f'partner-nil-churn-{i}.json').write_bytes(data)
  if first is None:first=data
  else:assert data==first
finally:
 after=frozen();(out/'partner-nil-churn-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
r={'status':'ACTUAL_ORIGINAL_CHURN_AFTER_NARROW_PARTNER_NIL_TWICE','baseHead':head,'naturallyClosedAt':utc(),'steps':steps,'guardCount':len(before),'allFrozenInputsUnchanged':True,'oldSha256':hashlib.sha256(baseline).hexdigest(),'newSha256':hashlib.sha256(first).hexdigest(),'byteIdenticalTwice':True,'oldGoldenUnchanged':baseline==first,'report':json.loads(first),'allOriginalAssertionsAndGeneratorUnchanged':True};(out/'partner-nil-churn-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
