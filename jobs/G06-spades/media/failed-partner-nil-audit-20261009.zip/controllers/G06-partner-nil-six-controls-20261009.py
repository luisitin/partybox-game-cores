import subprocess,hashlib,json,os,sysconfig,shutil,sys,datetime,signal
from pathlib import Path
root=Path('/tmp/core-root-queue-claims-remote-20261009');job=root/'jobs/G06-spades';out=Path('/tmp/G06-root-audit-20261009')
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
git=lambda *a:subprocess.check_output(['git','-C',str(root),*a])
head=git('rev-parse','HEAD').decode().strip();assert head=='f92ddec60e4f7f4f48a855951574dd798f6b8f5b'
tracked=[root/p for p in git('ls-tree','-r','--name-only',head).decode().splitlines()]
for p in tracked:assert p.read_bytes()==git('show',head+':'+str(p.relative_to(root)))
paths=list(tracked)
for directory in [job/'node_modules',root/'contract/node_modules']:paths.extend(p for p in directory.rglob('*') if p.is_file())
stdlib=Path(sysconfig.get_paths()['stdlib'])
paths.extend(p for p in stdlib.rglob('*.py') if 'site-packages' not in p.parts);paths.extend(p for p in stdlib.rglob('*.so') if 'site-packages' not in p.parts)
paths.extend(Path(m.__file__) for m in list(sys.modules.values()) if getattr(m,'__file__',None) and Path(m.__file__).is_file())
paths.extend([Path(__file__).resolve(),Path(shutil.which('node')).resolve(),Path(sys.executable).resolve(),job/'.work/failed-partner-nil-candidate-test.ts',job/'.work/bots.failed-partner-nil-final-two-candidate.ts',out/'failed-partner-nil-pressure-13bids-baseline-probe.json',out/'failed-partner-nil-baseline-probe.json'])
paths=sorted(set(paths))
def frozen():
 return {str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'resolved':str(p.resolve()),'bytes':p.stat().st_size,'dev':p.stat().st_dev,'ino':p.stat().st_ino} for p in paths}
before=frozen();(out/'partner-nil-six-controls-before.json').write_text(json.dumps(before,indent=2)+'\n')
steps=[]
try:
 for label,value,expected in [('baseline-negative','0',1),('candidate-positive','1',0)]:
  env=os.environ.copy();env['G06_PRIVATE_NIL_CANDIDATE']=value;begin=utc()
  child=subprocess.Popen(['node','--test',str(job/'.work/failed-partner-nil-candidate-test.ts')],cwd=job,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);natural=False
  try:stdout,stderr=child.communicate(timeout=120);natural=True
  finally:
   if child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=8)
  (out/('partner-nil-'+label+'.stdout')).write_bytes(stdout);(out/('partner-nil-'+label+'.stderr')).write_bytes(stderr)
  try:os.killpg(child.pid,0);empty=False
  except ProcessLookupError:empty=True
  step={'label':label,'startedAt':begin,'naturallyClosedAt':utc(),'exitCode':child.returncode,'natural':natural,'actualOwnedGroupEmpty':empty};steps.append(step);print(json.dumps(step),flush=True)
  assert child.returncode==expected and natural and empty and not stderr
  text=stdout.decode();assert 'ℹ tests 6' in text
  if value=='0':assert 'ℹ fail 3' in text and 'ℹ pass 3' in text
  else:assert 'ℹ pass 6' in text and 'ℹ fail 0' in text
finally:
 after=frozen();(out/'partner-nil-six-controls-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
r={'status':'ACTUAL_SIX_PRIVATE_NIL_PRESSURE_GROUPS_CLOSED','sourceHead':head,'naturallyClosedAt':utc(),'steps':steps,'guardCount':len(before),'allFrozenInputsUnchanged':True,'noProductionPolicyAdopted':True};(out/'partner-nil-six-controls-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
