import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {init,reduce,controllerView,sideOf,type State,type Input} from '../core.ts';
import {fromView as baseline} from '../bots-before-opponent-nil.ts';
import {fromView as current} from '../bots.ts';
import {context,conservation} from '../runner.ts';
import {stateSchema} from '../data-schema.ts';
import {scoreSide} from '../scoring.ts';
import {ledger} from '../reference.ts';
import {createRng} from '../../../contract/rng.ts';
const proof=JSON.parse(readFileSync('failed-opponent-nil-replay.json','utf8'));
const output='/tmp/G06-root-audit-20261009/public-unseen-last-trick-outcome-review.json';assert(!existsSync(output));
let events=0,privacy=0,boundaries=0;
function checked(s:State,e:any){const b=JSON.stringify(s),n=reduce(s,e);assert.notEqual(n,s);assert.equal(JSON.stringify(s),b);assert.deepEqual(n,reduce(JSON.parse(b),e));stateSchema.parse(n);conservation(n);events++;return n;}
let actual=init(context(4,577,{blind:false,exchange:false,failedNilCounts:true}));for(const e of proof.prefix)actual=checked(actual,e);assert.deepEqual(actual,proof.state);
const view=controllerView(actual,'p0'),ids=['p1','p2','p3'],remaining=ids.map(id=>{assert.equal(actual.hands[id]!.length,1);return actual.hands[id]![0]!;});
const suit=(card:number)=>Math.floor(card/13),voids=new Map(actual.seats.map(id=>[id,new Set<number>()]));
for(const t of [...actual.completed,{cards:actual.trick}])for(const c of t.cards)if(suit(c.card)!==suit(t.cards[0]!.card))voids.get(c.playerId)!.add(suit(t.cards[0]!.card));
function permutations(xs:number[]):number[][]{return xs.length===0?[[]]:xs.flatMap((x,i)=>permutations(xs.filter((_,j)=>j!==i)).map(rest=>[x,...rest]));}
function finish(s:State,first:Input){const trace:any[]=[];for(let k=0;s.phase.id!=='hand'&&k<30;k++){const id=s.seats[s.turn]!,e=s.phase.id==='trick'?{type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!}:{type:'input',playerId:id,input:k===0?first:baseline(controllerView(s,id),createRng(731),'normal')!,now:s.phase.startedAt+1};trace.push(e);s=checked(s,e);}assert.equal(s.phase.id,'hand');assert(s.report);for(let side=0;side<2;side++)assert.deepEqual(s.report.sides[side],ledger(s.seats.filter(id=>sideOf(s,id)===side).map(id=>({bid:s.bids[id]!,won:s.won[id]!})),0,0,s.settings.nilValue,true));return {report:s.report,trace};}
const records:any[]=[];let publiclyConsistent=0,minGain=Infinity,maxGain=-Infinity;
for(const allocation of permutations(remaining)){
 const projected=structuredClone(actual);for(let i=0;i<ids.length;i++)projected.hands[ids[i]!]=[allocation[i]!];stateSchema.parse(projected);conservation(projected);assert.deepEqual(controllerView(projected,'p0'),view);privacy++;
 const violations=ids.filter((id,i)=>voids.get(id)!.has(suit(allocation[i]!)));if(!violations.length)publiclyConsistent++;
 const decisions:any[]=[];for(const skill of ['normal','sharp'] as const){const a=createRng(731),b=createRng(731),old=baseline(view,a,skill),next=current(controllerView(projected,'p0'),b,skill);assert.deepEqual(old,{type:'play',card:18});assert.deepEqual(next,{type:'play',card:41});assert.deepEqual(a.state(),b.state());const x=finish(projected,old!),y=finish(projected,next!);const scores:any[]=[];
  for(const nilValue of [50,100])for(let ownBag=0;ownBag<10;ownBag++)for(let opponentBag=0;opponentBag<10;opponentBag++){const scored=[x.report,y.report].map(r=>[0,1].map(side=>{const seats=projected.seats.filter(id=>sideOf(projected,id)===side).map(id=>({bid:r.bids[id],won:r.won[id]})),bags=side===0?ownBag:opponentBag,p=scoreSide(seats,0,bags,nilValue,true);assert.deepEqual(p,ledger(seats,0,bags,nilValue,true));return p;}));const ownGain=scored[1]![0]!.score-scored[0]![0]!.score,opponentGain=scored[1]![1]!.score-scored[0]![1]!.score,marginGain=ownGain-opponentGain;if(!violations.length){assert(marginGain>=0);assert(ownGain>=0);minGain=Math.min(minGain,marginGain);maxGain=Math.max(maxGain,marginGain);}scores.push({nilValue,ownBag,opponentBag,original:scored[0],current:scored[1],ownGain,opponentGain,marginGain});boundaries++;}decisions.push({skill,original:x,current:y,scores});
 }records.push({allocation:Object.fromEntries(ids.map((id,i)=>[id,allocation[i]])),knownVoidViolations:violations,projected,decisions});
}
assert.equal(records.length,6);assert.equal(privacy,6);assert.equal(boundaries,2400);assert.equal(publiclyConsistent,6);
const report={status:'ACTUAL_PUBLIC_UNSEEN_LAST_TRICK_PRIVACY_OUTCOME_REVIEW_PASS',scope:'Six synthetic conserved hidden-card projections with identical public view, consistent with recorded public voids; not six replayable seeded histories or proof of exhaustive reachability. One genuine seed577 prefix retained; both legal final continuations and independent scoring across200 boundaries per skill. No policy change/new player gain/native timing.',records:records.length,events,privacy,boundaries,publiclyConsistent,minMarginGain:minGain,maxMarginGain:maxGain,knownVoids:[...voids].map(([id,x])=>({id,voids:[...x]})),gainMeasuredForNewProductionChange:0,allocations:records};
writeFileSync(output,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({...report,allocations:undefined}));
