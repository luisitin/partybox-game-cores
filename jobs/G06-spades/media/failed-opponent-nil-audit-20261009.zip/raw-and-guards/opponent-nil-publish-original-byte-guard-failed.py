from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone,timedelta
import json,subprocess,zipfile
root=Path('/tmp/core-root-queue-claims-remote-20261009');job=root/'jobs/G06-spades';private=Path('/tmp/G06-root-audit-20261009')
parent='255be4cfae5701fed8ed771019be641f51bda08f';branch='job/G06-spades-audit-20261009'
utc=lambda:datetime.now(timezone.utc)
def git(*args):return subprocess.check_output(['git','-C',str(root),*args]).decode().strip()
assert git('rev-parse','HEAD')==parent and git('branch','--show-current')==branch
assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==parent
def load(n):return json.loads((private/n).read_text())
focused=load('opponent-nil-corrected-new-focused-receipt.json');churn=load('opponent-nil-churn-receipt.json');capture=load('capture17-receipt.json');probe=load('opponent-nil-two-sided-probe-receipt.json');proof=load('failed-opponent-nil-two-sided-probe.json')
assert all(x['exitCode']==0 for x in focused['steps']) and focused['allWorkingSourceInputsUnchanged']
assert churn['byteIdenticalTwice'] and churn['oldGoldenUnchanged'] and all(x['exitCode']==0 for x in churn['steps'])
assert capture['exitCode']==0 and capture['allGuardsUnchanged'] and probe['exitCode']==0 and probe['allFrozenInputsUnchanged']
assert proof['ownGain']==120 and proof['opponentGain']==0 and proof['gain']==120 and len(proof['boundaries'])==200
assert (job/'failed-opponent-nil-replay.json').read_bytes()==(private/'failed-opponent-nil-two-sided-probe.json').read_bytes()
assert (job/'bots-before-opponent-nil.ts').read_bytes()==subprocess.check_output(['git','-C',str(root),'show',parent+':jobs/G06-spades/bots.ts'])
archive=job/'media/failed-opponent-nil-audit-20261009.zip';assert not archive.exists();members={}
for p in sorted(private.glob('opponent-nil-*')):
 if p.is_file():members['raw-and-guards/'+p.name]=p
for p in [private/'failed-opponent-nil-final-two-baseline-probe.json',private/'failed-opponent-nil-two-sided-probe.json',*sorted(private.glob('capture17*'))]:
 if p.is_file():members['raw-and-guards/'+p.name]=p
for p in [*sorted(Path('/tmp').glob('G06-opponent-nil-*-20261009.py')),Path('/tmp/G06-build-opponent-nil-focused-20261009.py'),Path('/tmp/G06-run-capture17-20261009.py')]:members['controllers/'+p.name]=p
for n in ['bots.failed-opponent-nil-two-sided-candidate.ts','failed-opponent-nil-two-sided-probe.ts']:
 p=job/'.work'/n;assert p.is_file();members['private-candidate-and-probe/'+n]=p
for n in ['bots-before-opponent-nil.ts','bots.ts','failed-opponent-nil-test.ts','failed-opponent-nil-replay.json','capture-milestone-17-report.json','media/milestone-17-pinned-encoder.webm']:
 members['adopted-source-and-functional-capture/'+n]=job/n
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for n,p in sorted(members.items()):z.writestr(n,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(members)
 for n,p in members.items():assert z.read(n)==p.read_bytes()
summary={'status':'ADOPTED_NARROW_FAILED_OPPONENT_NIL_PROPOSAL_CURRENT_FULL_ORIGINAL_PENDING','parent':parent,'KEEP16':{'seed':577,'ownNumericBid':6,'opponentNumericBid':9,'oldCard':18,'newCard':41,'oldOwnScore':-160,'newOwnScore':-40,'ownGain':120,'opponentGain':0,'marginGain':120,'independentBagAndNilBoundaries':200,'qualified':False,'noGainStreak':0},'guard':'Both teams need at least two numeric contract tricks; last two cards/fourth position; already failed opponent nil contributes. Only public controller information. Default false, Easy, live nil and cutthroat preserve original choices.','finiteProbe':probe,'newFocusedTests':focused,'oldPolicyNegativeControl':load('opponent-nil-old-focused-observation.json'),'unchangedOriginalChurnTwice':churn,'functionalCapture17':capture,'preservedImplementationError':'Initial private-candidate copy retained private relative imports; original strict compiler rejected TS2307. Complete original failure and corrected six-group pass are both preserved. No false focused pass or synthetic old-run physical freeze is claimed.','fullOriginalQualification':'Prior proof-only5dd original whole packet is accepted, but changed-source 48 core tests, original mutation/replay/leagues/browser/native frames and whole genuine official packet remain mandatory and pending. No Ready/Done/current FPS claim.','cadence':'Prior actual source push08:31:13.479797; hard09:01:13.479797 was missed during final evidence assembly/session compaction. Actual new publication closure and lateness recorded separately, never backdated.','archive':{'name':'media/'+archive.name,'members':len(members),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest()}}
name='failed-opponent-nil-audit-20261009.json';(job/name).write_text(json.dumps(summary,indent=2)+'\n')
text=f'''\nKEEP16 narrow failed-opponent-nil proposal adopted for current full verification. Genuine seed577, own numeric6/opponent9, p2+p3nil; at fourth card/final2 both contracts need2. Old duck18 scores own-160; legal trump41 scores-40: own+120, opponent0, margin+120 across all200 independent bag0..9/nil50+100 boundaries. Broad one-sided guard was rejected because it can deny opponent bag penalty. Original legal prefix/full two terminal traces are in failed-opponent-nil-replay.json. Six new focused groups PASS08:47:00.784193 after actual old policy3FAIL/3PASS;400 real hands67100 unaffected comparisons20184 live-opponent-nil observations, hidden-hand and one-trick-deficit controls. Actual private import-copy TS2307 failure is retained separately; corrected production diff is one predicate, using public information. Original churn generator/assertions unchanged, regenerated twice and BYTEIDENTICAL old43f1a188 golden,1003seeds181386events;3436 guards PASS08:56:11.868634. Functional original capture17 PASS08:51:23.313448 with3920 guards; this is not a native timing measurement. Whole raw archive media/{archive.name}: {len(members)} members/{archive.stat().st_size}B/SHA{sha256(archive.read_bytes()).hexdigest()}. Prior5dd whole original accepted08:28:07.780175; current changed-source original full and whole genuine packet PENDING, so gain PROVISIONAL/noGainStreak0/DraftPR16. Original ReadyPR7 unchanged. Actual milestone deadline09:01:13.479797 missed; exact source receipt records real closure/lateness without backdating.\n'''
for doc in ['ASSUMPTIONS.md','AUDIT.md','BOTS.md','LOOP.md','VERIFY.md']:
 p=job/doc;p.write_text(p.read_text()+text)
(job/'NEXT.md').write_text('''# G06 Spades: failed opponent nil saves120; current full checks pending

Protected ReadyPR7/head48430 remains unchanged; DraftPR16 bases canonical
job/G06-spades-core. Current change adds one public-information bot guard
after prior own+120 and partner+180 qualified fixes. KEEP16 seed577 uses
trump41 rather than duck18: own-160 to-40, opponent unchanged, margin+120.
Both teams must need at least2 numeric tricks, opponent nil already failed
and contributes, fourth card/final2. Broad one-sided proposal was rejected.
All200 independent two-team bags0..9/nil50+100 boundaries pass. Six meaningful
new groups pass; old policy fails3. 400 legitimate hands/67100 unaffected
choices/20184 live-opponent-nil observations and hidden-hand controls pass.
Original churn twice is byteexact old43f1a188, capture17 actual functional
only. Import-copy compiler failure and complete raw proofs remain archived.

NEXT: locate exact NEW source-head original G06 workflow, wait its natural
closure, read ENTIRE native log and download the genuine official whole
artifact. Run unchanged original full reader, physical/Git seals and full
VP8 decode for capture17. Expected48core/21focused/25actualmutants/1003full
byte-replays/16kleagues/1800raw/58negative/12capture. No parent-green transfer,
synthetic logs, native timing retries or skipped checks. Gain is PROVISIONAL;
PR16 stays Draft and noGainStreak0 until current original full passes.

After genuine current green, reread original instructions, rank5, fixworst,
measure/log/push KEEP rounds until3 substantive consecutive no-gain rounds.
Protect original ReadyPR7 and all older raw errors/archives. Refresh only
G06 mainCLAIMS with serialized own-row lease after actual source push.
Prior source push08:31:13.479797/hard09:01:13.479797 missed; exact new source
receipt logs actual publication and renews25/30min from observed closure.
''')
subprocess.run(['node','checksums.ts'],cwd=job,check=True,stdout=subprocess.PIPE)
commands=[['npm','run','check'],['node','generate.ts','--check'],['node','fixtures.ts','--check'],['node','build.ts','--check'],['node','checksums.ts','--check']];checks=[]
for args in commands:
 r=subprocess.run(args,cwd=job,capture_output=True,timeout=60);checks.append({'args':args,'exitCode':r.returncode});assert r.returncode==0,(args,r.stderr.decode())
r=subprocess.run(['ffmpeg','-v','error','-i',str(job/'media/milestone-17-pinned-encoder.webm'),'-f','null','-'],capture_output=True,timeout=30);assert r.returncode==0 and not r.stderr
paths=['jobs/G06-spades/'+n for n in ['ASSUMPTIONS.md','AUDIT.md','BOTS.md','LOOP.md','NEXT.md','VERIFY.md','SHA256SUMS.txt','bots.ts','package.json','play.html','bots-before-opponent-nil.ts','capture-milestone-17-report.json','failed-opponent-nil-replay.json','failed-opponent-nil-test.ts','media/milestone-17-pinned-encoder.webm',name,'media/'+archive.name]]+['.github/workflows/G06.yml']
for p in git('ls-tree','-r','--name-only',parent).splitlines():
 if p not in paths:assert(root/p).read_bytes()==subprocess.check_output(['git','-C',str(root),'show',parent+':'+p]),p
subprocess.run(['git','-C',str(root),'add','--',*paths],check=True);assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
subprocess.run(['git','-C',str(root),'diff','--cached','--check'],check=True)
subprocess.run(['git','-C',str(root),'commit','-m','fix G06 failed opponent nil final-trick contract pressure'],check=True,stdout=subprocess.PIPE)
head=git('rev-parse','HEAD');started=utc();r=subprocess.run(['git','-C',str(root),'push','origin','HEAD:refs/heads/'+branch],capture_output=True);closed=utc()
(private/'opponent-nil-gain-source-push.stdout').write_bytes(r.stdout);(private/'opponent-nil-gain-source-push.stderr').write_bytes(r.stderr)
prior=datetime.fromisoformat('2026-10-09T08:31:13.479797+00:00');gap=(closed-prior).total_seconds()
publication={'status':'ACTUAL_OPPONENT_NIL_PROVISIONAL_GAIN_SOURCE_PUSH','parent':parent,'sourceHead':head,'startedAt':started.isoformat(),'naturallyClosedAt':closed.isoformat(),'exitCode':r.returncode,'paths':paths,'originalSmallChecks':checks,'allNonOwnedOriginalBytesUnchanged':True,'fullClipDecodePass':True,'archive':summary['archive'],'intervalSeconds':gap,'hardIntervalPass':gap<=1800,'latenessSeconds':max(0,gap-1800),'nextEarlyDeadline':(closed+timedelta(minutes=25)).isoformat(),'nextHardDeadline':(closed+timedelta(minutes=30)).isoformat()}
(private/'opponent-nil-gain-source-push.json').write_text(json.dumps(publication,indent=2)+'\n');assert r.returncode==0
assert git('ls-remote','origin','refs/heads/'+branch).split()[0]==head and not git('status','--porcelain')
publication.update({'remoteReadbackAt':utc().isoformat(),'remoteHead':head,'trackedClean':True});(private/'opponent-nil-gain-source-push.json').write_text(json.dumps(publication,indent=2)+'\n');print(json.dumps(publication))
