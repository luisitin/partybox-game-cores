import subprocess,hashlib,json,os,sysconfig,shutil,sys,datetime,signal
from pathlib import Path
root=Path('/tmp/core-root-queue-claims-remote-20261009');job=root/'jobs/G06-spades';out=Path('/tmp/G06-root-audit-20261009')
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
git=lambda *a:subprocess.check_output(['git','-C',str(root),*a])
head=git('rev-parse','HEAD').decode().strip();assert head=='255be4cfae5701fed8ed771019be641f51bda08f'
tracked=[root/p for p in git('ls-tree','-r','--name-only',head).decode().splitlines()]
for p in tracked:assert p.read_bytes()==git('show',head+':'+str(p.relative_to(root)))
paths=list(tracked)
for directory in [job/'node_modules',root/'contract/node_modules']:paths.extend(p for p in directory.rglob('*') if p.is_file())
stdlib=Path(sysconfig.get_paths()['stdlib'])
paths.extend(p for p in stdlib.rglob('*.py') if 'site-packages' not in p.parts);paths.extend(p for p in stdlib.rglob('*.so') if 'site-packages' not in p.parts)
paths.extend(Path(m.__file__) for m in list(sys.modules.values()) if getattr(m,'__file__',None) and Path(m.__file__).is_file())
paths.extend([Path(__file__).resolve(),Path(shutil.which('node')).resolve(),Path(sys.executable).resolve(),job/'.work/failed-opponent-nil-two-sided-probe.ts',job/'.work/bots.failed-opponent-nil-two-sided-candidate.ts'])
paths=sorted(set(paths))
def frozen():
 return {str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'resolved':str(p.resolve()),'bytes':p.stat().st_size,'dev':p.stat().st_dev,'ino':p.stat().st_ino} for p in paths}
before=frozen();(out/'opponent-nil-two-sided-probe-input-before.json').write_text(json.dumps(before,indent=2)+'\n')
started=utc();natural=False;stdout=b'';stderr=b''
child=subprocess.Popen(['node',str(job/'.work/failed-opponent-nil-two-sided-probe.ts')],cwd=job,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
try:
 stdout,stderr=child.communicate(timeout=330);natural=True
finally:
 if child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=8)
 (out/'opponent-nil-two-sided-probe.stdout').write_bytes(stdout);(out/'opponent-nil-two-sided-probe.stderr').write_bytes(stderr)
 after=frozen();(out/'opponent-nil-two-sided-probe-input-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
try:os.killpg(child.pid,0);empty=False
except ProcessLookupError:empty=True
r={'status':'ACTUAL_FINITE_UNTIMED_OPPONENT_NIL_PROBE_CLOSED','sourceHead':head,'startedAt':started,'naturallyClosedAt':utc(),'exitCode':child.returncode,'natural':natural,'actualOwnedGroupEmpty':empty,'guardCount':len(before),'allFrozenInputsUnchanged':True,'probeScope':'finite seeded whole legal hands after5dd fullgreen; both team scores/margin200 independent carried-bag boundaries; unadopted proposal/current255 wholepending','controller':str(Path(__file__).resolve())}
(out/'opponent-nil-two-sided-probe-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True);assert child.returncode==0 and natural and empty and not stderr
print(stdout.decode(),flush=True)
