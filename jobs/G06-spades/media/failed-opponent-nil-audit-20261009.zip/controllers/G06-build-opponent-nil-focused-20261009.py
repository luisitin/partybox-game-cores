from pathlib import Path
import json,subprocess
job=Path('/tmp/core-root-queue-claims-remote-20261009/jobs/G06-spades');out=Path('/tmp/G06-root-audit-20261009')
proof=json.loads((out/'failed-opponent-nil-two-sided-probe.json').read_text());assert proof['gain']==120 and len(proof['boundaries'])==200 and all(x['marginGain']==120 for x in proof['boundaries'])
(job/'failed-opponent-nil-replay.json').write_text(json.dumps(proof,indent=2)+'\n')
(job/'bots-before-opponent-nil.ts').write_bytes((job/'bots.ts').read_bytes())
s=(job/'failed-partner-nil-test.ts').read_text()
start=s.index("test('legitimate failed-partner")
header=s[:start].replace('bots-before-partner-nil.ts','bots-before-opponent-nil.ts').replace('failed-partner-nil-replay.json','failed-opponent-nil-replay.json').replace("const bagProof=JSON.parse(readFileSync('failed-partner-nil-rejected-bag-proposal.json','utf8'));\n",'').replace('context(4,674,','context(4,577,')
tests=r'''test('legal failed-opponent-nil endgame wins the missing contract: -160 to -40',()=>{
 const s=prefix(),v=controllerView(s,'p0');assert.deepEqual(v.hand,[18,41]);assert.equal(v.trick.length,3);assert.equal(v.bids.p0!.value,6);assert.equal(v.bids.p1!.value,9);assert(v.won.p3!>0);assert.equal(v.won.p0!+v.won.p2!,4);assert.equal(v.won.p1!+v.won.p3!,7);
 for(const skill of ['normal','sharp'] as const){const a=baseline(v,createRng(731),skill),b=candidate.fromView(v,createRng(731),skill);assert.deepEqual(a,{type:'play',card:18});assert.deepEqual(b,{type:'play',card:41});const x=end(s,a!),y=end(s,b!);assert.equal(x.sides[0]!.score,-160);assert.equal(y.sides[0]!.score,-40);assert.equal(y.sides[0]!.score-x.sides[0]!.score,120);assert.equal(y.sides[1]!.score,x.sides[1]!.score);}
});
test('both nil bonuses and all valid two-team carried-bag boundaries independently preserve the 120-point gain',()=>{
 const old=proof.original.report,newer=proof.counterfactual.report;let count=0;
 for(const bonus of [50,100])for(let ownBag=0;ownBag<10;ownBag++)for(let opponentBag=0;opponentBag<10;opponentBag++){
  const records=[old,newer].map(r=>[0,1].map(side=>{const xs=['p0','p1','p2','p3'].filter((_,i)=>i%2===side).map(id=>({bid:r.bids[id],won:r.won[id]}));const carried=side===0?ownBag:opponentBag;const a=scoreSide(xs,0,carried,bonus,true);assert.deepEqual(a,ledger(xs,0,carried,bonus,true));return a;}));
  assert.equal(records[1]![0]!.score-records[0]![0]!.score,120);assert.equal(records[1]![1]!.score,records[0]![1]!.score);assert.equal((records[1]![0]!.score-records[1]![1]!.score)-(records[0]![0]!.score-records[0]![1]!.score),120);count++;
 }assert.equal(count,200);
 const s=prefix(true,50),v=controllerView(s,'p0'),x=end(s,baseline(v,createRng(731),'normal')!),y=end(s,candidate.fromView(v,createRng(731),'normal')!);assert.equal(y.sides[0]!.score-x.sides[0]!.score,120);
});
test('genuine one-trick opponent contract deficit preserves the original action',()=>{
 const p=structuredClone(proof);for(const e of p.prefix)if(e.type==='input'&&e.playerId==='p1'&&e.input.type==='bid')e.input.value=8;
 let s=init(context(4,577,{blind:false,exchange:false,failedNilCounts:true}));for(const e of p.prefix)s=advance(s,e);
 const v=controllerView(s,'p0');assert.equal(v.bids.p1!.value,8);assert.equal(v.won.p1!+v.won.p3!,7);
 for(const skill of ['easy','normal','sharp'] as const)for(let seed=1;seed<=100;seed++){const a=createRng(seed),b=createRng(seed);assert.deepEqual(candidate.fromView(v,b,skill),baseline(v,a,skill));assert.deepEqual(a.state(),b.state());comparisons++;}
});
test('default failed-nil exclusion and Easy preserve exact legal actions and RNG states',()=>{
 for(const count of [false,true])for(const bonus of [50,100])for(const skill of ['easy','normal','sharp'] as const)for(let seed=1;seed<=100;seed++){if(count&&skill!=='easy')continue;const v=controllerView(prefix(count,bonus),'p0'),a=createRng(seed),b=createRng(seed);assert.deepEqual(candidate.fromView(v,b,skill),baseline(v,a,skill));assert.deepEqual(a.state(),b.state());comparisons++;}
});
test('finite genuine first hands preserve unaffected choices, live nil and cutthroat',()=>{
 let liveNil=0,changed=0;
 for(const n of [3,4])for(const count of [false,true])for(let seed=1;seed<=100;seed++){
  let s=init(context(n,seed,{blind:false,exchange:false,failedNilCounts:count}));
  for(let step=0;s.phase.id!=='hand'&&step<150;step++){
   if(s.phase.id==='trick'){s=advance(s,{type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!});continue;}
   const id=s.seats[s.turn]!,v=controllerView(s,id);
   for(const skill of ['easy','normal','sharp'] as const){const a=createRng(seed),b=createRng(seed),x=baseline(v,a,skill),y=candidate.fromView(v,b,skill);
    if(JSON.stringify(x)!==JSON.stringify(y)){changed++;assert.equal(n,4);assert(count);assert.notEqual(skill,'easy');assert.equal(v.inputType,'play');assert.equal(v.hand.length,2);assert.equal(v.trick.length,3);}
    else{assert.deepEqual(y,x);assert.deepEqual(a.state(),b.state());comparisons++;}
    if(v.inputType==='play')for(const other of s.seats.filter(p=>p!==id&&p!==v.partner))if(v.bids[other]?.kind!=='number'&&v.won[other]===0)liveNil++;
   }
   let input=baseline(v,createRng(seed),'normal')!;if(s.phase.id==='bid'&&id===(n===4?'p3':'p0'))input={type:'nil'};s=advance(s,{type:'input',playerId:id,input,now:s.phase.startedAt+1});
  }assert.equal(s.phase.id,'hand');
 }assert(liveNil>0);console.log(JSON.stringify({scope:'400 genuine first hands/unaffected actions and live opponent nil',comparisons,liveNil,changed}));
});
test('hidden-hand permutations preserve the public projection and winning legal action',()=>{
 const s=prefix(),v=controllerView(s,'p0');for(const [a,b] of [['p1','p2'],['p1','p3'],['p2','p3']] as const){const h=structuredClone(s),x=h.hands[a]![0]!,y=h.hands[b]![0]!;h.hands[a]![0]=y;h.hands[b]![0]=x;stateSchema.parse(h);conservation(h);assert.deepEqual(controllerView(h,'p0'),v);for(const skill of ['normal','sharp'] as const)assert.deepEqual(candidate.fromView(controllerView(h,'p0'),createRng(731),skill),{type:'play',card:41});}
});
'''
(job/'failed-opponent-nil-test.ts').write_text(header+tests)
print('Six meaningful public groups prepared; runtime baseline unchanged until actual negative run.')
