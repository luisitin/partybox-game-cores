from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess,sys,sysconfig,shutil,os,signal
root=Path('/tmp/core-root-queue-claims-remote-20261009');job=root/'jobs/G06-spades';out=Path('/tmp/G06-root-audit-20261009')
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()=='255be4cfae5701fed8ed771019be641f51bda08f'
paths=[root/x for x in subprocess.check_output(['git','-C',str(root),'ls-tree','-r','--name-only','HEAD']).decode().splitlines()]
paths.extend([job/'failed-opponent-nil-test.ts',job/'failed-opponent-nil-replay.json',job/'bots-before-opponent-nil.ts',Path(__file__).resolve(),Path(sys.executable).resolve(),Path(shutil.which('node')).resolve()])
for folder in [job/'node_modules',root/'contract/node_modules']:paths.extend(p for p in folder.rglob('*') if p.is_file())
stdlib=Path(sysconfig.get_paths()['stdlib']);paths.extend(p for p in stdlib.rglob('*.py') if 'site-packages' not in p.parts);paths.extend(p for p in stdlib.rglob('*.so') if 'site-packages' not in p.parts)
paths=sorted(set(paths))
def freeze():return {str(p):{'sha256':sha256(p.read_bytes()).hexdigest(),'resolved':str(p.resolve()),'bytes':p.stat().st_size,'dev':p.stat().st_dev,'ino':p.stat().st_ino} for p in paths}
before=freeze();(out/'opponent-nil-corrected-new-focused-before.json').write_text(json.dumps(before,indent=2)+'\n');started=datetime.now(timezone.utc).isoformat();steps=[]
try:
 for name,args in [('strict',['npm','run','check']),('six-focused',['node','--test','failed-opponent-nil-test.ts'])]:
  child=subprocess.Popen(args,cwd=job,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);stdout,stderr=child.communicate(timeout=75)
  (out/('opponent-nil-corrected-new-'+name+'.stdout')).write_bytes(stdout);(out/('opponent-nil-corrected-new-'+name+'.stderr')).write_bytes(stderr)
  try:os.killpg(child.pid,0);empty=False
  except ProcessLookupError:empty=True
  steps.append({'name':name,'exitCode':child.returncode,'naturallyClosedAt':datetime.now(timezone.utc).isoformat(),'actualOwnedGroupEmpty':empty});assert child.returncode==0 and empty,(name,stderr.decode(),stdout.decode())
finally:
 after=freeze();(out/'opponent-nil-corrected-new-focused-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
receipt={'status':'ACTUAL_SIX_CORRECTED_FOCUSED_OPPONENT_NIL_GROUPS_PASS','startedAt':started,'naturallyClosedAt':datetime.now(timezone.utc).isoformat(),'guardCount':len(before),'allWorkingSourceInputsUnchanged':True,'steps':steps,'scope':'Actual modified working proposal, exact tracked parent255; genuine prefix/counterfactual200two-team scores,400 firsthands/unaffected/liveNil/privacy controls. No current fullCI qualification claim.'}
(out/'opponent-nil-corrected-new-focused-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
