import json,sys,pathlib,termios,subprocess,hashlib,datetime
fd=sys.stdin.fileno();settings=termios.tcgetattr(fd);settings[3]&=~termios.ECHO;termios.tcsetattr(fd,termios.TCSANOW,settings)
print('PRIVATE_STDIN_READY',flush=True)
d=json.loads(sys.stdin.readline());base=pathlib.Path('/tmp/G06-failed-official-5f5-20261009');base.mkdir(exist_ok=False)
u=d['download_url'];assert u.startswith('https://') and '\n' not in u and '\r' not in u
config='url = "'+u.replace('\\','\\\\').replace('"','\\"')+'"\n'
f=base/'actual.zip'
r=subprocess.run(['curl','--config','-','--fail','--silent','--show-error','--location','--retry','0','--connect-timeout','15','--max-time','60','--output',str(f)],input=config.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(base/'curl.stderr').write_bytes(r.stderr)
assert r.returncode==0,'Download failed; stderr private'
b=f.read_bytes();assert len(b)==90497;assert hashlib.sha256(b).hexdigest()=='bccea8700a4d17b4f716289517d2258626205c8490f45d81946e1c36c5388ee3'
receipt={'status':'ACTUAL_OFFICIAL_ZIP_SHA256_VERIFIED','closedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'artifactId':11597503170,'runId':37889847743,'jobId':113688060789,'sourceHead':'5f5c80df93ea20df3befca5a0140b460348dbef5'}
(base/'download-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
