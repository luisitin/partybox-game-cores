import subprocess,hashlib,json,os,sysconfig,shutil,sys,datetime,signal
from pathlib import Path
root=Path('/tmp/core-root-queue-claims-remote-20261009');job=root/'jobs/G06-spades';out=Path('/tmp/G06-root-audit-20261009')
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
git=lambda *a:subprocess.check_output(['git','-C',str(root),*a])
head=git('rev-parse','HEAD').decode().strip();assert head=='5f5c80df93ea20df3befca5a0140b460348dbef5'
tracked=[root/p for p in git('ls-tree','-r','--name-only',head).decode().splitlines()]
for p in tracked:assert p.read_bytes()==git('show',head+':'+str(p.relative_to(root)))
native=json.loads((out/'current5f5-failed-full-native.json').read_text())['native'];(out/'current5f5-failed-full-native.log').write_text(native)
assert len(native)==50960 and 'ℹ tests 36' in native and 'ℹ pass 36' in native and native.count('ℹ fail 0')==1
assert '25/25 genuine assertion kills; baseline 28/28' in native and native.count('/25 killed:')==25
assert 'churn.ts:58:120' in native and 'G06_COMPLETE_REPORT ' not in native and '8000 full 500-point/mercy matches complete' not in native
baseline=(job/'churn-results.json').read_bytes();(out/'churn-original-before-failed-nil.json').write_bytes(baseline)
expected=json.loads(baseline);expected['counts'].update({'input':44055,'drop':12244,'reconnect':9622,'kicked':3243,'left':5423,'skip':42618})
paths=[p for p in tracked if p!=job/'churn-results.json']
for directory in [job/'node_modules',root/'contract/node_modules']:paths.extend(p for p in directory.rglob('*') if p.is_file())
stdlib=Path(sysconfig.get_paths()['stdlib'])
paths.extend(p for p in stdlib.rglob('*.py') if 'site-packages' not in p.parts);paths.extend(p for p in stdlib.rglob('*.so') if 'site-packages' not in p.parts)
paths.extend(Path(m.__file__) for m in list(sys.modules.values()) if getattr(m,'__file__',None) and Path(m.__file__).is_file())
paths.extend([Path(__file__).resolve(),Path(shutil.which('node')).resolve(),Path(sys.executable).resolve(),out/'current5f5-failed-full-native.json',out/'current5f5-failed-full-native.log',out/'churn-original-before-failed-nil.json'])
paths=sorted(set(paths))
def frozen():
 return {str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'resolved':str(p.resolve()),'bytes':p.stat().st_size,'dev':p.stat().st_dev,'ino':p.stat().st_ino} for p in paths}
before=frozen();(out/'churn-failed-nil-regeneration-before.json').write_text(json.dumps(before,indent=2)+'\n')
started=utc();steps=[];first=None
try:
 for i in [1,2]:
  start=utc();child=subprocess.Popen(['node','churn.ts','--write'],cwd=job,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);natural=False
  try:
   stdout,stderr=child.communicate(timeout=80);natural=True
  finally:
   if child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=8)
  closed=utc();(out/f'churn-regeneration-{i}.stdout').write_bytes(stdout);(out/f'churn-regeneration-{i}.stderr').write_bytes(stderr)
  try:os.killpg(child.pid,0);empty=False
  except ProcessLookupError:empty=True
  r={'index':i,'startedAt':start,'naturallyClosedAt':closed,'exitCode':child.returncode,'natural':natural,'actualOwnedGroupEmpty':empty};steps.append(r);print(json.dumps(r),flush=True)
  assert child.returncode==0 and natural and empty and not stderr
  actual=(job/'churn-results.json').read_bytes();(out/f'churn-regeneration-{i}.json').write_bytes(actual)
  assert json.loads(actual)==expected
  if first is None:first=actual
  else:assert actual==first,'original regeneration must be byte-identical twice'
finally:
 after=frozen();(out/'churn-failed-nil-regeneration-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
receipt={'status':'ACTUAL_ORIGINAL_CHURN_REGENERATED_TWICE','parentHead':head,'startedAt':started,'naturallyClosedAt':utc(),'steps':steps,'fullGuardCount':len(before),'allImmutableGuardsUnchanged':True,'onlyMutableOutput':'jobs/G06-spades/churn-results.json','oldSha256':hashlib.sha256(baseline).hexdigest(),'newSha256':hashlib.sha256(first).hexdigest(),'byteIdenticalOriginalRegeneration':True,'newReport':expected,'actualFailedNativeCharacters':len(native),'nativeFullLogSha256':hashlib.sha256(native.encode()).hexdigest(),'scope':'original1003-seed generator with every original invariant/privacy/byte-replay assertion unchanged; current failedNilCounts=true strategic policy changes a few real events, so regenerate golden data, never relax the comparison; no browser, frame or clock invocation'}
(out/'churn-failed-nil-regeneration-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)

