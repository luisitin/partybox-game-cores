import subprocess,hashlib,json,os,sysconfig,sys,shutil,signal
from pathlib import Path
from datetime import datetime,timezone
root=Path('/tmp/core-root-queue-claims-remote-20261009');job=root/'jobs/G06-spades';out=Path('/tmp/G06-root-audit-20261009')
assert not (job/'capture-milestone-15-report.json').exists() and not (job/'media/milestone-15-pinned-encoder.webm').exists()
git=lambda *a:subprocess.check_output(['git','-C',str(root),*a])
assert git('rev-parse','HEAD').decode().strip()=='5f5c80df93ea20df3befca5a0140b460348dbef5'
paths=[root/p for p in git('ls-tree','-r','--name-only','HEAD').decode().splitlines()]
paths += [job/'bots-before-failed-nil.ts',job/'failed-nil-test.ts',job/'failed-nil-replay.json',Path(__file__).resolve(),Path(shutil.which('node')).resolve(),Path(sys.executable).resolve()]
for directory in [job/'node_modules',root/'contract/node_modules',Path('/home/agent/.cache/ms-playwright/chromium-1194'),Path('/home/agent/.cache/ms-playwright/chromium_headless_shell-1194'),Path('/home/agent/.cache/ms-playwright/ffmpeg-1011')]:
 assert directory.exists(),str(directory);paths.extend(p for p in directory.rglob('*') if p.is_file())
stdlib=Path(sysconfig.get_paths()['stdlib']);paths.extend(p for p in stdlib.rglob('*.py') if 'site-packages' not in p.parts);paths.extend(p for p in stdlib.rglob('*.so') if 'site-packages' not in p.parts)
paths.extend(Path(m.__file__) for m in list(sys.modules.values()) if getattr(m,'__file__',None) and Path(m.__file__).is_file())
paths=sorted(set(paths))
def frozen():return {str(p):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'resolved':str(p.resolve()),'bytes':p.stat().st_size,'dev':p.stat().st_dev,'ino':p.stat().st_ino} for p in paths}
before=frozen();(out/'capture15-source-before.json').write_text(json.dumps(before,indent=2)+'\n');started=datetime.now(timezone.utc).isoformat();child=None
try:
 child=subprocess.Popen(['node','capture.ts','--milestone=15'],cwd=job,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 stdout,stderr=child.communicate(timeout=120)
 (out/'capture15.stdout').write_bytes(stdout);(out/'capture15.stderr').write_bytes(stderr)
finally:
 if child and child.poll() is None:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=8)
 after=frozen();(out/'capture15-source-after.json').write_text(json.dumps(after,indent=2)+'\n');assert before==after
receipt={'status':'ACTUAL_CAPTURE15_CLOSED','parentHead':'5f5c80df93ea20df3befca5a0140b460348dbef5','startedAt':started,'naturallyClosedAt':datetime.now(timezone.utc).isoformat(),'exitCode':child.returncode,'allFrozenInputCount':len(before),'allGuardsUnchanged':True,'scope':'original actual-file clock-controlled functional capture only; no native frames/FPS gain','controllerSha256':before[str(Path(__file__).resolve())]['sha256']}
(out/'capture15-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print(stdout.decode());assert child.returncode==0
