import assert from 'node:assert/strict';
import {writeFileSync,existsSync} from 'node:fs';
import {init,reduce,controllerView,sideOf,type State,type Input} from '../core.ts';
import {fromView as baseline} from '../bots-before-opponent-nil.ts';
import {fromView as candidate} from '../bots.ts';
import {context,conservation} from '../runner.ts';
import {winningPlay} from '../cards.ts';
import {stateSchema} from '../data-schema.ts';
import {ledger} from '../reference.ts';
import {scoreSide} from '../scoring.ts';
import {createRng} from '../../../contract/rng.ts';
const output='/tmp/G06-root-audit-20261009/failed-opponent-nil-high-contract-expanded-probe.json';
assert(!existsSync(output));
let hands=0,events=0,eligible=0;
function checked(s:State,event:any):State{
 const before=JSON.stringify(s),n=reduce(s,event);assert.equal(JSON.stringify(s),before);assert.notEqual(n,s);
 assert.deepEqual(n,reduce(JSON.parse(before),event));stateSchema.parse(n);conservation(n);events++;return n;
}
function action(s:State):{playerId:string;input:Input}{
 const id=s.seats[s.turn]!,rng=createRng(731),input=baseline(controllerView(s,id),rng,'normal');
 assert.equal(rng.state().step,0);assert(input);return {playerId:id,input};
}
function roll(start:State,first:Input){
 let s=checked(start,{type:'input',playerId:'p0',input:first,now:start.phase.startedAt+1});
 const trace:any[]=[{type:'input',playerId:'p0',input:first,now:start.phase.startedAt+1}];
 for(let step=0;s.phase.id!=='hand'&&step<30;step++){
  const event=s.phase.id==='trick'?{type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!}:{type:'input',...action(s),now:s.phase.startedAt+1};
  trace.push(event);s=checked(s,event);
 }
 assert.equal(s.phase.id,'hand');assert(s.report);
 for(let side=0;side<2;side++)assert.deepEqual(s.report.sides[side],ledger(s.seats.filter(id=>sideOf(s,id)===side).map(id=>({bid:s.bids[id]!,won:s.won[id]!})),0,0,s.settings.nilValue,s.settings.failedNilCounts));
 return {report:s.report,trace};
}
let found=false;
outer:for(let seed=1001;seed<=10000;seed++)for(let ownBid=13;ownBid<=13;ownBid++){
 let s=init(context(4,seed,{blind:false,exchange:false,failedNilCounts:true}));
 stateSchema.parse(s);conservation(s);const prefix:any[]=[];hands++;
 for(let step=0;s.phase.id!=='hand'&&step<150;step++){
  if(s.phase.id==='play'&&s.seats[s.turn]==='p0'&&s.won.p3!>0&&s.trick.length===3&&s.hands.p0!.length===2&&winningPlay(s.trick)?.playerId==='p3'){
   const v=controllerView(s,'p0'),a=baseline(v,createRng(731),'normal'),b=candidate(v,createRng(731),'normal');assert(a&&b);
   if(JSON.stringify(a)!==JSON.stringify(b)){
    eligible++;const old=roll(s,a),counterfactual=roll(s,b),side=sideOf(s,'p0'),other=1-side,ownGain=counterfactual.report.sides[side]!.score-old.report.sides[side]!.score,opponentGain=counterfactual.report.sides[other]!.score-old.report.sides[other]!.score,gain=ownGain-opponentGain;
    const boundaries:any[]=[];
    for(const nilValue of [50,100])for(let ownBag=0;ownBag<10;ownBag++)for(let opponentBag=0;opponentBag<10;opponentBag++){
     const scores:any[]=[];
     for(const report of [old.report,counterfactual.report]){
      const scored=[side,other].map((team,i)=>{const xs=s.seats.filter(id=>sideOf(s,id)===team).map(id=>({bid:report.bids[id]!,won:report.won[id]!})),bags=i===0?ownBag:opponentBag;const production=scoreSide(xs,0,bags,nilValue,true);assert.deepEqual(production,ledger(xs,0,bags,nilValue,true));return production;});scores.push(scored);
     }
     const marginGain=(scores[1][0].score-scores[1][1].score)-(scores[0][0].score-scores[0][1].score);
     boundaries.push({nilValue,ownBag,opponentBag,original:scores[0],counterfactual:scores[1],marginGain});
    }
    if(gain<0||boundaries.some(x=>x.marginGain<0)){

     writeFileSync(output,JSON.stringify({status:'VALID_LEGAL_FAILED_OPPONENT_NIL_NEGATIVE_COUNTERFACTUAL',scope:'finite untimed legitimate full seeded hand, one legal decision, all continuations use unchanged baseline; no adopted policy or universal-strength claim',seed,ownBid,hands,events,eligible,initialContext:context(4,seed,{blind:false,exchange:false,failedNilCounts:true}),prefix,state:s,publicOwnView:v,originalChoice:a,legalCandidateChoice:b,original:old,counterfactual,side,other,ownGain,opponentGain,gain,boundaries},null,2)+'\n');
     console.log(JSON.stringify({status:'VALID_LEGAL_FAILED_OPPONENT_NIL_NEGATIVE_COUNTERFACTUAL',seed,ownBid,hands,events,eligible,baseline:a,candidate:b,oldScore:old.report.sides[side]!.score,newScore:counterfactual.report.sides[side]!.score,ownGain,opponentGain,marginGain:gain,validIndependentBoundaries:boundaries.length}));found=true;break outer;
    }
   }
  }
  let event:any;
  if(s.phase.id==='trick')event={type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!};
  else{const a=action(s);if(s.phase.id==='bid'&&a.playerId==='p0')a.input={type:'bid',value:ownBid};else if(s.phase.id==='bid'&&a.playerId==='p1')a.input={type:'bid',value:13};else if(s.phase.id==='bid'&&(a.playerId==='p2'||a.playerId==='p3'))a.input={type:'nil'};event={type:'input',...a,now:s.phase.startedAt+1};}
  prefix.push(event);s=checked(s,event);
 }
 assert.equal(s.phase.id,'hand');
}
if(!found){writeFileSync(output,JSON.stringify({status:'NO_NEGATIVE_GAIN_IN_FINITE_OPPONENT_NIL_PROBE',hands,events,eligible,seeds:[1001,10000],ownBids:[2,13],scope:'two-sided finite legitimate histories and200 independent score/bag boundaries per actual changed decision, not exhaustive or formal until full review'})+'\n');console.log(JSON.stringify({status:'NO_NEGATIVE_GAIN_IN_FINITE_OPPONENT_NIL_PROBE',hands,events,eligible}));}
