import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {init,reduce,controllerView,sideOf,type State,type Input} from '../core.ts';
import {fromView as baseline} from '../bots-before-opponent-nil.ts';
import {fromView as current} from '../bots.ts';
import {context,conservation} from '../runner.ts';
import {stateSchema} from '../data-schema.ts';
import {scoreSide} from '../scoring.ts';
import {ledger} from '../reference.ts';
import {createRng} from '../../../contract/rng.ts';
const proof=JSON.parse(readFileSync('failed-opponent-nil-replay.json','utf8'));
const output='/tmp/G06-root-audit-20261009/blind-nil-counterpart-review.json';assert(!existsSync(output));
let events=0,prelook=0,exchanges=0,boundaries=0;const records:any[]=[];
function checked(s:State,e:any){const b=JSON.stringify(s),n=reduce(s,e);assert.notEqual(n,s);assert.equal(JSON.stringify(s),b);assert.deepEqual(n,reduce(JSON.parse(b),e));stateSchema.parse(n);conservation(n);events++;return n;}
function finish(start:State,first:Input){let s=start;const trace:any[]=[];for(let k=0;s.phase.id!=='hand'&&k<30;k++){const id=s.seats[s.turn]!,e=s.phase.id==='trick'?{type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!}:{type:'input',playerId:id,input:k===0?first:baseline(controllerView(s,id),createRng(731),'normal')!,now:s.phase.startedAt+1};trace.push(e);s=checked(s,e);}assert.equal(s.phase.id,'hand');assert(s.report);for(let side=0;side<2;side++)assert.deepEqual(s.report.sides[side],ledger(s.seats.filter(id=>sideOf(s,id)===side).map(id=>({bid:s.bids[id]!,won:s.won[id]!})),0,0,s.settings.nilValue,true));return {report:s.report,trace};}
for(const ownBlind of [false,true])for(const opponentBlind of [false,true])for(const exchange of [false,true])for(const nilValue of [50,100]){
 const ctx=context(4,577,{blind:true,blindGap:0,exchange,failedNilCounts:true,nilValue});let s=init(ctx);stateSchema.parse(s);conservation(s);const prefix:any[]=[];const returns=new Map<string,number[]>();
 const advance=(e:any)=>{prefix.push(e);s=checked(s,e);};
 const flushExchange=()=>{while(s.phase.id==='exchange'){const r=s.exchangePlan[s.exchangeStep]!,remembered=returns.get(r.from),cards=remembered??s.hands[r.from]!.slice(0,2);if(!remembered)returns.set(r.to,[...cards]);assert(cards.every(c=>s.hands[r.from]!.includes(c)));advance({type:'input',playerId:r.from,input:{type:'exchange',cards},now:s.phase.startedAt+1});exchanges++;}};
 for(const original of proof.prefix){flushExchange();if(s.phase.id==='blind'){
   assert.equal(original.type,'input');assert.equal(s.seats[s.turn],original.playerId);const id=original.playerId,v=controllerView(s,id);assert.deepEqual(v.hand,[]);assert.deepEqual(v.legal,[]);assert(!s.looked.includes(id));assert(v.blindEligible);prelook++;
   if(original.input.type==='nil'&&((id==='p2'&&ownBlind)||(id==='p3'&&opponentBlind))){advance({type:'input',playerId:id,input:{type:'blind-nil'},now:s.phase.startedAt+1});continue;}
   advance({type:'input',playerId:id,input:{type:'look'},now:s.phase.startedAt+1});
  }
  const e=original.type==='timer'?{type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline!}:{...original,now:s.phase.startedAt+1};advance(e);
 }
 flushExchange();assert.equal(s.phase.id,'play');assert.equal(s.seats[s.turn],'p0');assert.deepEqual(s.hands,proof.state.hands);assert.deepEqual(s.won,proof.state.won);assert.equal(s.trick.length,3);assert.equal(s.bids.p2!.kind,ownBlind?'blind':'nil');assert.equal(s.bids.p3!.kind,opponentBlind?'blind':'nil');assert.equal(s.won.p2,0);assert(s.won.p3!>0);
 const v=controllerView(s,'p0');assert.deepEqual(v.hand,[18,41]);const decisions:any[]=[];
 for(const skill of ['normal','sharp'] as const){const a=createRng(731),b=createRng(731),old=baseline(v,a,skill),next=current(v,b,skill);assert.deepEqual(old,{type:'play',card:18});assert.deepEqual(next,{type:'play',card:41});assert.deepEqual(a.state(),b.state());const x=finish(s,old!),y=finish(s,next!);assert.equal(y.report.sides[0]!.score-x.report.sides[0]!.score,120);assert.equal(y.report.sides[1]!.score,x.report.sides[1]!.score);
  const pairs:any[]=[];for(let ownBag=0;ownBag<10;ownBag++)for(let opponentBag=0;opponentBag<10;opponentBag++){const scored=[x.report,y.report].map(r=>[0,1].map(side=>{const seats=s.seats.filter(id=>sideOf(s,id)===side).map(id=>({bid:r.bids[id],won:r.won[id]})),bags=side===0?ownBag:opponentBag,p=scoreSide(seats,0,bags,nilValue,true);assert.deepEqual(p,ledger(seats,0,bags,nilValue,true));return p;}));assert.equal(scored[1]![0]!.score-scored[0]![0]!.score,120);assert.equal(scored[1]![1]!.score,scored[0]![1]!.score);pairs.push({ownBag,opponentBag,original:scored[0],current:scored[1],marginGain:120});boundaries++;}decisions.push({skill,original:x,current:y,independentBoundaries:pairs});
 }records.push({ownBlind,opponentBlind,exchange,nilValue,initialContext:ctx,prefix,preDecision:s,decisions});
}
assert.equal(records.length,16);assert.equal(prelook,64);assert.equal(exchanges,16);assert.equal(boundaries,3200);
writeFileSync(output,JSON.stringify({status:'ACTUAL_GENUINE_BLIND_NIL_COUNTERPART_REVIEW_PASS',scope:'16 genuine pre-look/optional legal two-card exchanges/full original seeded prefix/two exact continuations, own/opponent nil and blind combinations, both bonuses/3200 independent two-team bags; unchanged bot policy/no new player gain/no timing',events,prelook,exchanges,boundaries,records},null,2)+'\n');console.log(JSON.stringify({status:'ACTUAL_GENUINE_BLIND_NIL_COUNTERPART_REVIEW_PASS',cases:records.length,events,prelook,exchanges,boundaries}));
