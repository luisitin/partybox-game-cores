from pathlib import Path
from datetime import datetime,timezone
import json,termios,sys,subprocess,hashlib
base=Path('/tmp/G06-current-official-396-20261009')
with open('/dev/tty','r') as channel:
    attrs=termios.tcgetattr(channel.fileno());attrs[3]&=~termios.ECHO;termios.tcsetattr(channel.fileno(),termios.TCSANOW,attrs)
    print('PRIVATE_STDIN_READY',flush=True)
    record=json.loads(channel.readline())
url=record['url'];assert url.startswith('https://') and '\n' not in url and '"' not in url
started=datetime.now(timezone.utc).isoformat()
result=subprocess.run(['curl','--config','-','--fail','--silent','--show-error','--connect-timeout','15','--max-time','60','--retry','0','--output',str(base/'actual.zip'),'--write-out','%{http_code}'],input=('url = "'+url+'"\n').encode(),capture_output=True,timeout=70)
(base/'download.stdout').write_bytes(result.stdout);(base/'download.stderr').write_bytes(result.stderr)
assert result.returncode==0 and result.stdout==b'200',(result.returncode,result.stdout)
raw=(base/'actual.zip').read_bytes();metadata=json.loads((base/'actual-github-artifact-metadata.json').read_text())
assert len(raw)==metadata['zipBytes'] and hashlib.sha256(raw).hexdigest()==metadata['zipSha256']
receipt={'status':'ACTUAL_GITHUB_WHOLE_DOWNLOAD_PASS','startedAt':started,'naturallyClosedAt':datetime.now(timezone.utc).isoformat(),'exitCode':result.returncode,'HTTP':200,'zipBytes':len(raw),'zipSha256':hashlib.sha256(raw).hexdigest(),'sourceHead':metadata['sourceHead']}
(base/'actual-download-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
