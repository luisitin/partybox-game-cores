# Assumptions

- Chat nickname codex-domino; main G04 claim uses actual UTC.
- G01 final949c2e3 passed full CI37715456734 and its three no-gain rounds
  are complete. Preserve its open PR and other workers' G02/G03 claims.
- Eight sample realm families follow the content-packs queue; this core does
  not build real packs or invent a shared-engine content ABI.
- Samples must say they describe a fictional workshop universe.
- Bots may consume only public projections,their own input and public past
  reveals; they must never read the live answer or authorship flags.
- Physical-phone evidence is unavailable; use Chromium390x844/4xCPU and
  label it accurately. Managed file navigation is administrator-blocked;
  use exact standalone bytes via setContent and report that limit.
- Shared contract and G08 owner's Shake Up assets are preserved.
- Stage only G04 and its workflow; local G01 dependency caches remain outside
  this branch's tracked files. No source/API block currently prevents G04.

- BCE/CE and decade conventions are from knowledge, unverified externally;
  they are explicit house rules, not an uninspected source claim.
- Local hot-seat concealment protects the screen, not developer tools.
  Correct-writer handovers visit every human to avoid identity inference.

- Injected bluff truths must remain nonempty after the same Unicode/control
  normalization used for submissions;invisible choices are invalid content.

## Strict re-claim, 2026-10-08

Current owner codex-reality claimed11:00:12UTC after fresh main/branch checks
proved G04 was the lowest eligible job, with both old branches beyond6h.
Created local job/G04-reality-check-core from claimed main, then normally
merged original152e5a history to preserve PR4; no force/duplicate PR.
Earlier gameplay/three no-gain rounds remain accepted unchanged. This
follow-up corrects a real missing MIT runtime notice and tests actual disk
navigation in the current environment. The earlier administrator file://
restriction is historical; it is not assumed to apply to this environment.
Pure core/bot/UI/data behavior is preserved. Only builder/license documentation
and verification transport/evidence change; no new local core league/matrix
rerun is warranted. Hosted npm test still runs the complete suite.
Original reports/clips are preserved; fresh recordings use milestone11 names.

Cadence exception, observed not authorized: initial claim11:00:12 to first
successful push11:31:26 took31m14s (74s beyond30min). Current NEXT gives
actual previous push and both early/hard next deadlines. No retroactive claim
time adjustment; future milestones keep a five-minute buffer.

Deadline fairness belongs to the offline host: keep the pure timer-only
reducer unchanged, deliver its matching due timer before an expired input,
and discard that input instead of forwarding it into the new phase. Check
bot expiry before sampling; dispatch checks again if computation crosses
the deadline. Controlled wallclock jumps prove ordering, not race frequency.

The observed second30-minute checkpoint miss is retained; no retroactive
claim adjustment or passing cadence assertion. Full CI JSON logging and
artifact retention are round11 evidence wrap-up, with no player gain or
additional KEEP streak count. Unexplained local frame failures remain public.

Round14 compiled host comparator mutation is verification-only. The test temporarily mutates only its own job UI/page, reconstructs the archived6-case runner with private guard/report paths, preserves both actual outcomes, and restores exact source buffers in finally. It supplements the25 independent pure-core mutants. Local speed variance and physical-phone approximation remain unresolved; no FPS or gameplay improvement is claimed.

## Recovery claim and verifier repair, 2026-10-08

Owner codex-reality-reverify legally claimed at20:20:15Z after fresh main
and all18 branch dates; normal merge preserves canonical PR4 history.
The environment interrupted work around20:31–20:40Z. The paused-before-READY
setup uses the real game Pause and Resume controls; it never installs a
virtual clock, changes a native timing API, freezes the sampler clock,
filters raw frames, changes a bot policy or extends the production deadline.
The extra600-interval profile is stronger evidence; original six300-interval
profiles remain valid scoped evidence and are still required by npm test.
Installed Zod/Playwright source guards refer to loaded public dependencies,
not committed node_modules. Shared contract and every production game byte
remain unchanged; no new player gain or additional KEEP round is claimed.

The genuine Playwright encoder does not provide image2pipe; the local cache
registry entry was already a symlink to the system FFmpeg before this job.
No shared cache was changed. Full actual system decoding is therefore an
explicit CI tool installation, with actual path/version/hash recorded.
The sampler, native APIs, game, data, bot, UI and original mean/p95 gates
remain unchanged. Differences in actual Node/decoder binaries across local
and hosted environments are scoped honestly. An actual isolated install
reproduced the old hosted package formatting exactly; --no-save preserves
the original shared package. All public source/artifact archives are public
code/data/evidence only, with bundled source licences retained.

## 2026-10-09 independent contract audit

Fresh main65ec rules/claims and all21 refs/20 job committer dates made G04 the
lowest eligible job at03:28:15Z; both G04 branches and the claim were older6h.
Main7ae claim push naturally CLOSED03:28:24Z, all other rows unchanged. Audit
branch starts from claimed main and normally merges canonical c81 without force.
The noCards declaration conflicts with160 English prompts under the shared
contract; omission, not false, is schema-valid and preserves default English.
This fixes metadata semantics only; full SDK picker integration was not executed
and no player-visible/FPS gain is claimed. Reducer/view/bots/UI/fixtures unchanged.
Original gameplay KEEP12–14 remain historical; no invented numbered improvement.
Original negative-control child failed exactly true-versus-undefined. The outer
helper expected TAP but Node emitted spec, so its classifier EXIT1 stays public.
A distinct finite reader accepted that original output without rerunning the test.
Fresh c81 official proof is a historical baseline and cannot accept new source.
All four original source mechanisms were reread live; uppercase first README404
resolved from the actual pinned directory to readme.md. No external assets/code.
BCE/CE/decade conventions remain from knowledge, unverified externally.
Full current hosted npmtest/artifact proof is still required before audit Ready.

## 2026-10-09 Unicode normalization follow-up

The latest queue instruction permits claiming a finished stale job. Fresh
main/all matching G04 committers establish G04 as lowest eligible at10:32;
the new follow-up preserves existing Ready PR14/source and earlier stop.
Socket length and stored length use the existing JS/Zod UTF-16-unit model.
A genuine NFKC expansion counterexample exceeds both its stated160-unit
fake bound and256KiB state contract. Refuse expanded oversize text rather
than silently truncate it or lock a failed submission. Normal eligible
Unicode answers, normalization equivalence and later retries are preserved.
The raw before and two genuine old failures are not synthesized or retried.
All local checks are untimed/pure/build/refusal controls; local FAST_TEST
does not replace the binding full workflow. No native/frame/picker gain is
claimed. The original three-no-gain gameplay stop remains historical, while
new player-change qualification awaits current full evidence and KEEP.
The fixed pipeline's2987 rows do not separately enumerate old installed
Zod; the unchanged1106 original full source/Zod/runtime/helper supplement
covers that earlier guard set across both actual controls. No overclaim of
an unrecorded per-phase dependency path or exact instantaneous RSS is made.
