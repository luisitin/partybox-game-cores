import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {makeSamples,catalogSchema} from '/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/samples.ts';
const old=await import(pathToFileURL('/workspace/game-cores-G04-audit-20261009/jobs/G04-reality-check/core.ts'));
const fixed=await import(pathToFileURL('/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/core.ts'));
const base=process.argv[2],rows=[],cases=[
 {id:'Arabic compatibility expansion162',text:'\ufdfa'.repeat(9),shouldFit:false},
 {id:'Latin compatibility expansion162',text:'\ufb03'.repeat(54),shouldFit:false},
 {id:'exact160 compatibility boundary',text:'\ufdfa'.repeat(8)+'x'.repeat(16),shouldFit:true},
 {id:'fullwidth exact160',text:'Ａ'.repeat(160),shouldFit:true},
 {id:'casefold expansion beyond160 with bounded stored text',text:'\u0130'.repeat(160),shouldFit:true}
];
const context={players:[0,1].map(i=>({id:'p'+i,name:'Seat '+(i+1),avatarId:'🙂',connected:true})),seed:91,now:0,settings:{mode:'bluff',rounds:4}};
const timer=s=>({type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline});
for(const c of cases){
 const content=makeSamples().map(r=>r.kind==='bluff'?{...r,correct:c.text}:r);
 assert(catalogSchema.safeParse(content).success);
 const observations=[];
 for(const [name,core] of [['Ready',old],['f79',fixed]]){
  const game=core.createGame(content);let s=game.init(context);
  for(let i=0;i<10&&s.phase.id!=='write';i++)s=game.reduce(s,timer(s));assert.equal(s.phase.id,'write');
  const parsed=game.inputSchema.safeParse({type:'write',text:c.text});assert(parsed.success);
  const before=s;s=game.reduce(s,{type:'input',playerId:'p0',input:parsed.data,now:s.phase.startedAt+1});
  const accepted=s!==before;s=game.reduce(s,timer(s));
  observations.push({source:name,catalogAccepted:true,rawInputSchemaAccepted:true,truthWriteAccepted:accepted,privateTruthConfirmation:game.controllerView(s,'p0').foundTruth,knowledgeHasWriter:s.knowledge.includes('p0')});
 }
 const cleaned=c.text.normalize('NFKC').replace(/[\p{Cc}\p{Cf}]/gu,' ').trim().replace(/\s+/gu,' ');
 assert.equal(observations[0].truthWriteAccepted,true);
 assert.equal(observations[1].truthWriteAccepted,c.shouldFit);
 rows.push({case:c.id,rawUnits:c.text.length,normalizedStoredUnits:cleaned.length,casefoldKeyUnits:cleaned.toLowerCase().length,expectedFitsPostNormalizationLimit:c.shouldFit,observations});
}
const mismatches=rows.filter(r=>!r.expectedFitsPostNormalizationLimit);
assert.equal(mismatches.length,2);
const report={status:'COUNTEREXAMPLE_CONFIRMED',sourceHead:'f79d33634ea678e0fd5194448d70e8c879e767e7',scope:'pre-green accepted catalog truth writability inquiry, not KEEP gain or browser timing',actualAcceptedCatalogTruthFailures:mismatches.length,validBoundaryControls:rows.length-mismatches.length,cases:rows,nativeTimingOrBrowser:false};
writeFileSync(base+'/actual-report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({status:report.status,actualAcceptedCatalogTruthFailures:2,validBoundaryControls:3,nativeTimingOrBrowser:false}));

