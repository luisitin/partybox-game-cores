from pathlib import Path
import os,subprocess,time,datetime,json,hashlib,urllib.request,zipfile,traceback,signal,ctypes,re
base=Path('/tmp/G04-0ad-whole-hosted-curl-20261009');base.mkdir(exist_ok=False)
repo=Path('/tmp/game-cores-G04-followup-20261009');snap=Path('/tmp/G04-0ad-preserved-baseline-20261009');job=snap/'jobs/G04-reality-check'
reader=job/'verify-hosted-artifact.py';python=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
provider=Path('/tmp/G04-0ad-hosted-curl-private-reference-20261009.json');loginput=Path('/tmp/G04-0ad-hosted-log-input-20261009.json');metadata=Path('/tmp/G04-0ad-hosted-artifact-meta-20261009.json')
head='0ad722bf4e815274976fea6d63c4ed1337b22ba2';runid=37926261413;t=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 st=p.stat();return {'path':str(p),'bytes':st.st_size,'sha256':h.hexdigest(),'immutableStat':[st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns]}
paths=sorted(p for root in [snap/'jobs/G04-reality-check',snap/'contract',snap/'.github/workflows'] for p in root.rglob('*') if p.is_file() and 'node_modules' not in p.parts)
paths+=[reader,python,Path(__file__).resolve(),provider,loginput,metadata,Path('/usr/bin/ffmpeg'),Path('/usr/bin/ffprobe'),Path('/usr/bin/curl')]
paths=list(dict.fromkeys(paths))
before=[digest(p) for p in paths];(base/'before.json').write_text(json.dumps({'at':t(),'rows':before},indent=2)+'\n')
started=t();start=time.monotonic();status='CLOSED_FAILED';peak=0;samples=[];signals=[];pid=None
def group(pid):
 rows=[]
 for entry in Path('/proc').iterdir():
  if not entry.name.isdigit():continue
  try:
   raw=(entry/'stat').read_text();tail=raw[raw.rfind(')')+2:].split()
   if int(tail[2])==pid:rows.append({'pid':int(entry.name),'rss':int(tail[21])*os.sysconf('SC_PAGE_SIZE'),'state':tail[0]})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return rows
try:
 meta=json.loads(metadata.read_text());assert meta['id']==11613424422 and meta['workflow_run']['id']==runid and meta['workflow_run']['head_sha']==head
 (base/'artifact-metadata.json').write_bytes(metadata.read_bytes())
 whole=json.loads(loginput.read_text())['wholeDecodedUTF8Log'].encode('utf8');(base/'complete-job.log').write_bytes(whole)
 text=whole.decode('utf8')
 for n in range(2,9):
  for mode in ['quick','mixed','bluff']:assert f'1000 complete bot games: {n} seats {mode}' in text
 for name in ['property replay seeds 1/2/3 plus 1000 random seeded event streams','1000 timer-only rosters finish inside estimatedMinutes × 3','Unicode normalization keeps stored bluff writes within the 160-unit limit','Unicode normalization cannot exceed the saved-state ceiling across twelve bluff rounds','catalog truth normalization uses the writable display limit without limiting casefold keys','malformed UTF16 and binary catalog controls are rejected before play','maximal well formed catalog and three byte writes keep every saved state bounded']:
  assert name in text,name
 assert re.search(r'(?:#|ℹ)\s+tests\s+57\b',text) and re.search(r'(?:#|ℹ)\s+pass\s+57\b',text)
 assert re.search(r'(?:#|ℹ)\s+tests\s+4\b',text) and re.search(r'(?:#|ℹ)\s+pass\s+4\b',text)
 assert not re.search(r'(?:#|ℹ)\s+fail\s+[1-9]',text)
 assert text.count('KILLED')>=25
 (base/'whole-log-reader.json').write_text(json.dumps({'observedAt':t(),'utf8Bytes':len(whole),'characters':len(text),'sha256':hashlib.sha256(whole).hexdigest(),'all21ThousandGameCohortsPresent':True,'originalReplayIdleBothUnicodeTestsPresent':True,'actualFullTests':57,'actualStrictProofTests':4,'all25KilledMarkersPresent':True,'noPositiveFailureCount':True,'scope':'whole original UTF8 log, final original reader separately required'},indent=2)+'\n')
 reference=json.loads(provider.read_text());url=reference['file_uri']['download_url'];assert url.startswith('https://') and url.isascii()
 config=('url = "'+url.replace('\\\\','\\\\\\\\').replace('"','\\\\"')+'"\\n').encode('ascii')
 actual=base/'actual.zip';h=hashlib.sha256();count=0
 curl='/usr/bin/curl'
 with (base/'download.stdout.log').open('wb') as out,(base/'download.stderr.log').open('wb') as err:
  p=subprocess.Popen([curl,'--silent','--show-error','--fail','--location','--connect-timeout','15','--max-time','60','--retry','0','--max-filesize',str(meta['size_in_bytes']),'--write-out','%{stderr}\\nG04_HTTP_STATUS:%{http_code}\\n','--output',str(actual),'--config','-'],stdin=subprocess.PIPE,stdout=out,stderr=err,start_new_session=True)
  p.stdin.write(config);p.stdin.close();pid=p.pid
  while p.poll() is None:
   owned=group(pid);rss=sum(x['rss'] for x in owned);peak=max(peak,rss);samples.append({'at':t(),'owned':owned,'rss':rss})
   if rss>512*1024*1024 or time.monotonic()-start>180:
    signals.append({'at':t(),'signal':'SIGTERM','why':'declared512MiB/180s bound'});os.killpg(pid,signal.SIGTERM);p.wait(timeout=5);break
   time.sleep(.025)
  exitcode=p.returncode
  assert exitcode==0 and group(pid)==[] and not signals,('configured curl failed',exitcode)
 assert 'G04_HTTP_STATUS:200' in (base/'download.stderr.log').read_text()
 with actual.open('rb') as source:
  for block in iter(lambda:source.read(1048576),b''):count+=len(block);assert count<=meta['size_in_bytes'];h.update(block)
 assert count==meta['size_in_bytes']==1450104 and h.hexdigest()==meta['digest'].removeprefix('sha256:')=='035d71b6feb616eaf9a7a9c665961ec5538717cdcc6645c1e892a2e2abd2a8e9'
 with zipfile.ZipFile(actual) as z:
  assert z.testzip() is None
  for item in z.infolist():assert len(z.read(item))==item.file_size
 (base/'whole-official-eof.json').write_text(json.dumps({'observedAt':t(),'artifactId':meta['id'],'wholeBytes':count,'sha256':h.hexdigest(),'httpStatus':200,'EOFRead':True,'allMembersFullReadAndCRC':True},indent=2)+'\n')
 env=dict(os.environ);env['GIT_DIR']=str(repo/'.git');env['GIT_WORK_TREE']=str(snap)
 with (base/'reader.stdout.log').open('wb') as out,(base/'reader.stderr.log').open('wb') as err:
  p=subprocess.Popen([str(python),str(reader),'--head',head,'--run-id',str(runid),'--evidence-dir',str(base)],cwd=job,env=env,stdout=out,stderr=err,start_new_session=True)
  pid=p.pid
  while p.poll() is None:
   owned=group(pid);rss=sum(x['rss'] for x in owned);peak=max(peak,rss);samples.append({'at':t(),'owned':owned,'rss':rss})
   if rss>512*1024*1024 or time.monotonic()-start>180:
    signals.append({'at':t(),'signal':'SIGTERM','why':'declared512MiB/180s bound'});os.killpg(pid,signal.SIGTERM);p.wait(timeout=5);break
   time.sleep(.025)
  exitcode=p.returncode
  for _ in range(80):
   for row in group(pid):
    try:os.waitpid(row['pid'],os.WNOHANG)
    except ChildProcessError:pass
   if not group(pid):break
   time.sleep(.025)
  assert exitcode==0 and group(pid)==[] and not signals,('original reader failed or descendants present',exitcode,group(pid))
 validation=json.loads((base/'independent-current-host-validation.json').read_text());assert validation['passed'] and validation['sourceCommit']==head and validation['sourceGuards']==1034 and len(validation['actualCurrentDecodedClips'])==5
 after=[digest(p) for p in paths];assert before==after
 (base/'after.json').write_text(json.dumps({'at':t(),'rows':after},indent=2)+'\n')
 status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':t(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 actualFinal=[digest(p) for p in paths];guardEqual=actualFinal==before
 (base/'always-final-guards.json').write_text(json.dumps({'at':t(),'equalBefore':guardEqual,'rows':actualFinal},indent=2)+'\n')
 r={'status':status,'startedAt':started,'closedAt':t(),'sourceHead':head,'runId':runid,'officialArtifactId':11613424422,'officialBytes':locals().get('count'),'officialSHA256':locals().get('h').hexdigest() if 'h' in locals() else None,'allPhysicalSourceRuntimeSelfInputGuardsEqual':guardEqual,'guardRows':len(before),'readerByteUnchanged':True,'original1034SourceGuards':status=='CLOSED_PASS','original3000NativeIntervalsAnd5FullClipDecodes':status=='CLOSED_PASS','sampledPeakOwnedRssBytes':peak,'actualReaderExitCode':locals().get('exitcode'),'naturalClosure':status=='CLOSED_PASS' and not signals,'finalOwnedGroup':group(pid) if pid else [],'signals':signals,'qualifiedKeepRounds':0,'scope':'genuine current0ad integrated KEEP1 text/state correction acceptance; KEEP1 actual gain qualifies, later source and rounds remain separate'}
 (base/'resource-process.json').write_text(json.dumps({'receipt':r,'samples':samples},indent=2)+'\n');(base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

