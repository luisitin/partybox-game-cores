from pathlib import Path
import json,gzip,hashlib,datetime,unicodedata,math,re
base=Path('/tmp/G04-keep2-unicode-credit-actual-v2-20261009')
paths=[base/'complete-games.jsonl.gz',base/'actual-events.jsonl',base/'actual-unicode-credit-report.json',base/'receipt.json',Path(__file__).resolve()]
def guard(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 stat=path.stat();return {'path':str(path),'bytes':stat.st_size,'sha256':h.hexdigest(),'identity':[stat.st_dev,stat.st_ino,stat.st_mtime_ns,stat.st_ctime_ns]}
before=[guard(p) for p in paths]
def canonical(text):
 value=unicodedata.normalize('NFKC',text)
 value=''.join(' ' if unicodedata.category(c) in ['Cc','Cf'] else c for c in value)
 return ' '.join(value.split()).lower()
report=json.loads((base/'actual-unicode-credit-report.json').read_text());assert report['games']==1003 and report['rounds']==4012
count=rounds=event_count=award_checks=owner_checks=0
with gzip.open(base/'complete-games.jsonl.gz','rt',encoding='utf8') as saved,(base/'actual-events.jsonl').open() as stream:
 for index,line in enumerate(saved):
  game=json.loads(line);ids=[p['id'] for p in game['context']['players']]
  assert 2<=len(ids)<=8 and game['context']['seed']==report['seeds'][index]
  assert game['context']['settings']=={'mode':'bluff','rounds':4} and len(game['roundReports'])==4
  total=dict.fromkeys(ids,0)
  for r in game['roundReports']:
   writing=r['writing'];votes=r['votesByPublicText'];truth=canonical(r['truth']);expected={}
   for author in ids:
    word=canonical(writing[author]);knows=word==truth
    points=1000 if knows or canonical(votes.get(author,''))==truth else 0
    if not knows:
     owners=[id for id in ids if canonical(writing[id])==word]
     fooled=[voter for voter in ids if canonical(writing[voter])!=truth and voter not in owners and canonical(votes.get(voter,''))==word]
     points+=len(fooled)*(500//len(owners))
    expected[author]=points*(2 if r['round']==4 else 1);total[author]+=expected[author];award_checks+=1
   assert expected==r['actualAwards']==r['independentExpectedAwards']==r['actualRoundReport']['awards']
   options=r['actualRoundReport']['options'];assert sum(o['correct'] for o in options)==1
   for option in options:
    word=canonical(option['text'])
    owners=[] if word==truth else [id for id in ids if canonical(writing[id])==word]
    assert sorted(owners)==sorted(option['owners']) and option['correct']==(word==truth);owner_checks+=1
   rounds+=1
  assert game['finalState']['phase']['id']=='done' and game['results']['scores']==total==game['finalState']['scores']
  high=max(total.values());assert game['results']['winnerIds']==[id for id in ids if total[id]==high]
  assert game['allReplayedHashesEqual'] is True
  for item in game['events']:
   actual=json.loads(next(stream));assert actual=={'gameIndex':index,'seed':game['context']['seed'],'item':item}
   assert re.fullmatch('[a-f0-9]{64}',item['before']) and re.fullmatch('[a-f0-9]{64}',item['after']) and 0<item['stateBytes']<=262144
   event_count+=1
  count+=1
 assert stream.read()==''
assert count==1003 and rounds==4012 and event_count==report['events']==48106
assert before==[guard(p) for p in paths]
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'WHOLE_SAVED_UNICODE_CREDIT_INDEPENDENT_PASS','gamesThroughGzipEOF':count,'rounds':rounds,'actualPerEventStreamRows':event_count,'authorAwardAssertions':award_checks,'optionOwnershipAssertions':owner_checks,'allFinalTotalsWinnersEqual':True,'wholeCompressedBytes':before[0]['bytes'],'wholeCompressedSha256':before[0]['sha256'],'allFivePhysicalInputGuardsUnchanged':True,'physicalInputGuards':before,'pythonUnicodeVersion':unicodedata.unidata_version,'independentReference':'Python author accumulation from original raw writes/public vote text; distinct from actual Node voter reducer; no new game/native timing','failedV1StillPreserved':True}
(base/'independent-whole-saved-credit-reader.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='physicalInputGuards'}))

