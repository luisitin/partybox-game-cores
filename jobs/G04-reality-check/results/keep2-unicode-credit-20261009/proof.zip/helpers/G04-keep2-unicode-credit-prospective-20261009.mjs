import assert from 'node:assert/strict';
import {appendFileSync,writeFileSync,readFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {game} from '/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/core.ts';
import {createRng} from '/tmp/game-cores-G04-followup-20261009/contract/rng.ts';
const output=process.argv[2];assert(output);
const canonical=text=>text.normalize('NFKC').replace(/[\p{Cc}\p{Cf}]/gu,' ').split(/\s+/u).filter(Boolean).join(' ').toLowerCase();
const fullwidth=text=>[...text].map(c=>{const n=c.codePointAt(0);return n>=33&&n<=126?String.fromCodePoint(n+0xfee0):c;}).join('');
const families=[
 ['ligature',['ﬃ','ffi','ＦＦＩ']],
 ['composition',['Café','Cafe\u0301','ＣＡＦÉ']],
 ['casefold160key',['\u0130'.repeat(80),'I\u0307'.repeat(80)]],
 ['casefold320key',['\u0130'.repeat(160)]],
 ['arabic-compatibility',['\ufdfa'.repeat(8),'\ufdfa'.repeat(8).normalize('NFKC')]],
 ['emoji',['🧭 Anchor','🧭 ＡＮＣＨＯＲ']],
 ['control-cleanup',['Anchor\u0001Watch','Anchor Watch','ＡＮＣＨＯＲ\tＷＡＴＣＨ']],
 ['literal-markup',['<Bluff>&"',' <BLUFF>&" ']]
];
const samplerSeed=0x6040015,sampler=createRng(samplerSeed),seedSet=new Set([1,2,3]);
while(seedSet.size<1003)seedSet.add(sampler.int(0,0xffffffff));
const seeds=[...seedSet],hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
let rounds=0,events=0,writes=0,votesCount=0,duplicateAuthors=0,truthWrites=0,selfVoteRefusals=0,peakState=0;const familyCounts={};
const summaries=[];
for(const [index,seed] of seeds.entries()){
 const n=2+index%7,[family,words]=families[index%families.length];familyCounts[family]=(familyCounts[family]??0)+1;
 const ctx={players:Array.from({length:n},(_,i)=>({id:'p'+i,name:'Seat '+(i+1),avatarId:'🙂',connected:true})),seed,now:0,settings:{mode:'bluff',rounds:4}};
 const random=createRng(seed^0x6040015),transcript=[],roundReports=[],total=Object.fromEntries(ctx.players.map(p=>[p.id,0]));
 let state=game.init(ctx);
 const send=e=>{
  const before=hash(state);state=game.reduce(state,e);const stateBytes=Buffer.byteLength(JSON.stringify(state));assert(stateBytes<=262144);peakState=Math.max(peakState,stateBytes);
  transcript.push({event:e,before,after:hash(state),stateBytes});events++;
 };
 const timer=()=>({type:'timer',phaseId:state.phase.id,startedAt:state.phase.startedAt,now:state.phase.deadline});
 for(let step=0;state.phase.id!=='done'&&step<300;step++){
  if(state.phase.id!=='write'){send(timer());continue;}
  const writing={},chosen={},truth=String(state.question.correct),ids=[...state.seats],round=state.round;
  for(const id of ids){
   const text=random.chance(.15)?random.pick([truth,truth.toUpperCase(),fullwidth(truth),truth+'\u0001']):random.chance(.2)?'Other fake '+random.int(0,2):random.pick(words);
   writing[id]=text;assert(game.inputSchema.safeParse({type:'write',text}).success);
   send({type:'input',playerId:id,input:{type:'write',text},now:state.phase.startedAt+1});writes++;
  }
  const publicOptions=state.phase.id==='vote'?game.tvView(state).options.map(o=>({...o})):[];
  if(state.phase.id==='vote')for(const id of ids){
   if(canonical(writing[id])===canonical(truth)){if(state.phase.id==='vote')assert.equal(game.controllerView(state,id).foundTruth,true);assert.equal(game.controllerView(state,id).inputType,null);continue;}
   const own=publicOptions.filter(o=>canonical(o.text)===canonical(writing[id]));
   for(const o of own){
    const invalid={type:'input',playerId:id,input:{type:'vote',choice:o.id},now:state.phase.startedAt+1};
    assert.equal(game.reduce(state,invalid),state);selfVoteRefusals++;
   }
   const menu=game.controllerView(state,id).menu;
   for(const o of menu)assert.equal(o.mine,canonical(o.text)===canonical(writing[id]));
   const legal=publicOptions.filter(o=>canonical(o.text)!==canonical(writing[id]));assert(legal.length>0);
   const selected=random.pick(legal);chosen[id]=selected.text;
   send({type:'input',playerId:id,input:{type:'vote',choice:selected.id},now:state.phase.startedAt+1});votesCount++;
  }
  assert.equal(state.phase.id,'reveal');
  const expected={};
  for(const author of ids){
   const word=canonical(writing[author]),knows=word===canonical(truth);if(knows)truthWrites++;
   let points=knows||canonical(chosen[author]??'')===canonical(truth)?1000:0;
   if(!knows){
    const owners=ids.filter(id=>canonical(writing[id])===word);if(owners.length>1)duplicateAuthors++;
    const fooled=ids.filter(voter=>canonical(writing[voter])!==canonical(truth)&&!owners.includes(voter)&&canonical(chosen[voter]??'')===word).length;
    points+=fooled*Math.floor(500/owners.length);
   }
   expected[author]=points*(round===4?2:1);total[author]+=expected[author];
  }
  assert.deepEqual(state.last.awards,expected);assert.deepEqual(state.scores,total);
  roundReports.push({round,family,writing,votesByPublicText:chosen,truth,independentExpectedAwards:expected,actualAwards:state.last.awards,actualRoundReport:state.last});rounds++;
  send(timer());
 }
 assert.equal(state.phase.id,'done');assert.equal(roundReports.length,4);assert.deepEqual(game.results(state).scores,total);
 let replay=game.init(ctx);
 for(const item of transcript){assert.equal(hash(replay),item.before);replay=game.reduce(replay,item.event);assert.equal(hash(replay),item.after);assert.equal(Buffer.byteLength(JSON.stringify(replay)),item.stateBytes);}
 assert.deepEqual(replay,state);
 const raw=Buffer.from(JSON.stringify({context:ctx,family,events:transcript,roundReports,finalState:state,results:game.results(state),allReplayedHashesEqual:true})+'\n');
 appendFileSync(output+'/complete-games.jsonl.gz',gzipSync(raw));
 summaries.push({index,seed,players:n,family,events:transcript.length,independentAwardRounds:4,finalStateSha256:hash(state),finalScores:total});
}
const bytes=readFileSync(output+'/complete-games.jsonl.gz');
const report={scope:'post-green untimed extra Unicode independent author/voter scoring and legal self-vote/property replay coverage; unchanged original 10000 oracle and production, no browser/native timing/player behavior change',samplerSeed,seeds,games:seeds.length,familyCounts,rounds,events,writes,votes:votesCount,duplicateAuthorCases:duplicateAuthors,truthWrites,selfVoteRefusals,peakStateBytes:peakState,independentAwardMismatches:0,allGamesDone:true,allReplayedStateHashesEqual:true,compressedWholeBytes:bytes.length,compressedWholeSha256:createHash('sha256').update(bytes).digest('hex'),summaries};
writeFileSync(output+'/actual-unicode-credit-report.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({games:report.games,rounds,events,writes,votes:votesCount,duplicateAuthors,truthWrites,selfVoteRefusals,peakState,independentAwardMismatches:0,allReplayExact:true}));

