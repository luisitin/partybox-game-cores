# KEEP GOING

Baseline current-head CI passed before round1. See REVIEWS.md.

1 | five weaknesses: private draft loss; phone context/focus/wheel; short-year parsing; medium fake style; phase-matrix coverage | fix worst: owner/phase draft cache | measured hide/reopen retention0/1→1/1, six numeric/range and two bluff restore assertions pass, hidden fields0, no owner crossover;20 browser scenarios; TV/phone60fps | player gain; no-gain streak0.
2 | five weaknesses: phone context/focus/wheel/wrapping; short years; medium fake style; phase fuzz; zero catalogs | fix phone play | measured wheel/question false→true, keyboard draft empty→typed, live timer matches,160-character unbroken vote fits;22 browser scenarios;TV60.0032fps/phone60.0028fps,p95≤16.80ms | player gain; no-gain streak0.
3 | five weaknesses: short years/eras; medium fake style; phase fuzz; custom zero/date catalogs; seed robustness | fix public date parser | measured valid-clue accuracy0/8→8/8 with hidden-truth independence;24 focused tests and12,000 leagues pass with identical default rates;22 browser scenarios/capture5 | player gain for supported date rows; no-gain streak0.
4 | five weaknesses: range safety; medium fake style; phase fuzz; random replay seeds; held-out skills | fix geometric underflow/zero-century correction and controller defaults | measured invalid inputs2674/9000→0/9000,26 focused tests,default league counts unchanged,22 browser scenarios/60fps/capture6 | player gain for valid custom ranges; no-gain streak0.
5 | five weaknesses: Medium fake style; phase/privacy matrix; sequential replay seeds; custom catalogs; held-out skill robustness | fix fake pattern | measured two-word conformity0/300→300/300,all50 tests/25 mutations/12,000 leagues/22 browser scenarios pass,all skill lower bounds>50%,capture7/60fps | player gain; no-gain streak0.
6 | five weaknesses: phase/privacy matrix; sequential replay seeds; custom catalogs; held-out skills; frame variance | fix coverage and seed sampling | measured7,000 frozen states/195,000 ignored events/60,000 privacy comparisons/90,000 bot comparisons,zero failures;1,003 exact random-seed replays pass;production unchanged | player gain0;no-gain streak1.
7 | five weaknesses: catalog validation; held-out skills; frame variance; presence churn; factory scale | fix invisible bluff truths | measured4/4 accepted→4/4 rejected before blank voting;10,000 valid rows/30,000 bot actions/7,500 defaults pass;28 tests/25 mutation kills/22 browser scenarios/60fps,capture8 | player gain;no-gain streak0.
8 | five weaknesses: held-out skill strength; frame variance; presence churn; factory scale; benchmark limits | fix seed-cohort coverage | measured12,000 fresh matches,all six skill confidence lower bounds>50%;original12,000 reports unchanged,no policy tuning | player gain0;no-gain streak1.
9 | five weaknesses: frame variance; presence churn; factory scale; physical-phone limit; future integration | fix repeatability evidence | measuredthree independent browser processes/66 scenarios/900 TV+900 phone intervals,all60fps/p95≤16.8ms,zero requests/errors;separate captures<10MB | player gain0;no-gain streak2.
10 | five weaknesses: presence churn; factory scale; physical-phone limit; future integration; editorial spacing | fix presence coverage | measured1,000 games/16,585 presence events/5,347 pauses/585 stale timer checks/50 prototype rosters,all finish with retained finite independently ranked seats,0 failures | player gain0;no-gain streak3.
11 | five weaknesses: expired input ordering; hosted raw retention; frame variance; phone approximation; recovery scope | fix worst: host consumes overdue timer before input/bot sample | preliminary actualfile6/6: latecorrect credit1000→0, human/bot latefake menu2→1, on-time/pause retained, guarded phoneclip209705bytes | player gain; no-gain streak0; exact25a6023 CI green:51tests/25mutants/24kleagues/66 scenarios/6x300 near60FPS; local22 scenarios pass but TV55.903FPS FAIL, full raw retained; evidence wrap-up7a7af73 exactCI green,6x300 raw/sourceguards retained; localphone54.057FPS FAIL remains disclosed; round11 requiredhostedchecks PASS.
12 | five weaknesses: stale source/media evidence; local frame variance; exact timer boundary coverage; physical phone approximation; recovery documentation | fix worst: independent current source/raw/capture validator, integrated after3 full runs | actual harmless HTML change old integrity PASS→new source proof REJECT, restored e570;23 corruptions rejected,1,800 true historical intervals recomputed, genuine156846-byte local clip hash checked separately; runtime unchanged | player gain0; no-gain streak1; exact5c45099 CI PASS and native actualclips/raw/source CLI PASS.
13 | five weaknesses: exact deadline equality; local frame variance; compiled host boundary mutant; physical phone limit; documentation | fix worst: add two real exact-deadline controls | eight cases PASS; actual compiled <= mutant escapes old6 but new8 catches both boundary cases, UI/page restored; actual host1,800 raw/3capturehashes independently PASS, fresh157763-byte clip | player gain0; no-gain streak2; exact5b99dae CI37787851588 SUCCESS, full actual logs read.
14 | five weaknesses: private/manual compiled host mutation; local frame variance; physical phone approximation; handoff navigation; future content integration | fix worst: self-contained actual compiled host mutation in npmtest | strict types PASS; old6 PASS, current8 catches exactly2 boundary cases, every originalcase PASS; finally restores all13 guarded sources including original UI/page; fresh157527-byte clip/108data-media hashes PASS | player gain0; no-gain streak3; exact b18952bf CI37791478413 SUCCESS14:26:07, full actual log read; runtime and frame thresholds unchanged.

## Independent contract audit, 2026-10-09 (outside player improvement rounds)

Concrete defect: false noCards:true declaration for160 English prompts. The new
regression fails on old core and passes after omission. Bounded fixed pipeline:
29 focused tests/4 strict controls/types/regeneration/data allPASS. Declaration
violations observed1→0; no gameplay, picker or performance gain is claimed.
Original reducer/view/bot/UI/timer/sampler and allseven fixtures unchanged.
Original player KEEP12–14 three-round no-gain stop remains historical; no new
numbered player round or candidate timing invented. Current full hosted checks
are still required; canonical c81 proof is explicitly historical baseline.

## Unicode follow-up baseline, 2026-10-09

Pre-green real defect |160 input→2880 stored; old676419B state | refuse normalized oversize before storage | fixed96 refusals/8995B peak;42 benign games/3395 event states plus bots/views/results equal;31 focused/4 strict controls pass | not a qualified KEEP round; new full hosted proof pending; original12–14 stop preserved; new completed rounds0/no-gain streak0.

## Catalog consistency follow-up, 2026-10-09
Pre-green real finding | two accepted catalog truths normalize to162 unwritable
units after f79 | shared case-preserving cleanup and catalog display-length
validation |32 focused/four strict PASS;10000 matching comparisons equal;
42 benign games3395 states/bots/views/results equal;3830 guards/closure PASS
| whole new original proof pending; new completed KEEP rounds0/no-gain streak0.

1 follow-up | five weaknesses: escaped JSON state growth;complex Unicode projections;custom catalogs;physical phone approximation;draft refusal | fix worst: refuse malformed writes and malformed/binary-control catalog strings | actual old3 games/33 oversized states/max288469; fixed42 pre-play refusals,9 maximal valid games1971 exact legal/replay events/max151384;34 focused/four strict/3834 guards pass;42 benign3395states and10000 matching cases unchanged | actual local player robustness gain; exact changed-head full still pending; completed new rounds0/no-gain streak0 until qualification; no clock gain.
