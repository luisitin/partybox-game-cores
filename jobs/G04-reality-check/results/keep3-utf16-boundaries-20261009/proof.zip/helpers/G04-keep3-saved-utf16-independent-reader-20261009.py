from pathlib import Path
import gzip,json,hashlib,datetime,subprocess,sys
base=Path('/tmp/G04-keep3-utf16-actual-20261009')
raw=base/'actual-utf16-cases.jsonl.gz';reportPath=base/'actual-utf16-report.json'
report=json.loads(reportPath.read_text());spec=Path('/tmp/G04-keep3-utf16-prospective-20261009.json')
inputs=[raw,reportPath,spec,Path('/tmp/G04-keep3-utf16-prospective-20261009.mjs'),Path(__file__).resolve(),Path(sys.executable).resolve()]
def guard(p):
 st=p.stat();h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'path':str(p),'bytes':st.st_size,'sha256':h.hexdigest(),'stat':[st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns]}
before=[guard(p) for p in inputs];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
counts={'single':0,'pair':0,'edge':0,'random':0,'catalog':0};decoded=hashlib.sha256();well=bad=refusals=0
randomSpec=json.loads(spec.read_text());rng=randomSpec['randomSamplerSeed'];seeds=[1,2,3];seen=set(seeds)
while len(seeds)<1003:
 rng=(rng*1664525+1013904223)&0xffffffff
 if rng not in seen:seen.add(rng);seeds.append(rng)
def expected_random(index):
 seed=seeds[index];state=seed
 def rn():
  nonlocal state
  state=(state*1664525+1013904223)&0xffffffff;return state
 units=[65];length=1+rn()%159;mode=index%4
 if mode==3:
  while len(units)<length:units.append(65+rn()%26)
  units.append(0xd800)
  if len(units)>160:del units[1]
 else:
  while len(units)<length:
   unit=rn()&65535
   if mode==0 and 0xd800<=unit<=0xdfff:unit=32
   if mode==1 and len(units)+2<=length:
    units.extend([0xd800+(unit&1023),0xdc00+((rn()>>8)&1023)]);continue
   if mode==1:unit=65
   units.append(unit)
 return units,seed,mode
controls=list(range(32))+[127]+list(range(128,160));fields=['id','prompt','hint','fact','correct','left','right']
ordinal=0
with gzip.open(raw,'rb') as f:
 for line in f:
  decoded.update(line);row=json.loads(line);assert row['ordinal']==ordinal
  family=row['family'];index=row['index'];assert index==counts[family]
  if family=='catalog':
   unit=controls[index//7];field=fields[index%7]
   assert row['controlUnit']==unit and row['field']==field
   allowed=unit in [9,10,13] or (unit>31 and unit!=127)
   assert row['expectedAllowed']==row['schemaAccepted']==row['factoryAccepted']==allowed
  else:
   units=row['units']
   if family=='single':assert units==[65,index]
   elif family=='pair':assert units==[65,0xd800+index//1024,0xdc00+index%1024]
   elif family=='edge':
    i=index//5;kind=index%5;h=0xd800+i;l=0xdc00+((i*37)&1023);h2=0xd800+((i*13)&1023);l2=0xdc00+((i*19)&1023)
    assert units==[[65,h,l,h],[65,h,h2,l],[65,l,h,l],[65,h,l,h2,l2],[65,l]][kind] and row['edgeKind']==kind
   elif family=='random':
    expected,seed,mode=expected_random(index);assert units==expected and row['seed']==seed and row['mode']==mode
   else:raise AssertionError('unexpected family')
   # Python's strict UTF16 decoder is independent of the JS regex/manual loop.
   binary=b''.join(unit.to_bytes(2,'little') for unit in units)
   try:binary.decode('utf-16-le',errors='strict');expected=True
   except UnicodeDecodeError:expected=False
   assert 1<=len(units)<=160 and row['expectedWellFormed']==row['actualWellFormed']==row['writeSchemaAccepted']==expected
   if expected:well+=1
   else:bad+=1
   refusal=row['refusal']
   if not expected and family in ['single','random']:
    assert refusal['sameIdentity'] and refusal['sameSerializedState'] and refusal['validRetryStored']=='valid retry';refusals+=1
   else:assert refusal is None
  counts[family]+=1;ordinal+=1
assert counts=={'single':65536,'pair':1048576,'edge':5120,'random':1003,'catalog':455}
assert ordinal==report['rows'] and counts==report['counts'] and well==report['wellFormedWriteCases'] and bad==report['malformedWriteCases'] and refusals==report['actualMalformedRefusals']==report['validRetryChecks']
assert decoded.hexdigest()==report['wholeDecodedJsonlSHA256'] and before[0]['bytes']==report['wholeGzipBytes'] and before[0]['sha256']==report['wholeGzipSHA256']
assert seeds==report['randomSeeds'];after=[guard(p) for p in inputs];assert before==after
receipt={'status':'PASS','startedAt':started,'closedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':report['sourceHead'],'wholeGzipEOFRead':True,'completeRows':ordinal,'counts':counts,'wellFormedCases':well,'malformedCases':bad,'actualRefusalRetryControls':refusals,'independentPythonStrictUTF16Decoder':True,'allSixPhysicalInputGuardsUnchanged':True,'before':before,'after':after,'noGameOrTimingRerun':True,'wholeGzipBytes':before[0]['bytes'],'wholeGzipSHA256':before[0]['sha256']}
(base/'independent-python-whole-utf16.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['before','after']}),flush=True)
