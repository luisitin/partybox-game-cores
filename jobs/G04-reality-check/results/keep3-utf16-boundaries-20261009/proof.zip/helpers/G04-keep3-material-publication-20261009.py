from pathlib import Path
import json,datetime,hashlib,zipfile,re,subprocess,traceback,shutil
repo=Path('/tmp/game-cores-G04-followup-20261009');job=repo/'jobs/G04-reality-check'
branch='job/G04-reality-check-followup-20261009';parent='c30d484ebba82df137893e238b7e6b5948603736'
base=Path('/tmp/G04-keep3-source-publication-20261009');base.mkdir(exist_ok=False)
out=job/'results/keep3-utf16-boundaries-20261009';out.mkdir(exist_ok=False)
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
started=utc();status='CLOSED_FAILED';steps=[]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def run(name,args,cwd=repo):
 start=utc();p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=90)
 (base/(name+'.stdout')).write_bytes(p.stdout);(base/(name+'.stderr')).write_bytes(p.stderr)
 steps.append({'name':name,'startedAt':start,'closedAt':utc(),'actualExitCode':p.returncode,'argv':args})
 assert p.returncode==0,(name,p.returncode,p.stderr[:500])
 return p.stdout
def headremote():return subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],cwd=repo,timeout=30).decode().split()[0]
tracked=[repo/x.decode() for x in subprocess.check_output(['git','ls-files','-z','jobs/G04-reality-check','contract','.github/workflows/G04.yml'],cwd=repo).split(b'\0') if x]
mutable={job/name for name in ['test.ts','NEXT.md','LOOP.md','VERIFY.md','ASSUMPTIONS.md','SHA256SUMS.txt']}
stable=[p for p in tracked if p not in mutable];before=[digest(p) for p in stable]
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()==parent and headremote()==parent
 fixed=json.loads(Path('/tmp/G04-keep3-utf16-fixed-v2-20261009/receipt.json').read_text());assert fixed['status']=='CLOSED_PASS' and fixed['actualChangedDuringPipeline']==[] and fixed['guardRows']==3839
 pure=json.loads(Path('/tmp/G04-keep3-utf16-actual-20261009/receipt.json').read_text());assert pure['status']=='CLOSED_PASS'
 full=json.loads(Path('/tmp/G04-c30-whole-hosted-curl-20261009/receipt.json').read_text());assert full['status']=='CLOSED_PASS' and full['sourceHead']==parent
 eof=json.loads(Path('/tmp/G04-keep3-utf16-actual-20261009/independent-python-whole-utf16.json').read_text());assert eof['status']=='PASS' and eof['completeRows']==1120690
 more=json.loads(Path('/tmp/G04-keep3-supplementary-catalog-actual-20261009/actual-supplementary-catalog-report.json').read_text());assert more['status']=='PASS' and more['games']==9 and more['peakStateBytes']==158015
 assert re.search(r'# tests 36\b',Path('/tmp/G04-keep3-utf16-fixed-v2-20261009/focused-tests.stdout.log').read_text())
 assert re.search(r'# pass 36\b',Path('/tmp/G04-keep3-utf16-fixed-v2-20261009/focused-tests.stdout.log').read_text())
 originals=[]
 for p in stable:
  relative=str(p.relative_to(repo));original=subprocess.check_output(['git','show',parent+':'+relative],cwd=repo)
  assert p.read_bytes()==original,relative
  originals.append({'relative':relative,**digest(p),'equalGenuineC30Bytes':True})
 (base/'original-product-source-bridge.json').write_text(json.dumps({'at':utc(),'genuineSource':parent,'rows':originals,'allEqual':True,'scope':'every tracked job/contract/workflow file except sole new test, verification documents and checksum manifest; no current new full acceptance inferred'},indent=2)+'\n')
 sources={}
 folders=[('whole-current-c30','/tmp/G04-c30-whole-hosted-curl-20261009'),('actual-exhaustive','/tmp/G04-keep3-utf16-actual-20261009'),('independent-reader-control','/tmp/G04-keep3-utf16-independent-reader-control-v2-20261009'),('failed-extra-length-oracle','/tmp/G04-keep3-utf16-fixed-20261009'),('actual-supplementary-catalog','/tmp/G04-keep3-supplementary-catalog-actual-20261009'),('corrected-local-pipeline','/tmp/G04-keep3-utf16-fixed-v2-20261009')]
 for label,folder in folders:
  for p in sorted(Path(folder).iterdir()):
   if p.is_file() and p.name!='complete-job.log':sources[label+'/'+p.name]=p
 for pattern in ['G04-keep3-*20261009.py','G04-keep3-*20261009.mjs','G04-keep3-*20261009.json','G04-keep3-*20261009.txt']:
  for p in sorted(Path('/tmp').glob(pattern)):sources['helpers/'+p.name]=p
 for p in [Path('/tmp/G04-keep2-qualified-c30-20261009.json'),Path('/tmp/G04-c30-whole-hosted-curl-20261009.py'),Path('/tmp/G04-0ad-cadence-explicit-supplement-20261009.json'),base/'original-product-source-bridge.json']:
  sources['helpers/'+p.name]=p
 for label,folder in [('prior-source-publication','/tmp/G04-keep2-source-publication-20261009'),('prior-main-refresh','/tmp/G04-main-refresh-c30-20261009')]:
  for name in ['receipt.json','current-source-guards.json','fixed-inputs-exact.json','CLAIMS.before','CLAIMS.after']:
   p=Path(folder)/name
   if p.exists():sources[label+'/'+name]=p
 for name in ['NEXT.md','LOOP.md','VERIFY.md','ASSUMPTIONS.md']:sources['historical/'+name]=job/name
 archive=out/'proof.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,p in sources.items():z.writestr(name,p.read_bytes())
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and len(z.namelist())==len(sources)
  for name,p in sources.items():assert z.read(name)==p.read_bytes()
 info={'assembledAt':utc(),'members':len(sources),'bytes':archive.stat().st_size,'sha256':digest(archive)['sha256'],'allMembersFullReadCRCPhysicalByteCompared':True,'wholeOfficialC30Included':True,'qualifiedNewRounds':2,'noGainStreak':1,'round3':'local verification gain0, prospective second no-gain pending exact new source original full','originalProductInputsUnchanged':len(originals),'noLocalBrowserOrNativeTiming':True}
 (out/'archive.json').write_text(json.dumps(info,indent=2)+'\n')
 (out/'README.md').write_text("""# KEEP3 text admission boundaries
An independent code-unit decoder matches the actual write schema and catalog factory
over all 65,536 single units, all 1,048,576 valid surrogate pairs, 5,120 adjacent
edges, 1,003 additional seeded strings and 455 catalog controls: 1,120,690 saved rows.
Python independently reads the complete gzip EOF and checks every row using its
strict UTF16 decoder. There are 2,517 actual malformed-input refusals with valid
retries, 210 expected catalog refusals, and no discrepancies. The original raw
gzip is 10,324,975 bytes, SHA f450abe5087a1fc747a83304b3988f08151b419e993323fb04e79b6381135949.

The new regression first failed an extra length assumption: pinned Zod4.6.5 counts
raw Unicode code points, whereas the existing normalized storage/UI bound counts
UTF16 units. The exact failed test, installed public source, logs and wrapper are
preserved. This is an oracle/prose correction, not a product change. A failed
wrapper's generic source flags are not observed changes; all 3,839 physical guards
were independently byte equal before correction. The output-directory allocation
error before the separate reader launched is also retained.

Distinct actual controls cover 24 raw length edges and 14 catalog boundaries.
Nine full games with maximum admitted supplementary-plane catalogs finish with
1,560 legal replay events, 432 writes, 108 rounds and exact independent scores.
Every saved state stays under the unchanged 262,144-byte limit; peak 158,015 bytes.
The corrected permanent test adds independent codepoint counting plus actual
normalized storage refusals and valid emoji boundaries. Local 36 focused/four
original strict controls/types/data/fixtures/two builds/benign equality pass.
No product, page, bot, original oracle, sampler, gate or clock changes.
Genuine current c30 original full proof is included; new source still needs its own
full original workflow and whole official archive. KEEP3 is only prospective second
no-player-gain until that acceptance. PR18 remains Draft.
""")
 (job/'NEXT.md').write_text("""# G04 supplemental follow-up handoff
Owner codex-reality-followup-20261009; branch job/G04-reality-check-followup-20261009;
Draft PR18 targets preserved Ready PR14/738de72b. Original README/RULES/JOBS,
contract, game rules and four pinned research sources read. Preserve canonicalPR4,
old Ready source/three-no-gain stop, every raw failure and all unique G10 licensed
HTML/data/dependencies. New work/metadata/dependencies are isolated under /tmp.

Last actual published source c30d484ebba82df137893e238b7e6b5948603736 normal push
12:09:02.150422Z/readback12:09:02.904300Z; interval1087.224057s EARLY/HARD PASS.
Own main265f5d695f753f6d81773b1fc918185fd5ce7659 row12:11:22Z, normal push
12:11:24.930192Z/readback12:11:25.530613Z; every foreign row/tree byte equal,
literal G10 BLOCKED preserved, lease released. For this next material milestone:
early12:34:02.150422Z/hard12:39:02.150422Z. Its actual source publication receipt
resets the 30-minute window; fresh-read remote commit and request own-row main lease.
Historical e32->0ad early target was missed105.733498s; hard30 passed. Original
receipt and explicit supplement stay exact; no retroactive earlier time.

Fix history: raw normalization growth160->2880 stored/max676419 bytes; unwritable
accepted catalog truth162 units; malformed text/catalog maximum33 states oversized,
max288469. Integrated0ad rejects normalized oversize/malformed writes and malformed
or binary catalog controls while retaining valid emoji, whitespace, C0 write
cleanup and casefold/scoring/bot/timer behavior. KEEP1 actual player robustness gain
qualified by genuine0ad whole original11:59:05.436258Z. Current c30 genuine original
accepted12:16:38.815738Z/run37928163178/artifact11614872418/full1433337 bytes/
SHA e387a93e5146ecc97663985673ce15608b4c595b93d682ffc18132fc44f2473f.
Complete58-test log/25 mutant kills, unchanged reader all1034 public module/source
guards,3000 native intervals,66 controls and five full VP8 decodes pass; all284
reception inputs unchanged/natural closure/no signals. KEEP2 independent Unicode
credit audit1003 games/4012 rounds/48106 events/Python awards/replay exact qualifies
first no-player-gain. Completed new rounds2/no-gain streak1. Historical proof stays
historical for the new test source.

KEEP3 five weaknesses: UTF16 admission boundaries; Unicode refusal/private paths;
custom catalog text; physical phone approximation; future engine/content ABI.
Worst: exhaustive independent decoder/factory coverage. Actual pure producer all
65536 singles+1048576 pairs+5120 edges+1003 random+455 catalog cases=1120690 rows.
Zero discrepancies;2517 actual malformed refusals with valid retries;210 catalog
refusals. Natural closure12:20:39.087683Z/all3840 guards/145997824B<256MiB180s.
Complete gzip10324975B/SHA f450abe5087a1fc747a83304b3988f08151b419e993323fb04e79b6381135949;
Python strict UTF16 whole EOF12:22:19.475306Z/all6 physical reader inputs unchanged;
independent wrapper closure12:22:20.402726Z/all3843 guards/14024704B/natural empty.

Important actual semantic correction: Zod4.6.5 raw .max(160) counts Unicode code
points; normalized storage/UI use160 UTF16 units. Earlier raw-limit prose assumed
they matched. The first new permanent test35 pass/1 fail is preserved with original
test/public Zod source and actual3839 unchanged guard supplement; it failed an
extra oracle assumption, not the reducer. The separate initial reader output
allocation failed before any child/guard started; original helper/output preserved.
Corrected test counts code points independently and checks that schema-admitted
oversize normalized text is still refused without locking a seat.
Distinct admitted supplementary-plane catalog controls:9 full games/108 rounds/
1560 legal replay events/432 writes,24 raw length edges/14 catalog boundaries;
max158015<unchanged262144, independent scores and all replay hashes exact.
Actual closure12:28:13.801737Z/all3840 guards/87220224B<256MiB180s/natural empty.
Corrected local pipeline36 focused/four original strict/types/data/two fixtures/
two identical builds/freshness/checksums/42 benign3395 states+10000 matching cases
PASS12:29:02.179987Z/all3839 guards/no output changes/431558656B<512MiB60s.
Product/reducer/page/catalog/scoring/bots/UI/original oracle/workflow/contract stay
byte equal to genuine c30. Full actual proof/failures/official c30 in
results/keep3-utf16-boundaries-20261009/proof.zip. No local native/frame timing.

NEXT: exact new-head original complete workflow plus genuine whole official ZIP/
decoded log/unchanged reader all1034/3000/66/five clips. KEEP3 player gain0 remains
prospective second no-gain until accepted. Then re-read the job, five weaknesses,
fix/measure/push a meaningful KEEP4 inquiry; need three consecutive qualified
no-player-gain rounds before Ready. Current completed2/streak1; do not reuse old
stop or count any failed observer/oracle. Original state, workload, performance,
bot, research/data and random gates immutable. No unchanged native timing retry.
""")
 with (job/'LOOP.md').open('a') as f:f.write("""
KEEP2 qualification | genuine exact c30 whole original accepted12:16:38.815738Z/run37928163178/full1433337B SHAe387a93e5146ecc97663985673ce15608b4c595b93d682ffc18132fc44f2473f | unchanged-product independent credit coverage, player gain0 | completed new rounds2/no-gain streak1; no failed observer counts.
3 follow-up | five weaknesses: UTF16 boundary coverage; Unicode refusal/private paths; admitted catalogs; physical phone; future ABI | worst: independent decoder/regression and admitted maximum controls |1120690 complete cases/Python strict decoder exact/2517 refusals+retries/455 catalogs;9 full maximum admitted games1560 legal events/max158015<262144;36 focused/four original strict/types/data/build/3839 guards pass; raw codepoint versus stored UTF16 assumption corrected with failed test preserved | player gain0, prospective second no-gain pending genuine changed-head full; completed2/streak1; no product/clock change.
""")
 with (job/'VERIFY.md').open('a') as f:f.write("""
## KEEP3 independent text validation and admitted storage maxima
Complete exact commands/helpers/specs/raw/failures/guards/closure/whole current c30
in results/keep3-utf16-boundaries-20261009/proof.zip, all full CRC/physical comparisons.
Node24 finite256MiB180s producer:1120690 saved rows (65536 singles/1048576 paired/
5120 edges/1003 new seeds/455 catalog cases), zero independent decoder/schema/
factory discrepancies;2517 actual malformed refusals+retries;210 expected catalog
refusals.3840 guards unchanged/natural12:20:39.087683Z/peak145997824B/no signals.
Python strict UTF16 whole gzip EOF1120690 rows PASS12:22:19.475306Z,all6 input
guards unchanged; wrapper3843 guards/natural12:22:20.402726Z/peak14024704B.
Gzip10324975B SHA f450abe5087a1fc747a83304b3988f08151b419e993323fb04e79b6381135949.
Extra permanent test actual35pass/1fail raw161UTF16-unit/160-codepoint assumption;
original failed test/Zod4.6.5 checks.ts/source/log retained. Independent3839 guards
all equal12:24:20.215253Z; generic failed-wrapper booleans do not show mutations.
Correct only raw length oracle to pinned codepoints; storage limit still160 units.
Initial independent-wrapper existing-directory allocation failed before any child,
original helper/tool output preserved; corrected output path only.
Distinct Node finite256MiB180s maximum actual admitted 4byte catalogs/3byte fakes:
9 games108 rounds1560 legal events432 writes/max158015<262144/all independent
scores/replay exact;24 raw length/14 catalog-boundary controls;all3840 guards,
natural12:28:13.801737Z/peak87220224B/no signals.
Corrected Node36 focused/four strict/types/data/2 fixtures/2 builds/freshness/
checksums/42 benign3395states+10000 matching cases PASS12:29:02.179987Z;
3839 unchanged inputs/no output changes/peak431558656B<512MiB60s phasebound.
Original current c30 complete58test/25mutants/genuine full1433337B official accepted
12:16:38.815738Z, unchanged reader all1034/3000 intervals/66controls/five VP8 clips.
Current new test source requires original full again. No local browser/frameclock.
""")
 with (job/'ASSUMPTIONS.md').open('a') as f:f.write("""
## KEEP3 raw codepoints versus normalized UTF16 storage
Actual pinned Zod4.6.5 checks.ts explicitly counts raw Unicode codepoints for string
min/max; earlier statements equating raw socket max160 with UTF16 were incorrect.
The reducer's existing normalized text.length<=160 and UI maxlength160 are UTF16,
so a raw160-codepoint/320-unit emoji write can validate yet remains refused before
storage. The catalog's normalized bluff truth uses the same writable bound.
The first new test failure and original prose are preserved, not relabeled PASS.
Correct only the independent length oracle; no raw admission rule, product, state
cap, clock, sampler or original10k oracle is altered. Whole supplementary-plane
catalog fields may contain up to two UTF16 units per raw codepoint; new actual
maximum controls cover that admitted space, not only the earlier BMP maxima.
C0 binary catalog controls refuse; tabs/LF/CR and C1 retain their actual original
admission. No invented all-control rejection claim. Paired Unicode remains valid.
Supplemental round qualification is separate from immutable generic receiver
fields; current completed2/no-gain1, KEEP3 prospective second until new full.
""")
 node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
 run('checksums-write',[node,'checksums.ts'],job);run('checksums-check',[node,'checksums.ts','--check'],job)
 assert [digest(p) for p in stable]==before
 (base/'fixed-inputs-exact.json').write_text(json.dumps({'at':utc(),'allStableInputsByteEqual':True,'rows':before},indent=2)+'\n')
 changes=run('scope-diff',['git','diff','--name-only']).decode().splitlines();assert all(p.startswith('jobs/G04-reality-check/') for p in changes)
 assert headremote()==parent
 run('stage',['git','add','--','jobs/G04-reality-check'])
 staged=run('staged-scope',['git','diff','--cached','--name-only']).decode().splitlines();assert staged and all(p.startswith('jobs/G04-reality-check/') for p in staged)
 run('commit',['git','commit','-m','G04: verify Unicode admission over the full UTF16 repertoire'])
 newhead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip();assert subprocess.check_output(['git','rev-parse','HEAD^'],cwd=repo).decode().strip()==parent
 assert headremote()==parent
 run('normal-push',['git','push','origin','HEAD:refs/heads/'+branch]);pushed=steps[-1]['closedAt']
 assert headremote()==newhead;readback=utc()
 assert run('clean-status',['git','status','--porcelain'])==b''
 guards=[digest(repo/x.decode()) for x in subprocess.check_output(['git','ls-files','-z','jobs/G04-reality-check','contract','.github/workflows/G04.yml'],cwd=repo).split(b'\0') if x]
 (base/'current-source-guards.json').write_text(json.dumps({'at':utc(),'sourceHead':newhead,'rows':guards},indent=2)+'\n')
 previous=datetime.datetime.fromisoformat('2026-10-09T12:09:02.150422+00:00');actual=datetime.datetime.fromisoformat(pushed);delta=(actual-previous).total_seconds()
 status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':utc(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':started,'closedAt':utc(),'parent':parent,'sourceHead':locals().get('newhead'),'branch':branch,'actualNormalSourcePushClosedAt':locals().get('pushed'),'exactRemoteReadbackClosedAt':locals().get('readback'),'normalExpectedHeadFastForwardOnly':status=='CLOSED_PASS','cadenceIntervalSeconds':locals().get('delta'),'early25TargetPassed':locals().get('delta',99999)<=1500,'hard30LimitPassed':locals().get('delta',99999)<=1800,'hard30LatenessSeconds':max(0,locals().get('delta',1800)-1800),'nextEarly25Utc':(actual+datetime.timedelta(seconds=1500)).isoformat() if 'actual' in locals() else None,'nextHard30Utc':(actual+datetime.timedelta(seconds=1800)).isoformat() if 'actual' in locals() else None,'publicArchive':locals().get('info'),'qualifiedCompletedNewRounds':2,'qualifiedNoGainStreak':1,'round3':'verification-only prospective second no-gain, exact changed-head original full pending','currentFullOriginalAccepted':False,'workingTreeClean':status=='CLOSED_PASS','noLocalNativeTiming':True}
 (base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');(base/'steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(r),flush=True)
