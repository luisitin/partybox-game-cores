import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import * as C from '/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/core.ts';
import * as S from '/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/samples.ts';
import {cleanText} from '/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/scoring.ts';
const output=process.argv[2],digest=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
const context=(seed,mode)=>({players:Array.from({length:8},(_,i)=>({id:'p'+i,name:'Seat '+(i+1),avatarId:'🙂',connected:true})),seed,now:0,settings:{mode,rounds:12}});
const timer=s=>({type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline});
const fillPoints=(prefix,glyph,max)=>[...(prefix+glyph.repeat(max))].slice(0,max).join('');
let state=C.init(context(91,'bluff'));for(let i=0;i<12&&state.phase.id!=='write';i++)state=C.reduce(state,timer(state));assert.equal(state.phase.id,'write');
const lengthCases=[];
for(const glyph of ['x','🧭','\ufdfa','界'])for(const count of [79,80,81,159,160,161]){
 const text=glyph.repeat(count),points=[...text].length,clean=cleanText(text),expectedSchema=points<=160;
 const schema=C.inputSchema.safeParse({type:'write',text}).success;assert.equal(schema,expectedSchema);
 const next=C.reduce(state,{type:'input',playerId:'p0',input:{type:'write',text},now:state.phase.startedAt+1});
 const expectedStore=expectedSchema&&clean.length<=160&&clean.length>0;
 assert.equal(next!==state,expectedStore);if(expectedStore)assert.equal(next.responses.p0,clean);
 lengthCases.push({glyphCodePoint:glyph.codePointAt(0),repeat:count,rawPoints:points,rawUnits:text.length,cleanUnits:clean.length,actualSchemaAccepted:schema,actualStored:next!==state,expectedStore,retry:C.reduce(state,{type:'input',playerId:'p0',input:{type:'write',text:'valid retry'},now:state.phase.startedAt+1}).responses.p0});
}
const catalogLimits={id:80,prompt:240,hint:200,fact:90,left:80,right:80,correct:80},catalogBoundaries=[];
for(const [field,limit] of Object.entries(catalogLimits))for(const count of [limit,limit+1]){
 const row={...S.sampleRows.find(r=>r.kind===(field==='left'||field==='right'?'choice':'bluff')),[field]:'🧭'.repeat(count)};
 const expected=count<=limit,actual=S.rowSchema.safeParse(row).success;assert.equal(actual,expected);
 catalogBoundaries.push({field,points:count,units:count*2,expected,actual});
}
const rows=S.makeSamples().map(row=>{
 const common={...row,id:fillPoints(row.id,'🧭',80),prompt:'🧭'.repeat(240),hint:'🧭'.repeat(200),fact:'🧭'.repeat(90)};
 if(row.kind==='bluff')return {...common,correct:fillPoints('Truth ','界',160)};
 if(row.kind==='choice')return {...common,left:'🧭'.repeat(80),right:'🧭'.repeat(80)};
 return common;
});
const game=C.createGame(rows),summaries=[];let totalEvents=0,totalWrites=0,totalRounds=0,globalPeak=0;
for(const mode of ['quick','mixed','bluff'])for(const seed of [1,2,3]){
 const ctx=context(seed,mode);let s=game.init(ctx),peak=0,scored=0;const events=[],totals=Object.fromEntries(s.seats.map(id=>[id,0]));
 const submit=event=>{const before=digest(s);s=game.reduce(s,event);const bytes=Buffer.byteLength(JSON.stringify(s));peak=Math.max(peak,bytes);assert(bytes<=262144);events.push({event,before,after:digest(s),stateBytes:bytes});totalEvents++;};
 for(let step=0;s.phase.id!=='done'&&step<350;step++){
  if(s.phase.id==='answer'){
   const answer=Number(s.question.correct);for(const id of [...s.seats])submit({type:'input',playerId:id,input:{type:'answer',value:answer},now:s.phase.startedAt+1});assert.equal(s.phase.id,'reveal');
  }else if(s.phase.id==='write'){
   for(const [i,id] of [...s.seats].entries()){const text=('f'+i+' '+'界'.repeat(160)).slice(0,160);submit({type:'input',playerId:id,input:{type:'write',text},now:s.phase.startedAt+1});assert.equal(s.responses[id],text);totalWrites++;}
   assert.equal(s.phase.id,'vote');assert.equal(s.options.length,9);
  }else if(s.phase.id==='vote'){
   const ids=[...s.seats],options=structuredClone(s.options);
   for(const [i,id] of ids.entries()){const option=options.find(o=>o.owners.includes(ids[(i+1)%8]));assert(option);submit({type:'input',playerId:id,input:{type:'vote',choice:option.id},now:s.phase.startedAt+1});}
   assert.equal(s.phase.id,'reveal');
  }else submit(timer(s));
  if(s.phase.id==='reveal'&&s.last.round>scored){
   const points=(s.last.kind==='bluff'?500:1000)*(s.last.round===12?2:1);
   for(const id of s.seats){assert.equal(s.last.awards[id],points);totals[id]+=points;}
   assert.deepEqual(s.scores,totals);scored=s.last.round;totalRounds++;
  }
 }
 assert.equal(s.phase.id,'done');assert.equal(scored,12);assert.equal(s.history.length,12);assert.deepEqual(game.results(s).scores,totals);
 let replay=game.init(ctx);for(const item of events){assert.equal(digest(replay),item.before);replay=game.reduce(replay,item.event);assert.equal(digest(replay),item.after);assert.equal(Buffer.byteLength(JSON.stringify(replay)),item.stateBytes);}
 assert.deepEqual(replay,s);const raw=Buffer.from(JSON.stringify({context:ctx,events,finalState:s,results:game.results(s),independentScores:totals}));
 const compressed=gzipSync(raw),name='max-four-byte-'+mode+'-'+seed+'.json.gz';writeFileSync(output+'/'+name,compressed);
 summaries.push({mode,seed,events:events.length,peakStateBytes:peak,rawBytes:raw.length,gzipBytes:compressed.length,gzipSHA256:createHash('sha256').update(compressed).digest('hex'),allLegalReplayHashesEqual:true,independentFinalScores:totals});
 globalPeak=Math.max(globalPeak,peak);
}
const report={status:'PASS',scope:'actual pinned Zod codepoint raw bounds vs existing stored UTF16 bounds; full maximum supplementary-plane admitted catalogs and three-byte stored fakes; no product change or timing',lengthCases,catalogBoundaries,games:summaries.length,totalEvents,totalWrites,totalRounds,peakStateBytes:globalPeak,allGamesDone:true,allReplaysExact:true,allIndependentScoresEqual:true,originalStateCapBytes:262144,rawZodMaxPoints:160,storedMaxUtf16Units:160,summaries};
writeFileSync(output+'/actual-supplementary-catalog-report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({...report,lengthCases:report.lengthCases.length,catalogBoundaries:report.catalogBoundaries.length,summaries:undefined}));
