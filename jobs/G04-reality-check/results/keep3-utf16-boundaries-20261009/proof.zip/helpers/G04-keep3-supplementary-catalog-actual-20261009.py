from pathlib import Path
import subprocess,datetime,time,os,json,hashlib,traceback,signal,ctypes
repo=Path('/tmp/game-cores-G04-followup-20261009');job=repo/'jobs/G04-reality-check'
old=Path('/workspace/game-cores-G04-audit-20261009')
base=Path('/tmp/G04-keep3-supplementary-catalog-actual-20261009');base.mkdir(exist_ok=False)
node=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')
driver=Path('/tmp/G04-keep3-supplementary-catalog-prospective-20261009.mjs')
t=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def tracked(root):
 return [root/x.decode() for x in subprocess.check_output(['git','ls-files','-z','jobs/G04-reality-check','contract','.github/workflows/G04.yml'],cwd=root).split(b'\0') if x]
paths=tracked(repo)+tracked(old)
for root in [job/'node_modules',repo/'contract/node_modules/zod']:
 paths+=sorted(p for p in root.rglob('*') if p.is_file())
paths+=sorted(p for p in (old/'jobs/G04-reality-check/node_modules/zod').resolve().rglob('*') if p.is_file())
paths+=[node.resolve(),driver,Path(__file__).resolve(),Path('/tmp/G04-keep3-supplementary-catalog-prospective-20261009.json')]
paths=list(dict.fromkeys(paths));before=[digest(p) for p in paths]
(base/'before.json').write_text(json.dumps({'at':t(),'rows':before},indent=2)+'\n')
fixtures=[p for p in paths if str(p).startswith(str(job/'fixtures')+'/')]
fixtureBefore={str(p):digest(p)['sha256'] for p in fixtures}
steps=[];status='CLOSED_FAILED';started=t();allSignals=[];sampledPeak=0
def group(pid):
 rows=[]
 for entry in Path('/proc').iterdir():
  if not entry.name.isdigit():continue
  try:
   raw=(entry/'stat').read_text();tail=raw[raw.rfind(')')+2:].split()
   if int(tail[2])==pid:rows.append({'pid':int(entry.name),'rss':int(tail[21])*os.sysconf('SC_PAGE_SIZE'),'state':tail[0]})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return rows
def run(name,args,extra=None):
 global sampledPeak
 start=t();s=time.monotonic();samples=[];signals=[];env=dict(os.environ)
 if extra:env.update(extra)
 with (base/(name+'.stdout.log')).open('wb') as out,(base/(name+'.stderr.log')).open('wb') as err:
  p=subprocess.Popen(args,cwd=job,env=env,stdout=out,stderr=err,start_new_session=True)
  while p.poll() is None:
   owned=group(p.pid);rss=sum(x['rss'] for x in owned);sampledPeak=max(sampledPeak,rss)
   samples.append({'at':t(),'owned':owned,'rss':rss})
   if rss>256*1024*1024 or time.monotonic()-s>180:
    signals.append({'at':t(),'signal':'SIGTERM','why':'declared256MiB/180s bound'})
    os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5);break
   time.sleep(.025)
  code=p.returncode
  for _ in range(80):
   for row in group(p.pid):
    try:os.waitpid(row['pid'],os.WNOHANG)
    except ChildProcessError:pass
   if not group(p.pid):break
   time.sleep(.025)
  closed=group(p.pid)
 r={'name':name,'argv':args,'startedAt':start,'closedAt':t(),'actualExitCode':code,'naturalClosed':code==0 and not signals and closed==[],'signals':signals,'finalOwnedGroup':closed,'sampledPeakOwnedRssBytes':max([x['rss'] for x in samples] or [0])}
 (base/(name+'.resource-process.json')).write_text(json.dumps({'receipt':r,'samples':samples},indent=2)+'\n')
 steps.append(r);allSignals.extend(signals);print(json.dumps(r),flush=True)
 assert r['naturalClosed'],r
 return (base/(name+'.stdout.log')).read_bytes()
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()=='c30d484ebba82df137893e238b7e6b5948603736'
 full=json.loads(Path('/tmp/G04-c30-whole-hosted-curl-20261009/receipt.json').read_text());assert full['status']=='CLOSED_PASS' and full['sourceHead']=='c30d484ebba82df137893e238b7e6b5948603736'
 memmax=int(Path('/sys/fs/cgroup/memory.max').read_text());memcurrent=int(Path('/sys/fs/cgroup/memory.current').read_text())
 assert memmax-memcurrent>256*1024*1024+128*1024*1024,'No fresh resource headroom for declared untimed work'
 (base/'fresh-resource.json').write_text(json.dumps({'at':t(),'memoryMax':memmax,'memoryCurrent':memcurrent,'requiredOwnBytes':256*1024*1024,'reserveBytes':128*1024*1024,'noQuietOrNativeTiming':True},indent=2)+'\n')
 run('supplementary-catalog-state-replay',[str(node),str(driver),str(base)])
 final=[digest(p) for p in paths];assert before==final
 report=json.loads((base/'actual-supplementary-catalog-report.json').read_text());assert report['games']==9 and report['totalRounds']==108 and report['allGamesDone'] and report['allReplaysExact'] and report['allIndependentScoresEqual'] and report['peakStateBytes']<=262144
 (base/'after.json').write_text(json.dumps({'at':t(),'rows':final},indent=2)+'\n')
 changed=[];status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':t(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 alwaysFinal=[digest(p) for p in paths];alwaysEqual=alwaysFinal==before
 (base/'always-final-guards.json').write_text(json.dumps({'at':t(),'equalBefore':alwaysEqual,'rows':alwaysFinal},indent=2)+'\n')
 r={'status':status,'startedAt':started,'closedAt':t(),'guardRows':len(before),'originalReadySourceUnchanged':all(a==b for a,b in zip(before,alwaysFinal) if a['path'].startswith(str(old)+'/')),'allOtherInputBytesUnchanged':alwaysEqual,'declaredMutableOutputs':[],'actualChangedDuringPipeline':locals().get('changed'),'allSevenFixturesUnchanged':status=='CLOSED_PASS','newBuildExecuted':False,'pureBeforeAfterEqual':status=='CLOSED_PASS','strictProofControlsUnchanged':True,'localSavedOnlyInquiry':True,'currentC30OriginalWholeAcceptedBeforeInquiry':True,'noBrowserOrNativeTiming':True,'perPhaseOwnedRssLimitBytes':256*1024*1024,'perPhaseTimeoutSeconds':180,'sampledPeakOwnedRssBytes':sampledPeak,'naturalClosure':status=='CLOSED_PASS' and not allSignals,'allSignals':allSignals,'steps':steps}
 (base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({k:v for k,v in r.items() if k!='steps'}),flush=True)
