import assert from 'node:assert/strict';
import {createWriteStream,readFileSync,writeFileSync,statSync} from 'node:fs';
import {createGzip} from 'node:zlib';
import {once} from 'node:events';
import {createHash} from 'node:crypto';
import path from 'node:path';
const repo='/tmp/game-cores-G04-followup-20261009',job=repo+'/jobs/G04-reality-check',base=process.argv[2];
const C=await import(job+'/core.ts'),S=await import(job+'/samples.ts'),T=await import(job+'/scoring.ts');
const spec=JSON.parse(readFileSync('/tmp/G04-keep3-utf16-prospective-20261009.json','utf8'));
assert.equal(spec.sourceHead,'c30d484ebba82df137893e238b7e6b5948603736');
function manual(units){for(let i=0;i<units.length;i++){const u=units[i];if(u>=0xd800&&u<=0xdbff){if(i+1>=units.length||units[i+1]<0xdc00||units[i+1]>0xdfff)return false;i++;}else if(u>=0xdc00&&u<=0xdfff)return false;}return true;}
const raw=createWriteStream(path.join(base,'actual-utf16-cases.jsonl.gz')),gzip=createGzip({level:6});gzip.pipe(raw);
let ordinal=0,well=0,bad=0,refused=0,retried=0,catalogCases=0,catalogRejected=0;
const digest=createHash('sha256');const counts={single:0,pair:0,edge:0,random:0,catalog:0};
let state=C.init({players:Array.from({length:8},(_,i)=>({id:'p'+i,name:'Seat '+(i+1),avatarId:'🙂',connected:true,bot:true})),seed:91,now:0,settings:{mode:'bluff',rounds:4}});
const timer=s=>({type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline});
for(let i=0;i<12&&state.phase.id!=='write';i++)state=C.reduce(state,timer(state));
assert.equal(state.phase.id,'write');const unchanged=JSON.stringify(state);
async function record(row){row.ordinal=ordinal++;const line=JSON.stringify(row)+'\n';digest.update(line);if(!gzip.write(line))await once(gzip,'drain');}
async function check(family,index,units,extra={}){
 assert(units.length>=1&&units.length<=160);
 const text=String.fromCharCode(...units),expected=manual(units),actual=T.isWellFormedText(text),schema=C.inputSchema.safeParse({type:'write',text}).success;
 assert.equal(actual,expected);assert.equal(schema,expected);counts[family]++;if(expected)well++;else bad++;
 let refusal=null;
 if(!expected&&(family==='single'||family==='random')){
  const event={type:'input',playerId:'p0',input:{type:'write',text},now:state.phase.startedAt+1};
  assert.equal(C.reduce(state,event),state);assert.equal(JSON.stringify(state),unchanged);refused++;
  const retry=C.reduce(state,{...event,input:{type:'write',text:'valid retry'}});
  assert.equal(retry.responses.p0,'valid retry');assert.equal(state.responses.p0,undefined);retried++;
  refusal={sameIdentity:true,sameSerializedState:true,deadline:state.phase.deadline,validRetryStored:'valid retry'};
 }
 await record({family,index,units,expectedWellFormed:expected,actualWellFormed:actual,writeSchemaAccepted:schema,refusal,...extra});
}
for(let unit=0;unit<65536;unit++)await check('single',unit,[65,unit]);
for(let high=0;high<1024;high++)for(let low=0;low<1024;low++)await check('pair',high*1024+low,[65,0xd800+high,0xdc00+low]);
for(let i=0;i<1024;i++){
 const h=0xd800+i,l=0xdc00+((i*37)&1023),h2=0xd800+((i*13)&1023),l2=0xdc00+((i*19)&1023);
 for(const [kind,units] of [[0,[65,h,l,h]],[1,[65,h,h2,l]],[2,[65,l,h,l]],[3,[65,h,l,h2,l2]],[4,[65,l]]])await check('edge',i*5+kind,units,{edgeKind:kind});
}
let rng=spec.randomSamplerSeed>>>0;const next=()=>rng=(Math.imul(rng,1664525)+1013904223)>>>0;
const seeds=[1,2,3];const seen=new Set(seeds);
while(seeds.length<1003){const seed=next();if(!seen.has(seed)){seen.add(seed);seeds.push(seed);}}
for(const [index,seed] of seeds.entries()){
 let r=seed>>>0;const rn=()=>r=(Math.imul(r,1664525)+1013904223)>>>0;const units=[65],length=1+(rn()%159),mode=index%4;
 if(mode===3){while(units.length<length)units.push(65+rn()%26);units.push(0xd800);if(units.length>160)units.splice(1,1);}
 else while(units.length<length){
  let u=rn()&65535;
  if(mode===0&&u>=0xd800&&u<=0xdfff)u=32;
  if(mode===1&&units.length+2<=length){units.push(0xd800+(u&1023),0xdc00+((rn()>>>8)&1023));continue;}
  if(mode===1)u=65;
  units.push(u);
 }
 await check('random',index,units,{seed,mode});
}
const controls=[...Array.from({length:32},(_,i)=>i),127,...Array.from({length:32},(_,i)=>128+i)];
const binary=u=>(u<=8||u===11||u===12||(u>=14&&u<=31)||u===127);
for(const code of controls)for(const [fieldIndex,field] of ['id','prompt','hint','fact','correct','left','right'].entries()){
 const rows=S.makeSamples(),row=rows.find(r=>r.kind===(field==='left'||field==='right'?'choice':'bluff'));row[field]='Visible '+String.fromCharCode(code);
 const expected=!binary(code),schema=S.catalogSchema.safeParse(rows).success;
 let factory=true;try{C.createGame(rows);}catch{factory=false;}
 assert.equal(schema,expected);assert.equal(factory,expected);catalogCases++;if(!expected)catalogRejected++;counts.catalog++;
 await record({family:'catalog',index:(controls.indexOf(code)*7+fieldIndex),controlUnit:code,field,expectedAllowed:expected,schemaAccepted:schema,factoryAccepted:factory});
}
gzip.end();await once(raw,'close');
const archive=readFileSync(path.join(base,'actual-utf16-cases.jsonl.gz'));
const report={status:'PASS',sourceHead:spec.sourceHead,rows:ordinal,counts,wellFormedWriteCases:well,malformedWriteCases:bad,actualMalformedRefusals:refused,validRetryChecks:retried,catalogCases,catalogRejected,randomSeeds:seeds,randomSamplerSeed:spec.randomSamplerSeed,wholeDecodedJsonlSHA256:digest.digest('hex'),wholeGzipBytes:statSync(path.join(base,'actual-utf16-cases.jsonl.gz')).size,wholeGzipSHA256:createHash('sha256').update(archive).digest('hex'),allIndependentWellFormedAndSchemaChecksMatch:true,allFactoryControlsMatch:true,original160And262144CapsUnchanged:true,noGameBotClockChange:true,noNativeTiming:true};
writeFileSync(path.join(base,'actual-utf16-report.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,randomSeeds:undefined}));
