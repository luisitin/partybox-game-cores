from pathlib import Path
import subprocess,datetime,time,os,json,hashlib,traceback,signal,ctypes
repo=Path('/tmp/game-cores-G04-followup-20261009');job=repo/'jobs/G04-reality-check'
old=Path('/workspace/game-cores-G04-audit-20261009')
base=Path('/tmp/G04-keep3-utf16-fixed-v2-20261009');base.mkdir(exist_ok=False)
node=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')
driver=Path('/tmp/G04-keep1-text-validation-fixed-benign-20261009.mjs')
t=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def tracked(root):
 return [root/x.decode() for x in subprocess.check_output(['git','ls-files','-z','jobs/G04-reality-check','contract','.github/workflows/G04.yml'],cwd=root).split(b'\0') if x]
paths=tracked(repo)+tracked(old)
for root in [job/'node_modules',repo/'contract/node_modules/zod']:
 paths+=sorted(p for p in root.rglob('*') if p.is_file())
paths+=sorted(p for p in (old/'jobs/G04-reality-check/node_modules/zod').resolve().rglob('*') if p.is_file())
paths+=[node.resolve(),driver,Path(__file__).resolve()]
paths=list(dict.fromkeys(paths));before=[digest(p) for p in paths]
(base/'before.json').write_text(json.dumps({'at':t(),'rows':before},indent=2)+'\n')
fixtures=[p for p in paths if str(p).startswith(str(job/'fixtures')+'/')]
fixtureBefore={str(p):digest(p)['sha256'] for p in fixtures}
steps=[];status='CLOSED_FAILED';started=t();allSignals=[];sampledPeak=0
def group(pid):
 rows=[]
 for entry in Path('/proc').iterdir():
  if not entry.name.isdigit():continue
  try:
   raw=(entry/'stat').read_text();tail=raw[raw.rfind(')')+2:].split()
   if int(tail[2])==pid:rows.append({'pid':int(entry.name),'rss':int(tail[21])*os.sysconf('SC_PAGE_SIZE'),'state':tail[0]})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return rows
def run(name,args,extra=None):
 global sampledPeak
 start=t();s=time.monotonic();samples=[];signals=[];env=dict(os.environ)
 if extra:env.update(extra)
 with (base/(name+'.stdout.log')).open('wb') as out,(base/(name+'.stderr.log')).open('wb') as err:
  p=subprocess.Popen(args,cwd=job,env=env,stdout=out,stderr=err,start_new_session=True)
  while p.poll() is None:
   owned=group(p.pid);rss=sum(x['rss'] for x in owned);sampledPeak=max(sampledPeak,rss)
   samples.append({'at':t(),'owned':owned,'rss':rss})
   if rss>512*1024*1024 or time.monotonic()-s>60:
    signals.append({'at':t(),'signal':'SIGTERM','why':'declared512MiB/60s bound'})
    os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5);break
   time.sleep(.025)
  code=p.returncode
  for _ in range(80):
   for row in group(p.pid):
    try:os.waitpid(row['pid'],os.WNOHANG)
    except ChildProcessError:pass
   if not group(p.pid):break
   time.sleep(.025)
  closed=group(p.pid)
 r={'name':name,'argv':args,'startedAt':start,'closedAt':t(),'actualExitCode':code,'naturalClosed':code==0 and not signals and closed==[],'signals':signals,'finalOwnedGroup':closed,'sampledPeakOwnedRssBytes':max([x['rss'] for x in samples] or [0])}
 (base/(name+'.resource-process.json')).write_text(json.dumps({'receipt':r,'samples':samples},indent=2)+'\n')
 steps.append(r);allSignals.extend(signals);print(json.dumps(r),flush=True)
 assert r['naturalClosed'],r
 return (base/(name+'.stdout.log')).read_bytes()
try:
 memmax=int(Path('/sys/fs/cgroup/memory.max').read_text());memcurrent=int(Path('/sys/fs/cgroup/memory.current').read_text())
 assert memmax-memcurrent>512*1024*1024+128*1024*1024,'No fresh resource headroom for declared finite local checks'
 (base/'fresh-resource.json').write_text(json.dumps({'at':t(),'memoryMax':memmax,'memoryCurrent':memcurrent,'requiredOwnBytes':512*1024*1024,'reserveBytes':128*1024*1024,'noQuietOrNativeTiming':True},indent=2)+'\n')
 run('types',[str(node),'node_modules/typescript/bin/tsc','--noEmit'])
 run('generated-data-check',[str(node),'generate.ts','--check'])
 run('fixtures-first',[str(node),'fixtures.ts'])
 firstFixture={str(p):digest(p)['sha256'] for p in fixtures};assert firstFixture==fixtureBefore
 run('fixtures-second',[str(node),'fixtures.ts'])
 assert {str(p):digest(p)['sha256'] for p in fixtures}==firstFixture
 run('offline-first',[str(node),'build.ts']);firstPage=digest(job/'play.html')['sha256']
 run('offline-second',[str(node),'build.ts']);assert digest(job/'play.html')['sha256']==firstPage
 run('offline-freshness',[str(node),'build.ts','--check'])
 run('checksums-write',[str(node),'checksums.ts'])
 run('checksums-check',[str(node),'checksums.ts','--check'])
 run('focused-tests',[str(node),'--test','--test-reporter=tap','test.ts'],{'FAST_TEST':'1','CORE_PATH':'./core.ts'})
 run('original-strict-proof-controls',[str(node),'--test','--test-reporter=tap','strict-proof.test.ts'])
 stableBefore=[digest(p) for p in paths];(base/'pure-before.json').write_text(json.dumps({'at':t(),'rows':stableBefore},indent=2)+'\n')
 run('pure-reducer-equality',[str(node),str(driver),str(base)])
 stableAfter=[digest(p) for p in paths];assert stableBefore==stableAfter
 (base/'pure-after.json').write_text(json.dumps({'at':t(),'rows':stableAfter},indent=2)+'\n')
 final=[digest(p) for p in paths]
 allowed={str(job/'play.html'),str(job/'SHA256SUMS.txt')}
 changed=[a['path'] for a,b in zip(before,final) if a!=b];assert set(changed)<=allowed,changed
 assert all(a==b for a,b in zip(before,final) if a['path'].startswith(str(old)+'/')),'Ready source changed'
 (base/'after.json').write_text(json.dumps({'at':t(),'rows':final},indent=2)+'\n')
 status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':t(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 alwaysFinal=[digest(p) for p in paths]
 (base/'always-final-guards.json').write_text(json.dumps({'at':t(),'rows':alwaysFinal,'allSourceInputBytesEqual':before==alwaysFinal,'actualChanged':[a['path'] for a,b in zip(before,alwaysFinal) if a!=b]},indent=2)+'\n')
 r={'status':status,'startedAt':started,'closedAt':t(),'guardRows':len(before),'originalReadySourceUnchanged':all(a==b for a,b in zip(before,alwaysFinal) if a['path'].startswith(str(old)+'/')),'allOtherInputBytesUnchanged':all(a==b for a,b in zip(before,alwaysFinal) if a['path'] not in {str(job/'play.html'),str(job/'SHA256SUMS.txt')}),'declaredMutableOutputs':['play.html','SHA256SUMS.txt'],'actualChangedDuringPipeline':locals().get('changed'),'allSevenFixturesUnchanged':status=='CLOSED_PASS','doubleOfflineBuildByteEqual':status=='CLOSED_PASS','pureBeforeAfterEqual':status=='CLOSED_PASS','strictProofControlsUnchanged':True,'localFastTestOnly':True,'originalCompleteWorkflowStillRequired':True,'noBrowserOrNativeTiming':True,'perPhaseOwnedRssLimitBytes':512*1024*1024,'perPhaseTimeoutSeconds':60,'sampledPeakOwnedRssBytes':sampledPeak,'naturalClosure':status=='CLOSED_PASS' and not allSignals,'allSignals':allSignals,'steps':steps}
 (base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({k:v for k,v in r.items() if k!='steps'}),flush=True)
