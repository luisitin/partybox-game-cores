from pathlib import Path
import json,hashlib,datetime
base=Path('/tmp/G04-unicode-normalization-fixed-20261009')
old=Path('/tmp/G04-unicode-normalization-before-20261009')
t=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
rows=json.loads((old/'before.json').read_text())['rows'];oldafter=json.loads((old/'after.json').read_text())['rows'];assert rows==oldafter
actual=[]
for row in rows:
 p=Path(row['path']);h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 st=p.stat();actual.append({'path':str(p),'bytes':st.st_size,'sha256':h.hexdigest(),'immutableStat':[st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns]})
assert actual==rows
(base/'original-ready-source-dependency-supplement.json').write_text(json.dumps({'observedAt':t(),'guardRows':len(rows),'allOriginalSourceZodRuntimeAndEarlierHelpersUnchangedAcrossBothControls':True,'scope':'1106 original before/after physical immutable rows; supplements2987 fixed pipeline rows whose old Ready list did not separately enumerate old installed Zod','rows':actual},indent=2)+'\n')
log=Path('/tmp/G04-unicode-normalization-negative-20261009/stdout.log').read_bytes()
assert b'# tests 2\n' in log and b'# pass 0\n' in log and b'# fail 2\n' in log
assert b'expanded fake must not lock a submission' in log and b'oversized normalized fake is refused for every seat' in log
assert Path('/tmp/G04-unicode-normalization-negative-20261009/stderr.log').read_bytes()==b''
receipt={'observedAt':t(),'actualToolExitCode':1,'scope':'actual old-core negative output; no rerun','actualNegativeTests':2,'passed':0,'failed':2,'bothExpectedAssertionCausesPresent':True,'stdoutBytes':len(log),'stdoutSHA256':hashlib.sha256(log).hexdigest(),'stderrBytes':0,'originalReadyGuardsStillEqual':True,'fixedRegressionsRequireNewFullHostedWorkflow':True}
Path('/tmp/G04-unicode-normalization-negative-20261009/independent-output-reader.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'observedAt':t(),'originalReadyFullGuards':len(rows),'unchanged':True,'negativeOutput':receipt}),flush=True)

