import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const base=process.argv[2];
const core=await import(pathToFileURL('/workspace/game-cores-G04-audit-20261009/jobs/G04-reality-check/core.ts'));
const raw='\ufdfa'.repeat(160);
assert.equal(raw.length,160);assert(core.inputSchema.safeParse({type:'write',text:raw}).success);
const normalized=raw.normalize('NFKC').replace(/[\p{Cc}\p{Cf}]/gu,' ').trim().replace(/\s+/gu,' ');
const ctx={players:Array.from({length:8},(_,i)=>({id:'p'+i,name:'Seat '+(i+1),avatarId:'🙂',connected:true,bot:true})),seed:91,now:0,settings:{mode:'bluff',rounds:12}};
let state=core.init(ctx);const events=[],observations=[];
let acceptedWrites=0,maxResponseLength=0,maxStateBytes=0,maxStateStep=0;
function record(){
 const bytes=Buffer.from(JSON.stringify(state));const lengths=Object.values(state.responses).filter(v=>typeof v==='string').map(v=>v.length);
 maxResponseLength=Math.max(maxResponseLength,0,...lengths);
 if(bytes.length>maxStateBytes){maxStateBytes=bytes.length;maxStateStep=events.length;}
 observations.push({step:events.length,round:state.round,phase:state.phase.id,stateBytes:bytes.length,stateSHA256:createHash('sha256').update(bytes).digest('hex'),responseLengths:lengths});
}
function send(event){const before=state;events.push(event);state=core.reduce(state,event);record();return before!==state;}
record();
for(let i=0;i<500&&state.phase.id!=='done';i++){
 if(state.phase.id==='write'){
  for(const id of [...state.seats]){
   assert.equal(state.phase.id,'write');
   if(send({type:'input',playerId:id,input:{type:'write',text:raw},now:state.phase.startedAt+1}))acceptedWrites++;
  }
 }else if(state.phase.id==='vote'){
  const truth=state.options.find(o=>o.correct);assert(truth);
  for(const id of [...state.seats])if(state.phase.id==='vote')send({type:'input',playerId:id,input:{type:'vote',choice:truth.id},now:state.phase.startedAt+1});
 }else send({type:'timer',phaseId:state.phase.id,startedAt:state.phase.startedAt,now:state.phase.deadline});
}
assert.equal(state.phase.id,'done');assert.equal(acceptedWrites,96);
const report={status:'COUNTEREXAMPLE_CONFIRMED',sourceHead:'738de72b01fe9c7b1bb77141f9d54149d0b0693c',seed:91,players:8,rounds:12,mode:'bluff',inputCodePoint:'U+FDFA',inputLength:raw.length,inputSchemaAccepted:true,normalizedLength:normalized.length,acceptedWrites,maxResponseLength,maxStateBytes,maxStateStep,contractStateLimitBytes:256*1024,ruleFakeLimit:160,originalGameReachedDone:true,eventCount:events.length,finalResults:core.results(state),nativeTimingOrBrowser:false};
assert(maxResponseLength>160,'actual post-normalization limit violation required');
assert(maxStateBytes>256*1024,'actual saved-state contract violation required');
const replay={context:ctx,events,observations,finalState:state};
writeFileSync(base+'/actual-replay.json.gz',gzipSync(Buffer.from(JSON.stringify(replay)),{level:9}));
writeFileSync(base+'/actual-report.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report));

