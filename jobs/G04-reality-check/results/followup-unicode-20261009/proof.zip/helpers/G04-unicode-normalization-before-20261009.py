from pathlib import Path
import os,subprocess,time,datetime,json,hashlib,traceback,signal
repo=Path('/workspace/game-cores-G04-audit-20261009')
base=Path('/tmp/G04-unicode-normalization-before-20261009');base.mkdir(exist_ok=False)
node=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')
driver=Path('/tmp/G04-unicode-normalization-before-20261009.mjs')
t=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 st=p.stat()
 return {'path':str(p),'bytes':st.st_size,'sha256':h.hexdigest(),'immutableStat':[st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns]}
paths=[repo/x.decode() for x in subprocess.check_output(['git','ls-files','-z','jobs/G04-reality-check','contract','.github/workflows/G04.yml'],cwd=repo).split(b'\0') if x]
zod=(repo/'jobs/G04-reality-check/node_modules/zod').resolve()
paths+=sorted(p for p in zod.rglob('*') if p.is_file())
paths+=[node.resolve(),driver,Path(__file__).resolve()]
paths=list(dict.fromkeys(paths))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()=='738de72b01fe9c7b1bb77141f9d54149d0b0693c'
before=[digest(p) for p in paths];(base/'before.json').write_text(json.dumps({'at':t(),'rows':before},indent=2)+'\n')
started=t();status='CLOSED_FAILED';pid=None;peak=0;samples=[];sent=[]
def group(pid):
 rows=[]
 for entry in Path('/proc').iterdir():
  if not entry.name.isdigit():continue
  try:
   raw=(entry/'stat').read_text();tail=raw[raw.rfind(')')+2:].split()
   if int(tail[2])==pid:
    rss=int(tail[21])*os.sysconf('SC_PAGE_SIZE');rows.append({'pid':int(entry.name),'rss':rss,'state':tail[0]})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return rows
try:
 with (base/'stdout.log').open('wb') as out,(base/'stderr.log').open('wb') as err:
  p=subprocess.Popen([str(node),str(driver),str(base)],cwd=repo/'jobs/G04-reality-check',stdout=out,stderr=err,start_new_session=True)
  pid=p.pid;start=time.monotonic()
  while p.poll() is None:
   owned=group(pid);rss=sum(x['rss'] for x in owned);peak=max(peak,rss)
   samples.append({'at':t(),'elapsedSeconds':time.monotonic()-start,'owned':owned,'rss':rss})
   if rss>512*1024*1024 or time.monotonic()-start>60:
    sent.append({'at':t(),'signal':'SIGTERM','why':'declared resource/time bound'})
    os.killpg(pid,signal.SIGTERM);p.wait(timeout=5);raise AssertionError('declared bound exceeded')
   time.sleep(.025)
  exitcode=p.returncode
  assert exitcode==0,('actual child exit',exitcode)
  closed=group(pid);assert closed==[],closed
 report=json.loads((base/'actual-report.json').read_text())
 assert report['status']=='COUNTEREXAMPLE_CONFIRMED' and report['nativeTimingOrBrowser'] is False
 status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':t(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 after=[digest(p) for p in paths];(base/'after.json').write_text(json.dumps({'at':t(),'rows':after},indent=2)+'\n')
 guards=before==after
 (base/'resource-process.json').write_text(json.dumps({'samples':samples,'peakSampledOwnedRssBytes':peak,'limitOwnedRssBytes':512*1024*1024,'timeBudgetSeconds':60,'signals':sent,'finalOwnedGroup':group(pid) if pid else []},indent=2)+'\n')
 receipt={'status':status if guards else 'CLOSED_GUARD_FAILED','startedAt':started,'closedAt':t(),'sourceHead':'738de72b01fe9c7b1bb77141f9d54149d0b0693c','guardRows':len(before),'allSourceDependencyRuntimeSelfGuardsEqual':guards,'nativeTimingOrBrowser':False,'actualChildExitCode':locals().get('exitcode'),'peakSampledOwnedRssBytes':peak,'naturalClosure':status=='CLOSED_PASS' and not sent,'finalOwnedGroup':group(pid) if pid else [],'signals':sent}
 (base/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
 assert guards,'physical source/dependency/runtime/helper guard changed'

