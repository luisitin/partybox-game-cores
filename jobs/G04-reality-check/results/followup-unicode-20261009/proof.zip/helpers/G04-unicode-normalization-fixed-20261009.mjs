import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {createRng} from '/tmp/game-cores-G04-followup-20261009/contract/rng.ts';
const base=process.argv[2];
const old=await import(pathToFileURL('/workspace/game-cores-G04-audit-20261009/jobs/G04-reality-check/core.ts'));
const fixed=await import(pathToFileURL('/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/core.ts'));
const context=(n,seed,mode,rounds=8)=>({players:Array.from({length:n},(_,i)=>({id:'p'+i,name:'Seat '+(i+1),avatarId:'🙂',connected:true,bot:true})),seed,now:0,settings:{mode,rounds}});
const timer=s=>({type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline});
const equality=[];
let totalEqualEventStates=0;
for(const n of [2,3,4,5,6,7,8])for(const seed of [1,91])for(const mode of ['quick','mixed','bluff']){
 let a=old.init(context(n,seed,mode)),b=fixed.init(context(n,seed,mode)),steps=0;
 const ar=a.seats.map((_,i)=>createRng(seed^(i+17))),br=b.seats.map((_,i)=>createRng(seed^(i+17)));
 while(a.phase.id!=='done'&&steps++<3000){
  assert.equal(JSON.stringify(a),JSON.stringify(b));
  let actor=null,input=null;
  for(let i=0;i<a.seats.length;i++){
   const skill=i%3===0?'sharp':i%3===1?'normal':'easy';
   const ai=old.game.bot.sampleInput(a,a.seats[i],ar[i],skill),bi=fixed.game.bot.sampleInput(b,b.seats[i],br[i],skill);
   assert.deepEqual(ai,bi);
   assert.deepEqual(old.tvView(a),fixed.tvView(b));
   assert.deepEqual(old.controllerView(a,a.seats[i]),fixed.controllerView(b,b.seats[i]));
   if(ai){actor=a.seats[i];input=ai;break;}
  }
  const event=input?{type:'input',playerId:actor,input,now:a.phase.startedAt+1}:timer(a);
  a=old.reduce(a,event);b=fixed.reduce(b,event);
  assert.equal(JSON.stringify(a),JSON.stringify(b));totalEqualEventStates++;
 }
 assert.equal(a.phase.id,'done');assert.equal(b.phase.id,'done');
 assert.deepEqual(old.results(a),fixed.results(b));
 equality.push({players:n,seed,mode,eventStates:steps,finalStateSHA256:createHash('sha256').update(JSON.stringify(a)).digest('hex'),allBotActionsViewsStatesResultsEqual:true});
}
let state=fixed.init(context(8,91,'bluff',12)),rejectedWrites=0,maxStateBytes=0;
const events=[],observations=[];
const oversized={type:'write',text:'\ufdfa'.repeat(160)};
function record(){
 const bytes=Buffer.from(JSON.stringify(state));maxStateBytes=Math.max(maxStateBytes,bytes.length);
 assert(bytes.length<=256*1024);
 observations.push({step:events.length,round:state.round,phase:state.phase.id,stateBytes:bytes.length,stateSHA256:createHash('sha256').update(bytes).digest('hex'),responseLengths:Object.values(state.responses).filter(v=>typeof v==='string').map(v=>v.length)});
}
function send(e){const before=state;events.push(e);state=fixed.reduce(state,e);record();return before!==state;}
record();
for(let i=0;i<500&&state.phase.id!=='done';i++){
 if(state.phase.id==='write'){
  for(const id of [...state.seats]){
   assert.equal(send({type:'input',playerId:id,input:oversized,now:state.phase.startedAt+1}),false);rejectedWrites++;
  }
  send(timer(state));
 }else if(state.phase.id==='vote'){
  const truth=state.options.find(o=>o.correct);assert(truth);
  for(const id of [...state.seats])if(state.phase.id==='vote')send({type:'input',playerId:id,input:{type:'vote',choice:truth.id},now:state.phase.startedAt+1});
 }else send(timer(state));
}
assert.equal(state.phase.id,'done');assert.equal(rejectedWrites,96);
const report={status:'PASS',originalReadyHead:'738de72b01fe9c7b1bb77141f9d54149d0b0693c',fixedBranchBase:'fa68187898f37e9b97ebbf841be0f723cf2782a7',inputCodePoint:'U+FDFA',rawInputLength:160,normalizedLength:2880,rejectedWrites,maxStateBytes,contractStateLimitBytes:256*1024,completedWorstCaseGame:true,worstCaseEventCount:events.length,benignGames:equality.length,totalEqualEventStates,benignScopes:equality,originalRulesBotRngViewsScoresPreservedInBenignControls:true,nativeTimingOrBrowser:false};
writeFileSync(base+'/actual-fixed-replay.json.gz',gzipSync(Buffer.from(JSON.stringify({context:context(8,91,'bluff',12),events,observations,finalState:state})),{level:9}));
writeFileSync(base+'/actual-fixed-report.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status,rejectedWrites,maxStateBytes,benignGames:equality.length,totalEqualEventStates,nativeTimingOrBrowser:false}));

