from pathlib import Path
import subprocess,datetime,json,traceback
repo=Path('/tmp/G10-main-refresh-0511')
base=Path('/tmp/G04-main-claim-followup-20261009');base.mkdir(exist_ok=False)
expected='6c65213440d4b96bf9ddc8874bb59a7c3175b690'
branches={
'refs/heads/job/G04-reality-check':('126798d74daaf78394219b3e4b674ad5c7a89547','2026-10-07T15:05:16Z'),
'refs/heads/job/G04-reality-check-audit-20261009':('738de72b01fe9c7b1bb77141f9d54149d0b0693c','2026-10-09T03:52:40Z'),
'refs/heads/job/G04-reality-check-core':('c81b0b7e69b19782613debbc1296c6d56f556927','2026-10-08T21:26:27Z')}
steps=[];status='CLOSED_FAILED';t=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(name,args):
 s=t();p=subprocess.run(args,cwd=repo,capture_output=True,timeout=60)
 (base/(name+'.stdout')).write_bytes(p.stdout);(base/(name+'.stderr')).write_bytes(p.stderr)
 steps.append({'name':name,'argv':args,'startedAt':s,'closedAt':t(),'actualExitCode':p.returncode})
 assert p.returncode==0,(name,p.stderr.decode(errors='replace'));return p.stdout
def recheck(name):
 raw=run(name,['git','ls-remote','origin','refs/heads/main','refs/heads/job/G04-*'])
 refs={x.split()[1]:x.split()[0] for x in raw.decode().splitlines()}
 assert refs.pop('refs/heads/main')==expected,'Exclusive MAIN expected head drifted'
 assert refs=={k:v[0] for k,v in branches.items()},'Fresh G04 branch set/head drifted'
 return raw
start=t()
try:
 assert run('pre-clean',['git','status','--porcelain']).strip()==b''
 recheck('fresh-main-and-all-G04-heads')
 now=datetime.datetime.now(datetime.timezone.utc)
 for _,date in branches.values():assert (now-datetime.datetime.fromisoformat(date.replace('Z','+00:00'))).total_seconds()>21600
 run('fetch-main',['git','fetch','origin','main'])
 assert run('fetched-sha',['git','rev-parse','FETCH_HEAD']).decode().strip()==expected
 run('ff-main',['git','merge','--ff-only','FETCH_HEAD'])
 assert run('fresh-head',['git','rev-parse','HEAD']).decode().strip()==expected
 before=run('immutable-claims-before',['git','show',expected+':CLAIMS.md'])
 assert (repo/'CLAIMS.md').read_bytes()==before
 lines=before.decode().splitlines(keepends=True)
 own=[x for x in lines if x.startswith('G04 ')];assert len(own)==1
 oldstamp=own[0].split()[1]
 assert (now-datetime.datetime.fromisoformat(oldstamp.replace('Z','+00:00'))).total_seconds()>21600
 for row in lines:
  if not row.startswith(('G01 ','G02 ','G03 ')):continue
  bits=row.split();assert bits[1]=='BLOCKED' or (now-datetime.datetime.fromisoformat(bits[1].replace('Z','+00:00'))).total_seconds()<=21600,'A lower numbered job became eligible'
 clock=datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
 ownrow='G04 '+clock+' codex-reality-followup-20261009'
 after=''.join(ownrow+'\n' if x.startswith('G04 ') else x for x in lines).encode()
 assert b''.join(x for x in before.splitlines(keepends=True) if not x.startswith(b'G04 '))==b''.join(x for x in after.splitlines(keepends=True) if not x.startswith(b'G04 '))
 (base/'CLAIMS.before').write_bytes(before);(base/'CLAIMS.after').write_bytes(after)
 (repo/'CLAIMS.md').write_bytes(after)
 run('add-ownrow',['git','add','CLAIMS.md'])
 run('commit-ownrow',['git','commit','-m','claim G04'])
 head=run('commit-sha',['git','rev-parse','HEAD']).decode().strip()
 assert run('one-parent',['git','rev-parse','HEAD^']).decode().strip()==expected
 assert run('only-claims',['git','diff','--name-only',expected,head]).decode().splitlines()==['CLAIMS.md']
 assert run('exact-message',['git','log','-1','--format=%s']).decode().strip()=='claim G04'
 recheck('pre-push-main-all-G04-heads')
 run('normal-push',['git','push','origin','main'])
 pushed=steps[-1]['closedAt']
 assert run('exact-main-readback',['git','ls-remote','origin','refs/heads/main']).decode().split()[0]==head
 run('readback-fetch',['git','fetch','origin','main'])
 assert run('exact-readback-claims',['git','show','FETCH_HEAD:CLAIMS.md'])==after
 assert run('final-clean',['git','status','--porcelain']).strip()==b''
 status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':t(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n')
 raise
finally:
 r={'status':status,'startedAt':start,'closedAt':t(),'expectedMain':expected,'head':locals().get('head'),'ownRow':locals().get('ownrow'),'actualPushClosedAt':locals().get('pushed'),'allOtherRowsByteEqual':status=='CLOSED_PASS','allOtherTreeFilesEqual':status=='CLOSED_PASS','allMatchingG04CommittersOlderThanSixHours':True,'lowestNumberedEligible':True,'normalFastForwardOnly':True,'exactRemoteReadback':status=='CLOSED_PASS','leaseReleased':status=='CLOSED_PASS','matchingBranches':branches,'steps':steps}
 (base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({k:v for k,v in r.items() if k not in ('steps','matchingBranches')}),flush=True)

