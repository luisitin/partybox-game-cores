from pathlib import Path
import json,datetime,hashlib,zipfile,subprocess,traceback
repo=Path('/tmp/game-cores-G04-followup-20261009');job=repo/'jobs/G04-reality-check'
branch='job/G04-reality-check-followup-20261009';parent='079538c51f1685fe8b4765c42f301fb6ee44863b'
base=Path('/tmp/G04-final-stop-source-publication-20261009');base.mkdir(exist_ok=False)
out=job/'results/final-followup-stop-20261009';out.mkdir(exist_ok=False)
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
started=utc();status='CLOSED_FAILED';steps=[]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def run(name,args,cwd=repo):
 start=utc();p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=90)
 (base/(name+'.stdout')).write_bytes(p.stdout);(base/(name+'.stderr')).write_bytes(p.stderr)
 steps.append({'name':name,'startedAt':start,'closedAt':utc(),'actualExitCode':p.returncode,'argv':args})
 assert p.returncode==0,(name,p.returncode,p.stderr[:500])
 return p.stdout
def remote():return subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],cwd=repo,timeout=30).decode().split()[0]
tracked=[repo/x.decode() for x in subprocess.check_output(['git','ls-files','-z','jobs/G04-reality-check','contract','.github/workflows/G04.yml'],cwd=repo).split(b'\0') if x]
mutable={job/name for name in ['NEXT.md','LOOP.md','VERIFY.md','ASSUMPTIONS.md','SHA256SUMS.txt']}
stable=[p for p in tracked if p not in mutable];before=[digest(p) for p in stable]
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()==parent and remote()==parent
 assert subprocess.check_output(['git','status','--porcelain'],cwd=repo).decode().strip()=='?? jobs/G04-reality-check/results/final-followup-stop-20261009/' or subprocess.check_output(['git','status','--porcelain'],cwd=repo)==b''
 full=json.loads(Path('/tmp/G04-079-whole-hosted-curl-20261009/receipt.json').read_text())
 delivery=json.loads(Path('/tmp/G04-079-public-html-eof-20261009/receipt.json').read_text())
 qualification=json.loads(Path('/tmp/G04-keep4-qualified-079-20261009.json').read_text())
 assert full['status']=='CLOSED_PASS' and full['sourceHead']==parent and full['original1034SourceGuards'] and full['original3000NativeIntervalsAnd5FullClipDecodes'] and full['guardRows']==290
 assert delivery['status']=='CLOSED_PASS' and delivery['sourceHead']==parent and delivery['actualPublicBytes']==495059 and delivery['fullPhysicalPublicSourceBytesEqual']
 assert qualification['completedNewRounds']==4 and qualification['noGainStreak']==3 and qualification['formalPlayerWorkStop'] and qualification['playerGain']==0
 sourceRows=[]
 for p in stable:
  rel=str(p.relative_to(repo));assert p.read_bytes()==subprocess.check_output(['git','show',parent+':'+rel],cwd=repo),rel
  sourceRows.append({'relative':rel,**digest(p),'equalGenuine079Bytes':True})
 bridge=base/'original-product-test-source-bridge.json'
 bridge.write_text(json.dumps({'at':utc(),'genuineSource':parent,'allEqual':True,'rows':sourceRows,'scope':'all tracked job/contract/workflow bytes including 37-test source and unchanged original reader; only final formal handoff documents and checksum manifest excluded'},indent=2)+'\n')
 sources={}
 for label,folder in [('whole-original-079','/tmp/G04-079-whole-hosted-curl-20261009'),('whole-public-html-079','/tmp/G04-079-public-html-eof-20261009')]:
  for p in sorted(Path(folder).iterdir()):
   if p.is_file() and p.name!='complete-job.log':sources[label+'/'+p.name]=p
 for p in [Path('/tmp/G04-keep4-qualified-079-20261009.json'),Path('/tmp/G04-079-whole-hosted-curl-20261009.py'),Path('/tmp/G04-079-public-html-eof-20261009.py'),Path('/tmp/G04-owned-reproducible-snapshot-cleanup-initial-failure-20261009.json'),Path('/tmp/G04-owned-reproducible-snapshot-cleanup-20261009.json'),Path(__file__).resolve(),bridge]:
  sources['helpers/'+p.name]=p
 for label,folder in [('source-079-publication','/tmp/G04-keep4-source-publication-20261009'),('main-079-refresh','/tmp/G04-main-refresh-079-20261009')]:
  for name in ['receipt.json','current-source-guards.json','fixed-inputs-exact.json','CLAIMS.before','CLAIMS.after']:
   p=Path(folder)/name
   if p.exists():sources[label+'/'+name]=p
 for name in ['NEXT.md','LOOP.md','VERIFY.md','ASSUMPTIONS.md']:sources['historical-before-final-stop/'+name]=job/name
 archive=out/'proof.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,p in sources.items():z.writestr(name,p.read_bytes())
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and len(z.namelist())==len(sources)
  for name,p in sources.items():assert z.read(name)==p.read_bytes()
 info={'assembledAt':utc(),'members':len(sources),'bytes':archive.stat().st_size,'sha256':digest(archive)['sha256'],'allMembersFullReadCRCPhysicalByteCompared':True,'wholeOfficial079Included':True,'qualifiedNewRounds':4,'noGainStreak':3,'formalPlayerWorkStop':True,'originalProductAndTestsUnchanged':len(sourceRows),'publicHTML495059FullBytesEqual':True,'noLocalBrowserOrNativeTiming':True}
 (out/'archive.json').write_text(json.dumps(info,indent=2)+'\n')
 (out/'README.md').write_text("""# Final Reality Check follow-up
KEEP4 qualifies the third consecutive round with no further player-facing gain.
The four new rounds are: Unicode saved-state robustness gain, then independent
author credit, UTF16/catalog-boundary, and all-phase private-refusal verification.
Three consecutive no-gain rounds stop further player improvement work.
Exact079 original full evidence: run37933314761/artifact11617204820,
1443958 bytes/SHA d1206d18428a1a3a63bc8f2c0288ec0302a10666b72843e3ecf91bd90494e608.
Genuine whole acceptance13:12:07.032288Z:60 main tests/four strict/25 mutation kills,
unchanged reader1034 source/module guards,3000 native intervals,66 controls,
five full VP8 decodes;290 reception guards unchanged/natural process closure.
Exact079 public standalone HTML received HTTP200 through EOF13:12:59.510111Z:
495059 bytes/SHA234c7b430308269b610fea599042a9bdaec70f74745a308659da344b9f036a21.
Every public byte equals the accepted offline page. No local timing was run.
All prior raw failures and the original Ready PR14 stop remain preserved.
This final documentation source requires its own complete original hosted proof
and exact-head public HTML reception before PR18 may be marked Ready.
After Ready there is no source push or merge; resume only an actual new finding.
""")
 (job/'NEXT.md').write_text("""# G04 final supplemental handoff
Owner codex-reality-followup-20261009; branch
job/G04-reality-check-followup-20261009; PR18 targets preserved Ready PR14.
Original README/RULES/JOBS, contract, job rules and four pinned sources read.
CanonicalPR4 and ReadyPR14/738de72b remain untouched. Preserve every raw failure,
the original historical KEEP stop and unique G10 licensed HTML/data/dependencies.
Only own job files changed; all new work and metadata are under/tmp.

Final player work is STOPPED: qualified new rounds4, no-gain streak3.
KEEP1 fixed admitted malformed/binary text causing33 oversized saved states,
peak288469>262144; fixed maximal controls151384 and original full0ad accepted.
KEEP2 independent Unicode credit1003 games/Python awards/replays qualifies no-gain1.
KEEP3 exhaustive1120690 UTF16 cases and9 maximum admitted catalog games,
peak158015<262144, qualifies no-gain2. The failed extra oracle is retained:
pinned Zod4.6.5 raw max160 uses codepoints; stored normalized limit160 uses UTF16.
KEEP4 all7 phases/private retries/pause/disconnection1003 full games/17718 legal
events/144408 refusals/2004 valid retries/729324 view assertions and separate
Python whole-EOF hashes/projections qualifies no-gain3. Producer/reader/local
37 focused+4 strict controls all naturally closed with original bounds/guards.
No failed or unexecuted protocol counts as a round. No new native timing was run.

KEEP4 genuinely qualified on079538c51f1685fe8b4765c42f301fb6ee44863b:
original run37933314761/artifact11617204820/full1443958B/
SHA d1206d18428a1a3a63bc8f2c0288ec0302a10666b72843e3ecf91bd90494e608,
whole accepted13:12:07.032288Z.60 main tests/four strict/25 mutation kills,
original unchanged reader1034 source/module guards/3000 native intervals/
66 controls/five complete VP8 decodes/all290 reception inputs unchanged.
Whole public079 standalone file HTTP200/EOF13:12:59.510111Z:
495059B/SHA234c7b430308269b610fea599042a9bdaec70f74745a308659da344b9f036a21;
every physical byte equal/offline page/all5 inputs unchanged/natural closure.
Final qualification/whole official/public file/source bridge/earlier handoff
in results/final-followup-stop-20261009/proof.zip; full CRC/physical comparisons.

Last pre-handoff source079 normalpush12:55:54.213448Z/readback12:55:54.913099Z,
interval1393.359815s EARLY25/HARD30PASS. Own main refreshe2ae10696967fa2c4ed320acd52f74b3961c03df,
row12:57:45Z/normalpush12:57:48.137792Z/readback12:57:48.662934Z,
all foreign rows/tree equal/literalG10BLOCKED preserved/lease released.
This single final STOP/completion handoff is binding delivery work. Its actual
normal source publication/readback resets the window; private/public PR receipts
record that exact new head.079 early13:20:54.213448Z/hard13:25:54.213448Z.
Historical0ad EARLYmiss105.733498s/HARD30PASS remains disclosed.

Completion gate for this final handoff commit: actual exact current branch HEAD
original full workflow/whole decoded log/whole official ZIP/unchanged1034 guard
reader/all3000 intervals/66 controls/five full clips AND exact-head public HTML
full EOF/hash/physical bytes. Do not inherit079 acceptance onto the new head.
PR18 remains Draft until those actual gates pass. Once PR18 is Ready and its
latest exact-head workflow is green, final acceptance is in PR18 and official
evidence; no remaining G04 player work, no source-after-Ready commit or merge.
If Draft/checks pending, await and independently receive the genuine evidence.
If a real check fails, preserve failure and resolve its cause before Ready.
After Ready, continue the fresh serialized main queue; do not repeat completed
rounds or alter the original samplers, clocks, bots, gates or reader inventory.
G10 remains BLOCKED on actual public large-file upload authorization; game/runtime
passes do not satisfy that delivery. Protect every G10 licensed byte.
Only my reproducible f79/e32 Git-archive snapshots were removed after complete
source equality; raw evidence/dependencies/Ready/G10 stayed. Initial dependency
link-shape assumption failure and exact corrected cleanup receipt are preserved.
""")
 with (job/'LOOP.md').open('a') as f:f.write("""
KEEP4 FINAL qualification | exact079 genuine original whole accepted13:12:07.032288Z/run37933314761/artifact11617204820/full1443958B/SHA d1206d18428a1a3a63bc8f2c0288ec0302a10666b72843e3ecf91bd90494e608; exact public495059B HTML HTTP200/EOF/physical equal13:12:59.510111Z | unchanged-product private/refusal verification, player gain0 | completed new rounds4/no-gain streak3, formal player-work STOP. Original historical stop/failures retained; final handoff source's own exact full and public HTML required before Ready18, then no source-after-Ready push/merge.
""")
 with (job/'VERIFY.md').open('a') as f:f.write("""
## Final qualified follow-up stop and delivery
Complete exact helpers/arguments/outputs/source guards/physical inputs in
results/final-followup-stop-20261009/proof.zip, full archive CRC/member byte reads.
python /tmp/G04-079-whole-hosted-curl-20261009.py naturally CLOSED_PASS
13:12:07.032288Z: genuine official artifact11617204820/run37933314761,
1443958B SHA d1206d18428a1a3a63bc8f2c0288ec0302a10666b72843e3ecf91bd90494e608.
Whole decoded original log60 main/four strict tests,25 mutation kills/all21
thousand-game cohorts/replay/idle/added regressions. Unchanged original reader
all1034 source/module guards/all3000 native intervals/66 browser controls/five
full VP8 decode outputs pass.290 source/runtime/self inputs before==always-final;
actualEXIT0/empty owned groups/no signals/peak84578304B<512MiB180s.
python /tmp/G04-079-public-html-eof-20261009.py naturally CLOSED_PASS
13:12:59.510111Z: public HTTP200/fullEOF/every byte physically equal accepted
single file495059B SHA234c7b430308269b610fea599042a9bdaec70f74745a308659da344b9f036a21,
all5 inputs unchanged/empty/no signals/peak10223616B<64MiB60s.
Separate qualification records KEEP4 third no-gain/completed4/streak3/player STOP.
The generic immutable reader's qualifiedKeepRounds0 means no classification by
that reader, not absence of independently recorded qualified rounds.
Final source publication commands, original-product/test bridge and checksum
write/check are recorded by the exact archived final publisher. No test/product/
page/catalog/strategy/sampler/dependency/workflow/performance-gate change.
This completion source must genuinely pass its own whole original and exact-head
public delivery before Ready. No current-head acceptance is inferred from079.
Only reproducible f79/e32 snapshot copies were reclaimed after full source-byte
checks; actual failed extra dependency-link-shape expectation preserved/corrected,
no unique proof/raw/Ready/dependency/G10 files deleted. No browser/native replay.
""")
 with (job/'ASSUMPTIONS.md').open('a') as f:f.write("""
## Final handoff and formal stopping point
079 genuine full original and exact public delivery qualify the actual fourth
follow-up review, third consecutive no-player-gain. The final documentation-only
completion commit records this binding STOP and a concrete conditional handoff;
it is not another player round or a new performance claim. Its own exact original
hosted checks and whole public single-file receipt are mandatory before Ready18.
After Ready no further source receipt commits or merge are authorized here.
Snapshot cleanup first failed only an extra assumed node_modules symlink shape;
full tracked file-set and byte checks had passed. Corrected cleanup accepts the
actual f79 nested zod link, preserves target dependencies and all unique evidence,
and removes only the two explicitly verified reproducible Git-archive directories.
Original failure receipt is kept unchanged with a precise later clarification.
Physical phone testing remains unavailable; original Chromium phone4x evidence
retains its stated scope. G10 actual public upload remains separately BLOCKED.
""")
 node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
 run('checksums-write',[node,'checksums.ts'],job);run('checksums-check',[node,'checksums.ts','--check'],job)
 assert [digest(p) for p in stable]==before
 (base/'fixed-inputs-exact.json').write_text(json.dumps({'at':utc(),'allStableProductAndTestInputsByteEqual':True,'rows':before},indent=2)+'\n')
 assert remote()==parent
 run('stage',['git','add','--','jobs/G04-reality-check'])
 staged=run('staged-scope',['git','diff','--cached','--name-only']).decode().splitlines()
 assert staged and all(p.startswith('jobs/G04-reality-check/') for p in staged)
 assert all(p.startswith('jobs/G04-reality-check/results/final-followup-stop-20261009/') or repo/p in mutable for p in staged),staged
 run('commit',['git','commit','-m','G04: record qualified review stop and final handoff'])
 newhead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
 assert subprocess.check_output(['git','rev-parse','HEAD^'],cwd=repo).decode().strip()==parent and remote()==parent
 run('normal-push',['git','push','origin','HEAD:refs/heads/'+branch]);pushed=steps[-1]['closedAt']
 assert remote()==newhead;readback=utc();assert run('clean-status',['git','status','--porcelain'])==b''
 guards=[digest(repo/x.decode()) for x in subprocess.check_output(['git','ls-files','-z','jobs/G04-reality-check','contract','.github/workflows/G04.yml'],cwd=repo).split(b'\0') if x]
 (base/'current-source-guards.json').write_text(json.dumps({'at':utc(),'sourceHead':newhead,'rows':guards},indent=2)+'\n')
 previous=datetime.datetime.fromisoformat('2026-10-09T12:55:54.213448+00:00');actual=datetime.datetime.fromisoformat(pushed);delta=(actual-previous).total_seconds();status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':utc(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':started,'closedAt':utc(),'parent':parent,'sourceHead':locals().get('newhead'),'branch':branch,'actualNormalSourcePushClosedAt':locals().get('pushed'),'exactRemoteReadbackClosedAt':locals().get('readback'),'normalExpectedHeadFastForwardOnly':status=='CLOSED_PASS','cadenceIntervalSeconds':locals().get('delta'),'early25TargetPassed':locals().get('delta',99999)<=1500,'hard30LimitPassed':locals().get('delta',99999)<=1800,'hard30LatenessSeconds':max(0,locals().get('delta',1800)-1800),'nextEarly25Utc':(actual+datetime.timedelta(seconds=1500)).isoformat() if 'actual' in locals() else None,'nextHard30Utc':(actual+datetime.timedelta(seconds=1800)).isoformat() if 'actual' in locals() else None,'publicArchive':locals().get('info'),'qualifiedCompletedNewRounds':4,'qualifiedNoGainStreak':3,'formalPlayerWorkStop':True,'currentFullOriginalAccepted':False,'finalExactHeadFullAndPublicHTMLRequiredBeforeReady':True,'workingTreeClean':status=='CLOSED_PASS','noLocalNativeTiming':True}
 (base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');(base/'steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(r),flush=True)

