import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {game as defaultGame,createGame} from '/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/core.ts';
const output=process.argv[2];assert(output);
import {makeSamples} from '/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/samples.ts';
const admission=[];
for(const control of ['\u0001','\u0007'])for(const field of ['id','prompt','hint','fact','correct']){
 const rows=makeSamples(),row=rows.find(r=>r.kind==='bluff');row[field]='Visible '+control.repeat(10);
 let admitted=true;try{createGame(rows);}catch{admitted=false;}
 admission.push({codePoint:control.codePointAt(0),field,admitted});
}
const families=[['control-01','\u0001'],['control-07','\u0007']];
const context=seed=>({players:Array.from({length:8},(_,i)=>({id:'p'+i,name:'Seat '+(i+1),avatarId:'🙂',connected:true})),seed,now:0,settings:{mode:'bluff',rounds:12}});
const digest=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
let totalEvents=0,totalWrites=0,totalRounds=0,globalPeak=0,oversizeStates=0;const summaries=[];
for(const [family,glyph] of families)for(const seed of [1]){
 const rows=makeSamples().map(row=>row.kind==='bluff'?{...row,id:(row.id+glyph.repeat(80)).slice(0,80),prompt:('Prompt '+glyph.repeat(240)).slice(0,240),hint:('Hint '+glyph.repeat(200)).slice(0,200),fact:('Fact '+glyph.repeat(90)).slice(0,90),correct:('Truth '+glyph.repeat(160)).slice(0,160)}:row);
 const game=createGame(rows);
 const ctx=context(seed);let state=game.init(ctx),peak=0;const transcript=[];
 const submit=event=>{
  const before=digest(state);state=game.reduce(state,event);const bytes=Buffer.byteLength(JSON.stringify(state));
  peak=Math.max(peak,bytes);if(bytes>262144)oversizeStates++;
  transcript.push({event,before,after:digest(state),stateBytes:bytes});totalEvents++;
 };
 const timer=()=>({type:'timer',phaseId:state.phase.id,startedAt:state.phase.startedAt,now:state.phase.deadline});
 for(let step=0;state.phase.id!=='done'&&step<300;step++){
  if(state.phase.id==='write'){
   for(const [i,id] of state.seats.entries()){
    const text=('f'+i+' '+'界'.repeat(160)).slice(0,160);
    assert(game.inputSchema.safeParse({type:'write',text}).success);
    submit({type:'input',playerId:id,input:{type:'write',text},now:state.phase.startedAt+1});
    assert.equal(typeof state.responses[id],'string');assert(String(state.responses[id]).length<=160);totalWrites++;
    if(state.phase.id==='write'){
     const other=structuredClone(state);other.responses[id]='A distinct private fake';
     const observer=state.seats[(i+1)%8];assert.deepEqual(game.tvView(state),game.tvView(other));
     assert.deepEqual(game.controllerView(state,observer),game.controllerView(other,observer));
    }
   }
   assert.equal(state.phase.id,'vote');assert.equal(state.options.length,9);
   assert.equal(state.knowledge.length,0);
  }else if(state.phase.id==='vote'){
   const ids=[...state.seats],options=structuredClone(state.options);
   for(const [i,id] of ids.entries()){
    const option=options.find(o=>o.owners.includes(ids[(i+1)%8]));assert(option);
    submit({type:'input',playerId:id,input:{type:'vote',choice:option.id},now:state.phase.startedAt+1});
   }
   assert.equal(state.phase.id,'reveal');
   for(const id of ids)assert.equal(state.last.awards[id],state.round===12?1000:500);
   totalRounds++;
  }else submit(timer());
 }
 assert.equal(state.phase.id,'done');assert.equal(state.history.length,12);
 for(const id of state.seats)assert.equal(state.scores[id],6500,'independent known twelve-round author awards');
 let replay=game.init(ctx);
 for(const item of transcript){assert.equal(digest(replay),item.before);replay=game.reduce(replay,item.event);assert.equal(digest(replay),item.after);assert.equal(Buffer.byteLength(JSON.stringify(replay)),item.stateBytes);}
 assert.deepEqual(replay,state);assert.deepEqual(game.results(replay),game.results(state));
 const saved={family,seed,context:ctx,events:transcript,finalState:state,results:game.results(state)};
 const raw=Buffer.from(JSON.stringify(saved));const zipped=gzipSync(raw);const name=family+'-seed'+seed+'.json.gz';writeFileSync(output+'/'+name,zipped);
 summaries.push({family,seed,events:transcript.length,peakStateBytes:peak,actualRawBytes:raw.length,gzipBytes:zipped.length,gzipSha256:createHash('sha256').update(zipped).digest('hex'),replayAllHashesEqual:true,finalStateSha256:digest(state)});
 globalPeak=Math.max(globalPeak,peak);
}
const report={scope:'actual current e32 saved-only accepted Unicode states, independent award formula, complete legal event replay, privacy projection; no browser/native timing/player gain',games:summaries.length,families:families.map(x=>x[0]),seeds:[1],totalEvents,totalWrites,totalRounds,originalStateLimitBytes:262144,peakStateBytes:globalPeak,oversizeStates,rawCatalogAdmission:admission,allGamesDone:true,allFinalScores:6500,allReplaysExact:true,summaries};
writeFileSync(output+'/actual-state-replay-report.json',JSON.stringify(report,null,2)+'\n');
let writeState=defaultGame.init(context(1));while(writeState.phase.id!=='write')writeState=defaultGame.reduce(writeState,{type:'timer',phaseId:writeState.phase.id,startedAt:writeState.phase.startedAt,now:writeState.phase.deadline});
const writeControls=[];for(const control of ['\u0001','\u0007']){
 const text='A'+control.repeat(159),event={type:'input',playerId:'p0',input:{type:'write',text},now:writeState.phase.startedAt+1};const after=defaultGame.reduce(writeState,event);
 assert(defaultGame.inputSchema.safeParse(event.input).success);assert.equal(after.responses.p0,'A');
 const empty={...event,input:{type:'write',text:control.repeat(160)}};assert.equal(defaultGame.reduce(writeState,empty),writeState);
 writeControls.push({codePoint:control.codePointAt(0),rawInputAdmitted:true,storedText:'A',storedLength:1,emptyRawRefused:true});
}
writeFileSync(output+'/actual-direct-control-admission.json',JSON.stringify({admission,writeControls},null,2)+'\n');
console.log(JSON.stringify({games:report.games,totalEvents,totalWrites,totalRounds,peakStateBytes:globalPeak,replaysExact:true}));

