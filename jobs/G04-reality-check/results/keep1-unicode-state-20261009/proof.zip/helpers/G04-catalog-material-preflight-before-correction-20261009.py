from pathlib import Path
import json,datetime,hashlib,zipfile,re,subprocess,traceback
repo=Path('/tmp/game-cores-G04-followup-20261009');job=repo/'jobs/G04-reality-check'
parent='f79d33634ea678e0fd5194448d70e8c879e767e7';branch='job/G04-reality-check-followup-20261009'
out=job/'results/followup-catalog-normalization-20261009';out.mkdir(exist_ok=False)
base=Path('/tmp/G04-catalog-source-publication-20261009');base.mkdir(exist_ok=False)
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
negative=Path('/tmp/G04-catalog-normalization-negative-20261009')
text=(negative/'stdout.log').read_text()
assert '# tests 1\n' in text and '# pass 0\n' in text and '# fail 1\n' in text and 'Missing expected exception: catalog must reject a truth that cannot fit a normalized submission' in text
assert 'ERR_MODULE_NOT_FOUND' not in text and 'not ok 1 - catalog truth normalization' in text
(negative/'independent-output-reader.json').write_text(json.dumps({'status':'EXPECTED_REGRESSION_FAILURE_ACCEPTED','at':utc(),'tests':1,'passed':0,'failed':1,'scope':'whole actual saved TAP read; no rerun','stdout':digest(negative/'stdout.log')},indent=2)+'\n')
sources={}
for label,path in [('probe',Path('/tmp/G04-catalog-truth-writability-probe-20261009')),('negative',negative),('fixed',Path('/tmp/G04-catalog-normalization-fixed-20261009'))]:
 for p in sorted(path.iterdir()):
  if p.is_file():sources[label+'/'+p.name]=p
for name in ['G04-catalog-truth-writability-probe-20261009.mjs','G04-catalog-truth-writability-probe-20261009.py','G04-catalog-normalization-fixed-20261009.mjs','G04-catalog-normalization-fixed-20261009.py','G04-f79-whole-hosted-20261009.py']:
 sources['helpers/'+name]=Path('/tmp')/name
for name in ['receipt.json','current-source-guards.json','fixed-inputs-exact.json']:
 sources['first-source-publication/'+name]=Path('/tmp/G04-unicode-source-publication-20261009')/name
for name in ['receipt.json','CLAIMS.before','CLAIMS.after']:
 p=Path('/tmp/G04-main-refresh-f79-20261009')/name
 if p.exists():sources['first-source-main-refresh/'+name]=p
for name in ['NEXT.md','LOOP.md','ASSUMPTIONS.md','VERIFY.md']:
 sources['historical/'+name]=job/name
failed=Path('/tmp/G04-f79-whole-hosted-20261009')
for name in ['receipt.json','whole-log-reader.json','artifact-metadata.json','resource-process.json','before.json']:
 p=failed/name
 if p.exists():sources['first-hosted/'+name]=p
redacted=base/'first-provider-failure.redacted.json'
raw=(failed/'failure.json').read_text()
raw=re.sub(r'https://[^\s"<>]+','[temporary URL redacted]',raw)
redacted.write_text(raw);sources['first-hosted/failure.redacted.json']=redacted
gherr=Path('/tmp/G04-f79-configured-gh-download.stderr')
safe=base/'configured-gh-download.stderr.redacted'
safe.write_text(re.sub(r'https://[^\s"<>]+','[temporary URL redacted]',gherr.read_text()))
sources['first-hosted/configured-gh-download.stderr.redacted']=safe
diagnostic={'at':utc(),'configuredGhArtifactDownloadActualExit':1,'receivedZipBytes':Path('/tmp/G04-f79-configured-gh-actual.zip').stat().st_size,'httpFailure':403,'scope':'saved actual configured client output independently read; provider and Azure redirects failed, no credential recovery; temporary signed URLs redacted publicly, private original bytes preserved','sourceWorkflowGreen':True,'wholeOfficialAccepted':False}
assert diagnostic['receivedZipBytes']==0 and '403' in safe.read_text()
(base/'configured-client-diagnostic.json').write_text(json.dumps(diagnostic,indent=2)+'\n');sources['first-hosted/configured-client-diagnostic.json']=base/'configured-client-diagnostic.json'
archive=out/'proof.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sources.items():z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(sources)
 for name,p in sources.items():assert z.read(name)==p.read_bytes()
info={'assembledAt':utc(),'members':len(sources),'bytes':archive.stat().st_size,'sha256':digest(archive)['sha256'],'allMembersFullReadCRCAndExactSourceCompared':True,'redactionScope':'only failed transport temporary signed URLs; private originals preserved','newLocalGuardRows':3830,'focusedTests':32,'originalStrictControls':4,'normalizationComparisons':10000,'qualifiedKeepRounds':0,'noBrowserOrNativeTiming':True}
(out/'archive.json').write_text(json.dumps(info,indent=2)+'\n')
(out/'README.md').write_text("""# Catalog and submission Unicode bounds
The actual first fix accepted two catalog truths which normalized to162 display
units and could no longer be written. The saved regression fails on exact f79.
The integrated fix shares case-preserving cleanup and validates display length
at catalog load and submission. Three valid160-unit boundaries still work,
including a160-unit stored answer with a320-unit lowercase comparison key.
Matching/scoring semantics remain identical in10000 actual seeded comparisons.
All32 focused tests and four unchanged strict controls pass.42 old/fixed games
retain3395 event states/bot actions/views/results. Worst-case96 refusals retain
8995-byte peak.3830 before/after source/dependency/runtime guards are unchanged
within recorded scopes; all owned children naturally close, peak436432896B.
The first f79 full workflow is metadata green. Its genuine official ZIP download
failed403 through both configured transports before any body byte; whole archive
acceptance is pending. All original source/native/clip gates remain mandatory.
The first source proof and every real failure remain preserved. This evidence
includes redacted public transport errors, with private raw bytes untouched.
No local browser/frame clock, qualified KEEP round or no-gain count is claimed.
""")
(job/'NEXT.md').write_text("""# G04 normalization follow-up handoff
Owner codex-reality-followup-20261009, branch job/G04-reality-check-followup-20261009,
supplemental Draft PR18 against preserved Ready PR14/738de72b. Lawful main claim
fa681878 was naturally pushed10:32:45.981861Z; all foreign rows/tree unchanged.
The original Ready source/PR14/canonical PR4, all earlier raw failures and
historical gameplay KEEP12–14 stop are preserved. Original instructions and
four pinned research sources were fully read; mechanics/data/scoring remain.
First material source f79d33634ea678e0fd5194448d70e8c879e767e7 naturally pushed
10:56:02.664508Z/readback10:56:03.168900Z; hardPASS. Own main refresh ec641e88
naturally pushed10:58:18.703453Z/readback10:58:19.248504Z, lease released.
Current source window early11:21:02.664508Z/hard11:26:02.664508Z; the next
actual source push receipt resets this window, never an inferred document time.

Actual old defect:160 input→2880 stored,96 fake writes,676419B state exceeding
original262144B. First narrow normalized submission limit solves that overflow.
New actual f79 catalog inquiry found two accepted truths→162 units unwritable.
Integrated fix shares original case-preserving cleanup and validates <=160 display
units in both catalog and write. Lowercase comparison keys remain unrestricted,
preserving a valid160-unit stored answer whose comparison key is320 units.
All seven fixtures, default160 fictional rows, bots/rules/scoring/timers intact.
The new regression genuinely fails on saved f79; complete TAP is preserved.

Actual bounded new pipeline naturally CLOSED11:10:33.286930Z: types/data,
two identical fixture generations/seven fixtures unchanged, two identical builds,
freshness/checksums,32 focused tests/four original strict controls PASS.
42 benign old/fixed games preserve3395 states/bot actions/views/results.
10000 original/new normalization comparisons are equal; two invalid catalogs
refused at load/three valid160 boundaries credited. Worst-case96 refusals8995B.
3830 source/dependency/runtime/helper rows unchanged apart declared generated
page; pure before/after equal, sampled peak436432896B <512MiB, all groups
naturally empty/no signals. FAST_TEST=1 is local only, no full local workload.
Archives: results/followup-unicode-20261009/proof.zip (first actual failure/fix)
and results/followup-catalog-normalization-20261009/proof.zip (current fix).

First f79 original hosted run37920764830/job113787854390 succeeded11:03:34Z.
Its complete actual decoded log passes54 tests/four strict controls, all21
1000-game cohorts/replays and25 mutation kills. Official artifact11611612904
metadata1448737B/SHA58c9f87a4b536df5df8d5de7b77353a4eaa1e0aed429db3d1b89787348145770.
Actual provider receiver40311:15:53; configured gh artifact download403 with
zero body bytes. First failed receiver broad guard flagfalse does not prove
source mutation; no reader/native/clip acceptance occurred. Raw failures retained,
temporary signed URLs redacted only in public copies. Full official acceptance
is pending, and would remain historical for this changed catalog source.
Next exact source original full workflow and genuine whole artifact MUST pass
unchanged original verify-hosted-artifact.py with exacthead/run, all1034 installed/
source guards,3000 native intervals and five actual fullVP8 clips before Ready.
No unchanged performance retry, gate or workload relaxation is authorized.

Current status: real integrated fix/local controls PASS; exact new full pending.
Pre-green investigations are not qualified KEEP rounds; completed new rounds0/
no-gain streak0. After genuine full green run original five-weakness KEEP until
three honest no-player-gain rounds. Root coordinates native measurement separately;
none is granted/executed locally. Refresh only main G04 row through fresh lease.
All work/deps/proofs under /tmp/game-cores-G04-followup-20261009; never mutate
old Ready workspace, shared metadata, unique G10 licensed HTML or other jobs.
BCE/CE conventions remain explicit house rules; all160 workshop rows fictional.
""")
with (job/'ASSUMPTIONS.md').open('a') as f:f.write("""
## Catalog normalization consistency, 2026-10-09
The first submission bound exposed a genuine custom-catalog regression:
accepted raw9/54-unit truths normalize to162 and cannot be submitted. Use the
same original case-preserving cleanup at catalog load and submission, limit
display/storage units, preserve lowercase matching keys and all original scoring.
Three valid160-unit boundaries and a320-unit comparison key remain accepted.
Saved original f79/source and failed regression remain unchanged; this is a
pre-green product correction, not a qualified KEEP/no-gain round.
The actual hosted download403 is distinct from a source/test failure. Metadata
green and complete text logs do not accept unreceived official ZIP/native clips.
Public signed-URL errors are redacted; all actual private original bytes remain.
""")
with (job/'LOOP.md').open('a') as f:f.write("""
## Catalog consistency follow-up, 2026-10-09
Pre-green real finding | two accepted catalog truths normalize to162 unwritable
units after f79 | shared case-preserving cleanup and catalog display-length
validation |32 focused/four strict PASS;10000 matching comparisons equal;
42 benign games3395 states/bots/views/results equal;3830 guards/closure PASS
| whole new original proof pending; new completed KEEP rounds0/no-gain streak0.
""")
with (job/'VERIFY.md').open('a') as f:f.write("""
## Catalog bound consistency (2026-10-09)
Complete probe/negative/fixed source/runtime/resource/raw receipts are in
results/followup-catalog-normalization-20261009/proof.zip; archive.json gives
full member CRC/exact byte comparisons and digest. Actual saved f79 catalog
regression command FAST_TEST=1 CORE_PATH=<saved-f79>/core.ts node --test
--test-reporter=tap --test-name-pattern='catalog truth normalization' test.ts:
EXIT1,one expected missing-exception failure/zero pass, complete TAP read.
New Node24 pipeline types/data/two fixtures/two builds/freshness/checksums PASS;
FAST_TEST=1 test.ts32 PASS; unchanged strict-proof.test.ts four PASS.
10000 seeded old/new normalization comparisons equal;2 overflow catalogs rejected,
3 exact160 display boundaries accepted/credited, including320 lowercase key.
42 oldReady/new games3395 states/actions/views/results exact. Same worst-case
96 refusals8995B. Actual closure11:10:33.286930Z, all3830 guards unchanged within
recorded declared-output scopes, peak436432896B<512MiB/no signals/empty groups.
First f79 workflow run37920764830/job113787854390 is metadata success; whole
decoded54-test log independently read. Official11611612904 expected1448737B/
SHA58c9f87a4b536df5df8d5de7b77353a4eaa1e0aed429db3d1b89787348145770.
Actual two configured403 downloads received0B; no whole/native/clip acceptance.
First broad failed controller flag is not a source mutation finding. New source
full original CI and unchanged complete-reader acceptance remain mandatory.
""")
steps=[];status='CLOSED_FAILED';started=utc()
def run(name,args,cwd=repo):
 s=utc();p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=60)
 (base/(name+'.stdout')).write_bytes(p.stdout);(base/(name+'.stderr')).write_bytes(p.stderr)
 steps.append({'name':name,'argv':args,'startedAt':s,'closedAt':utc(),'actualExitCode':p.returncode})
 assert p.returncode==0,(name,p.stderr.decode(errors='replace'));return p.stdout
try:
 assert run('own-parent',['git','rev-parse','HEAD']).decode().strip()==parent
 assert run('own-branch',['git','branch','--show-current']).decode().strip()==branch
 ignored={'NEXT.md','LOOP.md','ASSUMPTIONS.md','VERIFY.md','SHA256SUMS.txt'}
 fixed=json.loads(Path('/tmp/G04-catalog-normalization-fixed-20261009/after.json').read_text())['rows'];checked=[]
 for row in fixed:
  p=Path(row['path'])
  if p.parent==job and p.name in ignored:continue
  assert digest(p)==row,('Changed fixed input',str(p));checked.append(row)
 (base/'fixed-inputs-exact.json').write_text(json.dumps({'at':utc(),'count':len(checked),'rows':checked},indent=2)+'\n')
 node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
 run('checksum-write',[node,'checksums.ts'],job);run('checksum-check',[node,'checksums.ts','--check'],job);run('offline-freshness',[node,'build.ts','--check'],job)
 run('stage-only-owned-job',['git','add','--','jobs/G04-reality-check'])
 diff=run('owned-scope',['git','diff','--cached','--name-only']).decode().splitlines()
 assert diff and all(p.startswith('jobs/G04-reality-check/') for p in diff)
 assert run('original-workflow-contract',['git','diff','--cached','--name-only','--','contract','.github/workflows/G04.yml','CLAIMS.md']).strip()==b''
 run('whitespace',['git','diff','--cached','--check'])
 assert run('expected-remote',['git','ls-remote','origin','refs/heads/'+branch]).decode().split()[0]==parent
 run('material-commit',['git','commit','-m','fix G04 catalog and submission normalization bounds'])
 head=run('new-head',['git','rev-parse','HEAD']).decode().strip()
 assert run('exact-parent',['git','show','-s','--format=%P',head]).decode().strip()==parent
 assert run('clean-before',['git','status','--porcelain']).strip()==b''
 run('normal-source-push',['git','push','origin',branch]);pushed=steps[-1]['closedAt']
 assert run('exact-remote-readback',['git','ls-remote','origin','refs/heads/'+branch]).decode().split()[0]==head;remote=steps[-1]['closedAt']
 assert run('clean-after',['git','status','--porcelain']).strip()==b''
 paths=[repo/p.decode() for p in run('tracked-source-paths',['git','ls-files','-z','jobs/G04-reality-check','contract','.github/workflows/G04.yml']).split(b'\0') if p]
 guards=[digest(p) for p in paths];(base/'current-source-guards.json').write_text(json.dumps({'head':head,'at':utc(),'rows':guards},indent=2)+'\n')
 interval=(datetime.datetime.fromisoformat(pushed)-datetime.datetime.fromisoformat('2026-10-09T10:56:02.664508+00:00')).total_seconds()
 status='CLOSED_PASS'
except BaseException as error:
 (base/'failure.json').write_text(json.dumps({'at':utc(),'error':str(error),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 receipt={'status':status,'startedAt':started,'closedAt':utc(),'head':locals().get('head'),'parent':parent,'branch':branch,'actualNormalPushClosedAt':locals().get('pushed'),'exactRemoteReadbackClosedAt':locals().get('remote'),'actualSourceIntervalSeconds':locals().get('interval'),'hardMissSeconds':max(0,locals().get('interval',1800)-1800),'proofArchive':info,'fixedPhysicalRowsUnchanged':len(locals().get('checked',[])),'currentTrackedSourceGuardRows':len(locals().get('guards',[])),'sourceClean':status=='CLOSED_PASS','wholeNewOriginalRequired':True,'noLocalNativeTiming':True,'steps':steps}
 (base/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='steps'}),flush=True)

