import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {gzipSync} from 'node:zlib';
import {createGame} from '/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/core.ts';
const output=process.argv[2];assert(output);
import {makeSamples} from '/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/samples.ts';
const rows=makeSamples().map(row=>row.kind==='bluff'?{...row,id:(row.id+'\udfff'.repeat(80)).slice(0,80),prompt:('Prompt '+'\udfff'.repeat(240)).slice(0,240),hint:('Hint '+'\udfff'.repeat(200)).slice(0,200),fact:('Fact '+'\udfff'.repeat(90)).slice(0,90),correct:('Truth '+'\ud800'.repeat(160)).slice(0,160)}:row);
const game=createGame(rows);
const families=[['maximal-catalog-high-surrogate','\ud800']];
const context=seed=>({players:Array.from({length:8},(_,i)=>({id:'p'+i,name:'Seat '+(i+1),avatarId:'🙂',connected:true})),seed,now:0,settings:{mode:'bluff',rounds:12}});
const digest=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
let totalEvents=0,totalWrites=0,totalRounds=0,globalPeak=0,oversizeStates=0;const summaries=[];
for(const [family,glyph] of families)for(const seed of [1,2,3]){
 const ctx=context(seed);let state=game.init(ctx),peak=0;const transcript=[];
 const submit=event=>{
  const before=digest(state);state=game.reduce(state,event);const bytes=Buffer.byteLength(JSON.stringify(state));
  peak=Math.max(peak,bytes);if(bytes>262144)oversizeStates++;
  transcript.push({event,before,after:digest(state),stateBytes:bytes});totalEvents++;
 };
 const timer=()=>({type:'timer',phaseId:state.phase.id,startedAt:state.phase.startedAt,now:state.phase.deadline});
 for(let step=0;state.phase.id!=='done'&&step<300;step++){
  if(state.phase.id==='write'){
   for(const [i,id] of state.seats.entries()){
    const text=('f'+i+' '+glyph.repeat(160)).slice(0,160);
    assert(game.inputSchema.safeParse({type:'write',text}).success);
    submit({type:'input',playerId:id,input:{type:'write',text},now:state.phase.startedAt+1});
    assert.equal(typeof state.responses[id],'string');assert(String(state.responses[id]).length<=160);totalWrites++;
    if(state.phase.id==='write'){
     const other=structuredClone(state);other.responses[id]='A distinct private fake';
     const observer=state.seats[(i+1)%8];assert.deepEqual(game.tvView(state),game.tvView(other));
     assert.deepEqual(game.controllerView(state,observer),game.controllerView(other,observer));
    }
   }
   assert.equal(state.phase.id,'vote');assert.equal(state.options.length,9);
   assert.equal(state.knowledge.length,0);
  }else if(state.phase.id==='vote'){
   const ids=[...state.seats],options=structuredClone(state.options);
   for(const [i,id] of ids.entries()){
    const option=options.find(o=>o.owners.includes(ids[(i+1)%8]));assert(option);
    submit({type:'input',playerId:id,input:{type:'vote',choice:option.id},now:state.phase.startedAt+1});
   }
   assert.equal(state.phase.id,'reveal');
   for(const id of ids)assert.equal(state.last.awards[id],state.round===12?1000:500);
   totalRounds++;
  }else submit(timer());
 }
 assert.equal(state.phase.id,'done');assert.equal(state.history.length,12);
 for(const id of state.seats)assert.equal(state.scores[id],6500,'independent known twelve-round author awards');
 let replay=game.init(ctx);
 for(const item of transcript){assert.equal(digest(replay),item.before);replay=game.reduce(replay,item.event);assert.equal(digest(replay),item.after);assert.equal(Buffer.byteLength(JSON.stringify(replay)),item.stateBytes);}
 assert.deepEqual(replay,state);assert.deepEqual(game.results(replay),game.results(state));
 const saved={family,seed,context:ctx,events:transcript,finalState:state,results:game.results(state)};
 const raw=Buffer.from(JSON.stringify(saved));const zipped=gzipSync(raw);const name=family+'-seed'+seed+'.json.gz';writeFileSync(output+'/'+name,zipped);
 summaries.push({family,seed,events:transcript.length,peakStateBytes:peak,actualRawBytes:raw.length,gzipBytes:zipped.length,gzipSha256:createHash('sha256').update(zipped).digest('hex'),replayAllHashesEqual:true,finalStateSha256:digest(state)});
 globalPeak=Math.max(globalPeak,peak);
}
const report={scope:'distinct untimed actual accepted e32 maximal custom-catalog fields and accepted writes; original state ceiling is observed, never relaxed; no browser/native timing or no-gain classification',games:summaries.length,families:families.map(x=>x[0]),seeds:[1,2,3],totalEvents,totalWrites,totalRounds,originalStateLimitBytes:262144,peakStateBytes:globalPeak,oversizeStates,observedStateContractViolation:oversizeStates>0,allGamesDone:true,allFinalScores:6500,allReplaysExact:true,summaries};
writeFileSync(output+'/actual-state-replay-report.json',JSON.stringify(report,null,2)+'\n');
writeFileSync(output+'/actual-admitted-catalog.json.gz',gzipSync(Buffer.from(JSON.stringify(rows))));
console.log(JSON.stringify({oversizeStates,games:report.games,totalEvents,totalWrites,totalRounds,peakStateBytes:globalPeak,replaysExact:true}));

