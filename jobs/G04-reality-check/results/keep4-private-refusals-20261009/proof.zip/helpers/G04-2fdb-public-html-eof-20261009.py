from pathlib import Path
import json,datetime,hashlib,subprocess,os,time,signal,ctypes,traceback,sys
head='2fdb92060e17016378ce48007c477eccd61dc613';base=Path('/tmp/G04-2fdb-public-html-eof-20261009');base.mkdir(exist_ok=False)
source=Path('/tmp/G04-2fdb-preserved-baseline-20261009/jobs/G04-reality-check/play.html')
url='https://raw.githubusercontent.com/luisitin/partybox-game-cores/'+head+'/jobs/G04-reality-check/play.html'
t=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
def guard(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 st=p.stat();return {'path':str(p),'bytes':st.st_size,'sha256':h.hexdigest(),'stat':[st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns]}
inputs=[source,Path('/usr/bin/curl'),Path(sys.executable).resolve(),Path(__file__).resolve(),Path('/tmp/G04-2fdb-whole-hosted-curl-20261009/receipt.json')]
before=[guard(p) for p in inputs];started=t();status='CLOSED_FAILED';peak=0;samples=[];signals=[];pid=None
def group(pid):
 rows=[]
 for entry in Path('/proc').iterdir():
  if not entry.name.isdigit():continue
  try:
   raw=(entry/'stat').read_text();tail=raw[raw.rfind(')')+2:].split()
   if int(tail[2])==pid:rows.append({'pid':int(entry.name),'rss':int(tail[21])*os.sysconf('SC_PAGE_SIZE'),'state':tail[0]})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return rows
try:
 assert json.loads(inputs[-1].read_text())['status']=='CLOSED_PASS'
 maximum=int(Path('/sys/fs/cgroup/memory.max').read_text());current=int(Path('/sys/fs/cgroup/memory.current').read_text())
 assert maximum-current>64*1024*1024+128*1024*1024
 (base/'fresh-resources.json').write_text(json.dumps({'at':t(),'memoryMax':maximum,'memoryCurrent':current,'ownedLimitBytes':64*1024*1024,'reserveBytes':128*1024*1024,'wholeLimitSeconds':60,'noNativeTiming':True},indent=2)+'\n')
 output=base/'actual-public-play.html';clock=time.monotonic()
 with (base/'download.stdout').open('wb') as out,(base/'download.stderr').open('wb') as err:
  p=subprocess.Popen(['/usr/bin/curl','--silent','--show-error','--fail','--location','--connect-timeout','15','--max-time','60','--retry','0','--max-filesize',str(before[0]['bytes']),'--write-out','%{stderr}\nG04_HTTP_STATUS:%{http_code}\n','--output',str(output),url],stdout=out,stderr=err,start_new_session=True);pid=p.pid
  while p.poll() is None:
   owned=group(pid);rss=sum(row['rss'] for row in owned);peak=max(peak,rss);samples.append({'at':t(),'owned':owned,'rss':rss})
   if rss>64*1024*1024 or time.monotonic()-clock>60:
    signals.append({'at':t(),'signal':'SIGTERM','why':'declared64MiB/60s bound'});os.killpg(pid,signal.SIGTERM);p.wait(timeout=5);break
   time.sleep(.025)
  exitcode=p.returncode;assert exitcode==0 and group(pid)==[] and not signals
 assert 'G04_HTTP_STATUS:200' in (base/'download.stderr').read_text()
 actual=guard(output);assert actual['bytes']==before[0]['bytes'] and actual['sha256']==before[0]['sha256'] and output.read_bytes()==source.read_bytes()
 after=[guard(p) for p in inputs];assert before==after
 status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':t(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 final=[guard(p) for p in inputs]
 r={'status':status,'startedAt':started,'closedAt':t(),'sourceHead':head,'publicUrl':url,'httpStatus':200 if status=='CLOSED_PASS' else None,'wholePublicHTMLReadEOF':status=='CLOSED_PASS','sourceBytes':before[0]['bytes'],'sourceSHA256':before[0]['sha256'],'actualPublicBytes':locals().get('actual',{}).get('bytes'),'actualPublicSHA256':locals().get('actual',{}).get('sha256'),'fullPhysicalPublicSourceBytesEqual':status=='CLOSED_PASS','all5SourceRuntimeSelfInputsUnchanged':before==final,'before':before,'after':final,'sampledPeakOwnedRssBytes':peak,'naturalClosure':status=='CLOSED_PASS' and not signals,'finalOwnedGroup':group(pid) if pid else [],'signals':signals,'noNativeOrBrowserTiming':True,'current2fdbOriginalWholePreviouslyAccepted':True}
 (base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');(base/'resource-process.json').write_text(json.dumps(samples,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['before','after']}),flush=True)
