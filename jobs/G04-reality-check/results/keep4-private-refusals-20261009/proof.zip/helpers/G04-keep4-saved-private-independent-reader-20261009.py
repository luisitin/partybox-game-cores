from pathlib import Path
import gzip,json,hashlib,datetime,copy,re,unicodedata,sys
base=Path('/tmp/G04-keep4-private-refusals-actual-v2-20261009')
raw=base/'complete-private-refusal-games.jsonl.gz';reportPath=base/'actual-private-refusal-report.json';spec=Path('/tmp/G04-keep4-private-refusals-prospective-v2-20261009.json')
paths=[raw,reportPath,base/'receipt.json',spec,Path('/tmp/G04-keep4-private-refusals-prospective-v2-20261009.mjs'),Path(__file__).resolve(),Path(sys.executable).resolve()]
def guard(p):
 st=p.stat();h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return {'path':str(p),'bytes':st.st_size,'sha256':h.hexdigest(),'stat':[st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns]}
def statehash(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,separators=(',',':')).encode('utf8')).hexdigest()
def wellformed(text):
 try:text.encode('utf-16-le',errors='surrogatepass').decode('utf-16-le',errors='strict');return True
 except UnicodeDecodeError:return False
def clean(text):return ' '.join(''.join(' ' if unicodedata.category(c) in ['Cc','Cf'] else c for c in unicodedata.normalize('NFKC',text)).split())
bad=['\ud800','\udfff','A\ud800','\ufdfa'*9,'\ufdfa'*160,'a'*158+'\ufb03','🧭'*160,'\u0001'*160]
for text in bad:
 raw_valid=wellformed(text) and 1<=len(text)<=160;normalized=clean(text)
 assert not(raw_valid and normalized and len(normalized.encode('utf-16-le',errors='surrogatepass'))//2<=160)
before=[guard(p) for p in paths];start=datetime.datetime.now(datetime.timezone.utc).isoformat();report=json.loads(reportPath.read_text());proposal=json.loads(spec.read_text())
seeds=[1,2,3];seen=set(seeds);rng=proposal['samplerSeed']
while len(seeds)<1003:
 rng=(rng*1664525+1013904223)&0xffffffff
 if rng not in seen:seen.add(rng);seeds.append(rng)
games=events=anchors=refusals=retries=privatechecks=paused=dropped=0;phases=set();decoded=hashlib.sha256()
durations={'wheel':3000,'demo':10000,'answer':50000,'write':40000,'vote':30000,'reveal':15000}
with gzip.open(raw,'rb') as stream:
 for line in stream:
  decoded.update(line);packet=json.loads(line);index=packet['gameIndex'];assert index==games
  ctx=packet['context'];ids=[p['id'] for p in ctx['players']];n=2+index%7;mode=['quick','mixed','bluff'][index%3]
  assert ids==['p'+str(i) for i in range(n)] and ctx['seed']==seeds[index] and ctx['settings']=={'mode':mode,'rounds':4} and ctx['now']==0
  source_by_phase={p['phase']:p for p in packet['phaseStates']};assert len(source_by_phase)==len(packet['phaseStates'])
  for entry in packet['phaseStates']:
   s=entry['state'];assert entry['phase']==s['phase']['id'] and statehash(s)==entry['sourceHash']
   assert s['seats']==ids and all(score==0 for score in s['scores'].values())
  assert len(packet['probes'])==len(source_by_phase)
  for probe in packet['probes']:
   phase=probe['phase'];s=source_by_phase[phase]['state'];basehash=source_by_phase[phase]['sourceHash'];phases.add(phase);anchors+=1
   variants={'live':copy.deepcopy(s),'paused':copy.deepcopy(s),'disconnected':copy.deepcopy(s)}
   if phase!='done':variants['paused']['phase']['paused']={'at':s['phase']['startedAt']+1}
   variants['disconnected']['players']['p0']['connected']=False
   expected_hash={key:statehash(value) for key,value in variants.items()};counts=dict.fromkeys(variants,0);seen_retries=0
   for test in probe['tests']:
    variant=test['variant'];event=test['event'];assert event['type']=='input' and event['playerId']=='p0' and event['now']==s['phase']['startedAt']+2
    if variant=='valid-private-retry':
     assert phase=='write' and event['input']['type']=='write'
     expected_text=['PRIVATE-'+str(ctx['seed'])+'-p0','x'*158+'🧭','🧭'*80][seen_retries];assert event['input']['text']==test['stored']==expected_text
     retry=copy.deepcopy(s);retry['responses']['p0']=expected_text
     assert test['before']==basehash and test['after']==statehash(retry)
     assert test['ownMineExact'] and test['allOtherViewsConceal'] and test['deadlineUnchanged'] and test['rngUnchanged']
     own=test['ownView'];tv=test['tv'];assert own['mine']==expected_text and own['me']['id']=='p0' and own['me']['role']=='player' and own['inputType'] is None
     assert tv['phaseId']=='write' and tv['received']==1 and tv['deadline']==s['phase']['deadline'] and expected_text not in json.dumps(tv,ensure_ascii=False)
     assert [row['id'] for row in test['otherViews']]==ids[1:]
     for row in test['otherViews']:
      view=row['view'];assert view['mine'] is None and view['me']['id']==row['id'] and view['inputType']=='write' and expected_text not in json.dumps(view,ensure_ascii=False);privatechecks+=1
     seen_retries+=1;retries+=1
    else:
     assert variant in variants and test['inputIndex']==counts[variant] and event['input']=={'type':'write','text':bad[counts[variant]]}
     assert test['before']==test['after']==expected_hash[variant] and test['sameIdentity'] and test['allPrivateViewsEqual'] and test['deadlineUnchanged'] and test['rngUnchanged']
     counts[variant]+=1;refusals+=1;privatechecks+=n
     if variant=='paused':paused+=1
     if variant=='disconnected':dropped+=1
   assert counts=={'live':8,'paused':8,'disconnected':8} and seen_retries==(3 if phase=='write' else 0)
  previous=source_by_phase['wheel']['sourceHash'];previous_now=0
  for item in packet['timeline']:
   event=item['event'];assert event['type']=='timer' and event['phaseId'] in durations
   assert item['before']==previous and re.fullmatch('[a-f0-9]{64}',item['after']) and event['startedAt']==previous_now and event['now']==event['startedAt']+durations[event['phaseId']]
   assert 0<item['stateBytes']<=262144;previous=item['after'];previous_now=event['now'];events+=1
  final=packet['finalState'];assert final['phase']['id']=='done' and statehash(final)==previous and packet['allReplayHashesExact']
  assert final['seats']==ids and all(score==0 for score in final['scores'].values()) and packet['results']['scores']==final['scores'] and packet['results']['winnerIds']==ids
  games+=1
assert games==1003 and games==report['games'] and events==report['events'] and anchors==report['phaseAnchors']
assert refusals==report['actualRefusals'] and retries==report['validPrivateRetryChecks'] and privatechecks==report['independentPrivateViewAssertions'] and paused==report['pausedRefusals'] and dropped==report['disconnectedRefusals']
assert sorted(phases)==report['phaseCoverage']==['answer','demo','done','reveal','vote','wheel','write']
assert seeds==report['seeds'] and before[0]['bytes']==report['wholeGzipBytes'] and before[0]['sha256']==report['wholeGzipSHA256']
after=[guard(p) for p in paths];assert before==after
receipt={'status':'PASS','startedAt':start,'closedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':report['sourceHead'],'wholeGzipEOFRead':True,'completeGames':games,'legalTimerEvents':events,'phaseAnchors':anchors,'phaseCoverage':sorted(phases),'actualRefusalHashAssertions':refusals,'independentAcceptedPrivateRetries':retries,'privateViewAssertions':privatechecks,'pausedRefusals':paused,'disconnectedRefusals':dropped,'wholeGzipBytes':before[0]['bytes'],'wholeGzipSHA256':before[0]['sha256'],'wholeDecodedJsonlSHA256':decoded.hexdigest(),'allSevenPhysicalInputGuardsUnchanged':True,'before':before,'after':after,'independentReference':'Python strict UTF16/NFKC rejection, state-hash variant/retry reconstruction, explicit actual TV/owner/other projections, seeded whole-EOF legal timeline chain; no game/timing rerun'}
(base/'independent-python-whole-private-refusals.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['before','after']}),flush=True)
