import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createWriteStream,writeFileSync,readFileSync,statSync} from 'node:fs';
import {createGzip} from 'node:zlib';
import {once} from 'node:events';
import * as C from '/tmp/game-cores-G04-followup-20261009/jobs/G04-reality-check/core.ts';
const base=process.argv[2],spec=JSON.parse(readFileSync('/tmp/G04-keep4-private-refusals-prospective-v2-20261009.json','utf8'));
const fingerprint=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const timer=s=>({type:'timer',phaseId:s.phase.id,startedAt:s.phase.startedAt,now:s.phase.deadline});
const freeze=value=>{if(value&&typeof value==='object'){Object.freeze(value);for(const x of Object.values(value))freeze(x);}return value;};
const bad=['\ud800','\udfff','A\ud800','\ufdfa'.repeat(9),'\ufdfa'.repeat(160),'a'.repeat(158)+'\ufb03','🧭'.repeat(160),'\u0001'.repeat(160)];
let rng=spec.samplerSeed>>>0;const seeds=[1,2,3],seen=new Set(seeds);while(seeds.length<1003){rng=(Math.imul(rng,1664525)+1013904223)>>>0;if(!seen.has(rng)){seen.add(rng);seeds.push(rng);}}
const stream=createWriteStream(base+'/complete-private-refusal-games.jsonl.gz'),gzip=createGzip({level:6});gzip.pipe(stream);
const modes=['quick','mixed','bluff'],phaseCoverage=new Set();let games=0,events=0,anchors=0,refusals=0,validRetries=0,privateAssertions=0,pausedCases=0,droppedCases=0,peakState=0;
const summaries=[];
for(const [gameIndex,seed] of seeds.entries()){
 const n=2+gameIndex%7,mode=modes[gameIndex%3],context={players:Array.from({length:n},(_,i)=>({id:'p'+i,name:'Seat '+(i+1),avatarId:'🙂',connected:true})),seed,now:0,settings:{mode,rounds:4}};
 let state=C.init(context);const timeline=[],states=[],covered=new Set(),probes=[];
 for(let step=0;step<120;step++){
  const bytes=Buffer.byteLength(JSON.stringify(state));peakState=Math.max(peakState,bytes);assert(bytes<=262144);
  if(!covered.has(state.phase.id)){
   covered.add(state.phase.id);phaseCoverage.add(state.phase.id);anchors++;
   const source=freeze(structuredClone(state)),before=fingerprint(source);
   const variants=[['live',source],['paused',freeze(C.reduce(source,{type:'vip',action:'pause',now:source.phase.startedAt+1}))],['disconnected',freeze(C.reduce(source,{type:'player',playerId:'p0',connected:false,now:source.phase.startedAt+1}))]];
   const tests=[];
   for(const [variant,s] of variants){
    const original=fingerprint(s),tv=fingerprint(C.tvView(s)),views=s.seats.map(id=>({id,hash:fingerprint(C.controllerView(s,id))}));
    for(const [inputIndex,text] of bad.entries()){
     const event={type:'input',playerId:'p0',input:{type:'write',text},now:s.phase.startedAt+2};
     const actual=C.reduce(s,event);assert.equal(actual,s);assert.equal(fingerprint(actual),original);
     assert.equal(fingerprint(C.tvView(actual)),tv);
     for(const row of views){assert.equal(fingerprint(C.controllerView(actual,row.id)),row.hash);privateAssertions++;}
     tests.push({variant,inputIndex,event,before:original,after:fingerprint(actual),sameIdentity:true,allPrivateViewsEqual:true,deadlineUnchanged:true,rngUnchanged:true});
     refusals++;if(variant==='paused')pausedCases++;if(variant==='disconnected')droppedCases++;
    }
   }
   if(source.phase.id==='write'){
    for(const text of ['PRIVATE-'+seed+'-p0','x'.repeat(158)+'🧭','🧭'.repeat(80)]){
     const event={type:'input',playerId:'p0',input:{type:'write',text},now:source.phase.startedAt+2};
     const retry=C.reduce(source,event);assert.notEqual(retry,source);assert.equal(retry.responses.p0,text);assert.equal(retry.phase.id,'write');assert.equal(retry.phase.deadline,source.phase.deadline);assert.deepEqual(retry.rng,source.rng);
     assert.equal(C.controllerView(retry,'p0').mine,text);assert(!JSON.stringify(C.tvView(retry)).includes(text));
     for(const id of source.seats.filter(x=>x!=='p0')){assert.equal(C.controllerView(retry,id).mine,null);assert(!JSON.stringify(C.controllerView(retry,id)).includes(text));privateAssertions++;}
     assert.equal(C.reduce(retry,{...event,input:{type:'write',text:'replacement'}}),retry);validRetries++;
     tests.push({variant:'valid-private-retry',event,before,after:fingerprint(retry),stored:text,ownMineExact:true,allOtherViewsConceal:true,deadlineUnchanged:true,rngUnchanged:true,tv:C.tvView(retry),ownView:C.controllerView(retry,'p0'),otherViews:source.seats.filter(id=>id!=='p0').map(id=>({id,view:C.controllerView(retry,id)}))});
    }
   }
   assert.equal(fingerprint(source),before);
   states.push({phase:source.phase.id,state:source,sourceHash:before});probes.push({phase:source.phase.id,tests});
  }
  if(state.phase.id==='done')break;
  const event=timer(state),before=fingerprint(state);state=C.reduce(state,event);timeline.push({event,before,after:fingerprint(state),stateBytes:Buffer.byteLength(JSON.stringify(state))});events++;
 }
 assert.equal(state.phase.id,'done');
 for(const id of state.seats)assert.equal(state.scores[id],0);
 let replay=C.init(context);for(const item of timeline){assert.equal(fingerprint(replay),item.before);replay=C.reduce(replay,item.event);assert.equal(fingerprint(replay),item.after);assert.equal(Buffer.byteLength(JSON.stringify(replay)),item.stateBytes);}
 assert.deepEqual(replay,state);assert.deepEqual(C.results(replay),C.results(state));
 const packet={gameIndex,context,phaseStates:states,probes,timeline,finalState:state,results:C.results(state),allReplayHashesExact:true};
 const line=JSON.stringify(packet)+'\n';if(!gzip.write(line))await once(gzip,'drain');
 summaries.push({gameIndex,seed,players:n,mode,phases:[...covered],events:timeline.length,finalStateSHA256:fingerprint(state)});
 games++;
}
gzip.end();await once(stream,'close');
const content=readFileSync(base+'/complete-private-refusal-games.jsonl.gz');
const report={status:'PASS',sourceHead:spec.sourceHead,games,events,phaseAnchors:anchors,phaseCoverage:[...phaseCoverage].sort(),actualRefusals:refusals,validPrivateRetryChecks:validRetries,independentPrivateViewAssertions:privateAssertions,pausedRefusals:pausedCases,disconnectedRefusals:droppedCases,peakStateBytes:peakState,wholeGzipBytes:statSync(base+'/complete-private-refusal-games.jsonl.gz').size,wholeGzipSHA256:createHash('sha256').update(content).digest('hex'),allReplayHashesExact:true,allFinalScoresZero:true,allRefusalsRetainDeadlineRngAndState:true,allValidRetriesRemainPrivate:true,samplerSeed:spec.samplerSeed,seeds,summaries,noGamePolicyOrTimingChange:true};
writeFileSync(base+'/actual-private-refusal-report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({...report,seeds:undefined,summaries:undefined}));
