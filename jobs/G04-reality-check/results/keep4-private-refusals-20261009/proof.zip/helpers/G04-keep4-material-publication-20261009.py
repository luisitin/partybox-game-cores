from pathlib import Path
import json,datetime,hashlib,zipfile,re,subprocess,traceback,shutil
repo=Path('/tmp/game-cores-G04-followup-20261009');job=repo/'jobs/G04-reality-check'
branch='job/G04-reality-check-followup-20261009';parent='2fdb92060e17016378ce48007c477eccd61dc613'
base=Path('/tmp/G04-keep4-source-publication-20261009');base.mkdir(exist_ok=False)
out=job/'results/keep4-private-refusals-20261009';out.mkdir(exist_ok=False)
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
started=utc();status='CLOSED_FAILED';steps=[]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def run(name,args,cwd=repo):
 start=utc();p=subprocess.run(args,cwd=cwd,capture_output=True,timeout=90)
 (base/(name+'.stdout')).write_bytes(p.stdout);(base/(name+'.stderr')).write_bytes(p.stderr)
 steps.append({'name':name,'startedAt':start,'closedAt':utc(),'actualExitCode':p.returncode,'argv':args})
 assert p.returncode==0,(name,p.returncode,p.stderr[:500])
 return p.stdout
def headremote():return subprocess.check_output(['git','ls-remote','origin','refs/heads/'+branch],cwd=repo,timeout=30).decode().split()[0]
tracked=[repo/x.decode() for x in subprocess.check_output(['git','ls-files','-z','jobs/G04-reality-check','contract','.github/workflows/G04.yml'],cwd=repo).split(b'\0') if x]
mutable={job/name for name in ['test.ts','NEXT.md','LOOP.md','VERIFY.md','ASSUMPTIONS.md','SHA256SUMS.txt']}
stable=[p for p in tracked if p not in mutable];before=[digest(p) for p in stable]
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()==parent and headremote()==parent
 fixed=json.loads(Path('/tmp/G04-keep4-private-fixed-20261009/receipt.json').read_text());assert fixed['status']=='CLOSED_PASS' and fixed['actualChangedDuringPipeline']==[] and fixed['guardRows']==3842
 full=json.loads(Path('/tmp/G04-2fdb-whole-hosted-curl-20261009/receipt.json').read_text());assert full['status']=='CLOSED_PASS' and full['sourceHead']==parent
 pure=json.loads(Path('/tmp/G04-keep4-private-refusals-actual-v2-20261009/receipt.json').read_text());assert pure['status']=='CLOSED_PASS'
 eof=json.loads(Path('/tmp/G04-keep4-private-refusals-actual-v2-20261009/independent-python-whole-private-refusals.json').read_text());assert eof['status']=='PASS' and eof['completeGames']==1003 and eof['actualRefusalHashAssertions']==144408
 delivery=json.loads(Path('/tmp/G04-2fdb-public-html-eof-20261009/receipt.json').read_text());assert delivery['status']=='CLOSED_PASS' and delivery['sourceHead']==parent and delivery['actualPublicBytes']==495059
 assert re.search(r'# tests 37\b',Path('/tmp/G04-keep4-private-fixed-20261009/focused-tests.stdout.log').read_text()) and re.search(r'# pass 37\b',Path('/tmp/G04-keep4-private-fixed-20261009/focused-tests.stdout.log').read_text())
 originals=[]
 for p in stable:
  relative=str(p.relative_to(repo));original=subprocess.check_output(['git','show',parent+':'+relative],cwd=repo);assert p.read_bytes()==original,relative
  originals.append({'relative':relative,**digest(p),'equalGenuine2fdbBytes':True})
 (base/'original-product-source-bridge.json').write_text(json.dumps({'at':utc(),'genuineSource':parent,'rows':originals,'allEqual':True,'scope':'all tracked job/contract/workflow bytes except sole new test, verification documents and checksum manifest; current new source full still required'},indent=2)+'\n')
 sources={}
 folders=[('whole-current-2fdb','/tmp/G04-2fdb-whole-hosted-curl-20261009'),('actual-private-v2','/tmp/G04-keep4-private-refusals-actual-v2-20261009'),('independent-reader-control','/tmp/G04-keep4-private-independent-reader-control-20261009'),('local-fixed-pipeline','/tmp/G04-keep4-private-fixed-20261009'),('whole-public-html-2fdb','/tmp/G04-2fdb-public-html-eof-20261009')]
 for label,folder in folders:
  for p in sorted(Path(folder).iterdir()):
   if p.is_file() and p.name!='complete-job.log':sources[label+'/'+p.name]=p
 for pattern in ['G04-keep4-*20261009.py','G04-keep4-*20261009.mjs','G04-keep4-*20261009.json','G04-keep4-*20261009.txt']:
  for p in sorted(Path('/tmp').glob(pattern)):sources['helpers/'+p.name]=p
 for p in [Path('/tmp/G04-keep3-qualified-2fdb-20261009.json'),Path('/tmp/G04-2fdb-whole-hosted-curl-20261009.py'),Path('/tmp/G04-2fdb-public-html-eof-20261009.py'),base/'original-product-source-bridge.json']:
  sources['helpers/'+p.name]=p
 for label,folder in [('prior-source-publication','/tmp/G04-keep3-source-publication-20261009'),('prior-main-refresh','/tmp/G04-main-refresh-2fdb-20261009')]:
  for name in ['receipt.json','current-source-guards.json','fixed-inputs-exact.json','CLAIMS.before','CLAIMS.after']:
   p=Path(folder)/name
   if p.exists():sources[label+'/'+name]=p
 for name in ['NEXT.md','LOOP.md','VERIFY.md','ASSUMPTIONS.md']:sources['historical/'+name]=job/name
 archive=out/'proof.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for name,p in sources.items():z.writestr(name,p.read_bytes())
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None and len(z.namelist())==len(sources)
  for name,p in sources.items():assert z.read(name)==p.read_bytes()
 info={'assembledAt':utc(),'members':len(sources),'bytes':archive.stat().st_size,'sha256':digest(archive)['sha256'],'allMembersFullReadCRCPhysicalByteCompared':True,'wholeOfficial2fdbIncluded':True,'qualifiedNewRounds':3,'noGainStreak':2,'round4':'local verification gain0, prospective third no-gain pending exact new source original full','originalProductInputsUnchanged':len(originals),'publicHTML495059FullBytesEqual':True,'noLocalBrowserOrNativeTiming':True}
 (out/'archive.json').write_text(json.dumps(info,indent=2)+'\n')
 (out/'README.md').write_text("""# KEEP4 private text refusals
Worst remaining weakness: privacy and phase handling after new Unicode refusals,
including pause and disconnect. No product, policy, clock or gate changes.
The additional 1,003 full seeded games at every player count and all three modes
finish and replay exactly: 17,718 legal timer events, 6,017 phase anchors, all seven
phases, 144,408 refused writes, 2,004 valid private retries, and 729,324 view checks.
There are 48,136 paused and 48,136 disconnected refusal controls. Frozen states,
deadlines and RNG remain exact. Valid retries are visible only to their owner.
Python independently reads the whole 5,753,708-byte gzip through EOF, reconstructs
state/retry hashes and verifies the actual saved TV/owner/other-player projections.
SHA a9bcb969e3be8c3b07b8973e516ad47af47817227658afad3d0622b56b66167c.
The new permanent regression covers all seven phases and those private refusals.
Local 37 focused/four original strict/types/data/fixtures/two builds/equality pass.
Product, page, catalog, scoring, bots, original oracles/samplers/workflow unchanged.
Exact2fdb genuine full original archive and whole public HTML EOF proof included.
Published HTML495059 bytes/SHA234c7b430308269b610fea599042a9bdaec70f74745a308659da344b9f036a21
is physically identical to the accepted offline page, received over public HTTP200.
KEEP3 qualifies second no-gain; KEEP4 is prospective third until new exact-head
original full checks and whole official archive pass. PR18 remains Draft.
Original failures, historical stop, unexecuted earlier protocol and parse-error
diagnostic stay preserved. No local browser/frame or physical-phone claim.
""")
 (job/'NEXT.md').write_text("""# G04 supplemental follow-up handoff
Owner codex-reality-followup-20261009; job/G04-reality-check-followup-20261009,
Draft PR18 targets preserved Ready PR14/738de72b. Original README/RULES/JOBS,
contract/game rules/four pinned sources read; preserve canonicalPR4, old Ready
source/three-no-gain stop, all failures and unique G10 licensed HTML/data/deps.
All new work/metadata/dependencies under/tmp; only own job files may change.

Last actual source2fdb92060e17016378ce48007c477eccd61dc613 normal push
12:32:40.853633Z/readback12:32:41.582521Z, interval1418.703211s EARLY/HARD PASS.
Own main e6d9137042c27e8f0e7f8c82f6ad635e51da382c row12:34:02Z,
normal push12:34:04.581587Z/readback12:34:05.157820Z; all foreign rows/tree byte
equal/literal G10 BLOCKED preserved/lease released. This next material source
early12:57:40.853633Z/hard13:02:40.853633Z; actual normal publication receipt
resets the30-minute window. Fresh remote/readback and serialized own-row lease.
Historical0ad EARLYmiss105.733498s/hardPASS remains exact; no earlier time invented.

Actual fixes: normalized160->2880 fake/max676419B; accepted truth162 unwritable;
malformed text/maximal catalogs33 states oversized/max288469. Current product
refuses unwritable normalized/malformed writes and malformed/binary catalog text,
preserving emoji/whitespace/C0 write cleanup/casefold/scoring/bots/timers.
KEEP1 qualified robustness gain0ad whole original11:59:05.436258Z.
KEEP2 independent Unicode credit1003 games/48106 events/Python referee qualifies
first no-player-gain, genuinec30 whole12:16:38.815738Z.
KEEP3 complete1120690 UTF16 cases/Python EOF/maximum admitted4byte catalogs9
games1560 legal events/max158015<262144 qualifies second no-player-gain.
Actual raw Zod4.6.5 max160 is Unicode codepoints; normalized storage/UI max160 is
UTF16 units. Original failed extra oracle, installed source, output-only reader
allocation failure and failed-wrapper unchanged-guard supplement stay exact.
Genuine CURRENT2fdb original whole accepted12:44:05.074969Z/run37930745755/
artifact11616461807/full1437634B/SHA1d567eccbe08e3a8833dc49fe6766873068e72bda213241a4b3e72213c4cb3bf.
Whole59-testlog/25kills; unchanged original reader all1034 public module/source
guards,3000 native intervals,66 controls/five full VP8 decodes pass;287 reception
inputs unchanged/natural empty/no signals/88797184B. Qualified rounds3/streak2.

KEEP4 five weaknesses: private Unicode refusal/pause/presence; catalog metadata;
physical phone approximation; future engine/content ABI; manual hot-seat privacy.
Worst additional pure corpus:1003 full legal timer games/counts2–8/three modes/
four rounds,17718 legal events/6017 phase anchors/all seven phases/144408 refused
writes/2004 valid private retries/729324 actual view checks.48136 paused and48136
disconnected controls. Frozen source/deadlines/RNG retain identity; owner-only
retry projections exact; all legal replays/final scores exact. Producer natural
closure12:46:28.915189Z/all3843 guards/173887488B<256MiB180s/no signals.
Whole gzip5753708B/SHAa9bcb969e3be8c3b07b8973e516ad47af47817227658afad3d0622b56b66167c.
Separate Python strictUTF16/NFKC refusal/state/retry-hash/projection/seeded whole
EOF reader PASS12:48:35.369198Z/all7 input guards; wrapper natural
12:48:36.267304Z/all3846 guards/15876096B/no signals/no new games/timing.
Permanent independent all-phase refusal/privacy regression added. Local37focused/
four original strict/types/data/two identical fixtures/builds/freshness/checksums/
42 benign3395 states and10000 matching cases PASS12:50:03.287439Z/all3842
guards/no output changes/431173632B<512MiB60sphase bound/natural empty.
Production/reducer/page/catalog/scoring/bots/UI/original10k/workflow/contract
stay byte equal2fdb; previous unexecuted v1 and read-only v2 saved-projection
addition preserved. PR-body script parse failed before mutation; original actual
error retained, corrected only formatting. No failed/unexecuted round counted.

Single-file public delivery: actual HTTP200 whole2fdb HTML EOF12:51:31.614999Z,
495059B/SHA234c7b430308269b610fea599042a9bdaec70f74745a308659da344b9f036a21;
full physical bytes equal accepted standalone file/all5 inputs unchanged/natural
empty/10223616B<64MiB60s. Current new source must also qualify via exact full.
Full official2fdb/current corpus/reader/projections/publicHTML/helpers/oldhandoff
in results/keep4-private-refusals-20261009/proof.zip; all fullCRC/physical reads.

NEXT: changed-head original full workflow/full decoded log/whole genuine official
ZIP, unchanged reader all1034/3000/66/fiveclips, exact new-head public HTML EOF.
KEEP4 measured player gain0 is prospective third no-gain; current completed3/
streak2. Only after genuine new full can completed4/streak3 stop qualify.
Then publish material final qualification/handoff/source proof once, await that
final exact original full, and markPR18Ready; do not create proof-only push loops.
No new native timing retries/gate/corpus/bot/clock changes. G10 remainsBLOCKED.
If final checks fail, preserve actual failures and resolve actual cause; no Ready.
""")
 with (job/'LOOP.md').open('a') as f:f.write("""
KEEP3 qualification | exact2fdb genuine original whole accepted12:44:05.074969Z/run37930745755/full1437634B SHA1d567eccbe08e3a8833dc49fe6766873068e72bda213241a4b3e72213c4cb3bf | verification-only, product unchanged/player gain0 | completed new rounds3/no-gain streak2; failed extra oracle not a round.
4 follow-up | five weaknesses: private Unicode refusals/pause/presence; catalog metadata; physical phone; future ABI; manual concealment | worst: independent all-phase refusal/privacy regression and whole saved-game audit |1003 full games17718 legal events6017 anchors/all7phases/144408 refusals/2004 valid private retries/729324 view assertions/Python EOF hashes/projections equal;37 focused/four strict/all3842 guards pass; public495059B HTML HTTP200 full bytes exact | player gain0, prospective third no-gain until changed-head genuine original full; qualified3/streak2, no native measurement.
""")
 with (job/'VERIFY.md').open('a') as f:f.write("""
## KEEP4 private refusal/pause/presence/retry coverage
All actual commands/specs/helpers/raw/projections/current official2fdb/failures in
results/keep4-private-refusals-20261009/proof.zip, fullCRC/physical comparisons.
Node24 additional1003 fixed seeded full games/counts2–8/three modes:17718 legal
timer events/6017 frozen phase states/all7phases/144408 refusals/2004 private retry
checks/729324 view assertions,48136 paused and48136 disconnected controls.
All replay hashes/results/deadlines/RNG/private projections exact,states3977B peak.
Producer3843 inputs unchanged/natural12:46:28.915189Z/peak173887488B<256MiB180s.
Python strict UTF16/NFKC wholeEOF/state variant+retry hashes/actual TV and own/other
projection reader1003games/allcounts exact12:48:35.369198Z/all7 inputs unchanged;
wrapper3846 guards/natural12:48:36.267304Z/peak15876096B/no signals.
Whole gzip5753708B SHAa9bcb969e3be8c3b07b8973e516ad47af47817227658afad3d0622b56b66167c.
Local37 focused/4 strict/types/data/twofixtures/twobuilds/freshness/checksums/
42 benign3395 states+10000 matching cases PASS12:50:03.287439Z;3842 inputs/no
output changes/peak431173632B<512MiB60s/natural empty. No original sampler altered.
Configured public curl exact2fdb HTML HTTP200/fullEOF/full physical byte equality:
495059B/SHA234c7b430308269b610fea599042a9bdaec70f74745a308659da344b9f036a21,
12:51:31.614999Z/all5 inputs/naturalempty/peak10223616B<64MiB60s/no signals.
Genuine2fdb original full59-tests/25mutants/official1437634B accepted
12:44:05.074969Z/all1034 source/module guards/3000 native intervals/66controls/
five VP8 full decodes/all287 receipt guards. New source requires exact full again.
Earlier unexecuted v1 preserved; v2 adds saved actual projections only. PR-body
JS parse failure before all mutation is retained; corrected string formatting.
Original job/rules remain binding; no local browser/frame/physical-phone claim.
""")
 with (job/'ASSUMPTIONS.md').open('a') as f:f.write("""
## KEEP4 rejected inputs and privacy
Additional deterministic replay seeds are isolated from every original sampler.
Frozen phase-state probes use actual pure reducer events, not browser clocks or
synthetic performance measurements. The live/pause/disconnected variants retain
actual identity/deadlines/RNG on malformed, normalized oversize, raw codepoint
oversize-storage and control-only writes. Accepted retry views are saved in full
for independent Python state-hash/projection checking. Timer-only final scores
zero are a baseline/control, not a bot skill or strategy claim.
Prospective v1 was never executed; v2 only adds output of actual read-only views.
The PR-body script parse error happened before any tool/source/PR mutation and
does not count as a game failure/no-gain. Original raw and earlier failed checks
stay preserved. Completed qualified3/streak2; round4 prospective final third.
The public495059-byte file is actual GitHub HTTP delivery, distinct from decoded
video/runtime checks. Exact new-head full and final qualification are mandatory.
""")
 node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
 run('checksums-write',[node,'checksums.ts'],job);run('checksums-check',[node,'checksums.ts','--check'],job)
 assert [digest(p) for p in stable]==before
 (base/'fixed-inputs-exact.json').write_text(json.dumps({'at':utc(),'allStableInputsByteEqual':True,'rows':before},indent=2)+'\n')
 changes=run('scope-diff',['git','diff','--name-only']).decode().splitlines();assert all(p.startswith('jobs/G04-reality-check/') for p in changes)
 assert headremote()==parent
 run('stage',['git','add','--','jobs/G04-reality-check'])
 staged=run('staged-scope',['git','diff','--cached','--name-only']).decode().splitlines();assert staged and all(p.startswith('jobs/G04-reality-check/') for p in staged)
 run('commit',['git','commit','-m','G04: verify private text refusals through every game phase'])
 newhead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip();assert subprocess.check_output(['git','rev-parse','HEAD^'],cwd=repo).decode().strip()==parent
 assert headremote()==parent
 run('normal-push',['git','push','origin','HEAD:refs/heads/'+branch]);pushed=steps[-1]['closedAt']
 assert headremote()==newhead;readback=utc()
 assert run('clean-status',['git','status','--porcelain'])==b''
 guards=[digest(repo/x.decode()) for x in subprocess.check_output(['git','ls-files','-z','jobs/G04-reality-check','contract','.github/workflows/G04.yml'],cwd=repo).split(b'\0') if x]
 (base/'current-source-guards.json').write_text(json.dumps({'at':utc(),'sourceHead':newhead,'rows':guards},indent=2)+'\n')
 previous=datetime.datetime.fromisoformat('2026-10-09T12:32:40.853633+00:00');actual=datetime.datetime.fromisoformat(pushed);delta=(actual-previous).total_seconds()
 status='CLOSED_PASS'
except BaseException as e:
 (base/'failure.json').write_text(json.dumps({'at':utc(),'error':str(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
finally:
 r={'status':status,'startedAt':started,'closedAt':utc(),'parent':parent,'sourceHead':locals().get('newhead'),'branch':branch,'actualNormalSourcePushClosedAt':locals().get('pushed'),'exactRemoteReadbackClosedAt':locals().get('readback'),'normalExpectedHeadFastForwardOnly':status=='CLOSED_PASS','cadenceIntervalSeconds':locals().get('delta'),'early25TargetPassed':locals().get('delta',99999)<=1500,'hard30LimitPassed':locals().get('delta',99999)<=1800,'hard30LatenessSeconds':max(0,locals().get('delta',1800)-1800),'nextEarly25Utc':(actual+datetime.timedelta(seconds=1500)).isoformat() if 'actual' in locals() else None,'nextHard30Utc':(actual+datetime.timedelta(seconds=1800)).isoformat() if 'actual' in locals() else None,'publicArchive':locals().get('info'),'qualifiedCompletedNewRounds':3,'qualifiedNoGainStreak':2,'round4':'verification-only prospective third no-gain, exact changed-head original full pending','currentFullOriginalAccepted':False,'workingTreeClean':status=='CLOSED_PASS','noLocalNativeTiming':True}
 (base/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');(base/'steps.json').write_text(json.dumps(steps,indent=2)+'\n');print(json.dumps(r),flush=True)
